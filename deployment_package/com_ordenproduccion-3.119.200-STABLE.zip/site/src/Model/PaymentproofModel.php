<?php
/**
 * Payment Proof Model for Com Orden Produccion
 */

namespace Grimpsa\Component\Ordenproduccion\Site\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\ItemModel;
use Grimpsa\Component\Ordenproduccion\Site\Helper\AsistenciaHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\PaymentOrderQueryHelper;
use Grimpsa\Component\Ordenproduccion\Site\Service\ApprovalWorkflowService;

class PaymentproofModel extends ItemModel
{
    /**
     * The prefix to use with controller messages.
     *
     * @var    string
     * @since  3.1.3
     */
    protected $text_prefix = 'COM_ORDENPRODUCCION_PAYMENT_PROOF';

    /**
     * The type alias for this content type.
     *
     * @var    string
     * @since  3.1.3
     */
    public $typeAlias = 'com_ordenproduccion.paymentproof';

    /**
     * Document numbers flagged as duplicates during the last save() call.
     *
     * @var    string[]
     * @since  3.119.87
     */
    protected $duplicateDocumentNumbersOnSave = [];

    /**
     * Document numbers detected as duplicates on the last successful save().
     *
     * @return  string[]
     *
     * @since   3.119.87
     */
    public function getDuplicateDocumentNumbersOnSave(): array
    {
        return $this->duplicateDocumentNumbersOnSave;
    }

    /**
     * Method to get the record form.
     *
     * @param   array    $data      Data for the form.
     * @param   boolean  $loadData  True if the form should load its own data (default case), false if not.
     *
     * @return  \Joomla\CMS\Form\Form|boolean  A Form object on success, false on failure
     *
     * @since   3.1.3
     */
    public function getForm($data = [], $loadData = true)
    {
        // Get the form.
        $form = $this->loadForm('com_ordenproduccion.paymentproof', 'paymentproof', ['control' => 'jform', 'load_data' => $loadData]);

        if (empty($form)) {
            return false;
        }

        return $form;
    }

    /**
     * Method to populate the state.
     *
     * @param   string  $ordering   An optional ordering field.
     * @param   string  $direction  An optional direction (asc|desc).
     *
     * @return  void
     *
     * @since   3.1.3
     */
    protected function populateState($ordering = null, $direction = null)
    {
        $app = Factory::getApplication();
        
        // Load the parameters.
        $params = $app->getParams();
        $this->setState('params', $params);

        // Load state from the request.
        $id = $app->input->getInt('id', 0);
        $this->setState('paymentproof.id', $id);
    }

    /**
     * Method to get a single record.
     *
     * @param   integer  $pk  The id of the primary key.
     *
     * @return  mixed  Object on success, false on failure.
     *
     * @since   3.1.3
     */
    public function getItem($pk = null)
    {
        $pk = (!empty($pk)) ? $pk : (int) $this->getState('paymentproof.id');

        if ($this->_item === null) {
            $this->_item = [];
        }

        if (!isset($this->_item[$pk])) {
            try {
                $db = $this->getDatabase();
                $query = $db->getQuery(true)
                    ->select('*')
                    ->from($db->quoteName('#__ordenproduccion_payment_proofs'))
                    ->where($db->quoteName('id') . ' = ' . (int) $pk)
                    ->where($db->quoteName('state') . ' = 1');

                $db->setQuery($query);
                $data = $db->loadObject();

                if (empty($data)) {
                    $this->setError(Text::_('COM_ORDENPRODUCCION_ERROR_PAYMENT_PROOF_NOT_FOUND'));
                    return false;
                }

                $this->_item[$pk] = $data;
            } catch (\Exception $e) {
                $this->setError($e->getMessage());
                return false;
            }
        }

        return $this->_item[$pk];
    }

    /**
     * Method to save payment proof data
     * Uses junction table for many-to-many: multiple payments per order, multiple orders per payment.
     * Supports multiple payment method lines (3.64.0+): cheque + nota crédito fiscal, etc.
     *
     * @param   array  $data  The form data. May include payment_lines (array of {payment_type, bank, document_number, document_date, amount}).
     *
     * @return  boolean  True on success, false on failure.
     *
     * @since   3.1.3
     */
    public function save($data)
    {
        // Once saved, payment proofs cannot be modified—only deleted (from Control de Pagos).
        if (!empty($data['id']) && (int) $data['id'] > 0) {
            $this->setError(Text::_('COM_ORDENPRODUCCION_PAYMENT_PROOF_CANNOT_EDIT'));
            return false;
        }

        try {
            $db = $this->getDatabase();
            $this->duplicateDocumentNumbersOnSave = [];

            // Build payment_lines from data (new multi-line or legacy single-line)
            $paymentLines = $this->normalizePaymentLines($data);
            if (empty($paymentLines)) {
                $this->setError(Text::_('COM_ORDENPRODUCCION_ERROR_MISSING_REQUIRED_FIELDS'));
                return false;
            }

            $paymenttypeModel = null;
            try {
                $component = Factory::getApplication()->bootComponent('com_ordenproduccion');
                $paymenttypeModel = $component->getMVCFactory()->createModel('Paymenttype', 'Site', ['ignore_request' => true]);
            } catch (\Throwable $e) {
                $paymenttypeModel = null;
            }
            if ($paymenttypeModel && method_exists($paymenttypeModel, 'isPaymentTypeAllowedForUser')) {
                foreach ($paymentLines as $line) {
                    $type = trim((string) ($line['payment_type'] ?? ''));
                    if ($type !== '' && !$paymenttypeModel->isPaymentTypeAllowedForUser($type)) {
                        $this->setError(Text::_('COM_ORDENPRODUCCION_PAYMENT_TYPE_SUPER_USER_ONLY_DENIED'));
                        return false;
                    }
                }
            }

            // Flag duplicate combinations (payment_type + bank + document_number) but allow save.
            foreach ($paymentLines as $line) {
                $type = trim((string) ($line['payment_type'] ?? ''));
                $bank = trim((string) ($line['bank'] ?? ''));
                $doc = trim((string) ($line['document_number'] ?? ''));
                $baId = (int) ($line['bank_account_id'] ?? 0);
                if ($type !== '' && $doc !== '' && $this->documentCombinationExists($type, $bank, $doc, $baId)) {
                    $this->duplicateDocumentNumbersOnSave[] = $doc;
                }
            }
            $this->duplicateDocumentNumbersOnSave = array_values(array_unique($this->duplicateDocumentNumbersOnSave));
            $paymentAmount = 0;
            foreach ($paymentLines as $line) {
                $paymentAmount += (float) ($line['amount'] ?? 0);
            }
            if ($paymentAmount <= 0) {
                $this->setError(Text::_('COM_ORDENPRODUCCION_ERROR_MISSING_REQUIRED_FIELDS'));
                return false;
            }
            $firstLine = $paymentLines[0] ?? null;
            $paymentType = $firstLine['payment_type'] ?? ($data['payment_type'] ?? 'efectivo');
            $bank = $firstLine['bank'] ?? ($data['bank'] ?? '');
            $documentNumber = $firstLine['document_number'] ?? ($data['document_number'] ?? '');
            
            // Start transaction
            $db->transactionStart();
            
            $primaryOrderId = !empty($data['payment_orders'][0]['order_id']) 
                ? (int) $data['payment_orders'][0]['order_id'] 
                : 0;
            
            // Insert new payment proof record
            $query = $db->getQuery(true);
            $columns = [
                'order_id',
                'payment_type',
                'bank',
                'document_number',
                'payment_amount',
                'file_path',
                'created_by',
                'created',
                'state'
            ];
            $values = [
                $primaryOrderId > 0 ? $primaryOrderId : 'NULL',
                $db->quote($paymentType),
                $db->quote($bank),
                $db->quote($documentNumber),
                (float) $paymentAmount,
                $db->quote($data['file_path'] ?? ''),
                (int) ($data['created_by'] ?? 0),
                $db->quote($data['created'] ?? Factory::getDate()->toSql()),
                (int) ($data['state'] ?? 1)
            ];
            $ppCols = $db->getTableColumns('#__ordenproduccion_payment_proofs', false);
            $ppCols = is_array($ppCols) ? array_change_key_case($ppCols, CASE_LOWER) : [];
            if (isset($ppCols['mismatch_note'])) {
                $columns[] = 'mismatch_note';
                $values[] = $db->quote(trim((string) ($data['mismatch_note'] ?? '')));
            }
            if (isset($ppCols['mismatch_difference'])) {
                $columns[] = 'mismatch_difference';
                $values[] = $db->quote(trim((string) ($data['mismatch_difference'] ?? '')));
            }
            if (isset($ppCols['verification_status'])) {
                $columns[] = 'verification_status';
                $values[] = $db->quote('ingresado');
            }
            $query->insert($db->quoteName('#__ordenproduccion_payment_proofs'))
                  ->columns($db->quoteName($columns))
                  ->values(implode(',', $values));
            
            $db->setQuery($query);
            $db->execute();
            
            $paymentProofId = $db->insertid();

            $lineFilePaths = $data['line_file_paths'] ?? null;
            if (!is_array($lineFilePaths) && !empty($data['file_paths']) && is_array($data['file_paths'])) {
                $lineFilePaths = [0 => $data['file_paths']];
            }

            // Insert payment_proof_lines if table exists (3.64.0+); attach files in the same pass so
            // payment_proof_line_id always matches the line we just inserted (same index as buildLineFilePathsForRegister).
            if ($this->hasPaymentProofLinesTable() && !empty($paymentLines)) {
                $pplCols = $db->getTableColumns('#__ordenproduccion_payment_proof_lines', false);
                $pplCols = is_array($pplCols) ? array_change_key_case($pplCols, CASE_LOWER) : [];
                $hasDocumentDate = isset($pplCols['document_date']);
                $hasBankAccountId = isset($pplCols['bank_account_id']);
                $ordering     = 0;
                $lineFileIdx  = 0;
                $createdBy    = (int) ($data['created_by'] ?? 0);
                $hasLineCol   = $this->hasPaymentProofFileLineIdColumn();
                foreach ($paymentLines as $line) {
                    $amt = (float) ($line['amount'] ?? 0);
                    $columns = ['payment_proof_id', 'payment_type', 'bank', 'document_number', 'amount', 'ordering'];
                    $values = (int) $paymentProofId . ',' .
                        $db->quote($line['payment_type'] ?? 'efectivo') . ',' .
                        $db->quote($line['bank'] ?? '') . ',' .
                        $db->quote($line['document_number'] ?? '') . ',' .
                        $amt . ',' .
                        $ordering++;
                    if ($hasDocumentDate) {
                        $docDate = trim($line['document_date'] ?? '');
                        $columns[] = 'document_date';
                        $values .= ',' . ($docDate !== '' ? $db->quote($docDate) : 'NULL');
                    }
                    if ($hasBankAccountId) {
                        $columns[] = 'bank_account_id';
                        $baIns = (int) ($line['bank_account_id'] ?? 0);
                        $values .= ',' . ($baIns > 0 ? (string) $baIns : 'NULL');
                    }
                    $insertLine = $db->getQuery(true)
                        ->insert($db->quoteName('#__ordenproduccion_payment_proof_lines'))
                        ->columns($db->quoteName($columns))
                        ->values($values);
                    $db->setQuery($insertLine);
                    $db->execute();
                    $newLineId = (int) $db->insertid();

                    if ($this->hasPaymentProofFilesTable() && is_array($lineFilePaths)) {
                        $paths = $lineFilePaths[$lineFileIdx] ?? [];
                        $lineFileIdx++;
                        if (is_array($paths)) {
                            foreach ($paths as $fp) {
                                $fp = trim((string) $fp);
                                if ($fp === '') {
                                    continue;
                                }
                                $lineFk = ($hasLineCol && $newLineId > 0) ? $newLineId : null;
                                $this->addFileToProof((int) $paymentProofId, $fp, $createdBy, $lineFk);
                            }
                        }
                    }
                }
            } elseif ($this->hasPaymentProofFilesTable() && is_array($lineFilePaths)) {
                // No payment_proof_lines table: legacy proof-level files only (no line FK).
                $createdBy = (int) ($data['created_by'] ?? 0);
                foreach ($lineFilePaths as $paths) {
                    if (!is_array($paths)) {
                        continue;
                    }
                    foreach ($paths as $fp) {
                        $fp = trim((string) $fp);
                        if ($fp === '') {
                            continue;
                        }
                        $this->addFileToProof((int) $paymentProofId, $fp, $createdBy, null);
                    }
                }
            }
            
            if ($this->hasPaymentOrdersTable()) {
                // Insert into junction table (payment_orders) for each order (one row per order per proof — UNIQUE)
                if (!empty($data['payment_orders']) && is_array($data['payment_orders'])) {
                    $mergedOrders = $this->mergePaymentOrdersForJunction($data['payment_orders']);
                    foreach ($mergedOrders as $paymentOrder) {
                        $orderId = (int) ($paymentOrder['order_id'] ?? 0);
                        $amountApplied = (float) ($paymentOrder['value'] ?? 0);

                        if ($orderId > 0 && $amountApplied > 0) {
                            $insertQuery = $db->getQuery(true);
                            $insertQuery->insert($db->quoteName('#__ordenproduccion_payment_orders'))
                                ->columns($db->quoteName(['payment_proof_id', 'order_id', 'amount_applied', 'created', 'created_by']))
                                ->values(
                                    (int) $paymentProofId . ',' .
                                    $orderId . ',' .
                                    $amountApplied . ',' .
                                    $db->quote($data['created']) . ',' .
                                    (int) $data['created_by']
                                );
                            $db->setQuery($insertQuery);
                            $db->execute();
                        }
                    }
                }
            } else {
                // Legacy: update ordenes with payment_proof_id and payment_value for first order (if columns exist)
                $first = $data['payment_orders'][0] ?? null;
                if ($first && (int) ($first['order_id'] ?? 0) > 0 && $this->ordenesHasPaymentColumns($db)) {
                    try {
                        $orderId = (int) $first['order_id'];
                        $amountApplied = (float) ($first['value'] ?? 0);
                        $updateQuery = $db->getQuery(true)
                            ->update($db->quoteName('#__ordenproduccion_ordenes'))
                            ->set($db->quoteName('payment_proof_id') . ' = ' . (int) $paymentProofId)
                            ->set($db->quoteName('payment_value') . ' = ' . (float) $amountApplied)
                            ->where($db->quoteName('id') . ' = ' . $orderId);
                        $db->setQuery($updateQuery);
                        $db->execute();
                    } catch (\Throwable $e) {
                        // Columns may have been removed by migration; payment_proof is still saved
                    }
                }
            }
            
            $db->transactionCommit();

            // Optional: start approval workflow when a new proof is recorded (3.109.72+).
            try {
                if ((int) ComponentHelper::getParams('com_ordenproduccion')->get('approval_workflow_payment_proof', 0) === 1) {
                    $wfSvc       = new ApprovalWorkflowService();
                    $submitterId = (int) ($data['created_by'] ?? 0);
                    if ($wfSvc->hasSchema() && $submitterId > 0) {
                        $wfSvc->createRequest(
                            ApprovalWorkflowService::ENTITY_PAYMENT_PROOF,
                            (int) $paymentProofId,
                            $submitterId,
                            null
                        );
                    }
                }
            } catch (\Throwable $e) {
                // Non-fatal: proof is already saved
            }

            // Update client Saldo immediately (3.64.0)
            try {
                $adminModel = Factory::getApplication()->bootComponent('com_ordenproduccion')
                    ->getMVCFactory()->createModel('Administracion', 'Site', ['ignore_request' => true]);
                if ($adminModel && method_exists($adminModel, 'refreshClientBalances')) {
                    $adminModel->refreshClientBalances();
                }
            } catch (\Throwable $e) {
                // Non-fatal: Saldo will update on next clientes view load
            }

            return (int) $paymentProofId;
            
        } catch (\Exception $e) {
            if (isset($db)) {
                $db->transactionRollback();
            }
            $msg = $e->getMessage();
            if (stripos($msg, 'Duplicate entry') !== false && stripos($msg, 'idx_payment_order') !== false) {
                $this->setError(Text::_('COM_ORDENPRODUCCION_PAYMENT_ORDERS_JUNCTION_DUPLICATE'));
            } else {
                $this->setError($msg);
            }
            return false;
        }
    }

    /**
     * Merge duplicate order_id entries in payment_orders POST data.
     * idx_payment_order is UNIQUE(payment_proof_id, order_id); duplicate rows in the
     * form (e.g. JS template + hidden row) caused "Duplicate entry 'N-M' for key idx_payment_order".
     *
     * @param   array  $paymentOrders  Rows with order_id and value (amount)
     *
     * @return  array  List of ['order_id' => int, 'value' => float] one per order
     *
     * @since   3.99.0
     */
    protected function mergePaymentOrdersForJunction(array $paymentOrders)
    {
        $byOrder = [];
        foreach ($paymentOrders as $paymentOrder) {
            $orderId = (int) ($paymentOrder['order_id'] ?? 0);
            $amountApplied = (float) ($paymentOrder['value'] ?? 0);
            if ($orderId <= 0 || $amountApplied <= 0) {
                continue;
            }
            if (!isset($byOrder[$orderId])) {
                $byOrder[$orderId] = ['order_id' => $orderId, 'value' => 0.0];
            }
            $byOrder[$orderId]['value'] += $amountApplied;
        }
        return array_values($byOrder);
    }

    /**
     * Normalize payment lines from form data (multi-line or legacy single-line)
     *
     * @param   array  $data  Form data
     *
     * @return  array  Array of {payment_type, bank, document_number, amount}
     */
    protected function normalizePaymentLines($data)
    {
        $lines = [];
        if (!empty($data['payment_lines']) && is_array($data['payment_lines'])) {
            foreach ($data['payment_lines'] as $line) {
                $amount = (float) ($line['amount'] ?? 0);
                $type   = trim((string) ($line['payment_type'] ?? ''));
                $doc    = trim((string) ($line['document_number'] ?? ''));
                // Same rules as PaymentproofController::register() and buildLineFilePathsForRegister()
                if ($amount <= 0 || $type === '' || $doc === '') {
                    continue;
                }
                $lines[] = [
                    'payment_type' => $type,
                    'bank' => $line['bank'] ?? '',
                    'bank_account_id' => max(0, (int) ($line['bank_account_id'] ?? 0)),
                    'document_number' => $doc,
                    'document_date' => trim($line['document_date'] ?? ''),
                    'amount' => $amount
                ];
            }
        }
        if (empty($lines) && !empty($data['payment_type']) && !empty($data['document_number'])) {
            $amt = (float) ($data['payment_amount'] ?? 0);
            if ($amt > 0) {
                $lines[] = [
                    'payment_type' => $data['payment_type'],
                    'bank' => $data['bank'] ?? '',
                    'bank_account_id' => max(0, (int) ($data['bank_account_id'] ?? 0)),
                    'document_number' => trim($data['document_number']),
                    'document_date' => trim($data['document_date'] ?? ''),
                    'amount' => $amt
                ];
            }
        }
        return $lines;
    }

    /**
     * Check if the combination (payment_type, bank, document_number) already exists in payment_proofs or payment_proof_lines.
     * Only considers non-deleted records (state = 1); deleted payment proofs are ignored so the same document can be reused.
     *
     * @param   string  $paymentType      Payment type (e.g. transferencia, cheque)
     * @param   string  $bank             Bank code/name (can be empty)
     * @param   string  $documentNumber   Document number (e.g. cheque number, reference)
     * @param   int     $bankAccountId    Company bank account row id (0 = none / legacy)
     *
     * @return  bool  True if a record with this combination already exists (active proofs only)
     */
    protected function documentCombinationExists($paymentType, $bank, $documentNumber, $bankAccountId = 0)
    {
        $db = $this->getDatabase();
        $type = trim($paymentType);
        $bankVal = trim($bank);
        $doc = trim($documentNumber);
        $baId = (int) $bankAccountId;
        if ($type === '' || $doc === '') {
            return false;
        }
        $bankNorm = $bankVal === '' ? '' : $bankVal;
        // Check payment_proofs (legacy/single-line proofs) – only state = 1 (exclude deleted)
        $q = $db->getQuery(true)
            ->select('1')
            ->from($db->quoteName('#__ordenproduccion_payment_proofs'))
            ->where($db->quoteName('payment_type') . ' = ' . $db->quote($type))
            ->where($db->quoteName('document_number') . ' = ' . $db->quote($doc))
            ->where($db->quoteName('state') . ' = 1')
            ->where('(COALESCE(' . $db->quoteName('bank') . ', \'\') = ' . $db->quote($bankNorm) . ')');
        $db->setQuery($q);
        if ($db->loadResult()) {
            return true;
        }
        // Check payment_proof_lines (multi-line proofs) – only proofs with state = 1 (exclude deleted)
        if ($this->hasPaymentProofLinesTable()) {
            $q2 = $db->getQuery(true)
                ->select('1')
                ->from($db->quoteName('#__ordenproduccion_payment_proof_lines', 'ppl'))
                ->innerJoin(
                    $db->quoteName('#__ordenproduccion_payment_proofs', 'pp') . ' ON pp.id = ppl.payment_proof_id AND pp.state = 1'
                )
                ->where('ppl.' . $db->quoteName('payment_type') . ' = ' . $db->quote($type))
                ->where('ppl.' . $db->quoteName('document_number') . ' = ' . $db->quote($doc));
            if ($this->paymentProofLinesHasBankAccountIdColumn()) {
                if ($baId > 0) {
                    $q2->where('COALESCE(ppl.' . $db->quoteName('bank_account_id') . ', 0) = ' . $baId);
                } else {
                    $q2->where('COALESCE(ppl.' . $db->quoteName('bank_account_id') . ', 0) = 0')
                        ->where('(COALESCE(ppl.' . $db->quoteName('bank') . ', \'\') = ' . $db->quote($bankNorm) . ')');
                }
            } else {
                $q2->where('(COALESCE(ppl.' . $db->quoteName('bank') . ', \'\') = ' . $db->quote($bankNorm) . ')');
            }
            $db->setQuery($q2);
            if ($db->loadResult()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Whether payment_proof_lines has bank_account_id (3.118.2+).
     *
     * @return  bool
     *
     * @since   3.118.2
     */
    protected function paymentProofLinesHasBankAccountIdColumn(): bool
    {
        static $has = null;
        if ($has !== null) {
            return $has;
        }
        if (!$this->hasPaymentProofLinesTable()) {
            $has = false;

            return false;
        }
        $cols = $this->getDatabase()->getTableColumns('#__ordenproduccion_payment_proof_lines', false);
        $cols = is_array($cols) ? array_change_key_case($cols, CASE_LOWER) : [];
        $has = isset($cols['bank_account_id']);

        return $has;
    }

    /**
     * Get payment proofs for a specific order (via junction table - many-to-many)
     *
     * @param   integer  $orderId  The order ID
     *
     * @return  array  Array of objects with payment proof data + amount_applied for this order
     *
     * @since   3.1.3
     */
    public function getPaymentProofsByOrderId($orderId)
    {
        try {
            $db = $this->getDatabase();
            if (!$this->hasPaymentOrdersTable()) {
                return $this->getPaymentProofsByOrderIdLegacy($orderId);
            }
            $query = $db->getQuery(true)
                ->select([
                    'pp.*',
                    'po.' . $db->quoteName('amount_applied')
                ])
                ->from($db->quoteName('#__ordenproduccion_payment_orders', 'po'))
                ->innerJoin(
                    $db->quoteName('#__ordenproduccion_payment_proofs', 'pp') . ' ON pp.id = po.payment_proof_id'
                )
                ->where('po.' . $db->quoteName('order_id') . ' = ' . (int) $orderId)
                ->where('pp.' . $db->quoteName('state') . ' = 1')
                ->order('pp.' . $db->quoteName('created') . ' DESC');

            $db->setQuery($query);
            $rows = $db->loadObjectList();
            // Deduplicate by payment proof id (same proof can appear multiple times if payment_orders has duplicate rows)
            $byId = [];
            foreach ($rows as $row) {
                $id = (int) ($row->id ?? 0);
                if ($id <= 0) {
                    continue;
                }
                if (!isset($byId[$id])) {
                    $byId[$id] = clone $row;
                } else {
                    $byId[$id]->amount_applied = (float) ($byId[$id]->amount_applied ?? 0) + (float) ($row->amount_applied ?? 0);
                }
            }
            $result = array_values($byId);
            usort($result, function ($a, $b) {
                $t1 = strtotime($a->created ?? '');
                $t2 = strtotime($b->created ?? '');
                return $t2 - $t1;
            });
            return $result;
            
        } catch (\Throwable $e) {
            $this->setError($e->getMessage());
            return $this->getPaymentProofsByOrderIdLegacy($orderId);
        }
    }

    /**
     * Check if ordenes table still has payment_proof_id column (pre-3.54.0 schema)
     */
    protected function ordenesHasPaymentColumns($db)
    {
        try {
            $prefix = $db->getPrefix();
            $tableName = $prefix . 'ordenproduccion_ordenes';
            $db->setQuery(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS " .
                "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = " . $db->quote($tableName) . " " .
                "AND COLUMN_NAME = 'payment_proof_id'"
            );
            return (int) $db->loadResult() > 0;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Check if payment_orders junction table exists (3.54.0+ schema)
     */
    protected function hasPaymentOrdersTable()
    {
        try {
            $db = $this->getDatabase();
            $tables = $db->getTableList();
            $prefix = $db->getPrefix();
            $tableName = $prefix . 'ordenproduccion_payment_orders';
            foreach ($tables as $t) {
                if (strcasecmp($t, $tableName) === 0) {
                    return true;
                }
            }
            return false;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Legacy fallback: get payment proofs when junction table does not exist (pre-3.54.0)
     */
    protected function getPaymentProofsByOrderIdLegacy($orderId)
    {
        try {
            $db = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select('pp.*')
                ->from($db->quoteName('#__ordenproduccion_payment_proofs', 'pp'))
                ->where('pp.' . $db->quoteName('order_id') . ' = ' . (int) $orderId)
                ->where('pp.' . $db->quoteName('state') . ' = 1')
                ->order('pp.' . $db->quoteName('created') . ' DESC');
            $db->setQuery($query);
            $rows = $db->loadObjectList();
            foreach ($rows as $row) {
                $row->amount_applied = $row->payment_amount ?? 0;
            }
            return $rows;
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * Amount credited to a work order from one proof row (junction amount_applied, or payment_amount fallback).
     *
     * @param   object  $proof  Payment proof row (may include amount_applied from junction)
     *
     * @return  float
     *
     * @since   3.119.99
     */
    public function getEffectiveAmountAppliedToOrder($proof): float
    {
        $applied = (float) ($proof->amount_applied ?? 0);
        $paymentAmount = (float) ($proof->payment_amount ?? 0);

        if ($applied > 0) {
            return ($paymentAmount > 0 && $applied > $paymentAmount) ? $paymentAmount : $applied;
        }

        $proofId = (int) ($proof->id ?? 0);
        if ($proofId <= 0 || !$this->hasPaymentOrdersTable()) {
            return $paymentAmount;
        }

        $linked = $this->getOrdersByPaymentProofId($proofId);

        return count($linked) <= 1 ? $paymentAmount : 0.0;
    }

    /**
     * Get total amount paid for a specific order (sum of amount_applied from all payment proofs)
     *
     * @param   integer  $orderId  The order ID
     *
     * @return  float  Total paid amount
     *
     * @since   3.54.0
     */
    public function getTotalPaidByOrderId($orderId)
    {
        try {
            if (!$this->hasPaymentOrdersTable()) {
                return $this->getTotalPaidByOrderIdLegacy($orderId);
            }
            $db = $this->getDatabase();
            $ppCols = $db->getTableColumns('#__ordenproduccion_payment_proofs', false);
            $ppCols = is_array($ppCols) ? array_change_key_case($ppCols, CASE_LOWER) : [];
            $verifiedCondition = isset($ppCols['verification_status'])
                ? " AND pp.verification_status = 'verificado'"
                : '';
            $effective = PaymentOrderQueryHelper::effectiveAppliedAmountExpr($db);
            $query = $db->getQuery(true)
                ->select('COALESCE(SUM(' . $effective . '), 0)')
                ->from($db->quoteName('#__ordenproduccion_payment_orders', 'po'))
                ->innerJoin(
                    $db->quoteName('#__ordenproduccion_payment_proofs', 'pp') . ' ON pp.id = po.payment_proof_id AND pp.state = 1' . $verifiedCondition
                )
                ->where('po.' . $db->quoteName('order_id') . ' = ' . (int) $orderId);

            $db->setQuery($query);
            $junctionTotal = (float) $db->loadResult();

            $legacyQuery = $db->getQuery(true)
                ->select('COALESCE(SUM(pp.' . $db->quoteName('payment_amount') . '), 0)')
                ->from($db->quoteName('#__ordenproduccion_payment_proofs', 'pp'))
                ->where('pp.' . $db->quoteName('order_id') . ' = ' . (int) $orderId)
                ->where('pp.' . $db->quoteName('state') . ' = 1')
                ->where('NOT EXISTS (SELECT 1 FROM ' . $db->quoteName('#__ordenproduccion_payment_orders', 'po_x')
                    . ' WHERE po_x.' . $db->quoteName('payment_proof_id') . ' = pp.' . $db->quoteName('id') . ')');
            if ($verifiedCondition !== '') {
                $legacyQuery->where("pp.verification_status = 'verificado'");
            }
            $db->setQuery($legacyQuery);

            return $junctionTotal + (float) $db->loadResult();
            
        } catch (\Throwable $e) {
            return $this->getTotalPaidByOrderIdLegacy($orderId);
        }
    }

    protected function getTotalPaidByOrderIdLegacy($orderId)
    {
        try {
            $db = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select('COALESCE(SUM(pp.payment_amount), 0)')
                ->from($db->quoteName('#__ordenproduccion_payment_proofs', 'pp'))
                ->where('pp.' . $db->quoteName('order_id') . ' = ' . (int) $orderId)
                ->where('pp.' . $db->quoteName('state') . ' = 1');
            $ppCols = $db->getTableColumns('#__ordenproduccion_payment_proofs', false);
            $ppCols = is_array($ppCols) ? array_change_key_case($ppCols, CASE_LOWER) : [];
            if (isset($ppCols['verification_status'])) {
                $query->where("pp.verification_status = 'verificado'");
            }
            $db->setQuery($query);
            return (float) $db->loadResult();
        } catch (\Throwable $e) {
            return 0.0;
        }
    }

    /**
     * Get payment lines for a proof (3.64.0+)
     *
     * @param   int  $paymentProofId  Payment proof ID
     *
     * @return  array
     */
    public function getPaymentProofLines($paymentProofId)
    {
        if (!$this->hasPaymentProofLinesTable()) {
            return [];
        }
        try {
            $db = $this->getDatabase();
            $db->setQuery(
                $db->getQuery(true)
                    ->select('*')
                    ->from($db->quoteName('#__ordenproduccion_payment_proof_lines'))
                    ->where($db->quoteName('payment_proof_id') . ' = ' . (int) $paymentProofId)
                    ->order($db->quoteName('ordering') . ' ASC, id ASC')
            );
            return $db->loadObjectList() ?: [];
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * Get orders linked to a payment proof
     *
     * @param   integer  $paymentProofId  The payment proof ID
     *
     * @return  array  Array of objects with order_id, amount_applied, order_number
     *
     * @since   3.54.0
     */
    public function getOrdersByPaymentProofId($paymentProofId)
    {
        try {
            $db = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select([
                    'po.order_id',
                    'po.amount_applied',
                    'o.order_number',
                    'o.client_name',
                    'o.invoice_value',
                    'o.request_date'
                ])
                ->from($db->quoteName('#__ordenproduccion_payment_orders', 'po'))
                ->innerJoin(
                    $db->quoteName('#__ordenproduccion_ordenes', 'o') . ' ON o.id = po.order_id'
                )
                ->where('po.' . $db->quoteName('payment_proof_id') . ' = ' . (int) $paymentProofId)
                ->where('o.' . $db->quoteName('state') . ' = 1');

            $db->setQuery($query);
            return $db->loadObjectList();

        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Get orders that can be associated to this payment proof (for "associate another order" dropdown).
     * Only returns orders from the same client as the orders already linked to this proof,
     * and that do not have any payment proof associated yet.
     *
     * @param   integer  $paymentProofId  The payment proof ID
     * @param   integer  $limit            Max number of orders to return (default 150)
     *
     * @return  array  Array of objects with id, order_number, client_name, invoice_value
     *
     * @since   3.83.0
     */
    public function getOrdersNotLinkedToProof($paymentProofId, $limit = 150)
    {
        $paymentProofId = (int) $paymentProofId;
        if ($paymentProofId <= 0) {
            return [];
        }
        try {
            $db = $this->getDatabase();
            $linkedOrders = $this->getOrdersByPaymentProofId($paymentProofId);
            $clientNames = [];
            foreach ($linkedOrders as $lo) {
                $name = trim((string) ($lo->client_name ?? $lo->nombre_del_cliente ?? ''));
                if ($name !== '' && !in_array($name, $clientNames, true)) {
                    $clientNames[] = $name;
                }
            }
            if (empty($clientNames)) {
                return [];
            }
            $orderCols = $db->getTableColumns('#__ordenproduccion_ordenes', false);
            $orderCols = is_array($orderCols) ? array_change_key_case($orderCols, CASE_LOWER) : [];
            $hasClientName = isset($orderCols['client_name']);
            $clientCol = $hasClientName ? 'o.client_name' : 'o.nombre_del_cliente';
            $quotedNames = array_map(function ($n) use ($db) {
                return $db->quote($n);
            }, $clientNames);
            $clientCondition = $db->quoteName($clientCol) . ' IN (' . implode(',', $quotedNames) . ')';
            $subThisProof = $db->getQuery(true)
                ->select('po.order_id')
                ->from($db->quoteName('#__ordenproduccion_payment_orders', 'po'))
                ->where('po.' . $db->quoteName('payment_proof_id') . ' = ' . $paymentProofId);
            $subAnyProof = $db->getQuery(true)
                ->select('order_id')
                ->from($db->quoteName('#__ordenproduccion_payment_orders'));
            $selectCols = ['o.id', 'o.order_number', 'o.invoice_value'];
            $selectCols[] = $hasClientName ? 'o.client_name' : 'o.nombre_del_cliente AS client_name';
            $query = $db->getQuery(true)
                ->select($selectCols)
                ->from($db->quoteName('#__ordenproduccion_ordenes', 'o'))
                ->where('o.' . $db->quoteName('state') . ' = 1')
                ->where('o.id NOT IN (' . (string) $subThisProof . ')')
                ->where('o.id NOT IN (' . (string) $subAnyProof . ')')
                ->where($clientCondition)
                ->order('o.id DESC')
                ->setLimit((int) $limit);
            $db->setQuery($query);
            return $db->loadObjectList() ?: [];
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Update mismatch note (and optional difference) for an existing payment proof.
     *
     * @param   integer  $proofId    Payment proof ID
     * @param   string   $note      Mismatch note text
     * @param   string   $difference  Optional difference amount at save time
     *
     * @return  boolean
     *
     * @since   3.83.0
     */
    public function updateMismatchNote($proofId, $note, $difference = null)
    {
        if ((int) $proofId <= 0) {
            return false;
        }
        try {
            $db = $this->getDatabase();
            $cols = $db->getTableColumns('#__ordenproduccion_payment_proofs', false);
            if (!isset($cols['mismatch_note'])) {
                return false;
            }
            $note = trim((string) $note);
            $updates = [$db->quoteName('mismatch_note') . ' = ' . $db->quote($note)];
            if (isset($cols['mismatch_difference'])) {
                $difference = $difference !== null ? trim((string) $difference) : '';
                $updates[] = $db->quoteName('mismatch_difference') . ' = ' . $db->quote($difference);
            }
            $query = $db->getQuery(true)
                ->update($db->quoteName('#__ordenproduccion_payment_proofs'))
                ->set($updates)
                ->where($db->quoteName('id') . ' = ' . (int) $proofId)
                ->where($db->quoteName('state') . ' = 1');
            $db->setQuery($query);
            $db->execute();
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Super User: update one payment line amount and recalculate proof totals / mismatch.
     *
     * @param   int    $lineId     payment_proof_lines.id
     * @param   float  $newAmount  New line amount (> 0)
     *
     * @return  bool
     *
     * @since   3.119.119
     */
    public function updatePaymentProofLineAmountSuperUser(int $lineId, float $newAmount): bool
    {
        $lineId = (int) $lineId;
        $newAmount = round((float) $newAmount, 2);

        if ($lineId < 1 || $newAmount <= 0) {
            $this->setError(Text::_('COM_ORDENPRODUCCION_PAYMENT_PROOF_LINE_AMOUNT_INVALID'));
            return false;
        }

        if (!$this->hasPaymentProofLinesTable()) {
            $this->setError(Text::_('COM_ORDENPRODUCCION_PAYMENT_PROOF_LINE_AMOUNT_NO_LINES'));
            return false;
        }

        try {
            $db = $this->getDatabase();
            $db->transactionStart();

            $db->setQuery(
                $db->getQuery(true)
                    ->select('*')
                    ->from($db->quoteName('#__ordenproduccion_payment_proof_lines'))
                    ->where($db->quoteName('id') . ' = ' . $lineId)
            );
            $line = $db->loadObject();
            if (!$line) {
                throw new \RuntimeException('line');
            }

            $proofId = (int) ($line->payment_proof_id ?? 0);
            if ($proofId < 1 || !$this->getItem($proofId)) {
                throw new \RuntimeException('proof');
            }

            $db->setQuery(
                $db->getQuery(true)
                    ->update($db->quoteName('#__ordenproduccion_payment_proof_lines'))
                    ->set($db->quoteName('amount') . ' = ' . $newAmount)
                    ->where($db->quoteName('id') . ' = ' . $lineId)
            );
            $db->execute();

            if (!$this->recalculateProofAmountAndMismatch($proofId)) {
                throw new \RuntimeException('recalc');
            }

            $db->transactionCommit();
            $this->refreshClientBalancesAfterProofChange();

            return true;
        } catch (\Throwable $e) {
            try {
                $db->transactionRollback();
            } catch (\Throwable $ignored) {
            }
            if (!$this->getError()) {
                $this->setError(Text::_('COM_ORDENPRODUCCION_PAYMENT_PROOF_LINE_AMOUNT_SAVE_FAILED'));
            }

            return false;
        }
    }

    /**
     * Super User: update legacy proof amount (no payment_proof_lines).
     *
     * @param   int    $proofId
     * @param   float  $newAmount
     *
     * @return  bool
     *
     * @since   3.119.119
     */
    public function updatePaymentProofAmountSuperUser(int $proofId, float $newAmount): bool
    {
        $proofId = (int) $proofId;
        $newAmount = round((float) $newAmount, 2);

        if ($proofId < 1 || $newAmount <= 0 || !$this->getItem($proofId)) {
            $this->setError(Text::_('COM_ORDENPRODUCCION_PAYMENT_PROOF_LINE_AMOUNT_INVALID'));
            return false;
        }

        if ($this->hasPaymentProofLinesTable()) {
            $lines = $this->getPaymentProofLines($proofId);
            if (!empty($lines)) {
                $this->setError(Text::_('COM_ORDENPRODUCCION_PAYMENT_PROOF_LINE_AMOUNT_USE_LINES'));
                return false;
            }
        }

        try {
            $db = $this->getDatabase();
            $db->transactionStart();

            $db->setQuery(
                $db->getQuery(true)
                    ->update($db->quoteName('#__ordenproduccion_payment_proofs'))
                    ->set($db->quoteName('payment_amount') . ' = ' . $newAmount)
                    ->where($db->quoteName('id') . ' = ' . $proofId)
                    ->where($db->quoteName('state') . ' = 1')
            );
            $db->execute();

            if (!$this->recalculateProofAmountAndMismatch($proofId, $newAmount)) {
                throw new \RuntimeException('recalc');
            }

            $db->transactionCommit();
            $this->refreshClientBalancesAfterProofChange();

            return true;
        } catch (\Throwable $e) {
            try {
                $db->transactionRollback();
            } catch (\Throwable $ignored) {
            }
            if (!$this->getError()) {
                $this->setError(Text::_('COM_ORDENPRODUCCION_PAYMENT_PROOF_LINE_AMOUNT_SAVE_FAILED'));
            }

            return false;
        }
    }

    /**
     * Sync payment_amount, junction amount_applied (single-order proofs), mismatch_difference.
     *
     * @param   int         $proofId
     * @param   float|null  $paymentAmount  When set, skip summing lines.
     *
     * @return  bool
     */
    protected function recalculateProofAmountAndMismatch(int $proofId, ?float $paymentAmount = null): bool
    {
        $proofId = (int) $proofId;
        if ($proofId < 1) {
            return false;
        }

        $db = $this->getDatabase();

        if ($paymentAmount === null) {
            $paymentAmount = 0.0;
            if ($this->hasPaymentProofLinesTable()) {
                $db->setQuery(
                    $db->getQuery(true)
                        ->select('COALESCE(SUM(' . $db->quoteName('amount') . '), 0)')
                        ->from($db->quoteName('#__ordenproduccion_payment_proof_lines'))
                        ->where($db->quoteName('payment_proof_id') . ' = ' . $proofId)
                );
                $paymentAmount = round((float) $db->loadResult(), 2);
            } else {
                $proof = $this->getItem($proofId);
                $paymentAmount = round((float) ($proof->payment_amount ?? 0), 2);
            }
        } else {
            $paymentAmount = round((float) $paymentAmount, 2);
        }

        if ($paymentAmount <= 0) {
            return false;
        }

        $db->setQuery(
            $db->getQuery(true)
                ->update($db->quoteName('#__ordenproduccion_payment_proofs'))
                ->set($db->quoteName('payment_amount') . ' = ' . $paymentAmount)
                ->where($db->quoteName('id') . ' = ' . $proofId)
                ->where($db->quoteName('state') . ' = 1')
        );
        $db->execute();

        if ($this->hasPaymentOrdersTable()) {
            $linked = $this->getOrdersByPaymentProofId($proofId);
            if (\count($linked) === 1) {
                $orderId = (int) ($linked[0]->order_id ?? 0);
                if ($orderId > 0) {
                    $db->setQuery(
                        $db->getQuery(true)
                            ->update($db->quoteName('#__ordenproduccion_payment_orders'))
                            ->set($db->quoteName('amount_applied') . ' = ' . $paymentAmount)
                            ->where($db->quoteName('payment_proof_id') . ' = ' . $proofId)
                            ->where($db->quoteName('order_id') . ' = ' . $orderId)
                    );
                    $db->execute();
                }
            }
        }

        $ordersTotal = 0.0;
        foreach ($this->getOrdersByPaymentProofId($proofId) as $orderRow) {
            $ordersTotal += (float) ($orderRow->invoice_value ?? 0);
        }
        $ordersTotal = round($ordersTotal, 2);
        $diff        = round($paymentAmount - $ordersTotal, 2);

        $ppCols = $db->getTableColumns('#__ordenproduccion_payment_proofs', false);
        $ppCols = \is_array($ppCols) ? array_change_key_case($ppCols, CASE_LOWER) : [];
        if (isset($ppCols['mismatch_difference'])) {
            $db->setQuery(
                $db->getQuery(true)
                    ->update($db->quoteName('#__ordenproduccion_payment_proofs'))
                    ->set($db->quoteName('mismatch_difference') . ' = ' . $db->quote(number_format($diff, 2, '.', '')))
                    ->where($db->quoteName('id') . ' = ' . $proofId)
            );
            $db->execute();
        }

        return true;
    }

    /**
     * @return  void
     */
    protected function refreshClientBalancesAfterProofChange(): void
    {
        try {
            $adminModel = Factory::getApplication()->bootComponent('com_ordenproduccion')
                ->getMVCFactory()->createModel('Administracion', 'Site', ['ignore_request' => true]);
            if ($adminModel && method_exists($adminModel, 'refreshClientBalances')) {
                $adminModel->refreshClientBalances();
            }
        } catch (\Throwable $e) {
            // Non-fatal
        }
    }

    /**
     * Associate another order to an existing payment proof (add row to payment_orders).
     *
     * @param   integer  $proofId       Payment proof ID
     * @param   integer  $orderId      Order ID to link
     * @param   float    $amountApplied  Amount to apply to this order
     *
     * @return  boolean
     *
     * @since   3.83.0
     */
    public function addOrderToProof($proofId, $orderId, $amountApplied)
    {
        $proofId = (int) $proofId;
        $orderId = (int) $orderId;
        $amountApplied = (float) $amountApplied;
        if ($proofId <= 0 || $orderId <= 0 || $amountApplied <= 0) {
            return false;
        }
        try {
            $db = $this->getDatabase();
            $exists = $db->getQuery(true)
                ->select('1')
                ->from($db->quoteName('#__ordenproduccion_payment_orders'))
                ->where($db->quoteName('payment_proof_id') . ' = ' . $proofId)
                ->where($db->quoteName('order_id') . ' = ' . $orderId);
            $db->setQuery($exists);
            if ($db->loadResult()) {
                return false;
            }
            $user = Factory::getUser();
            $ins = (object) [
                'payment_proof_id' => $proofId,
                'order_id'         => $orderId,
                'amount_applied'   => $amountApplied,
                'created_by'      => (int) $user->id,
            ];
            $db->insertObject('#__ordenproduccion_payment_orders', $ins);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Check if an order is already linked to a payment proof.
     *
     * @param   integer  $proofId   Payment proof ID
     * @param   integer  $orderId   Order ID
     *
     * @return  boolean
     *
     * @since   3.97.0
     */
    public function isOrderLinkedToProof($proofId, $orderId)
    {
        $proofId = (int) $proofId;
        $orderId = (int) $orderId;
        if ($proofId <= 0 || $orderId <= 0) {
            return false;
        }
        try {
            $db = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select('1')
                ->from($db->quoteName('#__ordenproduccion_payment_orders'))
                ->where($db->quoteName('payment_proof_id') . ' = ' . $proofId)
                ->where($db->quoteName('order_id') . ' = ' . $orderId);
            $db->setQuery($query);
            return (bool) $db->loadResult();
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Set payment proof verification status to Verificado (so it counts toward client balance).
     *
     * @param   integer  $proofId  Payment proof ID
     *
     * @return  boolean
     *
     * @since   3.84.0
     */
    public function setVerificado($proofId)
    {
        $proofId = (int) $proofId;
        if ($proofId <= 0) {
            return false;
        }
        try {
            $db = $this->getDatabase();
            $cols = $db->getTableColumns('#__ordenproduccion_payment_proofs', false);
            $cols = is_array($cols) ? array_change_key_case($cols, CASE_LOWER) : [];
            if (!isset($cols['verification_status'])) {
                return false;
            }
            $query = $db->getQuery(true)
                ->update($db->quoteName('#__ordenproduccion_payment_proofs'))
                ->set($db->quoteName('verification_status') . ' = ' . $db->quote('verificado'));
            if (isset($cols['verified_date'])) {
                $query->set($db->quoteName('verified_date') . ' = ' . $db->quote(Factory::getDate()->toSql()));
            }
            $query
                ->where($db->quoteName('id') . ' = ' . $proofId)
                ->where($db->quoteName('state') . ' = 1');
            $db->setQuery($query);
            $db->execute();
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Check if the payment_proof_files table exists (3.65.0+)
     *
     * @return  boolean
     */
    public function hasPaymentProofFilesTable(): bool
    {
        try {
            $db     = $this->getDatabase();
            $tables = $db->getTableList();
            $target = $db->getPrefix() . 'ordenproduccion_payment_proof_files';
            foreach ($tables as $t) {
                if (strcasecmp($t, $target) === 0) {
                    return true;
                }
            }
            return false;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Whether payment_proof_files has payment_proof_line_id (3.109.49+).
     */
    public function hasPaymentProofFileLineIdColumn(): bool
    {
        if (!$this->hasPaymentProofFilesTable()) {
            return false;
        }
        try {
            $db   = $this->getDatabase();
            $cols = $db->getTableColumns('#__ordenproduccion_payment_proof_files', false);
            $cols = is_array($cols) ? array_change_key_case($cols, CASE_LOWER) : [];

            return isset($cols['payment_proof_line_id']);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Columns to select for payment_proof_files rows (includes optional columns when present).
     *
     * @return  array<int, string>
     */
    protected function getPaymentProofFilesSelectColumns(): array
    {
        $fields = ['id', 'file_path'];
        if (!$this->hasPaymentProofFilesTable()) {
            return $fields;
        }
        try {
            $db   = $this->getDatabase();
            $cols = $db->getTableColumns('#__ordenproduccion_payment_proof_files', false);
            $cols = is_array($cols) ? array_change_key_case($cols, CASE_LOWER) : [];
            if (isset($cols['payment_proof_line_id'])) {
                $fields[] = 'payment_proof_line_id';
            }
            if (isset($cols['created'])) {
                $fields[] = 'created';
            }
        } catch (\Throwable $e) {
        }

        return $fields;
    }

    /**
     * Return all file attachments for a payment proof.
     * Reads from the new payment_proof_files table when available;
     * falls back to the legacy file_path column otherwise.
     *
     * @param   object  $proof  Payment proof object (needs id and file_path)
     *
     * @return  array   Array of objects with a file_path property
     */
    public function getPaymentProofFiles(object $proof): array
    {
        $files = [];

        if ($this->hasPaymentProofFilesTable()) {
            try {
                $db     = $this->getDatabase();
                $fields = $this->getPaymentProofFilesSelectColumns();
                $query  = $db->getQuery(true)
                    ->select($db->quoteName($fields))
                    ->from($db->quoteName('#__ordenproduccion_payment_proof_files'))
                    ->where($db->quoteName('payment_proof_id') . ' = ' . (int) ($proof->id ?? 0))
                    ->where($db->quoteName('state') . ' = 1')
                    ->order('id ASC');
                $db->setQuery($query);
                $files = $db->loadObjectList();
            } catch (\Throwable $e) {
                $files = [];
            }
        }

        // Always include the legacy file_path if it is not already in the list.
        // This covers proofs created before the payment_proof_files table existed
        // that later had extra files added via addFileToProof().
        $legacyPath = trim((string) ($proof->file_path ?? ''));
        if ($legacyPath !== '') {
            $alreadyListed = false;
            foreach ($files as $f) {
                if (trim((string) ($f->file_path ?? '')) === $legacyPath) {
                    $alreadyListed = true;
                    break;
                }
            }
            if (!$alreadyListed) {
                array_unshift($files, (object) ['id' => 0, 'file_path' => $legacyPath]);
            }
        }

        return $files;
    }

    /**
     * Add a file attachment to an existing payment proof.
     *
     * @param   int       $proofId          Payment proof ID
     * @param   string    $filePath         Relative file path
     * @param   int       $createdBy        User ID
     * @param   int|null  $paymentLineId    FK to payment_proof_lines.id, or null for proof-level (legacy)
     *
     * @return  boolean
     */
    public function addFileToProof(int $proofId, string $filePath, int $createdBy, ?int $paymentLineId = null): bool
    {
        if ($proofId <= 0 || $filePath === '') {
            return false;
        }

        try {
            $db    = $this->getDatabase();
            if ($this->hasPaymentProofFileLineIdColumn()) {
                $lineVal = ($paymentLineId !== null && $paymentLineId > 0) ? (int) $paymentLineId : 'NULL';
                $query   = $db->getQuery(true)
                    ->insert($db->quoteName('#__ordenproduccion_payment_proof_files'))
                    ->columns($db->quoteName(['payment_proof_id', 'payment_proof_line_id', 'file_path', 'created_by', 'state']))
                    ->values(
                        $proofId . ',' .
                        $lineVal . ',' .
                        $db->quote($filePath) . ',' .
                        $createdBy . ',1'
                    );
            } else {
                $query = $db->getQuery(true)
                    ->insert($db->quoteName('#__ordenproduccion_payment_proof_files'))
                    ->columns($db->quoteName(['payment_proof_id', 'file_path', 'created_by', 'state']))
                    ->values(
                        $proofId . ',' .
                        $db->quote($filePath) . ',' .
                        $createdBy . ',1'
                    );
            }
            $db->setQuery($query);
            $db->execute();
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Group attachment file rows by payment line for display.
     * Rows with payment_proof_line_id go to that line. Rows without (legacy uploads) are paired
     * to lines in **registration order** (created ASC, then id), not raw id order, so thumbnails
     * match the payment line sequence (line 1, 2, 3…). Legacy synthetic rows (id 0 placeholder)
     * attach to the first line only.
     *
     * @param   object  $proof  Payment proof row
     * @param   array   $lines  Rows from getPaymentProofLines (ordered)
     *
     * @return  array<int, array<int, object>>  payment_proof_lines.id => file rows
     *
     * @since   3.109.50
     */
    public function groupFilesByPaymentLineForDisplay(object $proof, array $lines): array
    {
        $byLine = [];
        foreach ($lines as $line) {
            $lid = (int) ($line->id ?? 0);
            if ($lid > 0) {
                $byLine[$lid] = [];
            }
        }

        if (empty($byLine)) {
            return [];
        }

        $raw              = $this->getPaymentProofFiles($proof);
        $explicit         = [];
        $dbOrphans        = [];
        $legacySynthetics = [];

        foreach ($raw as $f) {
            $fkLine = $this->getPaymentProofLineIdFromFileRow($f);
            if ($fkLine !== null) {
                if (!isset($explicit[$fkLine])) {
                    $explicit[$fkLine] = [];
                }
                $explicit[$fkLine][] = $f;
            } elseif ((int) ($f->id ?? 0) === 0) {
                // Placeholder row for payment_proofs.file_path only (not a DB id)
                $legacySynthetics[] = $f;
            } else {
                $dbOrphans[] = $f;
            }
        }

        foreach ($explicit as $lid => &$list) {
            usort(
                $list,
                static function ($a, $b) {
                    return ((int) ($a->id ?? 0)) <=> ((int) ($b->id ?? 0));
                }
            );
        }
        unset($list);

        usort(
            $dbOrphans,
            function ($a, $b) {
                $ta = isset($a->created) ? strtotime((string) $a->created) : false;
                $tb = isset($b->created) ? strtotime((string) $b->created) : false;
                if ($ta !== false && $tb !== false && $ta !== $tb) {
                    return $ta <=> $tb;
                }

                return ((int) ($a->id ?? 0)) <=> ((int) ($b->id ?? 0));
            }
        );

        $lineList         = array_values($lines);
        $lineIdsOrdered   = [];
        foreach ($lineList as $line) {
            $lid = (int) ($line->id ?? 0);
            if ($lid > 0) {
                $lineIdsOrdered[] = $lid;
            }
        }
        $nLines         = count($lineIdsOrdered);
        $orphanByLineId = [];
        $orphanQueue    = $dbOrphans;

        // Orphans (NULL line FK): first fill lines that have no explicit attachment, in document order;
        // then spread any remainder round-robin so files do not pile onto the last line only.
        if ($nLines > 0) {
            foreach ($lineIdsOrdered as $lid) {
                if (empty($orphanQueue)) {
                    break;
                }
                if (empty($explicit[$lid])) {
                    $o = array_shift($orphanQueue);
                    if (!isset($orphanByLineId[$lid])) {
                        $orphanByLineId[$lid] = [];
                    }
                    $orphanByLineId[$lid][] = $o;
                }
            }
            $rr = 0;
            while (!empty($orphanQueue)) {
                $o   = array_shift($orphanQueue);
                $lid = $lineIdsOrdered[$rr % $nLines];
                $rr++;
                if (!isset($orphanByLineId[$lid])) {
                    $orphanByLineId[$lid] = [];
                }
                $orphanByLineId[$lid][] = $o;
            }
        }

        $out = [];
        foreach ($byLine as $lid => $_) {
            $out[$lid] = array_merge($explicit[$lid] ?? [], $orphanByLineId[$lid] ?? []);
        }

        $firstLid = $nLines > 0 ? (int) ($lineList[0]->id ?? 0) : 0;
        if ($firstLid > 0 && $legacySynthetics !== []) {
            foreach (array_reverse($legacySynthetics) as $ls) {
                array_unshift($out[$firstLid], $ls);
            }
        }

        return $out;
    }

    /**
     * Read FK to payment_proof_lines.id from a file row (handles driver/casing quirks).
     *
     * @param   object  $f  File row from getPaymentProofFiles
     *
     * @return  int|null  Positive line id, or null if column missing / not set / legacy row
     */
    protected function getPaymentProofLineIdFromFileRow(object $f): ?int
    {
        if (!$this->hasPaymentProofFileLineIdColumn()) {
            return null;
        }
        $v = null;
        foreach (get_object_vars($f) as $name => $val) {
            if (strcasecmp((string) $name, 'payment_proof_line_id') === 0) {
                $v = $val;
                break;
            }
        }
        if ($v === null || $v === '') {
            return null;
        }
        $id = (int) $v;

        return $id > 0 ? $id : null;
    }

    /**
     * @param   object  $f  File row from getPaymentProofFiles
     */
    protected function proofFileHasPositiveLineId(object $f): bool
    {
        return $this->getPaymentProofLineIdFromFileRow($f) !== null;
    }

    /**
     * Delete one attachment (Administración). Removes DB row and file on disk; clears legacy file_path when needed.
     *
     * @param   int  $proofId    Payment proof id
     * @param   int  $fileRowId  Row id in payment_proof_files, or 0 for legacy payment_proofs.file_path only
     *
     * @return  boolean
     *
     * @since   3.109.50
     */
    public function deleteProofAttachment(int $proofId, int $fileRowId): bool
    {
        if ($proofId <= 0) {
            return false;
        }

        try {
            $db = $this->getDatabase();

            if ($fileRowId === 0) {
                $db->setQuery(
                    $db->getQuery(true)
                        ->select($db->quoteName('file_path'))
                        ->from($db->quoteName('#__ordenproduccion_payment_proofs'))
                        ->where($db->quoteName('id') . ' = ' . (int) $proofId)
                        ->where($db->quoteName('state') . ' = 1')
                );
                $path = trim((string) $db->loadResult());
                if ($path === '') {
                    return false;
                }
                $this->unlinkPaymentProofFile($path);
                $db->setQuery(
                    $db->getQuery(true)
                        ->update($db->quoteName('#__ordenproduccion_payment_proofs'))
                        ->set($db->quoteName('file_path') . ' = ' . $db->quote(''))
                        ->where($db->quoteName('id') . ' = ' . (int) $proofId)
                );
                $db->execute();

                return true;
            }

            if (!$this->hasPaymentProofFilesTable()) {
                return false;
            }

            $db->setQuery(
                $db->getQuery(true)
                    ->select([$db->quoteName('id'), $db->quoteName('file_path')])
                    ->from($db->quoteName('#__ordenproduccion_payment_proof_files'))
                    ->where($db->quoteName('id') . ' = ' . (int) $fileRowId)
                    ->where($db->quoteName('payment_proof_id') . ' = ' . (int) $proofId)
                    ->where($db->quoteName('state') . ' = 1')
            );
            $row = $db->loadObject();
            if ($row === null || trim((string) ($row->file_path ?? '')) === '') {
                return false;
            }

            $path = trim((string) $row->file_path);
            $db->setQuery(
                $db->getQuery(true)
                    ->delete($db->quoteName('#__ordenproduccion_payment_proof_files'))
                    ->where($db->quoteName('id') . ' = ' . (int) $fileRowId)
                    ->where($db->quoteName('payment_proof_id') . ' = ' . (int) $proofId)
            );
            $db->execute();

            $this->unlinkPaymentProofFile($path);

            $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('file_path'))
                    ->from($db->quoteName('#__ordenproduccion_payment_proofs'))
                    ->where($db->quoteName('id') . ' = ' . (int) $proofId)
            );
            $legacy = trim((string) $db->loadResult());
            if ($legacy !== '' && $legacy === $path) {
                $db->setQuery(
                    $db->getQuery(true)
                        ->update($db->quoteName('#__ordenproduccion_payment_proofs'))
                        ->set($db->quoteName('file_path') . ' = ' . $db->quote(''))
                        ->where($db->quoteName('id') . ' = ' . (int) $proofId)
                );
                $db->execute();
            }

            return true;
        } catch (\Throwable $e) {
            $this->setError($e->getMessage());

            return false;
        }
    }

    /**
     * @param   string  $relativePath  Path as stored in DB
     */
    protected function unlinkPaymentProofFile(string $relativePath): void
    {
        if ($relativePath === '' || strpos($relativePath, '..') !== false) {
            return;
        }
        $fullPath = JPATH_ROOT . '/' . ltrim($relativePath, '/');
        if (is_file($fullPath)) {
            @unlink($fullPath);
        }
    }

    /**
     * Get payment type options (from DB if payment_types table exists, else hardcoded fallback)
     *
     * @return  array  Array of payment type options (code => label)
     *
     * @since   3.1.3
     */
    public function getPaymentTypeOptions()
    {
        try {
            $component = Factory::getApplication()->bootComponent('com_ordenproduccion');
            $mvcFactory = $component->getMVCFactory();
            $paymenttypeModel = $mvcFactory->createModel('Paymenttype', 'Site', ['ignore_request' => true]);

            if ($paymenttypeModel && method_exists($paymenttypeModel, 'getPaymentTypeOptions')) {
                $options = $paymenttypeModel->getPaymentTypeOptions();
                if (!empty($options)) {
                    return $options;
                }
            }
        } catch (\Exception $e) {
            // Table may not exist yet - fall through to hardcoded
        }

        return [
            'efectivo' => AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_TYPE_CASH', 'Cash', 'Efectivo'),
            'cheque' => AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_TYPE_CHECK', 'Check', 'Cheque'),
            'transferencia' => AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_TYPE_TRANSFER', 'Bank Transfer', 'Transferencia Bancaria'),
            'deposito' => AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_TYPE_DEPOSIT', 'Bank Deposit', 'Depósito Bancario'),
            'nota_credito_fiscal' => AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_TYPE_TAX_CREDIT_NOTE', 'Tax Credit Note', 'Nota Crédito Fiscal')
        ];
    }

    /**
     * True if this payment line belongs to the given payment proof.
     *
     * @param   int  $paymentProofLineId  Row id in payment_proof_lines
     * @param   int  $paymentProofId      Payment proof id
     *
     * @return  bool
     */
    public function paymentProofLineBelongsToProof(int $paymentProofLineId, int $paymentProofId): bool
    {
        if ($paymentProofLineId <= 0 || $paymentProofId <= 0 || !$this->hasPaymentProofLinesTable()) {
            return false;
        }
        try {
            $db = $this->getDatabase();
            $q  = $db->getQuery(true)
                ->select('COUNT(*)')
                ->from($db->quoteName('#__ordenproduccion_payment_proof_lines'))
                ->where($db->quoteName('id') . ' = ' . (int) $paymentProofLineId)
                ->where($db->quoteName('payment_proof_id') . ' = ' . (int) $paymentProofId);
            $db->setQuery($q);

            return (int) $db->loadResult() > 0;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Check if payment_proof_lines table exists (3.64.0+ schema)
     */
    protected function hasPaymentProofLinesTable()
    {
        try {
            $db = $this->getDatabase();
            $tables = $db->getTableList();
            $prefix = $db->getPrefix();
            $tableName = $prefix . 'ordenproduccion_payment_proof_lines';
            foreach ($tables as $t) {
                if (strcasecmp($t, $tableName) === 0) {
                    return true;
                }
            }
            return false;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Get Guatemalan banks options
     *
     * @return  array  Array of bank options
     *
     * @since   3.1.3
     */
    public function getBankOptions()
    {
        // ALWAYS try to get banks from database first (new method in 3.5.1)
        try {
            $component = Factory::getApplication()->bootComponent('com_ordenproduccion');
            $mvcFactory = $component->getMVCFactory();
            $bankModel = $mvcFactory->createModel('Bank', 'Site', ['ignore_request' => true]);
            
            if ($bankModel && method_exists($bankModel, 'getBankOptions')) {
                $options = $bankModel->getBankOptions();
                
                // Debug logging to verify what we're getting
                error_log("PaymentProofModel::getBankOptions() - Got " . count($options) . " banks from BankModel");
                if (!empty($options)) {
                    error_log("PaymentProofModel::getBankOptions() - Bank codes: " . implode(', ', array_keys($options)));
                }
                
                // ALWAYS return database banks - even if empty array
                // This ensures deleted banks are not shown
                return $options;
            }
            
            // If model doesn't exist, log and return empty array instead of hardcoded fallback
            error_log("PaymentProofModel::getBankOptions() - BankModel could not be created");
            return [];
            
        } catch (\Exception $e) {
            // Log full exception details for debugging
            error_log("PaymentProofModel::getBankOptions() - Exception: " . $e->getMessage());
            error_log("PaymentProofModel::getBankOptions() - Stack trace: " . $e->getTraceAsString());
            
            // Only fall back to hardcoded list if it's a database table missing error
            // For all other errors, return empty array to avoid showing stale hardcoded banks
            if (strpos($e->getMessage(), 'doesn\'t exist') !== false || 
                strpos($e->getMessage(), 'Table') !== false ||
                strpos($e->getMessage(), 'Unknown table') !== false) {
                // Database table doesn't exist yet - use fallback during initial setup
                error_log("PaymentProofModel::getBankOptions() - Database table missing, using hardcoded fallback");
                Factory::getApplication()->enqueueMessage(
                    'Error loading banks from database: ' . $e->getMessage(), 
                    'notice'
                );
                
                // Fallback to hardcoded list ONLY if table doesn't exist
                return [
            'banco_industrial' => Text::_('COM_ORDENPRODUCCION_BANK_INDUSTRIAL'),
            'banco_gyt' => Text::_('COM_ORDENPRODUCCION_BANK_GYT'),
            'banco_promerica' => Text::_('COM_ORDENPRODUCCION_BANK_PROMERICA'),
            'banco_agricola' => Text::_('COM_ORDENPRODUCCION_BANK_AGRICOLA'),
            'banco_azteca' => Text::_('COM_ORDENPRODUCCION_BANK_AZTECA'),
            'banco_citibank' => Text::_('COM_ORDENPRODUCCION_BANK_CITIBANK'),
            'banco_davivienda' => Text::_('COM_ORDENPRODUCCION_BANK_DAVIVIENDA'),
            'banco_ficohsa' => Text::_('COM_ORDENPRODUCCION_BANK_FICOHSA'),
            'banco_gyte' => Text::_('COM_ORDENPRODUCCION_BANK_GYTE'),
            'banco_inmobiliario' => Text::_('COM_ORDENPRODUCCION_BANK_INMOBILIARIO'),
            'banco_internacional' => Text::_('COM_ORDENPRODUCCION_BANK_INTERNACIONAL'),
            'banco_metropolitano' => Text::_('COM_ORDENPRODUCCION_BANK_METROPOLITANO'),
            'banco_promerica_guatemala' => Text::_('COM_ORDENPRODUCCION_BANK_PROMERICA_GUATEMALA'),
            'banco_refaccionario' => Text::_('COM_ORDENPRODUCCION_BANK_REFACCIONARIO'),
            'banco_rural' => Text::_('COM_ORDENPRODUCCION_BANK_RURAL'),
            'banco_salud' => Text::_('COM_ORDENPRODUCCION_BANK_SALUD'),
            'banco_vivibanco' => Text::_('COM_ORDENPRODUCCION_BANK_VIVIBANCO')
                ];
            }
            
            // For all other exceptions, return empty array to force using database only
            return [];
        }
    }

    /**
     * Get default bank code
     *
     * @return  string|null  Default bank code or null if no default set
     *
     * @since   3.5.3
     */
    public function getDefaultBankCode()
    {
        try {
            $component = Factory::getApplication()->bootComponent('com_ordenproduccion');
            $mvcFactory = $component->getMVCFactory();
            $bankModel = $mvcFactory->createModel('Bank', 'Site', ['ignore_request' => true]);
            
            if ($bankModel && method_exists($bankModel, 'getDefaultBankCode')) {
                $defaultCode = $bankModel->getDefaultBankCode();
                error_log("PaymentProofModel::getDefaultBankCode() - Default bank code: " . ($defaultCode ?: 'none'));
                return $defaultCode;
            }
        } catch (\Exception $e) {
            error_log("PaymentProofModel::getDefaultBankCode() - Exception: " . $e->getMessage());
        }
        
        return null;
    }
}
