<?php
/**
 * Pre-Cotización document: header, lines table, "Cálculo de Folios" and "Otros Elementos" modals, Total.
 *
 * @package     com_ordenproduccion
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Grimpsa\Component\Ordenproduccion\Site\Helper\AccessHelper;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;

/** @var \Grimpsa\Component\Ordenproduccion\Site\View\Cotizador\HtmlView $this */

$item  = $this->item ?? null;
$lines = $this->lines ?? [];
$precotJsLiveTotalsPayload = null;
$listUrl = Route::_('index.php?option=com_ordenproduccion&view=cotizador');
$addLineTask = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.addLine');
$editLineTask = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.editLine');
$token = Session::getFormToken();

if (!$item) {
    return;
}

$documentMode = isset($item->document_mode) ? (string) $item->document_mode : 'pliego';
if ($documentMode === 'proveedor_externo') {
    echo $this->loadTemplate('proveedor_externo');
    return;
}

$preCotizacionId = (int) $item->id;
$canSaveImpresionOverride = !empty($this->canSaveImpresionOverride);
// Absolute SEF-safe URLs (same scheme as current request). Uri::root().'index.php' breaks with http/https mismatch or some SEF layouts.
$saveImpresionOverrideUrl = Route::_(
    'index.php?option=com_ordenproduccion&task=precotizacion.saveImpresionOverride&format=json&tmpl=component',
    false,
    Route::TLS_IGNORE,
    true
);
$precotizacionLocked = !empty($this->precotizacionLocked);
$canEditDocument = isset($this->precotizacionDocumentEditable)
    ? (bool) $this->precotizacionDocumentEditable
    : !$precotizacionLocked;
$ofertaViewOnly = !empty($item->oferta) && !$canEditDocument && !$precotizacionLocked;
$paperNames = [];
$sizeNames = [];
foreach ($this->pliegoPaperTypes ?? [] as $p) {
    $paperNames[(int) $p->id] = $p->name ?? '';
}
foreach ($this->pliegoSizes ?? [] as $s) {
    $sizeNames[(int) $s->id] = $s->name ?? '';
}

$baseUrl = Route::_('index.php?option=com_ordenproduccion&task=cotizacion.calculatePliegoPrice&format=raw');
$sizes = $this->pliegoSizes ?? [];
$paperTypes = $this->pliegoPaperTypes ?? [];
$sizeIdsByPaperType = $this->pliegoSizeIdsByPaperType ?? [];
$laminationTypeIdsBySizeTiro = $this->pliegoLaminationTypeIdsBySizeTiro ?? [];
$laminationTypeIdsBySizeRetiro = $this->pliegoLaminationTypeIdsBySizeRetiro ?? [];
$pliegoBarnizBySizeTiro = $this->pliegoBarnizBySizeTiro ?? [];
$pliegoBarnizBySizeRetiro = $this->pliegoBarnizBySizeRetiro ?? [];
$laminationTypes = $this->pliegoLaminationTypes ?? [];
$processes = $this->pliegoProcesses ?? [];
$tablesExist = $this->pliegoTablesExist ?? false;
$elementosById = [];
foreach ($this->elementos ?? [] as $el) {
    $elementosById[(int) $el->id] = $el;
}
// Use stored snapshot totals when present (3.86.0+), so totals stay historical if prices change later
$hasStoredTotals = isset($item->lines_subtotal) && $item->lines_subtotal !== null && $item->lines_subtotal !== '';
if ($hasStoredTotals) {
    $linesSubtotal = (float) $item->lines_subtotal;
    $margenAmount = (float) ($item->margen_amount ?? 0);
    $ivaAmount = (float) ($item->iva_amount ?? 0);
    $isrAmount = (float) ($item->isr_amount ?? 0);
    $comisionAmount = (float) ($item->comision_amount ?? 0);
    $linesTotal = (float) ($item->total ?? 0);
    $linesTotalFinal = isset($item->total_final) && $item->total_final !== null && $item->total_final !== '' ? (float) $item->total_final : $linesTotal;
} else {
    $linesSubtotal = 0;
    if (!empty($lines)) {
        foreach ($lines as $l) {
            $linesSubtotal += (float) ($l->total ?? 0);
        }
    }
    $paramMargen = isset($this->paramMargen) ? (float) $this->paramMargen : 0;
    $paramIva = isset($this->paramIva) ? (float) $this->paramIva : 0;
    $paramIsr = isset($this->paramIsr) ? (float) $this->paramIsr : 0;
    $paramComision = isset($this->paramComision) ? (float) $this->paramComision : 0;
    $margenAmount = $linesSubtotal * ($paramMargen / 100);
    $facturar = !empty($item->facturar);
    $ivaAmount = $facturar ? ($linesSubtotal * ($paramIva / 100)) : 0;
    $isrAmount = $facturar ? ($linesSubtotal * ($paramIsr / 100)) : 0;
    $comisionAmount = $linesSubtotal * ($paramComision / 100);
    $linesTotal = $linesSubtotal + $margenAmount + $ivaAmount + $isrAmount + $comisionAmount;
    $linesTotalFinal = $linesTotal;
}
$facturar = !empty($item->facturar);
$paramMargen = isset($this->paramMargen) ? (float) $this->paramMargen : 0;
$paramIva = isset($this->paramIva) ? (float) $this->paramIva : 0;
$paramIsr = isset($this->paramIsr) ? (float) $this->paramIsr : 0;
$paramComision = isset($this->paramComision) ? (float) $this->paramComision : 0;
$paramComisionMargenAdicional = isset($this->paramComisionMargenAdicional) ? (float) $this->paramComisionMargenAdicional : 0;
$margenAdicional = ($item && isset($item->margen_adicional) && $item->margen_adicional !== null && $item->margen_adicional !== '') ? (float) $item->margen_adicional : 0;
$comisionMargenAdicionalAmount = ($item && isset($item->comision_margen_adicional) && $item->comision_margen_adicional !== null && $item->comision_margen_adicional !== '') ? (float) $item->comision_margen_adicional : 0;
$displayTotal = $linesTotalFinal + $margenAdicional;
$pctMaUi = (float) $paramComisionMargenAdicional;
$precotComisionMaPctText = (\abs($pctMaUi - \round($pctMaUi)) < 0.000001)
    ? (string) (int) \round($pctMaUi)
    : \number_format($pctMaUi, 1, '.', '');
$pctMgUi = (float) $paramMargen;
$precotMargenPctText = (\abs($pctMgUi - \round($pctMgUi)) < 0.000001)
    ? (string) (int) \round($pctMgUi)
    : \number_format($pctMgUi, 1, '.', '');
$tarjetaCreditoTableOk = !empty($this->tarjetaCreditoTableExists);
$tarjetaCreditoRates = is_array($this->tarjetaCreditoRates ?? null) ? $this->tarjetaCreditoRates : [];
$tcCuotasSel = isset($item->tarjeta_credito_cuotas) && $item->tarjeta_credito_cuotas !== null && $item->tarjeta_credito_cuotas !== ''
    ? (int) $item->tarjeta_credito_cuotas
    : 0;
$tcMonto = isset($item->tarjeta_credito_monto) && $item->tarjeta_credito_monto !== null && $item->tarjeta_credito_monto !== ''
    ? (float) $item->tarjeta_credito_monto
    : 0.0;
$tcTasa = isset($item->tarjeta_credito_tasa) && $item->tarjeta_credito_tasa !== null && $item->tarjeta_credito_tasa !== ''
    ? (float) $item->tarjeta_credito_tasa
    : 0.0;
$totalConTarjeta = isset($item->total_con_tarjeta) && $item->total_con_tarjeta !== null && $item->total_con_tarjeta !== ''
    ? (float) $item->total_con_tarjeta
    : null;
$canSeePrecotInternalTax = AccessHelper::canSeePrecotizacionInternalTaxBreakdown($preCotizacionId);
$canSetTercerizadoImporte = !empty($this->canSetTercerizadoImporte);

/* IVA/ISR líneas pie: necesitan vista interna + Facturar. Además debe haber tasa global (params iva/isr)
 * distinta de 0, o importe persistido/recalculado no trivial — las opciones del componente (manifest)
 * usan defecto 0 si no las configuran en Opciones del componente. */
$precotFooterShowIva = $canSeePrecotInternalTax && $facturar
    && (($paramIva != 0) || abs((float) $ivaAmount) >= 0.005);
$precotFooterShowIsr = $canSeePrecotInternalTax && $facturar
    && (($paramIsr != 0) || abs((float) $isrAmount) >= 0.005);

$saveTarjetaUrl = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.saveTarjetaCredito');
// Labels for add-line buttons (fallback if lang key missing or old "Nueva Línea" override)
$labelCalculoFolios = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_CALCULO_FOLIOS');
if ($labelCalculoFolios === 'COM_ORDENPRODUCCION_PRE_COTIZACION_CALCULO_FOLIOS' || $labelCalculoFolios === 'COM_ORDENPRODUCCION_PRE_COTIZACION_NUEVA_LINEA' || $labelCalculoFolios === 'New Line' || $labelCalculoFolios === 'Nueva Línea') {
    $labelCalculoFolios = 'Cálculo de Folios';
}
$labelOtrosElementos = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_OTROS_ELEMENTOS');
if ($labelOtrosElementos === 'COM_ORDENPRODUCCION_PRE_COTIZACION_OTROS_ELEMENTOS' || $labelOtrosElementos === 'Other elements') {
    $labelOtrosElementos = 'Otros Elementos';
}
$labelAnadirEnvio = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ANADIR_ENVIO');
if ($labelAnadirEnvio === 'COM_ORDENPRODUCCION_PRE_COTIZACION_ANADIR_ENVIO') {
    $labelAnadirEnvio = 'Añadir envío';
}
$labelProductoTercerizado = Text::_('COM_ORDENPRODUCCION_PRE_COT_TERCERIZADO_BTN');
if ($labelProductoTercerizado === 'COM_ORDENPRODUCCION_PRE_COT_TERCERIZADO_BTN') {
    $labelProductoTercerizado = 'Servicio tercerizado';
}
$envios = $this->envios ?? [];

$canReviewDiscountApproval = !empty($this->canReviewDiscountApproval);
$pendingSolicitudDescuento    = !empty($this->pendingSolicitudDescuento);
$canAdjustLineSubtotals = $canSaveImpresionOverride
    || ($canReviewDiscountApproval && $pendingSolicitudDescuento);
$showLineBreakdownDetail = $canSeePrecotInternalTax
    || ($canAdjustLineSubtotals && $canReviewDiscountApproval);

$hasAnyBreakdownOverrideRows = false;
$precotModelDoc = $this->precotizacionModel ?? null;
if ($canAdjustLineSubtotals && $lines !== [] && $precotModelDoc) {
    foreach ($lines as $ln) {
        if (!$precotModelDoc->isPliegoQuoteLine($ln)) {
            continue;
        }
        $br = $precotModelDoc->resolvePliegoBreakdownForLine($ln);
        foreach ($br as $bi => $_br) {
            if ($precotModelDoc->getBreakdownRowAdjustmentMeta($ln, (int) $bi) !== null) {
                $hasAnyBreakdownOverrideRows = true;
                break 2;
            }
            if ($canReviewDiscountApproval && $pendingSolicitudDescuento) {
                $st = round((float) ($_br['subtotal'] ?? 0), 2);
                if ($st > 0) {
                    $hasAnyBreakdownOverrideRows = true;
                    break 2;
                }
            }
        }
    }
}
$hasExpandablePliegoLines = false;
if ($lines !== [] && $precotModelDoc) {
    foreach ($lines as $_lnExp) {
        if ($precotModelDoc->isPliegoQuoteLine($_lnExp)) {
            $hasExpandablePliegoLines = true;
            break;
        }
    }
}
$linesTableColspan = $hasExpandablePliegoLines ? 8 : 7;
$saveBreakdownBatchUrl = Route::_(
    'index.php?option=com_ordenproduccion&task=precotizacion.saveBreakdownSubtotalsBatch&format=json&tmpl=component',
    false,
    Route::TLS_IGNORE,
    true
);
$rejectSinDescuentoUrl = Route::_(
    'index.php?option=com_ordenproduccion&task=precotizacion.rejectSolicitudDescuentoSinDescuento&format=json&tmpl=component',
    false,
    Route::TLS_IGNORE,
    true
);

$pendingCreacionOtReq = isset($this->pendingCreacionOtRequestId) ? (int) $this->pendingCreacionOtRequestId : 0;
$fechaDefaultCreacionOt = isset($this->pendingCreacionOtDefaultFechaYmd) ? trim((string) $this->pendingCreacionOtDefaultFechaYmd) : '';
$decideCreacionOtUrl = Route::_(
    'index.php?option=com_ordenproduccion&task=precotizacion.decideCreacionOrdenTrabajo&format=json&tmpl=component',
    false,
    Route::TLS_IGNORE,
    true
);
$showCreacionOtApprovalBanner = AccessHelper::isInAprobacionesVentasGroup()
    && ($this->canCompleteCreacionOtApprovalHere ?? false)
    && $pendingCreacionOtReq > 0;

$canReviewDiscountApproval = !empty($this->canReviewDiscountApproval);
$autoExpandPliegoLineDetails = $canReviewDiscountApproval && !empty($this->pendingSolicitudDescuento);
$showDiscountApprovalBanner  = $canReviewDiscountApproval && !empty($this->pendingSolicitudDescuento);

$discountWorkflowAvailable   = !empty($this->discountWorkflowAvailable);
$canRequestSolicitudDescuento = !empty($this->canRequestSolicitudDescuento);
$solicitudDescuentoLatestNote = isset($this->solicitudDescuentoLatestNote)
    ? trim((string) $this->solicitudDescuentoLatestNote)
    : '';
$itemIdForRoutes            = (int) Factory::getApplication()->getInput()->getInt('Itemid', 0);
$solicitarDescuentoAction   = Route::_(
    'index.php?option=com_ordenproduccion&task=precotizacion.solicitarDescuento'
    . ($itemIdForRoutes > 0 ? '&Itemid=' . $itemIdForRoutes : ''),
    false,
    Route::TLS_IGNORE,
    true
);
?>

<div class="com-ordenproduccion-precotizacion-document container py-4">
    <nav class="mb-3">
        <a href="<?php echo $listUrl; ?>" class="btn btn-outline-secondary"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_BACK'); ?></a>
    </nav>

    <?php if ($showCreacionOtApprovalBanner) :
        ?>
    <div class="alert alert-info d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
        <div>
            <strong><?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_ALERT_TITLE'); ?></strong>
            <span class="d-block small text-muted"><?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_ALERT_INTRO'); ?></span>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#precotCreacionOtApprovalModal">
                <i class="fas fa-clipboard-check" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_BTN_REVIEW'); ?>
            </button>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($showDiscountApprovalBanner) : ?>
    <div class="alert alert-warning d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
        <div>
            <strong><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_DESCUENTO_PENDING_BADGE'); ?></strong>
            <span class="d-block small text-muted"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_DESCUENTO_APPROVAL_LINE_DETAIL_HINT'); ?></span>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($showDiscountApprovalBanner && $solicitudDescuentoLatestNote !== '') : ?>
    <div class="mb-3 precotizacion-discount-request-note">
        <div class="small text-muted mb-1"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_DESCUENTO_NOTE_LABEL'); ?></div>
        <div class="border rounded p-2 bg-light small text-body"><?php echo nl2br(htmlspecialchars($solicitudDescuentoLatestNote, ENT_QUOTES, 'UTF-8')); ?></div>
    </div>
    <?php endif; ?>

    <?php if ($canEditDocument) : ?>
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <h1 class="page-title mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TITLE'); ?> <?php echo htmlspecialchars($item->number); ?></h1>
        <button type="submit" form="precotizacion-desc-medidas-form" class="btn btn-secondary"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_DOCUMENT_SAVE_BTN'); ?></button>
    </div>
    <?php else : ?>
    <h1 class="page-title"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TITLE'); ?> <?php echo htmlspecialchars($item->number); ?></h1>
    <?php endif; ?>

    <?php
    $associatedQuotations = $this->associatedQuotations ?? [];
    if (!empty($associatedQuotations)) :
        $labelAssociated = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ASSOCIATED_QUOTATION');
        if (strpos($labelAssociated, 'COM_ORDENPRODUCCION_') === 0) {
            $labelAssociated = 'Associated quotation(s)';
        }
    ?>
    <div class="precotizacion-associated-quotations mb-3 p-3 bg-light rounded">
        <strong><?php echo htmlspecialchars($labelAssociated); ?>:</strong>
        <?php
        $links = [];
        foreach ($associatedQuotations as $q) {
            $url = Route::_('index.php?option=com_ordenproduccion&view=cotizacion&id=' . (int) $q->id);
            $links[] = '<a href="' . htmlspecialchars($url) . '">' . htmlspecialchars($q->quotation_number ?? ('COT-' . $q->id)) . '</a>';
        }
        echo implode(', ', $links);
        ?>
    </div>
    <?php endif; ?>

    <?php if ($precotizacionLocked) :
        if (!empty($this->precotizacionLockedByOrdenTrabajo)) {
            $msgLocked = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_LOCKED_ORDEN_TRABAJO');
            if ($msgLocked === 'COM_ORDENPRODUCCION_PRE_COTIZACION_LOCKED_ORDEN_TRABAJO'
                || (is_string($msgLocked) && strpos($msgLocked, 'COM_ORDENPRODUCCION_') === 0)) {
                $msgLocked = 'Esta pre-cotización tiene una orden de trabajo activa; no se puede modificar.';
            }
        } else {
            $msgLocked = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_LOCKED_MODIFY');
            if ($msgLocked === 'COM_ORDENPRODUCCION_PRE_COTIZACION_LOCKED_MODIFY'
                || (is_string($msgLocked) && strpos($msgLocked, 'COM_ORDENPRODUCCION_') === 0)) {
                $msgLocked = 'Esta pre-cotización ya forma parte de una cotización formal, por eso no se puede editar aquí. Si necesita cambios, cree una nueva pre-cotización o revise la cotización vinculada.';
            }
        }
    ?>
    <div class="alert alert-info mb-3"><?php echo htmlspecialchars($msgLocked); ?></div>
    <?php endif; ?>

    <?php if ($ofertaViewOnly) :
        $msgOfertaRo = Text::_('COM_ORDENPRODUCCION_PRE_OFERTA_VIEW_ONLY');
        if ($msgOfertaRo === 'COM_ORDENPRODUCCION_PRE_OFERTA_VIEW_ONLY' || (is_string($msgOfertaRo) && strpos($msgOfertaRo, 'COM_ORDENPRODUCCION_') === 0)) {
            $msgOfertaRo = 'Esta pre-cotización es una oferta plantilla. Solo el autor puede editarla; usted puede verla.';
        }
    ?>
    <div class="alert alert-warning mb-3"><?php echo htmlspecialchars($msgOfertaRo); ?></div>
    <?php endif; ?>

    <?php
    $labelFacturar = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_FACTURAR');
    if (strpos($labelFacturar, 'COM_ORDENPRODUCCION_') === 0) {
        $labelFacturar = 'Facturar';
    }
    $facturarChecked = !empty($item->facturar);
    $saveFacturarUrl = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.saveFacturar');
    $labelDescripcion = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_DESCRIPCION');
    if (strpos($labelDescripcion, 'COM_ORDENPRODUCCION_') === 0) {
        $labelDescripcion = 'Descripción';
    }
    $descripcionValue = isset($item->descripcion) ? (string) $item->descripcion : '';
    $saveDescripcionUrl = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.saveDescripcion');
    ?>
    <?php
    $labelOferta = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_OFERTA');
    if (strpos($labelOferta, 'COM_ORDENPRODUCCION_') === 0) {
        $labelOferta = 'Oferta';
    }
    $labelOfertaExpires = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_OFERTA_EXPIRES');
    if (strpos($labelOfertaExpires, 'COM_ORDENPRODUCCION_') === 0) {
        $labelOfertaExpires = 'Fecha de vencimiento';
    }
    $ofertaChecked = !empty($item->oferta);
    $ofertaExpiresValue = isset($item->oferta_expires) && $item->oferta_expires !== '' && $item->oferta_expires !== null
        ? (new \DateTime($item->oferta_expires))->format('Y-m-d') : '';
    $canShowOfertaExpiry = property_exists($item, 'oferta_expires') && $ofertaChecked;
    $ofertaExpiresDisplay = '';
    if ($canShowOfertaExpiry && $ofertaExpiresValue !== '') {
        try {
            $ofertaExpiresDisplay = (new \DateTime($ofertaExpiresValue))->format('d/m/Y');
        } catch (\Throwable $e) {
            $ofertaExpiresDisplay = (string) $item->oferta_expires;
        }
    }
    $todayMinDate = (new \DateTime('today'))->format('Y-m-d');
    $labelOfertaChangeExpires = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_OFERTA_CHANGE_EXPIRES');
    if (strpos($labelOfertaChangeExpires, 'COM_') === 0) {
        $labelOfertaChangeExpires = 'Cambiar vencimiento';
    }
    $canEditOfertaExpiry = $canEditDocument && !empty($this->showOfertaCheckbox)
        && $ofertaChecked && property_exists($item, 'oferta_expires');
    $saveOfertaUrl = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.saveOferta');
    $labelMedidas = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_MEDIDAS');
    if (strpos($labelMedidas, 'COM_ORDENPRODUCCION_') === 0) {
        $labelMedidas = 'Medidas';
    }
    $placeholderMedidas = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_MEDIDAS_PLACEHOLDER');
    if (strpos($placeholderMedidas, 'COM_ORDENPRODUCCION_') === 0) {
        $placeholderMedidas = 'ingrese medidas en pulgadas';
    }
    $medidasValue = isset($item->medidas) ? (string) $item->medidas : '';
    $labelCantidadTotal = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_CANTIDAD_TOTAL');
    if (strpos($labelCantidadTotal, 'COM_ORDENPRODUCCION_') === 0) {
        $labelCantidadTotal = 'Cantidad total';
    }
    $placeholderCantidadTotal = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_CANTIDAD_TOTAL_PLACEHOLDER');
    if (strpos($placeholderCantidadTotal, 'COM_ORDENPRODUCCION_') === 0) {
        $placeholderCantidadTotal = '';
    }
    $cantidadTotalValue = isset($item->cantidad_total) ? (string) $item->cantidad_total : '';
    $medidasOneLineValue = trim(preg_replace('/\s+/u', ' ', str_replace(["\r\n", "\r", "\n"], ' ', $medidasValue)));
    ?>
    <div class="precotizacion-descripcion mb-3">
        <?php if ($precotizacionLocked || !$canEditDocument) : ?>
            <div class="row g-2 mb-2">
                <div class="col-12 col-md-6">
                    <span class="form-label fw-bold mb-0 d-block"><?php echo htmlspecialchars($labelCantidadTotal); ?></span>
                    <div class="form-control-plaintext bg-light px-2 py-1 rounded mt-1"><?php echo $cantidadTotalValue !== '' ? htmlspecialchars($cantidadTotalValue) : '<span class="text-muted">—</span>'; ?></div>
                </div>
                <div class="col-12 col-md-6">
                    <span class="form-label fw-bold mb-0 d-block"><?php echo htmlspecialchars($labelMedidas); ?></span>
                    <div class="form-control-plaintext bg-light px-2 py-1 rounded mt-1"><?php echo $medidasValue !== '' ? htmlspecialchars($medidasValue) : '<span class="text-muted">—</span>'; ?></div>
                </div>
            </div>
            <label class="form-label fw-bold"><?php echo htmlspecialchars($labelDescripcion); ?></label>
            <div class="form-control-plaintext bg-light px-2 py-1 rounded"><?php echo $descripcionValue !== '' ? htmlspecialchars($descripcionValue) : '<span class="text-muted">—</span>'; ?></div>
        <?php else : ?>
        <form action="<?php echo htmlspecialchars($saveDescripcionUrl); ?>" method="post" id="precotizacion-desc-medidas-form" class="mb-0 w-100" style="min-width: 0;">
            <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>">
            <?php echo HTMLHelper::_('form.token'); ?>
            <div class="row g-2 mb-2">
                <div class="col-12 col-md-6">
                    <label class="form-label fw-bold mb-1" for="precotizacion-cantidad-total"><?php echo htmlspecialchars($labelCantidadTotal); ?></label>
                    <input type="number" name="cantidad_total" id="precotizacion-cantidad-total" class="form-control" min="1" step="1" inputmode="numeric" autocomplete="off"
                           placeholder="<?php echo htmlspecialchars($placeholderCantidadTotal); ?>"
                           value="<?php echo htmlspecialchars($cantidadTotalValue, ENT_QUOTES, 'UTF-8'); ?>" required>
                </div>
                <div class="col-12 col-md-6">
                    <label class="form-label fw-bold mb-1" for="precotizacion-medidas"><?php echo htmlspecialchars($labelMedidas); ?></label>
                    <input type="text" name="medidas" id="precotizacion-medidas" class="form-control" maxlength="512" autocomplete="off"
                           placeholder="<?php echo htmlspecialchars($placeholderMedidas); ?>"
                           value="<?php echo htmlspecialchars($medidasOneLineValue, ENT_QUOTES, 'UTF-8'); ?>" required>
                </div>
            </div>
            <div class="mb-2">
                <label class="form-label fw-bold mb-1" for="precotizacion-descripcion"><?php echo htmlspecialchars($labelDescripcion); ?></label>
                <textarea id="precotizacion-descripcion" name="descripcion" class="form-control w-100" rows="2" placeholder="<?php echo htmlspecialchars($labelDescripcion); ?>" style="resize: vertical; min-height: 4.25rem;" required><?php echo htmlspecialchars($descripcionValue); ?></textarea>
            </div>
        </form>
        <?php endif; ?>
    </div>

    <div class="precotizacion-oferta-facturar mb-3 d-flex flex-wrap align-items-center gap-4">
        <?php if ($canEditDocument && !empty($this->showOfertaCheckbox)) : ?>
        <button type="button" class="d-none" id="trigger-modal-oferta-expires" data-bs-toggle="modal" data-bs-target="#modal-oferta-expires" aria-hidden="true"></button>
        <div class="d-flex flex-wrap align-items-center gap-2 gap-md-3">
            <form action="<?php echo htmlspecialchars($saveOfertaUrl); ?>" method="post" class="d-inline mb-0" id="form-oferta">
                <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>">
                <?php echo HTMLHelper::_('form.token'); ?>
                <div class="form-check mb-0">
                    <input type="checkbox" class="form-check-input" name="oferta" id="precotizacion-oferta" value="1" <?php echo $ofertaChecked ? ' checked' : ''; ?>>
                    <label class="form-check-label" for="precotizacion-oferta"><?php echo htmlspecialchars($labelOferta); ?></label>
                </div>
            </form>
            <?php if ($canShowOfertaExpiry) : ?>
            <span class="precotizacion-oferta-expires-preview small text-muted mb-0">
                <span class="text-body-secondary"><?php echo htmlspecialchars($labelOfertaExpires); ?>:</span>
                <?php if ($ofertaExpiresDisplay !== '') : ?>
                    <strong class="text-body"><?php echo htmlspecialchars($ofertaExpiresDisplay); ?></strong>
                <?php else : ?>
                    <span class="text-muted">—</span>
                <?php endif; ?>
            </span>
            <?php endif; ?>
            <?php if ($canEditOfertaExpiry) : ?>
            <button type="button" class="btn btn-link btn-sm p-0 align-baseline" id="precotizacion-oferta-change-expires"><?php echo htmlspecialchars($labelOfertaChangeExpires); ?></button>
            <?php endif; ?>
        </div>
        <div class="modal fade" id="modal-oferta-expires" tabindex="-1" aria-labelledby="modal-oferta-expires-label" aria-hidden="true" data-bs-backdrop="static">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modal-oferta-expires-label"><?php echo htmlspecialchars($labelOfertaExpires); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo Text::_('JCLOSE'); ?>" id="modal-oferta-expires-btn-close"></button>
                    </div>
                    <form action="<?php echo htmlspecialchars($saveOfertaUrl); ?>" method="post" id="form-oferta-modal">
                        <div class="modal-body">
                            <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>">
                            <input type="hidden" name="oferta" value="1">
                            <?php echo HTMLHelper::_('form.token'); ?>
                            <div class="mb-0">
                                <label for="precotizacion-oferta-expires" class="form-label"><?php echo htmlspecialchars($labelOfertaExpires); ?></label>
                                <input type="date" name="oferta_expires" id="precotizacion-oferta-expires" class="form-control" required
                                       value="<?php echo htmlspecialchars($ofertaExpiresValue); ?>"
                                       data-min-first="<?php echo htmlspecialchars($todayMinDate); ?>">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="modal-oferta-expires-btn-cancel"><?php echo Text::_('JCANCEL'); ?></button>
                            <button type="submit" class="btn btn-primary"><?php echo Text::_('JSAVE'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script>
        (function() {
            var chk = document.getElementById('precotizacion-oferta');
            var triggerBtn = document.getElementById('trigger-modal-oferta-expires');
            var modalEl = document.getElementById('modal-oferta-expires');
            var modalForm = document.getElementById('form-oferta-modal');
            var btnChange = document.getElementById('precotizacion-oferta-change-expires');
            var dateInput = document.getElementById('precotizacion-oferta-expires');
            if (!chk || !modalEl) return;
            var modalMode = 'first';
            var savingFromModal = false;
            var minFirst = dateInput && dateInput.getAttribute('data-min-first') ? dateInput.getAttribute('data-min-first') : '';

            if (modalForm) {
                modalForm.addEventListener('submit', function() {
                    savingFromModal = true;
                });
            }
            modalEl.addEventListener('show.bs.modal', function() {
                if (!dateInput) return;
                if (modalMode === 'edit') {
                    dateInput.removeAttribute('min');
                } else if (minFirst) {
                    dateInput.setAttribute('min', minFirst);
                }
            });
            modalEl.addEventListener('hide.bs.modal', function() {
                if (savingFromModal) {
                    savingFromModal = false;
                    return;
                }
                if (modalMode === 'edit') {
                    modalMode = 'first';
                    return;
                }
                if (!chk.checked) return;
                chk.checked = false;
                var fm = document.getElementById('form-oferta');
                if (fm) fm.submit();
            });
            chk.addEventListener('change', function() {
                if (this.checked) {
                    modalMode = 'first';
                    if (triggerBtn) triggerBtn.click();
                } else {
                    var fm = document.getElementById('form-oferta');
                    if (fm) fm.submit();
                }
            });
            if (btnChange) {
                btnChange.addEventListener('click', function() {
                    modalMode = 'edit';
                    if (triggerBtn) triggerBtn.click();
                });
            }
        })();
        </script>
        <?php elseif ((!$canEditDocument || $precotizacionLocked) && !empty($this->showOfertaCheckbox)) : ?>
        <div class="d-flex flex-wrap align-items-center gap-2 gap-md-3">
            <div class="form-check mb-0">
                <input type="checkbox" class="form-check-input" id="precotizacion-oferta-display" disabled <?php echo $ofertaChecked ? ' checked' : ''; ?>>
                <label class="form-check-label text-muted" for="precotizacion-oferta-display"><?php echo htmlspecialchars($labelOferta); ?></label>
            </div>
            <?php if ($canShowOfertaExpiry) : ?>
            <span class="precotizacion-oferta-expires-preview small text-muted mb-0">
                <span class="text-body-secondary"><?php echo htmlspecialchars($labelOfertaExpires); ?>:</span>
                <?php if ($ofertaExpiresDisplay !== '') : ?>
                    <strong class="text-body"><?php echo htmlspecialchars($ofertaExpiresDisplay); ?></strong>
                <?php else : ?>
                    <span class="text-muted">—</span>
                <?php endif; ?>
            </span>
            <?php endif; ?>
        </div>
        <?php elseif (!empty($item->oferta) && property_exists($item, 'oferta_expires')) : ?>
        <div class="d-flex flex-wrap align-items-center gap-2 gap-md-3">
            <span class="badge bg-info text-dark"><?php echo htmlspecialchars($labelOferta); ?></span>
            <span class="precotizacion-oferta-expires-preview small text-muted mb-0">
                <span class="text-body-secondary"><?php echo htmlspecialchars($labelOfertaExpires); ?>:</span>
                <?php if ($ofertaExpiresDisplay !== '') : ?>
                    <strong class="text-body"><?php echo htmlspecialchars($ofertaExpiresDisplay); ?></strong>
                <?php else : ?>
                    <span class="text-muted">—</span>
                <?php endif; ?>
            </span>
        </div>
        <?php endif; ?>
        <?php if ($precotizacionLocked || !$canEditDocument) : ?>
        <div class="form-check">
            <input type="checkbox" class="form-check-input" id="precotizacion-facturar-display" disabled <?php echo $facturarChecked ? ' checked' : ''; ?>>
            <label class="form-check-label" for="precotizacion-facturar-display"><?php echo htmlspecialchars($labelFacturar); ?></label>
        </div>
        <?php else : ?>
        <form action="<?php echo htmlspecialchars($saveFacturarUrl); ?>" method="post" class="d-inline mb-0" id="form-facturar">
            <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>">
            <?php echo HTMLHelper::_('form.token'); ?>
            <div class="form-check mb-0">
                <input type="checkbox" class="form-check-input" name="facturar" id="precotizacion-facturar" value="1" <?php echo $facturarChecked ? ' checked' : ''; ?> onchange="this.form.submit();">
                <label class="form-check-label" for="precotizacion-facturar"><?php echo htmlspecialchars($labelFacturar); ?></label>
            </div>
        </form>
        <?php endif; ?>
    </div>

    <div class="mb-3 d-flex flex-wrap align-items-center gap-2 precotizacion-doc-toolbar">
        <?php if ($canEditDocument) : ?>
        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#pliegoLineModal">
            <?php echo htmlspecialchars($labelCalculoFolios); ?>
        </button>
        <button type="button" class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#elementosLineModal">
            <?php echo htmlspecialchars($labelOtrosElementos); ?>
        </button>
        <button type="button" class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#tercerizadoLineModal" id="btnTercerizadoLineOpen">
            <?php echo htmlspecialchars($labelProductoTercerizado); ?>
        </button>
        <?php if (!empty($envios)) : ?>
        <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#envioLineModal">
            <?php echo htmlspecialchars($labelAnadirEnvio); ?>
        </button>
        <?php endif; ?>
        <?php if ($canEditDocument && $tarjetaCreditoTableOk && !empty($tarjetaCreditoRates)) : ?>
        <form method="post" action="<?php echo htmlspecialchars($saveTarjetaUrl); ?>" class="d-inline-flex align-items-center gap-2 mb-0">
            <?php echo HTMLHelper::_('form.token'); ?>
            <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>" />
            <label for="precotizacion-tarjeta-cuotas" class="small text-muted mb-0 text-nowrap"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TARJETA_LABEL'); ?></label>
            <select name="tarjeta_cuotas" id="precotizacion-tarjeta-cuotas" class="form-select form-select-sm" style="min-width: 220px; max-width: 280px;" onchange="this.form.submit()">
                <option value="0"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TARJETA_NONE'); ?></option>
                <?php foreach ($tarjetaCreditoRates as $tcRow) :
                    $cq = (int) ($tcRow->cuotas ?? 0);
                    $tp = isset($tcRow->tasa_percent) ? (float) $tcRow->tasa_percent : 0.0;
                    if ($cq < 1) {
                        continue;
                    }
                    ?>
                <option value="<?php echo $cq; ?>"<?php echo $tcCuotasSel === $cq ? ' selected' : ''; ?>>
                    <?php echo Text::sprintf('COM_ORDENPRODUCCION_PRE_COTIZACION_TARJETA_OPTION', $cq, number_format($tp, 2)); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </form>
        <?php endif; ?>
        <?php endif; ?>
    </div>

    <h2 class="h5 mt-4"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_LINES'); ?></h2>

    <?php if (empty($lines)) : ?>
        <p class="text-muted"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_NO_LINES'); ?></p>
        <p class="mb-0 text-end"><strong><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TOTAL'); ?>:</strong> Q <?php echo number_format(0, 2); ?></p>
    <?php else : ?>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <?php if ($hasExpandablePliegoLines) : ?>
                        <th class="text-center precot-line-expand-col" style="width: 3.25rem;" scope="col">
                            <span class="visually-hidden"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_VER_DETALLE'); ?></span>
                        </th>
                        <?php endif; ?>
                        <th><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TIPO_ELEMENTO'); ?></th>
                        <th><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_LINE_QUANTITY'); ?></th>
                        <th><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_COL_ELEMENTO'); ?></th>
                        <th><?php echo Text::_('COM_ORDENPRODUCCION_QUOTE_SIZE'); ?></th>
                        <th>Tiro/Retiro</th>
                        <th class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_LINE_TOTAL'); ?></th>
                        <th class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_ACTIONS'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($lines as $line) :
                        $deleteLineUrl = 'index.php?option=com_ordenproduccion&task=precotizacion.deleteLine&line_id=' . (int) $line->id . '&id=' . $preCotizacionId;
                        $isEnvio = isset($line->line_type) && $line->line_type === 'envio';
                        $isTercerizado = isset($line->line_type) && $line->line_type === 'tercerizado';
                        $isElemento = !$isEnvio && !$isTercerizado && isset($line->line_type) && $line->line_type === 'elementos' && !empty($line->elemento_id);
                        $isPliegoQuoteLine = $precotModelDoc && $precotModelDoc->isPliegoQuoteLine($line);
                        $lineDetailExpanded = $autoExpandPliegoLineDetails && $isPliegoQuoteLine;
                        if ($isEnvio) {
                            $paperName = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ENVIO_LABEL');
                            if (strpos($paperName, 'COM_ORDENPRODUCCION_') === 0) {
                                $paperName = 'Envío';
                            }
                            $envioName = isset($line->envio_name) ? (string) $line->envio_name : '';
                            if ($envioName !== '') {
                                $paperName .= ': ' . $envioName;
                            }
                            $sizeName = '—';
                        } elseif ($isTercerizado) {
                            $paperName = isset($line->tercerizado_producto) ? trim((string) $line->tercerizado_producto) : '';
                            if ($paperName === '') {
                                $paperName = '—';
                            }
                            $sizeName = '—';
                        } elseif ($isElemento && !$isPliegoQuoteLine && isset($elementosById[(int) $line->elemento_id])) {
                            $el = $elementosById[(int) $line->elemento_id];
                            $paperName = $el->name ?? '';
                            $sizeName = $el->size ?? '—';
                        } else {
                            $paperName = $paperNames[$line->paper_type_id ?? 0] ?? ('ID ' . (int) $line->paper_type_id);
                            $sizeName = $sizeNames[$line->size_id ?? 0] ?? ('ID ' . (int) $line->size_id);
                        }
                        $lineJson = ($isEnvio || $isTercerizado) ? '' : htmlspecialchars(json_encode([
                            'id' => (int) $line->id,
                            'tipo_elemento' => isset($line->tipo_elemento) ? (string) $line->tipo_elemento : '',
                            'quantity' => (int) $line->quantity,
                            'paper_type_id' => (int) $line->paper_type_id,
                            'size_id' => (int) $line->size_id,
                            'tiro_retiro' => $line->tiro_retiro ?? 'tiro',
                            'lamination_type_id' => $line->lamination_type_id ? (int) $line->lamination_type_id : null,
                            'lamination_tiro_retiro' => $line->lamination_tiro_retiro ?? 'tiro',
                            'barniz_tiro_retiro' => !empty($line->barniz_tiro_retiro) ? (string) $line->barniz_tiro_retiro : null,
                            'process_ids' => $line->process_ids_array ?? [],
                            'price_per_sheet' => (float) $line->price_per_sheet,
                            'total' => (float) $line->total,
                            'breakdown' => $line->breakdown ?? [],
                        ]), ENT_QUOTES, 'UTF-8');
                        $tipoElemento = isset($line->tipo_elemento) && trim((string) $line->tipo_elemento) !== '' ? trim((string) $line->tipo_elemento) : '—';
                        $terImportePend = $isTercerizado && !empty($line->tercerizado_importe_pendiente);
                        ?>
                        <tr class="line-data-row">
                            <?php if ($hasExpandablePliegoLines) : ?>
                            <td class="text-center align-middle p-1 precot-line-expand-col">
                                <?php if ($isPliegoQuoteLine) : ?>
                                <button type="button"
                                    class="btn btn-sm btn-outline-primary toggle-line-detail px-2 py-1"
                                    data-detail-id="line-detail-<?php echo (int) $line->id; ?>"
                                    aria-expanded="<?php echo $lineDetailExpanded ? 'true' : 'false'; ?>"
                                    title="<?php echo htmlspecialchars($lineDetailExpanded ? Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_OCULTAR_DETALLE') : Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_VER_DETALLE'), ENT_QUOTES, 'UTF-8'); ?>">
                                    <i class="fas fa-chevron-<?php echo $lineDetailExpanded ? 'up' : 'down'; ?> toggle-detail-icon" aria-hidden="true"></i>
                                    <span class="visually-hidden toggle-detail-label"><?php echo $lineDetailExpanded ? Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_OCULTAR_DETALLE') : Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_VER_DETALLE'); ?></span>
                                </button>
                                <?php endif; ?>
                            </td>
                            <?php endif; ?>
                            <td><?php if ($terImportePend && $canSetTercerizadoImporte) : ?>
                                <span class="text-warning me-1" title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_TERCERIZADO_IMPORTE_PENDIENTE_HINT'), ENT_QUOTES, 'UTF-8'); ?>"><i class="fas fa-circle-exclamation" aria-hidden="true"></i></span>
                                <?php endif; ?><?php echo htmlspecialchars($tipoElemento); ?></td>
                            <td><?php echo (int) $line->quantity; ?></td>
                            <td><?php echo $isEnvio ? htmlspecialchars($paperName) : (($isElemento && !$isPliegoQuoteLine) || $isTercerizado ? htmlspecialchars($paperName) : htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_FOLIOS_PREFIX') . ' ' . $paperName)); ?></td>
                            <td><?php echo htmlspecialchars($sizeName); ?></td>
                            <td><?php echo ($isEnvio || $isTercerizado) ? '—' : (($isElemento && !$isPliegoQuoteLine) ? '—' : (($line->tiro_retiro ?? '') === 'retiro' ? 'Tiro/Retiro' : 'Tiro')); ?></td>
                            <td class="text-end precot-line-total-cell" data-line-id="<?php echo (int) $line->id; ?>"><span class="precot-line-total-amt">Q <?php echo number_format((float) $line->total, 2); ?></span></td>
                            <td class="text-end">
                                <?php if ($canEditDocument) : ?>
                                    <?php if ($isPliegoQuoteLine) : ?>
                                    <button type="button" class="btn btn-sm btn-outline-primary pliego-edit-line-btn" data-line="<?php echo $lineJson; ?>">
                                        <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_EDIT_LINE'); ?>
                                    </button>
                                    <?php endif; ?>
                                    <?php if ($isTercerizado) :
                                        $teEd = isset($line->tipo_elemento) ? (string) $line->tipo_elemento : '';
                                        $prEd = isset($line->tercerizado_producto) ? (string) $line->tercerizado_producto : '';
                                        $toEd = isset($line->total) ? (float) $line->total : 0;
                                        $pendEd = !empty($line->tercerizado_importe_pendiente) ? '1' : '0';
                                        ?>
                                    <button type="button" class="btn btn-sm btn-outline-primary tercerizado-edit-line-btn"
                                        data-line-id="<?php echo (int) $line->id; ?>"
                                        data-tipo-elemento="<?php echo htmlspecialchars($teEd, ENT_QUOTES, 'UTF-8'); ?>"
                                        data-tercerizado-producto="<?php echo htmlspecialchars($prEd, ENT_QUOTES, 'UTF-8'); ?>"
                                        data-total="<?php echo htmlspecialchars(number_format($toEd, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>"
                                        data-importe-pendiente="<?php echo htmlspecialchars($pendEd, ENT_QUOTES, 'UTF-8'); ?>">
                                        <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_EDIT_LINE'); ?>
                                    </button>
                                    <?php endif; ?>
                                    <form action="<?php echo Route::_($deleteLineUrl); ?>" method="post" class="d-inline" onsubmit="return confirm('<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_CONFIRM_DELETE_LINE')); ?>');">
                                        <?php echo HTMLHelper::_('form.token'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger"><?php echo Text::_('JACTION_DELETE'); ?></button>
                                    </form>
                                <?php elseif ($isElemento || $isEnvio || $isTercerizado) : ?>
                                    —
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php if ($isPliegoQuoteLine) : ?>
                        <tr id="line-detail-<?php echo (int) $line->id; ?>" class="line-detail-row"<?php echo $lineDetailExpanded ? '' : ' style="display:none;"'; ?>>
                            <td colspan="<?php echo (int) $linesTableColspan; ?>" class="p-0 bg-light align-top">
                                <div class="p-2">
                                    <?php
                                    $precotRowModel = $this->precotizacionModel ?? null;
                                    $breakdown = $precotRowModel
                                        ? $precotRowModel->resolvePliegoBreakdownForLine($line)
                                        : ($line->breakdown ?? []);
                                    $hasBreakdownOverrideCols = false;
                                    if ($canAdjustLineSubtotals && $precotRowModel && $breakdown !== []) {
                                        foreach ($breakdown as $bi => $_br) {
                                            if ($precotRowModel->getBreakdownRowAdjustmentMeta($line, (int) $bi) !== null) {
                                                $hasBreakdownOverrideCols = true;
                                                break;
                                            }
                                            if ($canReviewDiscountApproval && $pendingSolicitudDescuento) {
                                                $stChk = round((float) ($_br['subtotal'] ?? 0), 2);
                                                if ($stChk > 0) {
                                                    $hasBreakdownOverrideCols = true;
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    $precotBreakdownFixedSubtotal = 0.0;
                                    if ($showLineBreakdownDetail && $hasBreakdownOverrideCols && $precotRowModel) {
                                        foreach ($breakdown as $biFix => $rowFix) {
                                            if ($precotRowModel->getBreakdownRowAdjustmentMeta($line, (int) $biFix) === null) {
                                                $precotBreakdownFixedSubtotal += (float) ($rowFix['subtotal'] ?? 0);
                                            }
                                        }
                                    }
                                    ?>
                                    <table class="table table-sm table-bordered mb-0 precot-pliego-breakdown-table" style="max-width: 920px;"
                                        data-precot-line-id="<?php echo (int) $line->id; ?>"
                                        data-precot-fixed-subtotal="<?php echo htmlspecialchars(number_format($precotBreakdownFixedSubtotal, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>">
                                        <?php if ($showLineBreakdownDetail) : ?>
                                        <thead>
                                            <tr>
                                                <th><?php echo Text::_('COM_ORDENPRODUCCION_CALC_COL_ITEM'); ?></th>
                                                <th class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_CALC_COL_DETAIL'); ?></th>
                                                <th class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_CALC_COL_SUBTOTAL'); ?></th>
                                                <?php if ($hasBreakdownOverrideCols) : ?>
                                                <th class="text-end text-nowrap"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_ROW_OVERRIDE_COL_MIN'); ?></th>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($breakdown as $bi => $row) :
                                                $label = isset($row['label']) ? htmlspecialchars($row['label']) : '';
                                                $detail = isset($row['detail']) ? htmlspecialchars($row['detail']) : '';
                                                $subtotal = isset($row['subtotal']) ? number_format((float) $row['subtotal'], 2) : '0.00';
                                                $rowMeta = ($hasBreakdownOverrideCols && $precotRowModel)
                                                    ? $precotRowModel->getBreakdownRowAdjustmentMeta($line, (int) $bi)
                                                    : null;
                                                if ($rowMeta === null && $hasBreakdownOverrideCols && $canReviewDiscountApproval && $pendingSolicitudDescuento) {
                                                    $stAdj = isset($row['subtotal']) ? round((float) $row['subtotal'], 2) : 0.0;
                                                    if ($stAdj > 0) {
                                                        $rowMeta = [
                                                            'base'    => $stAdj,
                                                            'min'     => round($stAdj * 0.6, 2),
                                                            'current' => $stAdj,
                                                        ];
                                                    }
                                                }
                                            ?>
                                                <tr>
                                                    <td><?php echo $label; ?></td>
                                                    <td class="text-end"><?php echo $detail; ?></td>
                                                    <?php if ($rowMeta !== null) :
                                                        $rBase = $rowMeta['base'];
                                                        $rMin  = $rowMeta['min'];
                                                        $rCur  = $rowMeta['current'];
                                                        $overrideInputId = 'breakdown-override-' . (int) $line->id . '-' . (int) $bi;
                                                    ?>
                                                    <td class="text-end align-middle">
                                                        <div class="breakdown-row-override-wrap text-end"
                                                            data-line-id="<?php echo (int) $line->id; ?>"
                                                            data-breakdown-index="<?php echo (int) $bi; ?>"
                                                            data-base="<?php echo htmlspecialchars((string) $rBase, ENT_QUOTES, 'UTF-8'); ?>"
                                                            data-min="<?php echo htmlspecialchars((string) $rMin, ENT_QUOTES, 'UTF-8'); ?>">
                                                            <input type="number" step="0.01" min="<?php echo htmlspecialchars((string) $rMin, ENT_QUOTES, 'UTF-8'); ?>" max="<?php echo htmlspecialchars((string) $rBase, ENT_QUOTES, 'UTF-8'); ?>"
                                                                class="form-control form-control-sm breakdown-row-override-input d-inline-block" style="max-width: 7.5rem;"
                                                                id="<?php echo htmlspecialchars($overrideInputId, ENT_QUOTES, 'UTF-8'); ?>"
                                                                value="<?php echo htmlspecialchars(number_format($rCur, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>"
                                                                inputmode="decimal"
                                                                title="<?php echo htmlspecialchars(Text::sprintf('COM_ORDENPRODUCCION_PRE_COT_IMPRESION_OVERRIDE_HELP', number_format($rMin, 2), number_format($rBase, 2)), ENT_QUOTES, 'UTF-8'); ?>" />
                                                            <div class="text-danger small breakdown-row-override-warning mt-1 d-none text-start" role="alert"></div>
                                                        </div>
                                                    </td>
                                                    <td class="text-end align-middle">Q <?php echo number_format($rMin, 2); ?></td>
                                                    <?php elseif ($hasBreakdownOverrideCols) : ?>
                                                    <td class="text-end">Q <?php echo $subtotal; ?></td>
                                                    <td class="text-end text-muted">—</td>
                                                    <?php else : ?>
                                                    <td class="text-end">Q <?php echo $subtotal; ?></td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr class="table-secondary fw-bold">
                                                <td colspan="2"><?php echo Text::_('COM_ORDENPRODUCCION_CALC_TOTAL'); ?></td>
                                                <td class="text-end precot-line-detail-total" data-for-line-id="<?php echo (int) $line->id; ?>"><span class="precot-line-detail-total-amt">Q <?php echo number_format((float) $line->total, 2); ?></span></td>
                                                <?php if ($hasBreakdownOverrideCols) : ?>
                                                <td></td>
                                                <?php endif; ?>
                                            </tr>
                                        </tfoot>
                                        <?php else : ?>
                                        <thead>
                                            <tr>
                                                <th><?php echo Text::_('COM_ORDENPRODUCCION_CALC_COL_ITEM'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($breakdown as $row) :
                                                $label = isset($row['label']) ? htmlspecialchars($row['label']) : '';
                                            ?>
                                                <tr>
                                                    <td><?php echo $label; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr class="table-secondary fw-bold">
                                                <td><?php echo Text::_('COM_ORDENPRODUCCION_CALC_TOTAL'); ?></td>
                                            </tr>
                                        </tfoot>
                                        <?php endif; ?>
                                    </table>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    <?php
                    $showApproverDiscountActions = !empty($canAdjustLineSubtotals)
                        && (!empty($hasAnyBreakdownOverrideRows) || !empty($pendingSolicitudDescuento));
                    ?>
                    <?php if ($showApproverDiscountActions) : ?>
                    <tr class="precotizacion-breakdown-batch-save-row">
                        <td colspan="<?php echo (int) $linesTableColspan; ?>" class="bg-light border-top py-3 text-end">
                            <div class="d-inline-flex flex-wrap justify-content-end gap-2">
                                <?php if (!empty($pendingSolicitudDescuento)) : ?>
                                <button type="button" id="precotizacion-reject-sin-descuento" class="btn btn-outline-danger">
                                    <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_REJECT_SIN_DESCUENTO_BTN'); ?>
                                </button>
                                <?php endif; ?>
                                <?php if (!empty($hasAnyBreakdownOverrideRows)) : ?>
                                <button type="button" id="precotizacion-save-all-breakdown-subtotals" class="btn btn-primary">
                                    <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_BREAKDOWN_BATCH_SAVE_BTN'); ?>
                                </button>
                                <?php endif; ?>
                            </div>
                            <div class="text-danger small mt-2 d-none text-end" id="precotizacion-breakdown-batch-msg" role="alert"></div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <?php $tfootLabelSpan = $hasExpandablePliegoLines ? 6 : 5; ?>
                    <tr>
                        <td colspan="<?php echo $tfootLabelSpan; ?>" class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_SUBTOTAL'); ?></td>
                        <td class="text-end"><span id="precot-footer-subtotal">Q <?php echo number_format($linesSubtotal, 2); ?></span></td>
                        <td></td>
                    </tr>
                    <?php $margenTotal = $margenAmount + $margenAdicional; ?>
                    <?php if ($precotFooterShowIva) : ?>
                    <tr>
                        <td colspan="<?php echo $tfootLabelSpan; ?>" class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_PARAM_IVA'); ?><?php echo $paramIva != 0 ? ' (' . number_format($paramIva, 1) . '%)' : ''; ?></td>
                        <td class="text-end"><span id="precot-footer-iva-amt">Q <?php echo number_format($ivaAmount, 2); ?></span></td>
                        <td></td>
                    </tr>
                    <?php endif; ?>
                    <?php if ($precotFooterShowIsr) : ?>
                    <tr>
                        <td colspan="<?php echo $tfootLabelSpan; ?>" class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_PARAM_ISR'); ?><?php echo $paramIsr != 0 ? ' (' . number_format($paramIsr, 1) . '%)' : ''; ?></td>
                        <td class="text-end"><span id="precot-footer-isr-amt">Q <?php echo number_format($isrAmount, 2); ?></span></td>
                        <td></td>
                    </tr>
                    <?php endif; ?>
                    <?php if ($paramComision != 0) : ?>
                    <tr>
                        <td colspan="<?php echo $tfootLabelSpan; ?>" class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_BONO_VENTA'); ?> (<?php echo number_format($paramComision, 1); ?>%)</td>
                        <td class="text-end"><span id="precot-footer-bono-amt">Q <?php echo number_format($comisionAmount, 2); ?></span></td>
                        <td></td>
                    </tr>
                    <?php endif; ?>
                    <?php if ($canSeePrecotInternalTax && $paramMargen != 0) : ?>
                    <tr class="margen-total-row">
                        <td colspan="<?php echo $tfootLabelSpan; ?>" class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_PARAM_MARGEN_GANANCIA'); ?> (<?php echo htmlspecialchars($precotMargenPctText, ENT_QUOTES, 'UTF-8'); ?>%)</td>
                        <td class="text-end"><span id="precot-footer-margen-amt">Q <?php echo number_format($margenAmount, 2, '.', ''); ?></span></td>
                        <td></td>
                    </tr>
                    <tr class="margen-total-row">
                        <td colspan="<?php echo $tfootLabelSpan; ?>" class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_MARGEN_ADICIONAL'); ?></td>
                        <td class="text-end"><span id="precot-footer-margen-adicional-amt">Q <?php echo number_format($margenAdicional, 2, '.', ''); ?></span></td>
                        <td></td>
                    </tr>
                    <?php endif; ?>
                    <?php if ($margenAdicional > 0) : ?>
                    <tr>
                        <td colspan="<?php echo $tfootLabelSpan; ?>" class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_MARGEN_TOTAL'); ?></td>
                        <td class="text-end"><span id="precot-footer-margen-combined">Q <?php echo \number_format($margenTotal, 2, '.', ''); ?></span></td>
                        <td></td>
                    </tr>
                    <?php endif; ?>
                    <tr class="table-secondary fw-bold">
                        <td colspan="<?php echo $tfootLabelSpan; ?>" class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TOTAL'); ?></td>
                        <td class="text-end"><span id="precot-footer-grand-total">Q <?php echo number_format($displayTotal, 2); ?></span></td>
                        <td></td>
                    </tr>
                    <?php if ($tcCuotasSel > 0 && $totalConTarjeta !== null && $totalConTarjeta > 0) : ?>
                    <tr>
                        <td colspan="<?php echo $tfootLabelSpan; ?>" class="text-end">
                            <?php echo Text::sprintf('COM_ORDENPRODUCCION_PRE_COTIZACION_TARJETA_CARGO_ROW', $tcCuotasSel, number_format($tcTasa, 2)); ?>
                        </td>
                        <td class="text-end">Q <?php echo number_format($tcMonto, 2); ?></td>
                        <td></td>
                    </tr>
                    <tr class="table-primary fw-bold">
                        <td colspan="<?php echo $tfootLabelSpan; ?>" class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TOTAL_CON_TARJETA'); ?></td>
                        <td class="text-end">Q <?php echo number_format($totalConTarjeta, 2); ?></td>
                        <td></td>
                    </tr>
                    <?php endif; ?>
                    <?php if ($comisionMargenAdicionalAmount > 0) : ?>
                    <?php $totalComision = $comisionAmount + $comisionMargenAdicionalAmount; ?>
                    <tr class="comision-margen-adicional-row">
                        <td colspan="<?php echo $tfootLabelSpan; ?>" class="text-end">
                            <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_COMISION_MARGEN_ADICIONAL'); ?>
                            (<?php echo htmlspecialchars($precotComisionMaPctText, ENT_QUOTES, 'UTF-8'); ?>%) = Q.<span id="precot-footer-comision-ma-dot"><?php echo \number_format($comisionMargenAdicionalAmount, 2, '.', ''); ?></span>
                            &mdash;
                            <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TOTAL_COMISION'); ?>
                        </td>
                        <td class="text-end"><span id="precot-footer-total-comision-sum"><?php echo 'Q ' . \number_format($totalComision, 2, '.', ''); ?></span></td>
                        <td></td>
                    </tr>
                    <?php endif; ?>
                </tfoot>
            </table>
        </div>
        <style>
        .comision-margen-adicional-row td { background-color: #e7f1ff !important; color: #004085; font-weight: 500; }
        .margen-total-row td { background-color: #d4edda !important; color: #155724; font-weight: 500; }
        </style>
    <?php
    if (!empty($lines) && !empty($showLineBreakdownDetail) && (!empty($hasAnyBreakdownOverrideRows) || ($canReviewDiscountApproval && $pendingSolicitudDescuento && $canAdjustLineSubtotals))) {
        $precotLt = [];
        foreach ($lines as $_ln) {
            $precotLt[(string) (int) $_ln->id] = round((float) ($_ln->total ?? 0), 2);
        }
        $precotJsLiveTotalsPayload = [
            'facturar' => (bool) $facturar,
            'paramMargen' => (float) $paramMargen,
            'paramIva' => (float) $paramIva,
            'paramIsr' => (float) $paramIsr,
            'paramComision' => (float) $paramComision,
            'margenAdicional' => (float) $margenAdicional,
            'lineTotals' => $precotLt,
            'showMargenRow' => $canSeePrecotInternalTax && $paramMargen != 0,
            'showIvaRow' => (bool) $precotFooterShowIva,
            'showIsrRow' => (bool) $precotFooterShowIsr,
            'showBonoRow' => $paramComision != 0,
            'showComisionMaRow' => $comisionMargenAdicionalAmount > 0,
            'comisionMargenAdicionalAmount' => (float) $comisionMargenAdicionalAmount,
            'showMargenTotalBreakdownRow' => $margenAdicional > 0,
        ];
    }
    ?>
    <?php endif; ?>

    <?php
    $userCreCotModal = Factory::getUser();
    $cotDestUrlModal = trim((string) ComponentHelper::getParams('com_ordenproduccion')->get('cotizacion_destination_url', ''));
    // Igual que id= en el documento PRE: PK de pre_cotización, no el número PRE-xxxxxx.
    $preCotizacionIdParaCotUrl = (int) $preCotizacionId;
    if (!$userCreCotModal->guest && $cotDestUrlModal !== '') {
        include __DIR__ . '/crear_cotizacion_modal.php';
    }
    ?>

    <?php if ($discountWorkflowAvailable) : ?>
    <div class="mt-3 text-end precotizacion-discount-footer">
        <?php if ($solicitudDescuentoLatestNote !== '' && !$showDiscountApprovalBanner) : ?>
        <div class="text-start ms-auto mb-3" style="max-width: 42rem; margin-left: auto !important;">
            <div class="small text-muted mb-1"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_DESCUENTO_NOTE_LABEL'); ?></div>
            <div class="border rounded p-2 bg-light small text-body"><?php echo nl2br(htmlspecialchars($solicitudDescuentoLatestNote, ENT_QUOTES, 'UTF-8')); ?></div>
        </div>
        <?php endif; ?>
        <div class="d-inline-flex flex-wrap justify-content-end align-items-center gap-2">
            <?php if ($canRequestSolicitudDescuento) : ?>
            <button type="button" class="btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#precotizacionSolicitarDescuentoModal">
                <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_SOLICITAR_DESCUENTO_BTN'); ?>
            </button>
            <?php elseif ($pendingSolicitudDescuento) : ?>
            <span class="badge bg-warning text-dark"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_DESCUENTO_PENDING_BADGE'); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <?php if ($canRequestSolicitudDescuento) : ?>
    <div class="modal fade" id="precotizacionSolicitarDescuentoModal" tabindex="-1" aria-labelledby="precotizacionSolicitarDescuentoModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="post" action="<?php echo htmlspecialchars($solicitarDescuentoAction, ENT_QUOTES, 'UTF-8'); ?>">
                    <div class="modal-header">
                        <h5 class="modal-title" id="precotizacionSolicitarDescuentoModalLabel"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_SOLICITAR_DESCUENTO_MODAL_TITLE'); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo Text::_('JCANCEL'); ?>"></button>
                    </div>
                    <div class="modal-body text-start">
                        <input type="hidden" name="option" value="com_ordenproduccion" />
                        <input type="hidden" name="task" value="precotizacion.solicitarDescuento" />
                        <?php echo HTMLHelper::_('form.token'); ?>
                        <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>" />
                        <label for="discount_request_note" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_SOLICITAR_DESCUENTO_NOTE_FIELD'); ?></label>
                        <textarea class="form-control" name="discount_request_note" id="discount_request_note" rows="4" maxlength="2000" required></textarea>
                        <div class="form-text"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_SOLICITAR_DESCUENTO_NOTE_HINT'); ?></div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo Text::_('JCANCEL'); ?></button>
                        <button type="submit" class="btn btn-warning"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_SOLICITAR_DESCUENTO_SUBMIT'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<?php if ($precotJsLiveTotalsPayload !== null) : ?>
<script>
(function() {
    'use strict';
    window.precotLiveCalc = <?php echo json_encode($precotJsLiveTotalsPayload, JSON_UNESCAPED_UNICODE); ?>;
    function precotParseDecimal(el) {
        if (!el) return 0;
        var raw = String(el.value != null ? el.value : el.textContent || '').replace(/,/g, '.').replace(/[^\d.\-]/g, '');
        var v = parseFloat(raw, 10);
        return isNaN(v) ? 0 : v;
    }
    function precotFmtQ(v) {
        return 'Q ' + (Math.round(v * 100) / 100).toFixed(2);
    }
    function recalcPrecotLiveTotals() {
        var cfg = window.precotLiveCalc;
        if (!cfg || !cfg.lineTotals) return;
        var lineTotals = {};
        for (var id in cfg.lineTotals) {
            if (Object.prototype.hasOwnProperty.call(cfg.lineTotals, id)) {
                lineTotals[id] = cfg.lineTotals[id];
            }
        }
        document.querySelectorAll('.precot-pliego-breakdown-table').forEach(function(tbl) {
            if (!tbl.querySelector('.breakdown-row-override-input')) return;
            var lid = tbl.getAttribute('data-precot-line-id');
            if (!lid) return;
            var fixed = precotParseDecimal({ value: tbl.getAttribute('data-precot-fixed-subtotal') });
            var sumOv = 0;
            tbl.querySelectorAll('.breakdown-row-override-input').forEach(function(inp) {
                sumOv += precotParseDecimal(inp);
            });
            lineTotals[lid] = Math.round((fixed + sumOv) * 100) / 100;
        });
        var linesSubtotal = 0;
        for (var k in lineTotals) {
            if (Object.prototype.hasOwnProperty.call(lineTotals, k)) {
                linesSubtotal += lineTotals[k];
            }
        }
        linesSubtotal = Math.round(linesSubtotal * 100) / 100;
        var margenAmount = linesSubtotal * (cfg.paramMargen / 100);
        var ivaAmount = cfg.facturar ? (linesSubtotal * (cfg.paramIva / 100)) : 0;
        var isrAmount = cfg.facturar ? (linesSubtotal * (cfg.paramIsr / 100)) : 0;
        var comisionAmount = linesSubtotal * (cfg.paramComision / 100);
        var linesTotal = linesSubtotal + margenAmount + ivaAmount + isrAmount + comisionAmount;
        linesTotal = Math.round(linesTotal * 100) / 100;
        var displayTotal = Math.round((linesTotal + cfg.margenAdicional) * 100) / 100;
        var margenCombined = Math.round((margenAmount + cfg.margenAdicional) * 100) / 100;
        var el;
        el = document.getElementById('precot-footer-subtotal');
        if (el) el.textContent = precotFmtQ(linesSubtotal);
        el = document.getElementById('precot-footer-margen-amt');
        if (el && cfg.showMargenRow) el.textContent = precotFmtQ(margenAmount);
        el = document.getElementById('precot-footer-margen-adicional-amt');
        if (el && cfg.showMargenRow) el.textContent = precotFmtQ(cfg.margenAdicional);
        el = document.getElementById('precot-footer-margen-combined');
        if (el && cfg.showMargenRow && cfg.showMargenTotalBreakdownRow) el.textContent = precotFmtQ(margenCombined);
        el = document.getElementById('precot-footer-iva-amt');
        if (el && cfg.showIvaRow) el.textContent = precotFmtQ(ivaAmount);
        el = document.getElementById('precot-footer-isr-amt');
        if (el && cfg.showIsrRow) el.textContent = precotFmtQ(isrAmount);
        el = document.getElementById('precot-footer-bono-amt');
        if (el && cfg.showBonoRow) el.textContent = precotFmtQ(comisionAmount);
        el = document.getElementById('precot-footer-grand-total');
        if (el) el.textContent = precotFmtQ(displayTotal);
        if (cfg.showComisionMaRow) {
            var maAmt = Math.round(cfg.comisionMargenAdicionalAmount * 100) / 100;
            var totalComision = Math.round((comisionAmount + cfg.comisionMargenAdicionalAmount) * 100) / 100;
            el = document.getElementById('precot-footer-comision-ma-dot');
            if (el) el.textContent = maAmt.toFixed(2);
            el = document.getElementById('precot-footer-total-comision-sum');
            if (el) el.textContent = precotFmtQ(totalComision);
        }
        for (var lid2 in lineTotals) {
            if (!Object.prototype.hasOwnProperty.call(lineTotals, lid2)) continue;
            var amt = lineTotals[lid2];
            document.querySelectorAll('.precot-line-total-cell[data-line-id="' + lid2 + '"] .precot-line-total-amt').forEach(function(span) {
                span.textContent = precotFmtQ(amt);
            });
            document.querySelectorAll('.precot-line-detail-total[data-for-line-id="' + lid2 + '"] .precot-line-detail-total-amt').forEach(function(span) {
                span.textContent = precotFmtQ(amt);
            });
        }
    }
    document.querySelectorAll('.breakdown-row-override-input').forEach(function(inp) {
        ['input', 'change'].forEach(function(ev) {
            inp.addEventListener(ev, recalcPrecotLiveTotals);
        });
    });
    recalcPrecotLiveTotals();
})();
</script>
<?php endif; ?>

<?php if (!empty($lines)) : ?>
<script>
(function() {
    var verDetalle = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_VER_DETALLE')); ?>;
    var ocultarDetalle = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_OCULTAR_DETALLE')); ?>;
    document.addEventListener('click', function(e) {
        var btn = e.target && e.target.closest && e.target.closest('.toggle-line-detail');
        if (!btn) return;
        var id = btn.getAttribute('data-detail-id');
        if (!id) return;
        var row = document.getElementById(id);
        var label = btn.querySelector('.toggle-detail-label');
        var icon = btn.querySelector('.toggle-detail-icon');
        if (!row || !label) return;
        var isHidden = row.style.display === 'none';
        row.style.display = isHidden ? 'table-row' : 'none';
        btn.setAttribute('aria-expanded', isHidden ? 'true' : 'false');
        label.textContent = isHidden ? ocultarDetalle : verDetalle;
        if (icon) {
            icon.classList.remove(isHidden ? 'fa-chevron-down' : 'fa-chevron-up');
            icon.classList.add(isHidden ? 'fa-chevron-up' : 'fa-chevron-down');
        }
        btn.setAttribute('title', isHidden ? ocultarDetalle : verDetalle);
    });
})();
</script>
<?php endif; ?>

<?php
$showApproverDiscountActionsJs = !empty($lines) && !empty($canAdjustLineSubtotals)
    && (!empty($hasAnyBreakdownOverrideRows) || !empty($pendingSolicitudDescuento));
?>
<?php if ($showApproverDiscountActionsJs) : ?>
<script>
(function() {
    var batchUrl = <?php echo json_encode($saveBreakdownBatchUrl); ?>;
    var rejectUrl = <?php echo json_encode($rejectSinDescuentoUrl); ?>;
    var tokenName = <?php echo json_encode($token); ?>;
    var preCotId = <?php echo (int) $preCotizacionId; ?>;
    var msgBelow = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_IMPRESION_OVERRIDE_CLIENT_BELOW')); ?>;
    var msgAbove = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_IMPRESION_OVERRIDE_CLIENT_ABOVE')); ?>;
    var msgErr = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_IMPRESION_OVERRIDE_SAVE_ERROR')); ?>;
    var msgDiscountDone = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_BREAKDOWN_BATCH_DISCOUNT_COMPLETED')); ?>;
    var msgRejectConfirm = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_REJECT_SIN_DESCUENTO_CONFIRM')); ?>;
    var msgRejectDone = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_REJECT_SIN_DESCUENTO_DONE')); ?>;
    function postJsonResponse(r) {
        var status = r.status;
        return r.text().then(function(text) {
            try {
                return JSON.parse(text);
            } catch (e) {
                return { success: false, message: msgErr + (status ? ' (HTTP ' + status + ')' : '') };
            }
        });
    }
    var saveBtn = document.getElementById('precotizacion-save-all-breakdown-subtotals');
    var rejectBtn = document.getElementById('precotizacion-reject-sin-descuento');
    var batchMsg = document.getElementById('precotizacion-breakdown-batch-msg');
    if (rejectBtn) {
        rejectBtn.addEventListener('click', function() {
            if (batchMsg) {
                batchMsg.classList.add('d-none');
                batchMsg.textContent = '';
            }
            if (!window.confirm(msgRejectConfirm)) {
                return;
            }
            var fd = new FormData();
            fd.append('pre_cotizacion_id', String(preCotId));
            fd.append(tokenName, '1');
            rejectBtn.disabled = true;
            if (saveBtn) {
                saveBtn.disabled = true;
            }
            fetch(rejectUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(postJsonResponse)
                .then(function(data) {
                    if (data && data.success) {
                        try { window.alert(msgRejectDone); } catch (e) {}
                        window.location.reload();
                        return;
                    }
                    if (batchMsg) {
                        batchMsg.textContent = (data && data.message) ? data.message : msgErr;
                        batchMsg.classList.remove('d-none');
                    }
                })
                .catch(function() {
                    if (batchMsg) {
                        batchMsg.textContent = msgErr;
                        batchMsg.classList.remove('d-none');
                    }
                })
                .finally(function() {
                    rejectBtn.disabled = false;
                    if (saveBtn) {
                        saveBtn.disabled = false;
                    }
                });
        });
    }
    if (!saveBtn) {
        return;
    }
    saveBtn.addEventListener('click', function() {
        if (batchMsg) {
            batchMsg.classList.add('d-none');
            batchMsg.textContent = '';
        }
        var wraps = document.querySelectorAll('.breakdown-row-override-wrap');
        var items = [];
        var firstWarn = null;
        wraps.forEach(function(wrap) {
            var input = wrap.querySelector('.breakdown-row-override-input');
            var warn = wrap.querySelector('.breakdown-row-override-warning');
            if (!input || !warn) return;
            warn.classList.add('d-none');
            warn.textContent = '';
            var minV = parseFloat(wrap.getAttribute('data-min'), 10);
            var maxV = parseFloat(wrap.getAttribute('data-base'), 10);
            var raw = String(input.value || '').replace(/,/g, '.').replace(/[^\d.\-]/g, '');
            var v = parseFloat(raw, 10);
            if (isNaN(v) || v < minV - 0.0001) {
                warn.textContent = msgBelow;
                warn.classList.remove('d-none');
                firstWarn = firstWarn || warn;
                return;
            }
            if (v > maxV + 0.0001) {
                warn.textContent = msgAbove;
                warn.classList.remove('d-none');
                firstWarn = firstWarn || warn;
                return;
            }
            var lineId = wrap.getAttribute('data-line-id');
            var bIdx = wrap.getAttribute('data-breakdown-index');
            if (bIdx === null || bIdx === '') bIdx = '0';
            items.push({ line_id: parseInt(lineId, 10), breakdown_index: parseInt(bIdx, 10), subtotal: v });
        });
        if (firstWarn) {
            try { firstWarn.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (e) {}
            return;
        }
        if (items.length === 0) {
            if (batchMsg) {
                batchMsg.textContent = msgErr;
                batchMsg.classList.remove('d-none');
            }
            return;
        }
        var fd = new FormData();
        fd.append('pre_cotizacion_id', String(preCotId));
        fd.append('items_json', JSON.stringify(items));
        fd.append(tokenName, '1');
        saveBtn.disabled = true;
        if (rejectBtn) {
            rejectBtn.disabled = true;
        }
        fetch(batchUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
            .then(postJsonResponse)
            .then(function(data) {
                if (data && data.success) {
                    if (data.discount_request_completed && msgDiscountDone) {
                        try { window.alert(msgDiscountDone); } catch (e) {}
                    }
                    window.location.reload();
                    return;
                }
                if (batchMsg) {
                    batchMsg.textContent = (data && data.message) ? data.message : msgErr;
                    batchMsg.classList.remove('d-none');
                }
            })
            .catch(function() {
                if (batchMsg) {
                    batchMsg.textContent = msgErr;
                    batchMsg.classList.remove('d-none');
                }
            })
            .finally(function() {
                saveBtn.disabled = false;
                if (rejectBtn) {
                    rejectBtn.disabled = false;
                }
            });
    });
})();
</script>
<?php endif; ?>

<?php if ($tablesExist) : ?>
<!-- Modal: Cálculo de Folios (Pliego form) -->
<div class="modal fade" id="pliegoLineModal" tabindex="-1" aria-labelledby="pliegoLineModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="pliegoLineModalLabel"><?php echo Text::_('COM_ORDENPRODUCCION_NUEVA_COTIZACION_PLIEGO_TITLE'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="pliego-line-form" method="post" action="<?php echo $addLineTask; ?>" data-add-action="<?php echo htmlspecialchars($addLineTask); ?>" data-edit-action="<?php echo htmlspecialchars($editLineTask); ?>">
                    <?php echo HTMLHelper::_('form.token'); ?>
                    <input type="hidden" name="pre_cotizacion_id" value="<?php echo $preCotizacionId; ?>">
                    <input type="hidden" name="line_id" id="pliego_modal_line_id" value="">
                    <input type="hidden" name="price_per_sheet" id="pliego_modal_price_per_sheet" value="">
                    <input type="hidden" name="total" id="pliego_modal_total" value="">
                    <input type="hidden" name="calculation_breakdown" id="pliego_modal_breakdown" value="">

                    <div class="mb-2">
                        <label for="pliego_modal_tipo_elemento" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TIPO_ELEMENTO'); ?></label>
                        <input type="text" id="pliego_modal_tipo_elemento" name="tipo_elemento" class="form-control" maxlength="255" required autocomplete="off" placeholder="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TIPO_ELEMENTO_PLACEHOLDER'), ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="row mb-2">
                        <div class="col-md-4">
                            <label for="pliego_modal_quantity" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_QUOTE_QUANTITY'); ?></label>
                            <input type="number" id="pliego_modal_quantity" name="quantity" class="form-control" min="1" value="1" required>
                        </div>
                        <div class="col-md-4">
                            <label for="pliego_modal_paper_type" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_QUOTE_PAPER_TYPE'); ?></label>
                            <select id="pliego_modal_paper_type" name="paper_type_id" class="form-select" required>
                                <option value=""><?php echo Text::_('COM_ORDENPRODUCCION_SELECT_PAPER_TYPE'); ?></option>
                                <?php foreach ($paperTypes as $p) : ?>
                                    <option value="<?php echo (int) $p->id; ?>"><?php echo htmlspecialchars($p->name ?? ''); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="pliego_modal_size" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_QUOTE_SIZE'); ?></label>
                            <select id="pliego_modal_size" name="size_id" class="form-select" required>
                                <option value=""><?php echo Text::_('COM_ORDENPRODUCCION_SELECT_SIZE'); ?></option>
                                <?php foreach ($sizes as $s) : ?>
                                    <option value="<?php echo (int) $s->id; ?>"><?php echo htmlspecialchars($s->name ?? ''); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-2">
                        <div class="col-md-6">
                            <div class="form-check">
                                <input type="checkbox" id="pliego_modal_retiro" name="tiro_retiro" value="retiro" class="form-check-input">
                                <label class="form-check-label" for="pliego_modal_retiro"><?php echo Text::_('COM_ORDENPRODUCCION_TIRO_RETIRO'); ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-2">
                        <div class="col-md-6">
                            <div class="form-check">
                                <input type="checkbox" id="pliego_modal_needs_lamination" name="needs_lamination" value="1" class="form-check-input">
                                <label class="form-check-label" for="pliego_modal_needs_lamination"><?php echo Text::_('COM_ORDENPRODUCCION_QUOTE_NEEDS_LAMINATION'); ?></label>
                            </div>
                        </div>
                        <div class="col-md-6" id="pliego_modal_lamination_wrap" style="display:none;">
                            <label for="pliego_modal_lamination_type" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_QUOTE_LAMINATION_TYPE'); ?></label>
                            <select id="pliego_modal_lamination_type" name="lamination_type_id" class="form-select">
                                <option value=""><?php echo Text::_('COM_ORDENPRODUCCION_SELECT_LAMINATION'); ?></option>
                                <?php foreach ($laminationTypes as $l) : ?>
                                    <option value="<?php echo (int) $l->id; ?>"><?php echo htmlspecialchars($l->name ?? ''); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-check mt-1">
                                <input type="checkbox" id="pliego_modal_lamination_retiro" name="lamination_tiro_retiro" value="retiro" class="form-check-input">
                                <label class="form-check-label" for="pliego_modal_lamination_retiro"><?php echo Text::_('COM_ORDENPRODUCCION_LAMINATION_TIRO_RETIRO'); ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-2">
                        <div class="col-md-6">
                            <div class="form-check">
                                <input type="checkbox" id="pliego_modal_needs_barniz" name="needs_barniz" value="1" class="form-check-input">
                                <label class="form-check-label" for="pliego_modal_needs_barniz"><?php echo Text::_('COM_ORDENPRODUCCION_QUOTE_NEEDS_BARNIZ'); ?></label>
                            </div>
                        </div>
                        <div class="col-md-6" id="pliego_modal_barniz_wrap" style="display:none;">
                            <div class="form-check mt-1">
                                <input type="checkbox" id="pliego_modal_barniz_retiro" name="barniz_tiro_retiro" value="retiro" class="form-check-input">
                                <label class="form-check-label" for="pliego_modal_barniz_retiro"><?php echo Text::_('COM_ORDENPRODUCCION_BARNIZ_TIRO_RETIRO'); ?></label>
                            </div>
                        </div>
                    </div>

                    <?php if (!empty($processes)) : ?>
                    <div class="mb-2">
                        <label class="form-label mb-1"><?php echo Text::_('COM_ORDENPRODUCCION_QUOTE_ADDITIONAL_PROCESSES'); ?></label>
                        <div class="row g-1">
                            <?php foreach ($processes as $pr) : ?>
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input type="checkbox" name="process_ids[]" value="<?php echo (int) $pr->id; ?>" id="pliego_modal_proc_<?php echo (int) $pr->id; ?>" class="form-check-input pliego-modal-process-cb">
                                        <label class="form-check-label" for="pliego_modal_proc_<?php echo (int) $pr->id; ?>"><?php echo htmlspecialchars($pr->name ?? ''); ?></label>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="border-top pt-2 mt-2">
                        <p class="mb-1"><strong><?php echo Text::_('COM_ORDENPRODUCCION_QUOTE_PRICE_PER_PLIEGO'); ?>:</strong> <span id="pliego_modal_price_display">-</span></p>
                        <p class="mb-1"><strong><?php echo Text::_('COM_ORDENPRODUCCION_QUOTE_TOTAL'); ?>:</strong> <span id="pliego_modal_total_display">-</span></p>
                        <div id="pliego_modal_calc_detail" class="mt-2 small" style="display:none;">
                            <strong><?php echo Text::_('COM_ORDENPRODUCCION_CALC_DETAIL'); ?></strong>
                            <div class="table-responsive mt-1">
                                <table class="table table-sm table-bordered mb-1" id="pliego_modal_calc_table">
                                    <?php if ($canSeePrecotInternalTax) : ?>
                                    <thead><tr><th><?php echo Text::_('COM_ORDENPRODUCCION_CALC_COL_ITEM'); ?></th><th class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_CALC_COL_DETAIL'); ?></th><th class="text-end" style="min-width:6em;"><?php echo Text::_('COM_ORDENPRODUCCION_CALC_COL_SUBTOTAL'); ?></th></tr></thead>
                                    <tbody id="pliego_modal_calc_body"></tbody>
                                    <tfoot><tr class="table-secondary fw-bold"><td colspan="2"><?php echo Text::_('COM_ORDENPRODUCCION_CALC_TOTAL'); ?></td><td class="text-end" id="pliego_modal_calc_total_cell">—</td></tr></tfoot>
                                    <?php else : ?>
                                    <thead><tr><th><?php echo Text::_('COM_ORDENPRODUCCION_CALC_COL_ITEM'); ?></th></tr></thead>
                                    <tbody id="pliego_modal_calc_body"></tbody>
                                    <tfoot><tr class="table-secondary fw-bold"><td><?php echo Text::_('COM_ORDENPRODUCCION_CALC_TOTAL'); ?></td></tr></tfoot>
                                    <?php endif; ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo Text::_('JCANCEL'); ?></button>
                <button type="button" class="btn btn-primary" id="pliego_modal_submit_btn" disabled><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ADD_LINE_BTN'); ?></button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($showCreacionOtApprovalBanner) : ?>
<!-- Modal: Creación OT — aprobación (fecha + completar / rechazar) -->
<div class="modal fade" id="precotCreacionOtApprovalModal" tabindex="-1" aria-labelledby="precotCreacionOtApprovalModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="precotCreacionOtApprovalModalLabel"><?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_MODAL_TITLE'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo htmlspecialchars(Text::_('JCLOSE'), ENT_QUOTES, 'UTF-8'); ?>"></button>
            </div>
            <div class="modal-body">
                <p class="small text-muted mb-3"><?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_MODAL_INTRO'); ?></p>
                <div class="mb-3">
                    <label for="precotCreacionOtFechaInput" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_FECHA_ENTREGA_LABEL'); ?> <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" id="precotCreacionOtFechaInput" name="ot_fecha_entrega" required
                        value="<?php echo htmlspecialchars($fechaDefaultCreacionOt, ENT_QUOTES, 'UTF-8'); ?>" />
                </div>
                <div id="precotCreacionOtApprovalErr" class="alert alert-danger py-2 small" style="display:none;" role="alert"></div>
            </div>
            <div class="modal-footer flex-wrap gap-2">
                <button type="button" class="btn btn-outline-danger" id="precotCreacionOtRejectBtn"><?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_BTN_REJECT'); ?></button>
                <button type="button" class="btn btn-success" id="precotCreacionOtApproveBtn"><?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_BTN_COMPLETE'); ?></button>
            </div>
        </div>
    </div>
</div>
<script>
(function() {
    var url = <?php echo json_encode($decideCreacionOtUrl, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    var tok = <?php echo json_encode(Session::getFormToken(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    var reqId = <?php echo (int) $pendingCreacionOtReq; ?>;
    var preId = <?php echo (int) $preCotizacionId; ?>;
    var errEl = document.getElementById('precotCreacionOtApprovalErr');
    function showErr(msg) {
        if (!errEl) return;
        errEl.textContent = msg || '';
        errEl.style.display = msg ? 'block' : 'none';
    }
    function postDecision(action) {
        showErr('');
        var fe = document.getElementById('precotCreacionOtFechaInput');
        var fd = new FormData();
        fd.append('request_id', String(reqId));
        fd.append('pre_cotizacion_id', String(preId));
        fd.append('decision', action);
        if (tok) fd.append(tok, '1');
        if (action === 'approve' && fe && fe.value) {
            fd.append('ot_fecha_entrega', String(fe.value));
        }
        var ab = document.getElementById('precotCreacionOtApproveBtn');
        var rb = document.getElementById('precotCreacionOtRejectBtn');
        if (ab) ab.disabled = true;
        if (rb) rb.disabled = true;
        fetch(url, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function(r) { return r.text().then(function(t) { try { return JSON.parse(t); } catch (e) { return { success: false, message: t.substring(0, 200) }; } }); })
            .then(function(data) {
                if (data && data.success && data.redirect_url) {
                    window.location.href = String(data.redirect_url);
                    return;
                }
                var m = (data && data.message) ? data.message : 'Error.';
                showErr(m);
                if (ab) ab.disabled = false;
                if (rb) rb.disabled = false;
            })
            .catch(function() {
                showErr(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_INSTRUCCIONES_MODAL_NETWORK_ERROR'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>);
                if (ab) ab.disabled = false;
                if (rb) rb.disabled = false;
            });
    }
    var abtn = document.getElementById('precotCreacionOtApproveBtn');
    var rbtn = document.getElementById('precotCreacionOtRejectBtn');
    if (abtn) abtn.addEventListener('click', function() {
        var fe = document.getElementById('precotCreacionOtFechaInput');
        if (!fe || !fe.value) {
            showErr(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_OT_WIZARD_STEP3_ERR_FECHA'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>);
            return;
        }
        postDecision('approve');
    });
    if (rbtn) rbtn.addEventListener('click', function() {
        if (!window.confirm(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_REJECT_CONFIRM'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>)) {
            return;
        }
        postDecision('reject');
    });
})();
</script>
<?php endif; ?>

<!-- Modal: Otros Elementos (always shown so "Otros Elementos" button always works) -->
<div class="modal fade" id="elementosLineModal" tabindex="-1" aria-labelledby="elementosLineModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="elementosLineModalLabel"><?php echo htmlspecialchars($labelOtrosElementos); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=precotizacion.addLineElemento'); ?>" method="post" id="elementos-line-form">
                <?php echo HTMLHelper::_('form.token'); ?>
                <input type="hidden" name="pre_cotizacion_id" value="<?php echo $preCotizacionId; ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="elementos_modal_tipo_elemento" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TIPO_ELEMENTO'); ?></label>
                        <input type="text" name="tipo_elemento" id="elementos_modal_tipo_elemento" class="form-control" maxlength="255" required autocomplete="off" placeholder="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TIPO_ELEMENTO_PLACEHOLDER'), ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="elementos_modal_elemento_id" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ELEMENTO_LINE'); ?></label>
                        <select name="elemento_id" id="elementos_modal_elemento_id" class="form-select" required>
                            <option value=""><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_SELECT_ELEMENTO'); ?></option>
                            <?php foreach ($this->elementos ?? [] as $el) : ?>
                                <option value="<?php echo (int) $el->id; ?>"><?php echo htmlspecialchars($el->name ?? ''); ?><?php echo ($el->size ?? '') !== '' ? ' (' . htmlspecialchars($el->size) . ')' : ''; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="elementos_modal_quantity" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_LINE_QUANTITY'); ?></label>
                        <input type="number" name="quantity" id="elementos_modal_quantity" class="form-control" min="1" value="1" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo Text::_('JCANCEL'); ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ADD_ELEMENTO_LINE'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: Servicio tercerizado -->
<div class="modal fade" id="tercerizadoLineModal" tabindex="-1" aria-labelledby="tercerizadoLineModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tercerizadoLineModalLabel"><?php echo htmlspecialchars($labelProductoTercerizado); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=precotizacion.saveLineTercerizado'); ?>" method="post" id="tercerizado-line-form">
                <?php echo HTMLHelper::_('form.token'); ?>
                <input type="hidden" name="pre_cotizacion_id" value="<?php echo (int) $preCotizacionId; ?>">
                <input type="hidden" name="line_id" id="tercerizado_modal_line_id" value="0">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="tercerizado_modal_tipo_elemento" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TIPO_ELEMENTO'); ?></label>
                        <input type="text" name="tipo_elemento" id="tercerizado_modal_tipo_elemento" class="form-control" maxlength="255" required autocomplete="off" placeholder="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TIPO_ELEMENTO_PLACEHOLDER'), ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="tercerizado_modal_producto" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_TERCERIZADO_PRODUCTO_LABEL'); ?></label>
                        <input type="text" name="tercerizado_producto" id="tercerizado_modal_producto" class="form-control" maxlength="512" required autocomplete="off" placeholder="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_TERCERIZADO_PRODUCTO_PLACEHOLDER'), ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <?php if ($canSetTercerizadoImporte) : ?>
                    <div class="mb-3" id="tercerizado-importe-field-wrap">
                        <label for="tercerizado_modal_total" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_TERCERIZADO_IMPORTE'); ?></label>
                        <div class="input-group">
                            <span class="input-group-text">Q</span>
                            <input type="number" name="total" id="tercerizado_modal_total" class="form-control" min="0" step="0.01" value="0.00" required>
                        </div>
                    </div>
                    <?php else : ?>
                    <input type="hidden" name="total" id="tercerizado_modal_total_hidden" value="0">
                    <p class="small text-muted mb-0" id="tercerizado-importe-ventas-note"><?php echo Text::_('COM_ORDENPRODUCCION_TERCERIZADO_IMPORTE_SOLO_APROBACIONES'); ?></p>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo Text::_('JCANCEL'); ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo $canSetTercerizadoImporte ? Text::_('JSAVE') : Text::_('COM_ORDENPRODUCCION_TERCERIZADO_SOLICITAR_PRECIO_BTN'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
(function() {
    var modalEl = document.getElementById('tercerizadoLineModal');
    if (!modalEl) return;
    var lineIdInp = document.getElementById('tercerizado_modal_line_id');
    var tipoInp = document.getElementById('tercerizado_modal_tipo_elemento');
    var prodInp = document.getElementById('tercerizado_modal_producto');
    var totInp = document.getElementById('tercerizado_modal_total');
    var totHidden = document.getElementById('tercerizado_modal_total_hidden');
    function resetAdd() {
        if (lineIdInp) lineIdInp.value = '0';
        if (tipoInp) tipoInp.value = '';
        if (prodInp) prodInp.value = '';
        if (totInp) totInp.value = '0.00';
        if (totHidden) totHidden.value = '0';
    }
    modalEl.addEventListener('show.bs.modal', function(ev) {
        var t = ev.relatedTarget;
        var fromEdit = t && t.classList && t.classList.contains('tercerizado-edit-line-btn');
        if (!fromEdit) {
            resetAdd();
            return;
        }
        if (lineIdInp) lineIdInp.value = String(t.getAttribute('data-line-id') || '0');
        if (tipoInp) tipoInp.value = t.getAttribute('data-tipo-elemento') || '';
        if (prodInp) prodInp.value = t.getAttribute('data-tercerizado-producto') || '';
        var tv = t.getAttribute('data-total') || '0.00';
        if (totInp) totInp.value = tv;
        if (totHidden) totHidden.value = tv;
    });
    var openAdd = document.getElementById('btnTercerizadoLineOpen');
    if (openAdd) {
        openAdd.addEventListener('click', function() {
            resetAdd();
        });
    }
    document.querySelectorAll('.tercerizado-edit-line-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                var m = bootstrap.Modal.getOrCreateInstance(modalEl);
                m.show(btn);
            }
        });
    });
})();
</script>

<?php if (!empty($envios)) : ?>
<!-- Modal: Añadir envío -->
<div class="modal fade" id="envioLineModal" tabindex="-1" aria-labelledby="envioLineModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="envioLineModalLabel"><?php echo htmlspecialchars($labelAnadirEnvio); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=precotizacion.addLineEnvio'); ?>" method="post" id="envio-line-form">
                <?php echo HTMLHelper::_('form.token'); ?>
                <input type="hidden" name="id" value="<?php echo $preCotizacionId; ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="envio_modal_tipo_elemento" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TIPO_ELEMENTO'); ?></label>
                        <input type="text" name="tipo_elemento" id="envio_modal_tipo_elemento" class="form-control" maxlength="255" required autocomplete="off" value="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ENVIO_TIPO_ELEMENTO_DEFAULT'), ENT_QUOTES, 'UTF-8'); ?>" placeholder="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TIPO_ELEMENTO_PLACEHOLDER'), ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="envio_modal_envio_id" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ENVIO_METHOD'); ?></label>
                        <select name="envio_id" id="envio_modal_envio_id" class="form-select" required data-envios="<?php echo htmlspecialchars(json_encode(array_map(function($e) { return ['id' => (int)$e->id, 'tipo' => isset($e->tipo) ? (string)$e->tipo : 'fixed', 'valor' => (float)($e->valor ?? 0)]; }, $envios))); ?>">
                            <option value=""><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_SELECT_ENVIO'); ?></option>
                            <?php foreach ($envios as $e) : ?>
                                <option value="<?php echo (int) $e->id; ?>" data-tipo="<?php echo htmlspecialchars(isset($e->tipo) ? $e->tipo : 'fixed'); ?>"><?php echo htmlspecialchars($e->name ?? ''); ?> (<?php echo (isset($e->tipo) && $e->tipo === 'custom') ? Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ENVIO_CUSTOM') : 'Q ' . number_format((float)($e->valor ?? 0), 2); ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3" id="envio_modal_custom_wrap" style="display:none;">
                        <label for="envio_modal_valor" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ENVIO_VALOR'); ?></label>
                        <input type="number" name="envio_valor" id="envio_modal_valor" class="form-control" min="0" step="0.01" value="">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo Text::_('JCANCEL'); ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ADD_ENVIO_LINE'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
(function() {
    var sel = document.getElementById('envio_modal_envio_id');
    var wrap = document.getElementById('envio_modal_custom_wrap');
    var enviosData = sel && sel.getAttribute('data-envios') ? JSON.parse(sel.getAttribute('data-envios')) : [];
    function toggleCustom() {
        var opt = sel && sel.options[sel.selectedIndex];
        var isCustom = opt && opt.getAttribute('data-tipo') === 'custom';
        if (wrap) wrap.style.display = isCustom ? 'block' : 'none';
        if (!isCustom && document.getElementById('envio_modal_valor')) document.getElementById('envio_modal_valor').removeAttribute('required');
        else if (isCustom && document.getElementById('envio_modal_valor')) document.getElementById('envio_modal_valor').setAttribute('required', 'required');
    }
    if (sel) sel.addEventListener('change', toggleCustom);
    var envioTipoDefault = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ENVIO_TIPO_ELEMENTO_DEFAULT')); ?>;
    if (document.getElementById('envioLineModal')) {
        document.getElementById('envioLineModal').addEventListener('show.bs.modal', function() {
            var te = document.getElementById('envio_modal_tipo_elemento');
            if (te) te.value = envioTipoDefault;
            if (sel) sel.selectedIndex = 0;
            if (document.getElementById('envio_modal_valor')) document.getElementById('envio_modal_valor').value = '';
            toggleCustom();
        });
    }
})();
</script>
<?php endif; ?>

<?php if ($canEditDocument) : ?>
<div class="modal fade" id="precotCabeceraNoticeModal" tabindex="-1" aria-labelledby="precotCabeceraNoticeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="precotCabeceraNoticeModalLabel"><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_SYSTEM_NOTICE_TITLE'), ENT_QUOTES, 'UTF-8'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo htmlspecialchars(Text::_('JCLOSE'), ENT_QUOTES, 'UTF-8'); ?>"></button>
            </div>
            <div class="modal-body" id="precotCabeceraNoticeModalBody"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal"><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_SYSTEM_NOTICE_OK'), ENT_QUOTES, 'UTF-8'); ?></button>
            </div>
        </div>
    </div>
</div>
<script>
(function() {
    function showPrecotCabeceraNoticeModal(message) {
        var modalEl = document.getElementById('precotCabeceraNoticeModal');
        var bodyEl = document.getElementById('precotCabeceraNoticeModalBody');
        if (bodyEl) {
            bodyEl.textContent = message;
        }
        if (modalEl && typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        } else if (typeof window.alert === 'function') {
            window.alert(message);
        }
    }
    var msgRequired = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_CABECERA_REQUIRED_BEFORE_LINES'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
    var msgCantidadInvalid = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_CANTIDAD_TOTAL_INVALID_INTEGER'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
    var msgDescFirstSegment = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_DESCRIPCION_FIRST_SEGMENT_NO_INTEGER_ONLY'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
    function strip(s) {
        return (s || '').replace(/^\s+|\s+$/g, '');
    }
    function cantidadTotalInputOk(c) {
        if (!c) {
            return true;
        }
        var v = strip(String(c.value != null ? c.value : ''));
        if (v === '') {
            return false;
        }
        return (/^\d+$/.test(v)) && (parseInt(v, 10) > 0);
    }
    function descripcionFirstSegmentOk(d) {
        if (!d) {
            return false;
        }
        var s = strip(d.value);
        if (s === '') {
            return false;
        }
        var parts = s.split(/\s+/);
        var first = parts[0] || '';
        if (first === '') {
            return false;
        }
        return !/^\d+$/.test(first);
    }
    /** @return {string|null} error message or null if OK */
    function cabeceraValidationMessage() {
        var d = document.getElementById('precotizacion-descripcion');
        var m = document.getElementById('precotizacion-medidas');
        var c = document.getElementById('precotizacion-cantidad-total');
        if (!d || !m) {
            return null;
        }
        if (strip(d.value) === '' || strip(m.value) === '') {
            return msgRequired;
        }
        if (c && strip(String(c.value != null ? c.value : '')) === '') {
            return msgRequired;
        }
        if (c && !cantidadTotalInputOk(c)) {
            return msgCantidadInvalid;
        }
        if (!descripcionFirstSegmentOk(d)) {
            return msgDescFirstSegment;
        }
        return null;
    }
    var formCab = document.getElementById('precotizacion-desc-medidas-form');
    if (formCab) {
        formCab.addEventListener('submit', function(ev) {
            var err = cabeceraValidationMessage();
            if (err) {
                ev.preventDefault();
                showPrecotCabeceraNoticeModal(err);
            }
        });
    }
    document.addEventListener('click', function(ev) {
        var el = ev.target && ev.target.closest ? ev.target.closest('button[data-bs-toggle="modal"][data-bs-target]') : null;
        if (!el) {
            return;
        }
        var t = el.getAttribute('data-bs-target') || '';
        if (t !== '#pliegoLineModal' && t !== '#elementosLineModal' && t !== '#tercerizadoLineModal' && t !== '#envioLineModal') {
            return;
        }
        var err = cabeceraValidationMessage();
        if (err) {
            ev.preventDefault();
            ev.stopPropagation();
            if (typeof ev.stopImmediatePropagation === 'function') {
                ev.stopImmediatePropagation();
            }
            showPrecotCabeceraNoticeModal(err);
        }
    }, true);
})();
</script>
<?php endif; ?>

<?php if ($tablesExist) : ?>
<script>
(function() {
    var baseUrl = <?php echo json_encode($baseUrl); ?>;
    var token = <?php echo json_encode($token); ?>;
    var sizeIdsByPaperType = <?php echo json_encode($sizeIdsByPaperType); ?>;
    var laminationTypeIdsBySizeTiro = <?php echo json_encode($laminationTypeIdsBySizeTiro); ?>;
    var laminationTypeIdsBySizeRetiro = <?php echo json_encode($laminationTypeIdsBySizeRetiro); ?>;
    var pliegoBarnizBySizeTiro = <?php echo json_encode($pliegoBarnizBySizeTiro); ?>;
    var pliegoBarnizBySizeRetiro = <?php echo json_encode($pliegoBarnizBySizeRetiro); ?>;
    var addLineBtnLabel = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ADD_LINE_BTN')); ?>;
    var saveLineBtnLabel = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_SAVE_LINE_BTN')); ?>;
    var modalTitleNew = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_NUEVA_COTIZACION_PLIEGO_TITLE')); ?>;
    var modalTitleEdit = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_EDIT_LINE')); ?>;

    var form = document.getElementById('pliego-line-form');
    var qty = document.getElementById('pliego_modal_quantity');
    var paper = document.getElementById('pliego_modal_paper_type');
    var size = document.getElementById('pliego_modal_size');
    var retiro = document.getElementById('pliego_modal_retiro');
    var lamination = document.getElementById('pliego_modal_needs_lamination');
    var laminationRetiro = document.getElementById('pliego_modal_lamination_retiro');
    var laminationType = document.getElementById('pliego_modal_lamination_type');
    var laminationWrap = document.getElementById('pliego_modal_lamination_wrap');
    var barniz = document.getElementById('pliego_modal_needs_barniz');
    var barnizRetiro = document.getElementById('pliego_modal_barniz_retiro');
    var barnizWrap = document.getElementById('pliego_modal_barniz_wrap');
    var submitBtn = document.getElementById('pliego_modal_submit_btn');
    var lineIdInput = document.getElementById('pliego_modal_line_id');
    var calcDetail = document.getElementById('pliego_modal_calc_detail');
    var calcBody = document.getElementById('pliego_modal_calc_body');
    var calcTotalCell = document.getElementById('pliego_modal_calc_total_cell');
    var precotShowLineBreakdownDetail = <?php echo !empty($showLineBreakdownDetail) ? 'true' : 'false'; ?>;
    var modalTitle = document.getElementById('pliegoLineModalLabel');
    var pliegoModal = document.getElementById('pliegoLineModal');
    var pliegoTipoElemento = document.getElementById('pliego_modal_tipo_elemento');
    var msgTipoElementoRequired = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TIPO_ELEMENTO_REQUIRED')); ?>;

    var lastCalc = null;

    function pliegoTipoElementoFilled() {
        return pliegoTipoElemento && pliegoTipoElemento.value.trim() !== '';
    }

    function updatePliegoSubmitEnabled() {
        if (!submitBtn) return;
        submitBtn.disabled = !lastCalc || !pliegoTipoElementoFilled();
    }

    function escapeHtml(s) {
        if (s == null) return '';
        var div = document.createElement('div');
        div.textContent = s;
        return div.innerHTML;
    }
    function renderBreakdownTable(rows, totalVal) {
        if (!calcDetail || !calcBody) return;
        if (!rows || rows.length === 0) {
            calcDetail.style.display = 'none';
            return;
        }
        if (precotShowLineBreakdownDetail) {
            if (!calcTotalCell) return;
            calcBody.innerHTML = rows.map(function(row) {
                return '<tr><td>' + escapeHtml(row.label) + '</td><td class="text-end">' + escapeHtml(row.detail) + '</td><td class="text-end">Q ' + Number(row.subtotal).toFixed(2) + '</td></tr>';
            }).join('');
            calcTotalCell.textContent = totalVal != null ? 'Q ' + Number(totalVal).toFixed(2) : '—';
        } else {
            calcBody.innerHTML = rows.map(function(row) {
                return '<tr><td>' + escapeHtml(row.label) + '</td></tr>';
            }).join('');
        }
        calcDetail.style.display = 'block';
    }

    function filterSizeDropdown() {
        var paperId = paper && paper.value ? parseInt(paper.value, 10) : 0;
        var allowedIds = (paperId && sizeIdsByPaperType[paperId]) ? sizeIdsByPaperType[paperId] : [];
        var options = size ? size.querySelectorAll('option') : [];
        var currentVal = size ? size.value : '';
        for (var i = 0; i < options.length; i++) {
            var opt = options[i];
            var vid = opt.value ? parseInt(opt.value, 10) : 0;
            if (vid === 0) { opt.disabled = false; opt.style.display = ''; continue; }
            var show = paperId && allowedIds.indexOf(vid) !== -1;
            opt.style.display = show ? '' : 'none';
            opt.disabled = !show;
            if (show && opt.value === currentVal) ; else if (currentVal && !show) size.value = '';
        }
        filterLaminationBySize();
        filterBarnizBySize();
    }
    if (paper) paper.addEventListener('change', filterSizeDropdown);

    function filterLaminationBySize() {
        var sizeId = size && size.value ? parseInt(size.value, 10) : 0;
        var lamRetiro = laminationRetiro && laminationRetiro.checked;
        var map = lamRetiro ? laminationTypeIdsBySizeRetiro : laminationTypeIdsBySizeTiro;
        var allowedLamIds = (sizeId && map[sizeId]) ? map[sizeId] : [];
        if (lamination) {
            lamination.disabled = allowedLamIds.length === 0;
            if (allowedLamIds.length === 0 && lamination.checked) { lamination.checked = false; if (laminationType) laminationType.value = ''; laminationWrap.style.display = 'none'; }
        }
        var options = laminationType ? laminationType.querySelectorAll('option') : [];
        for (var j = 0; j < options.length; j++) {
            var opt = options[j];
            var lid = opt.value ? parseInt(opt.value, 10) : 0;
            if (lid === 0) { opt.disabled = false; opt.style.display = ''; continue; }
            var show = allowedLamIds.indexOf(lid) !== -1;
            opt.style.display = show ? '' : 'none';
            opt.disabled = !show;
        }
        recalc();
    }
    function updateLaminationVisibility() {
        laminationWrap.style.display = lamination && lamination.checked ? 'block' : 'none';
    }
    if (lamination) lamination.addEventListener('change', updateLaminationVisibility);
    if (size) size.addEventListener('change', function() { filterLaminationBySize(); filterBarnizBySize(); });
    if (laminationRetiro) laminationRetiro.addEventListener('change', function() { filterLaminationBySize(); recalc(); });

    function updateBarnizVisibility() {
        if (barnizWrap) barnizWrap.style.display = barniz && barniz.checked ? 'block' : 'none';
    }
    if (barniz) barniz.addEventListener('change', updateBarnizVisibility);
    if (barnizRetiro) barnizRetiro.addEventListener('change', function() { filterBarnizBySize(); recalc(); });

    function barnizMapHasSize(map, sizeId) {
        if (!sizeId || !map) {
            return false;
        }
        return !!(map[sizeId] || map[String(sizeId)]);
    }

    function filterBarnizBySize() {
        var sizeId = size && size.value ? parseInt(size.value, 10) : 0;
        var barnRetiro = barnizRetiro && barnizRetiro.checked;
        var hasTiro = barnizMapHasSize(pliegoBarnizBySizeTiro, sizeId);
        var hasRetiro = barnizMapHasSize(pliegoBarnizBySizeRetiro, sizeId);
        var hasPrice = barnRetiro ? hasRetiro : hasTiro;
        if (barniz) {
            barniz.disabled = !(hasTiro || hasRetiro);
            if (!hasPrice && barniz.checked) {
                barniz.checked = false;
                if (barnizRetiro) barnizRetiro.checked = false;
                if (barnizWrap) barnizWrap.style.display = 'none';
            }
        }
        recalc();
    }

    function recalc() {
        var quantity = parseInt(qty.value, 10) || 0;
        var paperId = paper && paper.value ? paper.value : '';
        var sizeId = size && size.value ? size.value : '';
        if (!quantity || !paperId || !sizeId) {
            document.getElementById('pliego_modal_price_display').textContent = '-';
            document.getElementById('pliego_modal_total_display').textContent = '-';
            lastCalc = null;
            if (calcDetail) calcDetail.style.display = 'none';
            updatePliegoSubmitEnabled();
            return;
        }
        var tiroRetiro = (retiro && retiro.checked) ? 'retiro' : 'tiro';
        var lamTiroRetiro = (laminationRetiro && laminationRetiro.checked) ? 'retiro' : 'tiro';
        var lamId = (lamination && lamination.checked && laminationType && laminationType.value) ? laminationType.value : '';
        var needsBarniz = barniz && barniz.checked ? '1' : '0';
        var barnTiroRetiro = (barnizRetiro && barnizRetiro.checked) ? 'retiro' : 'tiro';
        var processIds = [];
        document.querySelectorAll('.pliego-modal-process-cb:checked').forEach(function(cb) { processIds.push(cb.value); });

        var url = baseUrl + '&' + token + '=1&quantity=' + encodeURIComponent(quantity) + '&paper_type_id=' + encodeURIComponent(paperId) + '&size_id=' + encodeURIComponent(sizeId) + '&tiro_retiro=' + encodeURIComponent(tiroRetiro) + '&lamination_tiro_retiro=' + encodeURIComponent(lamTiroRetiro) + '&lamination_type_id=' + encodeURIComponent(lamId) + '&needs_barniz=' + encodeURIComponent(needsBarniz) + '&barniz_tiro_retiro=' + encodeURIComponent(barnTiroRetiro);
        processIds.forEach(function(id) { url += '&process_ids[]=' + encodeURIComponent(id); });

        fetch(url)
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.success) {
                    document.getElementById('pliego_modal_price_display').textContent = 'Q ' + (data.price_per_sheet != null ? Number(data.price_per_sheet).toFixed(2) : '-');
                    document.getElementById('pliego_modal_total_display').textContent = 'Q ' + (data.total != null ? Number(data.total).toFixed(2) : '-');
                    lastCalc = { price_per_sheet: data.price_per_sheet, total: data.total, rows: data.rows || [] };
                    renderBreakdownTable(lastCalc.rows, data.total);
                    updatePliegoSubmitEnabled();
                } else {
                    document.getElementById('pliego_modal_price_display').textContent = '-';
                    document.getElementById('pliego_modal_total_display').textContent = data.message || '-';
                    lastCalc = null;
                    if (calcDetail) calcDetail.style.display = 'none';
                    updatePliegoSubmitEnabled();
                }
            })
            .catch(function() {
                document.getElementById('pliego_modal_price_display').textContent = '-';
                document.getElementById('pliego_modal_total_display').textContent = '-';
                lastCalc = null;
                if (calcDetail) calcDetail.style.display = 'none';
                updatePliegoSubmitEnabled();
            });
    }

    [qty, paper, size, retiro, lamination, laminationType, laminationRetiro, barniz, barnizRetiro].forEach(function(el) {
        if (el) el.addEventListener('change', recalc);
    });
    if (qty) qty.addEventListener('input', recalc);
    if (pliegoTipoElemento) {
        pliegoTipoElemento.addEventListener('input', updatePliegoSubmitEnabled);
        pliegoTipoElemento.addEventListener('change', updatePliegoSubmitEnabled);
    }
    document.querySelectorAll('.pliego-modal-process-cb').forEach(function(cb) { cb.addEventListener('change', recalc); });

    if (submitBtn && form) {
        submitBtn.addEventListener('click', function() {
            if (!lastCalc) return;
            if (!pliegoTipoElementoFilled()) {
                alert(msgTipoElementoRequired);
                if (pliegoTipoElemento) pliegoTipoElemento.focus();
                return;
            }
            document.getElementById('pliego_modal_price_per_sheet').value = lastCalc.price_per_sheet;
            document.getElementById('pliego_modal_total').value = lastCalc.total;
            document.getElementById('pliego_modal_breakdown').value = JSON.stringify(lastCalc.rows || []);
            if (lineIdInput && lineIdInput.value) {
                form.action = form.getAttribute('data-edit-action') || form.action;
            }
            form.submit();
        });
    }

    function setAddMode() {
        if (lineIdInput) lineIdInput.value = '';
        if (form) form.action = form.getAttribute('data-add-action') || form.action;
        if (modalTitle) modalTitle.textContent = modalTitleNew;
        if (submitBtn) submitBtn.textContent = addLineBtnLabel;
        if (pliegoTipoElemento) pliegoTipoElemento.value = '';
        if (qty) qty.value = '1';
        if (paper) paper.value = '';
        if (size) size.value = '';
        if (retiro) retiro.checked = false;
        if (lamination) { lamination.checked = false; }
        if (laminationType) laminationType.value = '';
        if (laminationRetiro) laminationRetiro.checked = false;
        if (barniz) { barniz.checked = false; barniz.disabled = false; }
        if (barnizRetiro) barnizRetiro.checked = false;
        document.querySelectorAll('.pliego-modal-process-cb').forEach(function(cb) { cb.checked = false; });
        lastCalc = null;
        if (calcDetail) calcDetail.style.display = 'none';
        document.getElementById('pliego_modal_price_display').textContent = '-';
        document.getElementById('pliego_modal_total_display').textContent = '-';
        updatePliegoSubmitEnabled();
        filterSizeDropdown();
        filterLaminationBySize();
        filterBarnizBySize();
        updateLaminationVisibility();
        updateBarnizVisibility();
    }

    var nuevaLineaBtn = document.querySelector('[data-bs-target="#pliegoLineModal"]');
    if (nuevaLineaBtn) {
        nuevaLineaBtn.addEventListener('click', function() { setAddMode(); });
    }
    if (pliegoModal) {
        pliegoModal.addEventListener('shown.bs.modal', function() {
            filterSizeDropdown();
            filterLaminationBySize();
            filterBarnizBySize();
            updateLaminationVisibility();
            updateBarnizVisibility();
        });
    }

    document.addEventListener('click', function(e) {
        var editBtn = e.target && e.target.closest && e.target.closest('.pliego-edit-line-btn');
        if (!editBtn) return;
        var dataStr = editBtn.getAttribute('data-line');
        if (!dataStr) return;
        var line;
        try { line = JSON.parse(dataStr); } catch (err) { return; }
        if (!line) return;
        if (lineIdInput) lineIdInput.value = line.id || '';
        if (form) form.action = form.getAttribute('data-edit-action') || form.action;
        if (modalTitle) modalTitle.textContent = modalTitleEdit;
        if (submitBtn) submitBtn.textContent = saveLineBtnLabel;
        if (pliegoTipoElemento) pliegoTipoElemento.value = line.tipo_elemento || '';
        if (qty) qty.value = line.quantity || 1;
        if (paper) paper.value = (line.paper_type_id || '').toString();
        if (size) size.value = (line.size_id || '').toString();
        if (retiro) retiro.checked = (line.tiro_retiro || '') === 'retiro';
        if (lamination) lamination.checked = !!(line.lamination_type_id);
        if (laminationType) laminationType.value = (line.lamination_type_id || '').toString();
        if (laminationRetiro) laminationRetiro.checked = (line.lamination_tiro_retiro || '') === 'retiro';
        if (barniz) barniz.checked = !!(line.barniz_tiro_retiro);
        if (barnizRetiro) barnizRetiro.checked = (line.barniz_tiro_retiro || '') === 'retiro';
        var procIds = (line.process_ids || []).map(function(x) { return parseInt(x, 10); });
        document.querySelectorAll('.pliego-modal-process-cb').forEach(function(cb) {
            cb.checked = procIds.indexOf(parseInt(cb.value, 10)) !== -1;
        });
        lastCalc = {
            price_per_sheet: line.price_per_sheet,
            total: line.total,
            rows: line.breakdown || []
        };
        renderBreakdownTable(lastCalc.rows, line.total);
        document.getElementById('pliego_modal_price_display').textContent = line.price_per_sheet != null && line.price_per_sheet !== '' ? 'Q ' + Number(line.price_per_sheet).toFixed(2) : '-';
        document.getElementById('pliego_modal_total_display').textContent = line.total != null && line.total !== '' ? 'Q ' + Number(line.total).toFixed(2) : '-';
        document.getElementById('pliego_modal_price_per_sheet').value = line.price_per_sheet != null && line.price_per_sheet !== '' ? line.price_per_sheet : '';
        document.getElementById('pliego_modal_total').value = line.total != null && line.total !== '' ? line.total : '';
        document.getElementById('pliego_modal_breakdown').value = (line.breakdown && line.breakdown.length) ? JSON.stringify(line.breakdown) : '[]';
        updatePliegoSubmitEnabled();
        filterSizeDropdown();
        filterLaminationBySize();
        filterBarnizBySize();
        updateLaminationVisibility();
        updateBarnizVisibility();
        if (pliegoModal && typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            var modal = bootstrap.Modal.getOrCreateInstance(pliegoModal);
            modal.show();
        }
    });

    filterSizeDropdown();
    filterLaminationBySize();
    updateLaminationVisibility();
})();
</script>
<?php endif; ?>
