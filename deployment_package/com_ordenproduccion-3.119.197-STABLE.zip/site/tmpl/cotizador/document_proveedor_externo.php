<?php
/**
 * Pre-cotización document: external vendor quotation request (lines only, no pliego modals).
 *
 * @package     com_ordenproduccion
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Grimpsa\Component\Ordenproduccion\Site\Helper\AccessHelper;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;

/** @var \Grimpsa\Component\Ordenproduccion\Site\View\Cotizador\HtmlView $this */

$item  = $this->item ?? null;
$lines = $this->lines ?? [];
if (!$item) {
    return;
}

$listUrl           = Route::_('index.php?option=com_ordenproduccion&view=cotizador');
$preCotizacionId   = (int) $item->id;
$precotizacionLocked = !empty($this->precotizacionLocked);
$precotLockedByOt = !empty($this->precotizacionLockedByOrdenTrabajo);
$canEditDocument = isset($this->precotizacionDocumentEditable)
    ? (bool) $this->precotizacionDocumentEditable
    : !$precotizacionLocked;
$ofertaViewOnly = !empty($item->oferta) && !$canEditDocument && !$precotizacionLocked;

$vendorLines = [];
$gastosEnvioLine = null;
$gastosEnvioAmount = 0.0;
foreach ($lines as $ln) {
    $lt = isset($ln->line_type) ? (string) $ln->line_type : 'pliego';
    if ($lt === 'proveedor_externo') {
        $vendorLines[] = $ln;
    } elseif ($lt === 'envio' && (empty($ln->envio_id) || (int) $ln->envio_id === 0)) {
        $gastosEnvioLine = $ln;
        $gastosEnvioAmount = round((float) ($ln->total ?? 0), 2);
    }
}
$colGastosEnvio = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_GASTOS_ENVIO');
$hasGastosEnvioRow = ($gastosEnvioLine !== null);
$anyVendorLineUnitPricePositive = false;
foreach ($vendorLines as $_vl) {
    if (round((float) ($_vl->price_per_sheet ?? 0), 2) > 0) {
        $anyVendorLineUnitPricePositive = true;
        break;
    }
}

$hasStoredTotals = isset($item->lines_subtotal) && $item->lines_subtotal !== null && $item->lines_subtotal !== '';
if ($hasStoredTotals) {
    $linesSubtotal = (float) $item->lines_subtotal;
    $margenAmount  = (float) ($item->margen_amount ?? 0);
    $ivaAmount     = (float) ($item->iva_amount ?? 0);
    $isrAmount     = (float) ($item->isr_amount ?? 0);
    $comisionAmount = (float) ($item->comision_amount ?? 0);
    $linesTotal    = (float) ($item->total ?? 0);
    $linesTotalFinal = isset($item->total_final) && $item->total_final !== null && $item->total_final !== ''
        ? (float) $item->total_final : $linesTotal;
} else {
    $linesSubtotal = 0.0;
    foreach ($lines as $l) {
        $linesSubtotal += (float) ($l->total ?? 0);
    }
    $paramMargen   = isset($this->paramMargen) ? (float) $this->paramMargen : 0;
    $paramIva      = isset($this->paramIva) ? (float) $this->paramIva : 0;
    $paramIsr      = isset($this->paramIsr) ? (float) $this->paramIsr : 0;
    $paramComision = isset($this->paramComision) ? (float) $this->paramComision : 0;
    $margenAmount  = $linesSubtotal * ($paramMargen / 100);
    $facturarCalc  = !empty($item->facturar);
    $ivaAmount     = $facturarCalc ? ($linesSubtotal * ($paramIva / 100)) : 0;
    $isrAmount     = $facturarCalc ? ($linesSubtotal * ($paramIsr / 100)) : 0;
    $comisionAmount = $linesSubtotal * ($paramComision / 100);
    $linesTotal    = $linesSubtotal + $margenAmount + $ivaAmount + $isrAmount + $comisionAmount;
    $linesTotalFinal = $linesTotal;
}

$facturar = !empty($item->facturar);
$paramMargen = isset($this->paramMargen) ? (float) $this->paramMargen : 0;
$paramIva = isset($this->paramIva) ? (float) $this->paramIva : 0;
$paramIsr = isset($this->paramIsr) ? (float) $this->paramIsr : 0;
$paramComision = isset($this->paramComision) ? (float) $this->paramComision : 0;
$paramComisionMargenAdicional = isset($this->paramComisionMargenAdicional) ? (float) $this->paramComisionMargenAdicional : 0;
$margenAdicional = ($item && isset($item->margen_adicional) && $item->margen_adicional !== null && $item->margen_adicional !== '')
    ? (float) $item->margen_adicional : 0;
$comisionMargenAdicionalAmount = ($item && isset($item->comision_margen_adicional) && $item->comision_margen_adicional !== null && $item->comision_margen_adicional !== '')
    ? (float) $item->comision_margen_adicional : 0;
$displayTotal = $linesTotalFinal + $margenAdicional;
$pctMaUi = (float) $paramComisionMargenAdicional;
$precotComisionMaPctText = (\abs($pctMaUi - \round($pctMaUi)) < 0.000001)
    ? (string) (int) \round($pctMaUi)
    : \number_format($pctMaUi, 1, '.', '');
$pctMgUi = (float) $paramMargen;
$precotMargenPctText = (\abs($pctMgUi - \round($pctMgUi)) < 0.000001)
    ? (string) (int) \round($pctMgUi)
    : \number_format($pctMgUi, 1, '.', '');
$canSeePrecotInternalTax = AccessHelper::canSeePrecotizacionInternalTaxBreakdown($preCotizacionId);
$precotFooterShowIva = $canSeePrecotInternalTax && $facturar
    && (($paramIva != 0) || abs((float) $ivaAmount) >= 0.005);
$precotFooterShowIsr = $canSeePrecotInternalTax && $facturar
    && (($paramIsr != 0) || abs((float) $isrAmount) >= 0.005);
$canSeeVendorPup         = AccessHelper::canEditProveedorExternoPrecioUnitProveedor();
$canAdminEditPupWhenLocked = $precotizacionLocked && !$precotLockedByOt && AccessHelper::canAdministracionEditProveedorExternoPupWhenQuotationLocked();
$linesTableLocked          = $precotizacionLocked || !$canEditDocument;
$showVendorPupColumn       = $canSeeVendorPup || $canAdminEditPupWhenLocked;
/** Hide Precio unidad + Total columns in read-only vendor line tables when all unit prices are still zero. */
$showVendorPriceTotalColumnsReadonly = $anyVendorLineUnitPricePositive;

$labelFacturar = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_FACTURAR');
if (strpos($labelFacturar, 'COM_ORDENPRODUCCION_') === 0) {
    $labelFacturar = 'Facturar';
}
$facturarChecked = !empty($item->facturar);
$saveFacturarUrl = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.saveFacturar');
$labelDescripcion = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_DESCRIPCION');
if (strpos($labelDescripcion, 'COM_ORDENPRODUCCION_') === 0) {
    $labelDescripcion = 'Descripción';
}
$descripcionValue = isset($item->descripcion) ? (string) $item->descripcion : '';
$saveDescripcionUrl = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.saveDescripcion');
$labelMedidas = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_MEDIDAS');
if (strpos($labelMedidas, 'COM_ORDENPRODUCCION_') === 0) {
    $labelMedidas = 'Medidas';
}
$placeholderMedidas = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_MEDIDAS_PLACEHOLDER');
if (strpos($placeholderMedidas, 'COM_ORDENPRODUCCION_') === 0) {
    $placeholderMedidas = 'ingrese medidas en pulgadas';
}
$medidasValue = isset($item->medidas) ? (string) $item->medidas : '';
$labelCantidadTotal = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_CANTIDAD_TOTAL');
if (strpos($labelCantidadTotal, 'COM_ORDENPRODUCCION_') === 0) {
    $labelCantidadTotal = 'Cantidad total';
}
$placeholderCantidadTotal = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_CANTIDAD_TOTAL_PLACEHOLDER');
if (strpos($placeholderCantidadTotal, 'COM_ORDENPRODUCCION_') === 0) {
    $placeholderCantidadTotal = '';
}
$cantidadTotalValue = isset($item->cantidad_total) ? (string) $item->cantidad_total : '';
$medidasOneLineValue = trim(preg_replace('/\s+/u', ' ', str_replace(["\r\n", "\r", "\n"], ' ', $medidasValue)));

$saveVendorLinesUrl     = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.saveProveedorExternoLines');
$saveVendorQuoteEventCondicionesUrl = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.saveVendorQuoteEventCondiciones', false, Route::TLS_IGNORE, true);
$uploadVendorQuoteUrl   = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.uploadVendorQuoteAttachment', false, Route::TLS_IGNORE, true);
$vendorQuoteAttachRel   = (isset($item->vendor_quote_attachment) && is_string($item->vendor_quote_attachment))
    ? trim($item->vendor_quote_attachment) : '';
$vendorQuoteAttachHref  = $vendorQuoteAttachRel !== ''
    ? rtrim(Uri::root(), '/') . '/' . str_replace('\\', '/', ltrim($vendorQuoteAttachRel, '/'))
    : '';
$vendorAttachExt        = $vendorQuoteAttachRel !== '' ? strtolower(pathinfo($vendorQuoteAttachRel, PATHINFO_EXTENSION)) : '';
$vendorAttachIsImage    = in_array($vendorAttachExt, ['jpg', 'jpeg', 'png'], true);
$vendorAttachIsPdf      = ($vendorAttachExt === 'pdf');
$badgeVendor        = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_BADGE');
if (strpos($badgeVendor, 'COM_ORDENPRODUCCION_') === 0) {
    $badgeVendor = 'Proveedor externo';
}
$colQty   = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_COL_QTY');
$colDesc  = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_COL_DESC');
$colPrice = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_COL_PRICE_SHORT');
if (strpos($colPrice, 'COM_ORDENPRODUCCION_') === 0) {
    $colPrice = 'Precio unidad';
}
$colPUnitProveedor = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_COL_P_UNIT_PROVEEDOR');
if (strpos($colPUnitProveedor, 'COM_ORDENPRODUCCION_') === 0) {
    $colPUnitProveedor = 'P.Unit Proveedor';
}
$colTotal = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_LINE_TOTAL');
$colAttach = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_COL_ATTACH');
if (strpos($colAttach, 'COM_ORDENPRODUCCION_') === 0) {
    $colAttach = 'Adjunto';
}
$colEventCondiciones = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_COL_CONDICIONES');
$labelSaveEventCondiciones = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_CONDICIONES_SAVE');
$colActions = Text::_('COM_ORDENPRODUCCION_ACTIONS');
$user  = Factory::getUser();
$solicitarCotProveedorUrl = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.solicitarCotizacionProveedor');
$solicitudCotWf          = isset($this->solicitudCotizacionWorkflowAvailable) ? (bool) $this->solicitudCotizacionWorkflowAvailable : false;
$pendingSolicitudCot     = isset($this->pendingSolicitudCotizacion) ? (bool) $this->pendingSolicitudCotizacion : false;
$canReqSolicitudCot      = isset($this->canRequestSolicitudCotizacion) ? (bool) $this->canRequestSolicitudCotizacion : false;
$vendorQuoteApprOk       = isset($this->vendorQuoteSolicitudApproved) ? (bool) $this->vendorQuoteSolicitudApproved : false;
$canViewVendorQuoteRequestLog = isset($this->canViewVendorQuoteRequestLog) ? (bool) $this->canViewVendorQuoteRequestLog : false;
// Flujo publicado: enviar solicitud a aprobaciones (no volver a mostrar como acción principal el modal de contacto hasta que exista aprobación previa).
$showSolicitarCotizacionExternaBtn = $solicitudCotWf && $canReqSolicitudCot && !$vendorQuoteApprOk;
// Sin flujo en Ajustes: mismo modal de proveedor que antes (correo / celular / PDF).
$showVendorQuoteDirectModalBtn = !$user->guest && !$solicitudCotWf && !$canViewVendorQuoteRequestLog;
/** Admin / Aprobaciones Ventas: "Pedir cotización a proveedor" abre el modal en modo procesar. */
$canPedirCotizacionProveedorAprobaciones = AccessHelper::canViewVendorQuoteRequestLog();
$canEditVendorQuoteEventLogRow = !$user->guest && $canViewVendorQuoteRequestLog
    && ($precotizacionLocked || $canEditDocument);
$canAttachVendorQuoteEvent = $canEditVendorQuoteEventLogRow;
$deleteVendorQuoteEventUrl = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.deleteVendorQuoteEvent', false, Route::TLS_IGNORE, true);
$openOrdenCompraEditorUrl   = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.openOrdenCompraEditor', false, Route::TLS_IGNORE, true);
$saveOrdenCompraDraftUrl    = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.saveOrdenCompraDraft', false, Route::TLS_IGNORE, true);
$submitOrdenCompraApprovalUrl = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.submitOrdenCompraForApproval', false, Route::TLS_IGNORE, true);
$deleteOrdenCompraUrl       = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.deleteOrdenCompra', false, Route::TLS_IGNORE, true);
$ordenCompraWorkflowAvailable       = isset($this->ordenCompraWorkflowAvailable) ? (bool) $this->ordenCompraWorkflowAvailable : false;
$ordenCompraTablesAvailable         = isset($this->ordenCompraTablesAvailable) ? (bool) $this->ordenCompraTablesAvailable : false;
$ordenCompraExistingCountForPrecot  = isset($this->ordenCompraExistingCountForPrecot) ? (int) $this->ordenCompraExistingCountForPrecot : 0;
$ordenCompraLinesReady              = isset($this->ordenCompraLinesReady) ? (bool) $this->ordenCompraLinesReady : false;
$canShowOrdenCompraButton           = !$user->guest && $ordenCompraTablesAvailable && $ordenCompraLinesReady;
$ordenCompraConfirmExistingMsg      = Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_CONFIRM_EXISTING_MSG');
$colOrdenCompra = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_COL_ORDEN_COMPRA');
$labelOrdenCompraViewPdf = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_ORDEN_COMPRA_VIEW_PDF');
if (strpos($labelOrdenCompraViewPdf, 'COM_ORDENPRODUCCION_') === 0) {
    $labelOrdenCompraViewPdf = 'Ver orden de compra (PDF)';
}
$ordenCompraLatestByProveedor = isset($this->ordenCompraLatestByProveedor) && is_array($this->ordenCompraLatestByProveedor)
    ? $this->ordenCompraLatestByProveedor : [];
$token = Session::getFormToken();
$pendingSolicitudCotReqIdDoc = isset($this->pendingSolicitudCotizacionRequestId) ? (int) $this->pendingSolicitudCotizacionRequestId : 0;
$canActSolicitudCotWfHere = !empty($this->canCompleteSolicitudCotizacionApprovalHere) && $pendingSolicitudCotReqIdDoc > 0;
$precotDocReturnB64VendorWf = base64_encode(
    Route::_('index.php?option=com_ordenproduccion&view=cotizador&layout=document&id=' . (int) $preCotizacionId, false, Route::TLS_IGNORE, true)
);
$wfVendorQuoteApproveUrl = Route::_('index.php?option=com_ordenproduccion&task=administracion.approveApprovalWorkflow', false, Route::TLS_IGNORE, true);
$wfVendorQuoteRejectUrl = Route::_('index.php?option=com_ordenproduccion&task=administracion.rejectApprovalWorkflow', false, Route::TLS_IGNORE, true);
$pendingCreacionOtReq = isset($this->pendingCreacionOtRequestId) ? (int) $this->pendingCreacionOtRequestId : 0;
$fechaDefaultCreacionOt = isset($this->pendingCreacionOtDefaultFechaYmd) ? trim((string) $this->pendingCreacionOtDefaultFechaYmd) : '';
$decideCreacionOtUrl = Route::_(
    'index.php?option=com_ordenproduccion&task=precotizacion.decideCreacionOrdenTrabajo&format=json&tmpl=component',
    false,
    Route::TLS_IGNORE,
    true
);
$showCreacionOtApprovalBanner = AccessHelper::isInAprobacionesVentasGroup()
    && ($this->canCompleteCreacionOtApprovalHere ?? false)
    && $pendingCreacionOtReq > 0;
$vendorQuoteProveedoresUrl = Route::_(
    'index.php?option=com_ordenproduccion&task=precotizacion.vendorQuoteProveedoresJson&format=json&' . $token . '=1',
    false,
    Route::TLS_IGNORE,
    true
);
/** Non-SEF index.php base so AJAX can append query params safely (SEF breaks string concat on Route URLs). */
$vendorQuoteAjaxIndex = rtrim(Uri::root(), '/') . '/index.php';
$vendorQuoteSendEmailUrl = Route::_('index.php?option=com_ordenproduccion&task=precotizacion.vendorQuoteSendEmail', false, Route::TLS_IGNORE, true);
?>

<div class="com-ordenproduccion-precotizacion-document com-ordenproduccion-precotizacion-proveedor-externo container py-4">
<style>
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-wrap {
    max-width: 100%;
    overflow-x: visible;
}
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-table {
    table-layout: fixed;
    width: 100%;
    margin-bottom: 0;
}
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-table th,
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-table td {
    vertical-align: middle;
    word-wrap: break-word;
    overflow-wrap: break-word;
    min-width: 0;
}
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-table thead th {
    font-size: 0.8rem;
    line-height: 1.25;
    font-weight: 600;
}
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-table .col-qty { width: 4.25rem; }
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-table .col-desc { width: 52%; }
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-table .col-price { width: 5.5rem; }
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-table .col-pup { width: 5.75rem; }
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-table .col-total { width: 5rem; }
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-table .col-actions { width: 2.75rem; padding-left: 0.2rem; padding-right: 0.2rem; }
.com-ordenproduccion-precotizacion-proveedor-externo .precot-vendor-quote-event-log .col-evt-cond { min-width: 10rem; }
.com-ordenproduccion-precotizacion-proveedor-externo .precot-vendor-quote-event-log tr.precot-vendor-evt-cond-row td.col-evt-cond { max-width: none; }
.com-ordenproduccion-precotizacion-proveedor-externo .precot-vendor-quote-event-log tr.precot-vendor-evt-cond-row td.col-evt-cond textarea.form-control {
    display: block;
    width: 100%;
    min-width: 0;
    min-height: calc(2 * 1.25em + 0.75rem);
    max-width: 100%;
    max-height: 12rem;
    resize: vertical;
    box-sizing: border-box;
    line-height: 1.25;
}
.com-ordenproduccion-precotizacion-proveedor-externo .precot-vendor-quote-event-log tr.precot-vendor-evt-main-row td.col-evt-spacer { width: 0.01%; }
.com-ordenproduccion-precotizacion-proveedor-externo .precot-vendor-quote-event-log td.col-evt-cond-label {
    max-width: 12rem;
    white-space: normal;
    vertical-align: top;
}
.com-ordenproduccion-precotizacion-proveedor-externo .precot-vendor-quote-event-log .col-evt-attach { width: 5.5rem; padding-left: 0.25rem; padding-right: 0.25rem; }
.com-ordenproduccion-precotizacion-proveedor-externo .precot-vendor-quote-event-log .col-evt-save { width: 2.85rem; padding-left: 0.2rem; padding-right: 0.2rem; }
.com-ordenproduccion-precotizacion-proveedor-externo .precot-vendor-quote-event-log .col-evt-oc { width: 3.1rem; padding-left: 0.2rem; padding-right: 0.2rem; }
.com-ordenproduccion-precotizacion-proveedor-externo .precot-vendor-quote-event-log .col-evt-delete { width: 2.85rem; padding-left: 0.2rem; padding-right: 0.2rem; }
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-table textarea.form-control {
    width: 100%;
    min-width: 0;
    max-width: 100%;
    resize: vertical;
    min-height: 3.25rem;
    max-height: 8rem;
    box-sizing: border-box;
}
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-table input.form-control {
    width: 100%;
    min-width: 0;
    max-width: 100%;
    box-sizing: border-box;
}
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-table .btn-vendor-row-action {
    padding: 0.15rem 0.4rem;
    line-height: 1.2;
    min-width: 0;
}
.com-ordenproduccion-precotizacion-proveedor-externo .pre-cot-vendor-lines-table .js-vendor-line-total {
    font-size: 0.9rem;
    white-space: nowrap;
}
.com-ordenproduccion-precotizacion-proveedor-externo .precot-vendor-line-viewer iframe {
    min-height: 480px;
}
@media (min-width: 768px) {
    .com-ordenproduccion-precotizacion-proveedor-externo .precot-vendor-line-viewer iframe {
        min-height: min(70vh, 720px);
    }
}
.com-ordenproduccion-precotizacion-proveedor-externo .precot-vendor-attachment-viewer iframe {
    min-height: 480px;
}
@media (min-width: 768px) {
    .com-ordenproduccion-precotizacion-proveedor-externo .precot-vendor-attachment-viewer iframe {
        min-height: min(70vh, 720px);
    }
}
</style>
    <nav class="mb-3">
        <a href="<?php echo $listUrl; ?>" class="btn btn-outline-secondary"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_BACK'); ?></a>
    </nav>

    <?php if ($showCreacionOtApprovalBanner) : ?>
    <div class="alert alert-info d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
        <div>
            <strong><?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_ALERT_TITLE'); ?></strong>
            <span class="d-block small text-muted"><?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_ALERT_INTRO'); ?></span>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#precotCreacionOtApprovalModal">
                <i class="fas fa-clipboard-check" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_BTN_REVIEW'); ?>
            </button>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($canEditDocument) : ?>
    <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
        <h1 class="page-title mb-0">
            <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TITLE'); ?> <?php echo htmlspecialchars($item->number); ?>
            <span class="badge bg-secondary ms-2"><?php echo htmlspecialchars($badgeVendor); ?></span>
        </h1>
    </div>
    <?php else : ?>
    <h1 class="page-title">
        <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TITLE'); ?> <?php echo htmlspecialchars($item->number); ?>
        <span class="badge bg-secondary ms-2"><?php echo htmlspecialchars($badgeVendor); ?></span>
    </h1>
    <?php endif; ?>

    <?php
    $associatedQuotations = $this->associatedQuotations ?? [];
    if (!empty($associatedQuotations)) :
        $labelAssociated = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ASSOCIATED_QUOTATION');
        if (strpos($labelAssociated, 'COM_ORDENPRODUCCION_') === 0) {
            $labelAssociated = 'Associated quotation(s)';
        }
    ?>
    <div class="precotizacion-associated-quotations mb-3 p-3 bg-light rounded">
        <strong><?php echo htmlspecialchars($labelAssociated); ?>:</strong>
        <?php
        $links = [];
        foreach ($associatedQuotations as $q) {
            $url = Route::_('index.php?option=com_ordenproduccion&view=cotizacion&id=' . (int) $q->id);
            $links[] = '<a href="' . htmlspecialchars($url) . '">' . htmlspecialchars($q->quotation_number ?? ('COT-' . $q->id)) . '</a>';
        }
        echo implode(', ', $links);
        ?>
    </div>
    <?php endif; ?>

    <?php if ($precotizacionLocked) :
        if ($precotLockedByOt) {
            $msgLocked = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_LOCKED_ORDEN_TRABAJO');
            if ($msgLocked === 'COM_ORDENPRODUCCION_PRE_COTIZACION_LOCKED_ORDEN_TRABAJO'
                || (is_string($msgLocked) && strpos($msgLocked, 'COM_ORDENPRODUCCION_') === 0)) {
                $msgLocked = 'Esta pre-cotización tiene una orden de trabajo activa; no se puede modificar.';
            }
        } else {
            $msgLocked = Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_LOCKED_MODIFY');
            if ($msgLocked === 'COM_ORDENPRODUCCION_PRE_COTIZACION_LOCKED_MODIFY'
                || (is_string($msgLocked) && strpos($msgLocked, 'COM_ORDENPRODUCCION_') === 0)) {
                $msgLocked = 'Esta pre-cotización ya forma parte de una cotización formal, por eso no se puede editar aquí. Si necesita cambios, cree una nueva pre-cotización o revise la cotización vinculada.';
            }
        }
    ?>
    <div class="alert alert-info mb-3"><?php echo htmlspecialchars($msgLocked); ?></div>
    <?php if ($canAdminEditPupWhenLocked) : ?>
    <p class="small text-muted mb-3"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_PUP_LOCKED_ADMIN_HINT'); ?></p>
    <?php endif; ?>
    <?php endif; ?>

    <?php if ($ofertaViewOnly) :
        $msgOfertaRo = Text::_('COM_ORDENPRODUCCION_PRE_OFERTA_VIEW_ONLY');
        if ($msgOfertaRo === 'COM_ORDENPRODUCCION_PRE_OFERTA_VIEW_ONLY' || (is_string($msgOfertaRo) && strpos($msgOfertaRo, 'COM_ORDENPRODUCCION_') === 0)) {
            $msgOfertaRo = 'Esta pre-cotización es una oferta plantilla. Solo el autor puede editarla; usted puede verla.';
        }
    ?>
    <div class="alert alert-warning mb-3"><?php echo htmlspecialchars($msgOfertaRo); ?></div>
    <?php endif; ?>

    <?php if ($solicitudCotWf && $pendingSolicitudCot && $canActSolicitudCotWfHere) : ?>
    <div class="alert alert-warning border border-warning mb-3 precot-vendor-quote-wf-approval-banner">
        <p class="mb-2 fw-semibold"><?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_WORKFLOW_APPROVAL_BANNER'); ?></p>
        <div class="row g-3">
            <div class="col-12 col-lg-6">
                <form method="post" action="<?php echo htmlspecialchars($wfVendorQuoteApproveUrl, ENT_QUOTES, 'UTF-8'); ?>" class="border rounded p-2 bg-white">
                    <?php echo HTMLHelper::_('form.token'); ?>
                    <input type="hidden" name="request_id" value="<?php echo (int) $pendingSolicitudCotReqIdDoc; ?>">
                    <input type="hidden" name="return" value="<?php echo htmlspecialchars($precotDocReturnB64VendorWf, ENT_QUOTES, 'UTF-8'); ?>">
                    <label class="form-label small mb-0" for="vendor-quote-wf-approve-cmt"><?php echo Text::_('COM_ORDENPRODUCCION_APPROVAL_APPROVE_NOTE'); ?></label>
                    <textarea class="form-control form-control-sm mb-2" name="comment" id="vendor-quote-wf-approve-cmt" rows="2" placeholder="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_APPROVAL_COMMENT_PLACEHOLDER'), ENT_QUOTES, 'UTF-8'); ?>"></textarea>
                    <button type="submit" class="btn btn-success btn-sm"><?php echo Text::_('COM_ORDENPRODUCCION_APPROVAL_BTN_APPROVE'); ?></button>
                </form>
            </div>
            <div class="col-12 col-lg-6">
                <form method="post" action="<?php echo htmlspecialchars($wfVendorQuoteRejectUrl, ENT_QUOTES, 'UTF-8'); ?>" class="border rounded p-2 bg-white">
                    <?php echo HTMLHelper::_('form.token'); ?>
                    <input type="hidden" name="request_id" value="<?php echo (int) $pendingSolicitudCotReqIdDoc; ?>">
                    <input type="hidden" name="return" value="<?php echo htmlspecialchars($precotDocReturnB64VendorWf, ENT_QUOTES, 'UTF-8'); ?>">
                    <label class="form-label small mb-0" for="vendor-quote-wf-reject-cmt"><?php echo Text::_('COM_ORDENPRODUCCION_APPROVAL_REJECT_NOTE'); ?></label>
                    <textarea class="form-control form-control-sm mb-2" name="comment" id="vendor-quote-wf-reject-cmt" rows="2" placeholder="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_APPROVAL_REJECT_COMMENT_PLACEHOLDER'), ENT_QUOTES, 'UTF-8'); ?>"></textarea>
                    <button type="submit" class="btn btn-outline-danger btn-sm"><?php echo Text::_('COM_ORDENPRODUCCION_APPROVAL_BTN_REJECT'); ?></button>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="precotizacion-descripcion mb-3">
        <?php if ($precotizacionLocked || !$canEditDocument) : ?>
            <div class="row g-2 mb-2">
                <div class="col-12 col-md-6">
                    <span class="form-label fw-bold mb-0 d-block"><?php echo htmlspecialchars($labelCantidadTotal); ?></span>
                    <div class="form-control-plaintext bg-light px-2 py-1 rounded mt-1"><?php echo $cantidadTotalValue !== '' ? htmlspecialchars($cantidadTotalValue) : '<span class="text-muted">—</span>'; ?></div>
                </div>
                <div class="col-12 col-md-6">
                    <span class="form-label fw-bold mb-0 d-block"><?php echo htmlspecialchars($labelMedidas); ?></span>
                    <div class="form-control-plaintext bg-light px-2 py-1 rounded mt-1"><?php echo $medidasValue !== '' ? htmlspecialchars($medidasValue) : '<span class="text-muted">—</span>'; ?></div>
                </div>
            </div>
            <label class="form-label fw-bold"><?php echo htmlspecialchars($labelDescripcion); ?></label>
            <div class="form-control-plaintext bg-light px-2 py-1 rounded"><?php echo $descripcionValue !== '' ? htmlspecialchars($descripcionValue) : '<span class="text-muted">—</span>'; ?></div>
        <?php else : ?>
        <form action="<?php echo htmlspecialchars($saveDescripcionUrl); ?>" method="post" id="precotizacion-desc-medidas-form" class="mb-0 w-100" style="min-width: 0;">
            <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>">
            <?php echo HTMLHelper::_('form.token'); ?>
            <div class="row g-2 mb-2">
                <div class="col-12 col-md-6">
                    <label class="form-label fw-bold mb-1" for="precotizacion-cantidad-total"><?php echo htmlspecialchars($labelCantidadTotal); ?></label>
                    <input type="number" name="cantidad_total" id="precotizacion-cantidad-total" class="form-control" min="1" step="1" inputmode="numeric" autocomplete="off"
                           placeholder="<?php echo htmlspecialchars($placeholderCantidadTotal); ?>"
                           value="<?php echo htmlspecialchars($cantidadTotalValue, ENT_QUOTES, 'UTF-8'); ?>" required>
                </div>
                <div class="col-12 col-md-6">
                    <label class="form-label fw-bold mb-1" for="precotizacion-medidas"><?php echo htmlspecialchars($labelMedidas); ?></label>
                    <input type="text" name="medidas" id="precotizacion-medidas" class="form-control" maxlength="512" autocomplete="off"
                           placeholder="<?php echo htmlspecialchars($placeholderMedidas); ?>"
                           value="<?php echo htmlspecialchars($medidasOneLineValue, ENT_QUOTES, 'UTF-8'); ?>" required>
                </div>
            </div>
            <div class="mb-2">
                <label class="form-label fw-bold mb-1" for="precotizacion-descripcion"><?php echo htmlspecialchars($labelDescripcion); ?></label>
                <textarea id="precotizacion-descripcion" name="descripcion" class="form-control w-100" rows="2" placeholder="<?php echo htmlspecialchars($labelDescripcion); ?>" style="resize: vertical; min-height: 4.25rem;" required><?php echo htmlspecialchars($descripcionValue); ?></textarea>
            </div>
            <div class="text-end mt-2">
                <button type="submit" class="btn btn-success"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_DOCUMENT_SAVE_CONTINUE_BTN'); ?></button>
            </div>
        </form>
        <?php endif; ?>
    </div>

    <?php if (!$precotizacionLocked && $canEditDocument) : ?>
<div class="modal fade" id="precotCabeceraNoticeModal" tabindex="-1" aria-labelledby="precotCabeceraNoticeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="precotCabeceraNoticeModalLabel"><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_SYSTEM_NOTICE_TITLE'), ENT_QUOTES, 'UTF-8'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo htmlspecialchars(Text::_('JCLOSE'), ENT_QUOTES, 'UTF-8'); ?>"></button>
            </div>
            <div class="modal-body" id="precotCabeceraNoticeModalBody"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal"><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_SYSTEM_NOTICE_OK'), ENT_QUOTES, 'UTF-8'); ?></button>
            </div>
        </div>
    </div>
</div>
<script>
(function() {
    function showPrecotCabeceraNoticeModal(message) {
        var modalEl = document.getElementById('precotCabeceraNoticeModal');
        var bodyEl = document.getElementById('precotCabeceraNoticeModalBody');
        if (bodyEl) {
            bodyEl.textContent = message;
        }
        if (modalEl && typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        } else if (typeof window.alert === 'function') {
            window.alert(message);
        }
    }
    var msgRequired = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_CABECERA_REQUIRED_BEFORE_LINES'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
    var msgCantidadInvalid = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_CANTIDAD_TOTAL_INVALID_INTEGER'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
    var msgDescFirstSegment = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_DESCRIPCION_FIRST_SEGMENT_NO_INTEGER_ONLY'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
    function strip(s) {
        return (s || '').replace(/^\s+|\s+$/g, '');
    }
    function cantidadTotalInputOk(c) {
        if (!c) {
            return true;
        }
        var v = strip(String(c.value != null ? c.value : ''));
        if (v === '') {
            return false;
        }
        return (/^\d+$/.test(v)) && (parseInt(v, 10) > 0);
    }
    function descripcionFirstSegmentOk(d) {
        if (!d) {
            return false;
        }
        var s = strip(d.value);
        if (s === '') {
            return false;
        }
        var parts = s.split(/\s+/);
        var first = parts[0] || '';
        if (first === '') {
            return false;
        }
        return !/^\d+$/.test(first);
    }
    function cabeceraValidationMessage() {
        var d = document.getElementById('precotizacion-descripcion');
        var m = document.getElementById('precotizacion-medidas');
        var c = document.getElementById('precotizacion-cantidad-total');
        if (!d || !m) {
            return null;
        }
        if (strip(d.value) === '' || strip(m.value) === '') {
            return msgRequired;
        }
        if (c && strip(String(c.value != null ? c.value : '')) === '') {
            return msgRequired;
        }
        if (c && !cantidadTotalInputOk(c)) {
            return msgCantidadInvalid;
        }
        if (!descripcionFirstSegmentOk(d)) {
            return msgDescFirstSegment;
        }
        return null;
    }
    var formCab = document.getElementById('precotizacion-desc-medidas-form');
    if (formCab) {
        formCab.addEventListener('submit', function(ev) {
            var err = cabeceraValidationMessage();
            if (err) {
                ev.preventDefault();
                showPrecotCabeceraNoticeModal(err);
            }
        });
    }
})();
</script>
    <?php endif; ?>

    <div class="precotizacion-oferta-facturar mb-3 d-flex flex-wrap align-items-center gap-4">
        <?php if ($precotizacionLocked || !$canEditDocument) : ?>
        <div class="form-check">
            <input type="checkbox" class="form-check-input" id="precotizacion-facturar-display" disabled <?php echo $facturarChecked ? ' checked' : ''; ?>>
            <label class="form-check-label" for="precotizacion-facturar-display"><?php echo htmlspecialchars($labelFacturar); ?></label>
        </div>
        <?php else : ?>
        <form action="<?php echo htmlspecialchars($saveFacturarUrl); ?>" method="post" class="d-inline mb-0" id="form-facturar">
            <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>">
            <?php echo HTMLHelper::_('form.token'); ?>
            <div class="form-check mb-0">
                <input type="checkbox" class="form-check-input" name="facturar" id="precotizacion-facturar" value="1" <?php echo $facturarChecked ? ' checked' : ''; ?> onchange="this.form.submit();">
                <label class="form-check-label" for="precotizacion-facturar"><?php echo htmlspecialchars($labelFacturar); ?></label>
            </div>
        </form>
        <?php endif; ?>
    </div>

    <h2 class="h5 mt-4" id="precot-vendor-lines-anchor"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_LINES_TITLE'); ?></h2>
    <?php if ($vendorQuoteAttachHref !== '') : ?>
    <p class="small mb-2">
        <span class="text-muted"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ATTACH_CURRENT'); ?>:</span>
        <a href="<?php echo htmlspecialchars($vendorQuoteAttachHref); ?>" target="_blank" rel="noopener"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ATTACH_VIEW'); ?></a>
    </p>
    <?php endif; ?>

    <?php if ($linesTableLocked && !$canAdminEditPupWhenLocked) : ?>
        <?php if (empty($vendorLines) && $gastosEnvioAmount <= 0) : ?>
            <p class="text-muted"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_NO_LINES'); ?></p>
        <?php else : ?>
        <div class="pre-cot-vendor-lines-wrap">
            <table class="table table-sm table-bordered pre-cot-vendor-lines-table">
                <thead>
                    <tr>
                        <th class="col-qty"><?php echo htmlspecialchars($colQty); ?></th>
                        <th class="col-desc"><?php echo htmlspecialchars($colDesc); ?></th>
                        <?php if ($showVendorPriceTotalColumnsReadonly) : ?>
                        <th class="col-price text-end" title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_COL_PRICE')); ?>"><?php echo htmlspecialchars($colPrice); ?></th>
                        <?php endif; ?>
                        <?php if ($showVendorPupColumn) : ?>
                        <th class="col-pup text-end" title="<?php echo htmlspecialchars($colPUnitProveedor); ?>"><?php echo htmlspecialchars($colPUnitProveedor); ?></th>
                        <?php endif; ?>
                        <?php if ($showVendorPriceTotalColumnsReadonly) : ?>
                        <th class="col-total text-end"><?php echo htmlspecialchars($colTotal); ?></th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($vendorLines as $line) :
                        $unit = round((float) ($line->price_per_sheet ?? 0), 2);
                        $pup  = round((float) ($line->vendor_precio_unit_proveedor ?? 0), 2);
                        ?>
                    <tr>
                        <td class="col-qty"><?php echo (int) $line->quantity; ?></td>
                        <td class="col-desc"><?php echo nl2br(htmlspecialchars((string) ($line->vendor_descripcion ?? ''))); ?></td>
                        <?php if ($showVendorPriceTotalColumnsReadonly) : ?>
                        <td class="col-price text-end">Q <?php echo number_format($unit, 2); ?></td>
                        <?php endif; ?>
                        <?php if ($showVendorPupColumn) : ?>
                        <td class="col-pup text-end">Q <?php echo number_format($pup, 2); ?></td>
                        <?php endif; ?>
                        <?php if ($showVendorPriceTotalColumnsReadonly) : ?>
                        <td class="col-total text-end">Q <?php echo number_format((float) ($line->total ?? 0), 2); ?></td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; ?>
                    <?php if ($gastosEnvioAmount > 0) : ?>
                    <tr>
                        <td class="col-qty">1</td>
                        <td class="col-desc"><?php echo htmlspecialchars($colGastosEnvio); ?></td>
                        <?php if ($showVendorPriceTotalColumnsReadonly) : ?>
                        <td class="col-price text-end">Q <?php echo number_format($gastosEnvioAmount, 2); ?></td>
                        <?php endif; ?>
                        <?php if ($showVendorPupColumn) : ?>
                        <td class="col-pup text-end">—</td>
                        <?php endif; ?>
                        <?php if ($showVendorPriceTotalColumnsReadonly) : ?>
                        <td class="col-total text-end">Q <?php echo number_format($gastosEnvioAmount, 2); ?></td>
                        <?php endif; ?>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
        <?php if (!$user->guest) : ?>
        <div class="d-flex flex-wrap justify-content-end gap-2 mt-2 align-items-center">
            <?php if ($solicitudCotWf && $pendingSolicitudCot) : ?>
            <button type="button" class="btn btn-primary" disabled title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_PENDING_HELP'), ENT_QUOTES, 'UTF-8'); ?>">
                <i class="fas fa-paper-plane" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_REQUEST_QUOTE_BTN'); ?>
            </button>
            <?php elseif ($showSolicitarCotizacionExternaBtn) : ?>
            <form method="post" action="<?php echo htmlspecialchars($solicitarCotProveedorUrl, ENT_QUOTES, 'UTF-8'); ?>" class="d-inline mb-0">
                <?php echo HTMLHelper::_('form.token'); ?>
                <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>" />
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-paper-plane" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_REQUEST_QUOTE_BTN'); ?>
                </button>
            </form>
            <?php endif; ?>
            <?php if ($showVendorQuoteDirectModalBtn) : ?>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#vendorQuoteModal" id="btn-vendor-quote-open-readonly">
                <i class="fas fa-paper-plane" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_REQUEST_QUOTE_BTN'); ?>
            </button>
            <?php endif; ?>
            <?php if ($canPedirCotizacionProveedorAprobaciones) : ?>
            <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#vendorQuoteModal" data-vendor-quote-mode="procesar" id="btn-vendor-quote-pedir-proveedor-readonly">
                <i class="fas fa-handshake" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_BTN_PEDIR_PROVEEDOR'); ?>
            </button>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    <?php elseif ($linesTableLocked && $canAdminEditPupWhenLocked) : ?>
        <?php if (empty($vendorLines) && $gastosEnvioAmount <= 0) : ?>
            <p class="text-muted"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_NO_LINES'); ?></p>
        <?php else : ?>
        <?php
        $adminLockedPricesFormId = 'proveedor-externo-admin-locked-prices-form';
        $adminLockedEnableLabel  = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ADMIN_LOCKED_ENABLE_EDIT');
        $adminLockedSaveLabel    = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ADMIN_LOCKED_SAVE');
        ?>
        <div class="js-admin-locked-prices-wrap">
        <form method="post" action="<?php echo htmlspecialchars($saveVendorLinesUrl); ?>" id="<?php echo htmlspecialchars($adminLockedPricesFormId); ?>" class="d-none" aria-hidden="true">
            <?php echo HTMLHelper::_('form.token'); ?>
            <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>">
        </form>
        <div class="pre-cot-vendor-lines-wrap">
            <table class="table table-sm table-bordered pre-cot-vendor-lines-table">
                <thead>
                    <tr>
                        <th class="col-qty"><?php echo htmlspecialchars($colQty); ?></th>
                        <th class="col-desc"><?php echo htmlspecialchars($colDesc); ?></th>
                        <th class="col-price text-end" title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_COL_PRICE')); ?>"><?php echo htmlspecialchars($colPrice); ?></th>
                        <?php if ($showVendorPupColumn) : ?>
                        <th class="col-pup text-end" title="<?php echo htmlspecialchars($colPUnitProveedor); ?>"><?php echo htmlspecialchars($colPUnitProveedor); ?></th>
                        <?php endif; ?>
                        <th class="col-total text-end"><?php echo htmlspecialchars($colTotal); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($vendorLines as $i => $line) :
                        $lid  = (int) $line->id;
                        $unit = round((float) ($line->price_per_sheet ?? 0), 2);
                        $pup  = round((float) ($line->vendor_precio_unit_proveedor ?? 0), 2);
                        $tot  = round((float) ($line->total ?? 0), 2);
                        ?>
                    <tr class="js-admin-locked-price-row">
                        <td class="col-qty js-admin-locked-qty"><?php echo (int) $line->quantity; ?></td>
                        <td class="col-desc"><?php echo nl2br(htmlspecialchars((string) ($line->vendor_descripcion ?? ''))); ?></td>
                        <td class="col-price">
                            <?php if ($lid > 0) : ?>
                            <input type="hidden" name="lines[<?php echo (int) $i; ?>][id]" value="<?php echo $lid; ?>" form="<?php echo htmlspecialchars($adminLockedPricesFormId); ?>">
                            <input type="number" class="form-control form-control-sm text-end js-admin-locked-line-input js-admin-locked-price" name="lines[<?php echo (int) $i; ?>][price_per_sheet]" form="<?php echo htmlspecialchars($adminLockedPricesFormId); ?>" min="0" step="0.01" value="<?php echo htmlspecialchars(number_format($unit, 2, '.', '')); ?>" title="<?php echo htmlspecialchars($colPrice); ?>" aria-label="<?php echo htmlspecialchars($colPrice); ?>" readonly tabindex="-1">
                            <?php else : ?>
                            <span class="text-muted small">—</span>
                            <?php endif; ?>
                        </td>
                        <?php if ($showVendorPupColumn) : ?>
                        <td class="col-pup">
                            <?php if ($lid > 0) : ?>
                            <input type="number" class="form-control form-control-sm text-end js-admin-locked-line-input js-admin-locked-pup" name="lines[<?php echo (int) $i; ?>][vendor_precio_unit_proveedor]" form="<?php echo htmlspecialchars($adminLockedPricesFormId); ?>" min="0" step="0.01" value="<?php echo htmlspecialchars(number_format($pup, 2, '.', '')); ?>" title="<?php echo htmlspecialchars($colPUnitProveedor); ?>" aria-label="<?php echo htmlspecialchars($colPUnitProveedor); ?>" readonly tabindex="-1">
                            <?php else : ?>
                            <span class="text-muted small">—</span>
                            <?php endif; ?>
                        </td>
                        <?php endif; ?>
                        <td class="col-total text-end align-middle"><span class="js-admin-locked-line-total">Q <?php echo number_format($tot, 2); ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if ($gastosEnvioAmount > 0) : ?>
                    <tr>
                        <td class="col-qty">1</td>
                        <td class="col-desc"><?php echo htmlspecialchars($colGastosEnvio); ?></td>
                        <td class="col-price text-end">Q <?php echo number_format($gastosEnvioAmount, 2); ?></td>
                        <?php if ($showVendorPupColumn) : ?>
                        <td class="col-pup text-end">—</td>
                        <?php endif; ?>
                        <td class="col-total text-end">Q <?php echo number_format($gastosEnvioAmount, 2); ?></td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if (!$user->guest) : ?>
        <div class="d-flex flex-wrap justify-content-end gap-2 mt-2 align-items-center">
            <button type="button" class="btn btn-primary js-admin-locked-prices-btn"
                    data-form-id="<?php echo htmlspecialchars($adminLockedPricesFormId, ENT_QUOTES, 'UTF-8'); ?>"
                    data-label-enable="<?php echo htmlspecialchars($adminLockedEnableLabel, ENT_QUOTES, 'UTF-8'); ?>"
                    data-label-save="<?php echo htmlspecialchars($adminLockedSaveLabel, ENT_QUOTES, 'UTF-8'); ?>"
                    data-editing="0"><?php echo htmlspecialchars($adminLockedEnableLabel); ?></button>
            <?php if ($solicitudCotWf && $pendingSolicitudCot) : ?>
            <button type="button" class="btn btn-primary" disabled title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_PENDING_HELP'), ENT_QUOTES, 'UTF-8'); ?>">
                <i class="fas fa-paper-plane" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_REQUEST_QUOTE_BTN'); ?>
            </button>
            <?php elseif ($showSolicitarCotizacionExternaBtn) : ?>
            <form method="post" action="<?php echo htmlspecialchars($solicitarCotProveedorUrl, ENT_QUOTES, 'UTF-8'); ?>" class="d-inline mb-0">
                <?php echo HTMLHelper::_('form.token'); ?>
                <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>" />
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-paper-plane" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_REQUEST_QUOTE_BTN'); ?>
                </button>
            </form>
            <?php endif; ?>
            <?php if ($showVendorQuoteDirectModalBtn) : ?>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#vendorQuoteModal" id="btn-vendor-quote-open-puponly">
                <i class="fas fa-paper-plane" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_REQUEST_QUOTE_BTN'); ?>
            </button>
            <?php endif; ?>
            <?php if ($canPedirCotizacionProveedorAprobaciones) : ?>
            <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#vendorQuoteModal" data-vendor-quote-mode="procesar" id="btn-vendor-quote-pedir-proveedor-puponly">
                <i class="fas fa-handshake" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_BTN_PEDIR_PROVEEDOR'); ?>
            </button>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <script>
        (function() {
            var wrap = document.querySelector('.js-admin-locked-prices-wrap');
            if (!wrap) {
                return;
            }
            function parseQty(td) {
                var n = parseInt(String(td && td.textContent ? td.textContent : '').trim(), 10);
                return isFinite(n) && n > 0 ? n : 1;
            }
            function updateRowTotal(row) {
                var qty = parseQty(row.querySelector('.js-admin-locked-qty'));
                var priceEl = row.querySelector('.js-admin-locked-price');
                var out = row.querySelector('.js-admin-locked-line-total');
                if (!priceEl || !out) {
                    return;
                }
                var p = parseFloat(String(priceEl.value).replace(',', '.'));
                p = isFinite(p) ? Math.round(p * 100) / 100 : 0;
                var t = Math.round(qty * p * 100) / 100;
                out.textContent = 'Q ' + t.toFixed(2);
            }
            wrap.querySelectorAll('.js-admin-locked-price-row').forEach(function(row) {
                var priceEl = row.querySelector('.js-admin-locked-price');
                if (priceEl) {
                    priceEl.addEventListener('input', function() { updateRowTotal(row); });
                }
            });
            wrap.addEventListener('click', function(e) {
                var btn = e.target && e.target.closest ? e.target.closest('.js-admin-locked-prices-btn') : null;
                if (!btn || !wrap.contains(btn)) {
                    return;
                }
                e.preventDefault();
                var editing = btn.getAttribute('data-editing') === '1';
                var formId = btn.getAttribute('data-form-id');
                var form = formId ? document.getElementById(formId) : null;
                if (!editing) {
                    wrap.querySelectorAll('.js-admin-locked-line-input').forEach(function(inp) {
                        inp.removeAttribute('readonly');
                        inp.removeAttribute('tabindex');
                    });
                    btn.setAttribute('data-editing', '1');
                    btn.textContent = btn.getAttribute('data-label-save') || '';
                    return;
                }
                if (form && typeof form.requestSubmit === 'function') {
                    form.requestSubmit();
                } else if (form) {
                    form.submit();
                }
            });
        })();
        </script>
        </div>
        <?php endif; ?>
    <?php else :
    if ($vendorLines === []) {
        $vendorLines = [
            (object) [
                'id'                           => 0,
                'quantity'                     => 1,
                'vendor_descripcion'           => '',
                'price_per_sheet'              => 0,
                'vendor_precio_unit_proveedor' => 0,
                'total'                        => 0,
                'line_type'                    => 'proveedor_externo',
            ],
        ];
    }
    ?>
    <?php $saveLinesFormId = 'proveedor-externo-lines-form'; ?>
    <?php /* Token + precot id only: line inputs use form= attribute so row upload/delete forms are not nested (invalid HTML). */ ?>
    <form method="post" action="<?php echo htmlspecialchars($saveVendorLinesUrl); ?>" id="<?php echo htmlspecialchars($saveLinesFormId); ?>" class="d-none" aria-hidden="true">
        <?php echo HTMLHelper::_('form.token'); ?>
        <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>">
        <input type="hidden" name="gastos_envio_present" id="gastos-envio-present-flag" value="<?php echo $hasGastosEnvioRow ? '1' : '0'; ?>">
    </form>
    <div class="pre-cot-vendor-lines-wrap mb-3">
            <table class="table table-sm table-bordered pre-cot-vendor-lines-table" id="proveedor-externo-lines-table">
                <thead>
                    <tr>
                        <th class="col-qty"><?php echo htmlspecialchars($colQty); ?></th>
                        <th class="col-desc"><?php echo htmlspecialchars($colDesc); ?></th>
                        <th class="col-price text-end" title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_COL_PRICE')); ?>"><?php echo htmlspecialchars($colPrice); ?></th>
                        <?php if ($showVendorPupColumn) : ?>
                        <th class="col-pup text-end" title="<?php echo htmlspecialchars($colPUnitProveedor); ?>"><?php echo htmlspecialchars($colPUnitProveedor); ?></th>
                        <?php endif; ?>
                        <th class="col-total text-end"><?php echo htmlspecialchars($colTotal); ?></th>
                        <th class="col-actions text-center"><span class="visually-hidden"><?php echo htmlspecialchars($colActions); ?></span></th>
                    </tr>
                </thead>
                <tbody id="proveedor-externo-lines-tbody">
                    <?php foreach ($vendorLines as $i => $line) :
                        $lid = (int) $line->id;
                        $unit = round((float) ($line->price_per_sheet ?? 0), 2);
                        $pup  = round((float) ($line->vendor_precio_unit_proveedor ?? 0), 2);
                        $tot  = round((float) ($line->total ?? 0), 2);
                        ?>
                    <tr class="proveedor-externo-line-row">
                        <td class="col-qty">
                            <input type="hidden" name="lines[<?php echo $i; ?>][id]" value="<?php echo $lid; ?>" form="<?php echo htmlspecialchars($saveLinesFormId); ?>">
                            <input type="number" class="form-control form-control-sm js-vendor-qty" name="lines[<?php echo $i; ?>][quantity]" form="<?php echo htmlspecialchars($saveLinesFormId); ?>" min="1" step="1" value="<?php echo (int) $line->quantity; ?>" required>
                        </td>
                        <td class="col-desc">
                            <textarea class="form-control form-control-sm" name="lines[<?php echo $i; ?>][vendor_descripcion]" form="<?php echo htmlspecialchars($saveLinesFormId); ?>" rows="2" aria-label="<?php echo htmlspecialchars($colDesc); ?>"><?php echo htmlspecialchars((string) ($line->vendor_descripcion ?? '')); ?></textarea>
                        </td>
                        <td class="col-price">
                            <input type="number" class="form-control form-control-sm text-end js-vendor-price" name="lines[<?php echo $i; ?>][price_per_sheet]" form="<?php echo htmlspecialchars($saveLinesFormId); ?>" min="0" step="0.01" value="<?php echo htmlspecialchars(number_format($unit, 2, '.', '')); ?>">
                        </td>
                        <?php if ($showVendorPupColumn) : ?>
                        <td class="col-pup">
                            <input type="number" class="form-control form-control-sm text-end js-vendor-pup" name="lines[<?php echo $i; ?>][vendor_precio_unit_proveedor]" form="<?php echo htmlspecialchars($saveLinesFormId); ?>" min="0" step="0.01" value="<?php echo htmlspecialchars(number_format($pup, 2, '.', '')); ?>" title="<?php echo htmlspecialchars($colPUnitProveedor); ?>" aria-label="<?php echo htmlspecialchars($colPUnitProveedor); ?>">
                        </td>
                        <?php endif; ?>
                        <td class="col-total text-end align-middle">
                            <span class="js-vendor-line-total">Q <?php echo number_format($tot, 2); ?></span>
                        </td>
                        <td class="col-actions text-center align-middle">
                            <?php if ($lid > 0) :
                                $deleteLineUrl = 'index.php?option=com_ordenproduccion&task=precotizacion.deleteLine&line_id=' . $lid . '&id=' . $preCotizacionId;
                                ?>
                            <form action="<?php echo Route::_($deleteLineUrl); ?>" method="post" class="d-inline" onsubmit="return confirm('<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_CONFIRM_DELETE_LINE')); ?>');">
                                <?php echo HTMLHelper::_('form.token'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger btn-vendor-row-action" title="<?php echo htmlspecialchars(Text::_('JACTION_DELETE')); ?>" aria-label="<?php echo htmlspecialchars(Text::_('JACTION_DELETE')); ?>">×</button>
                            </form>
                            <?php else : ?>
                            <button type="button" class="btn btn-sm btn-outline-secondary btn-vendor-row-action js-remove-vendor-row" title="<?php echo htmlspecialchars(Text::_('JACTION_DELETE')); ?>" aria-label="<?php echo htmlspecialchars(Text::_('JACTION_DELETE')); ?>">×</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if ($hasGastosEnvioRow) :
                        $gastosEnvioLineId = (int) $gastosEnvioLine->id;
                        ?>
                    <tr class="proveedor-externo-gastos-envio-row">
                        <td class="col-qty align-middle">1</td>
                        <td class="col-desc align-middle"><?php echo htmlspecialchars($colGastosEnvio); ?></td>
                        <td class="col-price">
                            <input type="number" class="form-control form-control-sm text-end js-gastos-envio-amount" name="gastos_envio" form="<?php echo htmlspecialchars($saveLinesFormId); ?>" min="0" step="0.01" value="<?php echo htmlspecialchars(number_format($gastosEnvioAmount, 2, '.', '')); ?>" aria-label="<?php echo htmlspecialchars($colGastosEnvio); ?>">
                        </td>
                        <?php if ($showVendorPupColumn) : ?>
                        <td class="col-pup text-end align-middle text-muted">—</td>
                        <?php endif; ?>
                        <td class="col-total text-end align-middle">
                            <span class="js-gastos-envio-total">Q <?php echo number_format($gastosEnvioAmount, 2); ?></span>
                        </td>
                        <td class="col-actions text-center align-middle">
                            <?php if ($gastosEnvioLineId > 0) :
                                $deleteGastosEnvioUrl = 'index.php?option=com_ordenproduccion&task=precotizacion.deleteLine&line_id=' . $gastosEnvioLineId . '&id=' . $preCotizacionId;
                                ?>
                            <form action="<?php echo Route::_($deleteGastosEnvioUrl); ?>" method="post" class="d-inline" onsubmit="return confirm('<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_CONFIRM_DELETE_LINE')); ?>');">
                                <?php echo HTMLHelper::_('form.token'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger btn-vendor-row-action" title="<?php echo htmlspecialchars(Text::_('JACTION_DELETE')); ?>" aria-label="<?php echo htmlspecialchars(Text::_('JACTION_DELETE')); ?>">×</button>
                            </form>
                            <?php else : ?>
                            <button type="button" class="btn btn-sm btn-outline-secondary btn-vendor-row-action js-remove-gastos-envio-row" title="<?php echo htmlspecialchars(Text::_('JACTION_DELETE')); ?>" aria-label="<?php echo htmlspecialchars(Text::_('JACTION_DELETE')); ?>">×</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
    </div>
        <div class="d-flex flex-wrap gap-2 mt-2 align-items-start justify-content-between">
            <?php if (!$user->guest) : ?>
            <div class="d-flex flex-wrap gap-2 align-items-center">
                <?php if ($showVendorQuoteDirectModalBtn) : ?>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#vendorQuoteModal" id="btn-vendor-quote-open-edit">
                    <i class="fas fa-paper-plane" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_REQUEST_QUOTE_BTN'); ?>
                </button>
                <?php endif; ?>
                <?php if ($canPedirCotizacionProveedorAprobaciones) : ?>
                <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#vendorQuoteModal" data-vendor-quote-mode="procesar" id="btn-vendor-quote-pedir-proveedor-edit">
                    <i class="fas fa-handshake" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_BTN_PEDIR_PROVEEDOR'); ?>
                </button>
                <?php endif; ?>
            </div>
            <?php else : ?>
            <div></div>
            <?php endif; ?>
            <div class="d-flex flex-column gap-2 align-items-stretch precot-vendor-save-stack" style="min-width: 220px; max-width: 100%;">
                <div class="text-end d-flex flex-wrap gap-2 justify-content-end">
                    <button type="button" class="btn btn-outline-primary btn-sm" id="proveedor-externo-add-line"><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ADD_LINE')); ?></button>
                    <button type="button" class="btn btn-outline-secondary btn-sm<?php echo $hasGastosEnvioRow ? ' d-none' : ''; ?>" id="proveedor-externo-add-gastos-envio"><?php echo htmlspecialchars($colGastosEnvio); ?></button>
                </div>
                <button type="submit" form="<?php echo htmlspecialchars($saveLinesFormId); ?>" class="btn btn-success w-100"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_SAVE_LINES'); ?></button>
                <?php if (!$user->guest && $solicitudCotWf && $pendingSolicitudCot) : ?>
                <button type="button" class="btn btn-primary w-100" disabled title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_PENDING_HELP'), ENT_QUOTES, 'UTF-8'); ?>">
                    <i class="fas fa-paper-plane" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_REQUEST_QUOTE_BTN'); ?>
                </button>
                <?php elseif (!$user->guest && $showSolicitarCotizacionExternaBtn) : ?>
                <form method="post" action="<?php echo htmlspecialchars($solicitarCotProveedorUrl, ENT_QUOTES, 'UTF-8'); ?>" class="mb-0 w-100">
                    <?php echo HTMLHelper::_('form.token'); ?>
                    <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>" />
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-paper-plane" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_REQUEST_QUOTE_BTN'); ?>
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    <?php
    $userCreCotModal = Factory::getUser();
    $cotDestUrlModal = trim((string) ComponentHelper::getParams('com_ordenproduccion')->get('cotizacion_destination_url', ''));
    // Igual que id= en el documento PRE: PK de pre_cotización, no el número PRE-xxxxxx.
    $preCotizacionIdParaCotUrl = (int) $preCotizacionId;
    if (!$userCreCotModal->guest && $cotDestUrlModal !== '') {
        include __DIR__ . '/crear_cotizacion_modal.php';
    }
    ?>

    <template id="proveedor-externo-line-template">
        <tr class="proveedor-externo-line-row">
            <td class="col-qty">
                <input type="hidden" name="lines[__I__][id]" value="0" form="<?php echo htmlspecialchars($saveLinesFormId); ?>">
                <input type="number" class="form-control form-control-sm js-vendor-qty" name="lines[__I__][quantity]" form="<?php echo htmlspecialchars($saveLinesFormId); ?>" min="1" step="1" value="1" required>
            </td>
            <td class="col-desc">
                <textarea class="form-control form-control-sm" name="lines[__I__][vendor_descripcion]" form="<?php echo htmlspecialchars($saveLinesFormId); ?>" rows="2"></textarea>
            </td>
            <td class="col-price">
                <input type="number" class="form-control form-control-sm text-end js-vendor-price" name="lines[__I__][price_per_sheet]" form="<?php echo htmlspecialchars($saveLinesFormId); ?>" min="0" step="0.01" value="0.00">
            </td>
            <?php if ($showVendorPupColumn) : ?>
            <td class="col-pup">
                <input type="number" class="form-control form-control-sm text-end js-vendor-pup" name="lines[__I__][vendor_precio_unit_proveedor]" form="<?php echo htmlspecialchars($saveLinesFormId); ?>" min="0" step="0.01" value="0.00" title="<?php echo htmlspecialchars($colPUnitProveedor); ?>" aria-label="<?php echo htmlspecialchars($colPUnitProveedor); ?>">
            </td>
            <?php endif; ?>
            <td class="col-total text-end align-middle">
                <span class="js-vendor-line-total">Q 0.00</span>
            </td>
            <td class="col-actions text-center align-middle">
                <button type="button" class="btn btn-sm btn-outline-secondary btn-vendor-row-action js-remove-vendor-row" title="<?php echo htmlspecialchars(Text::_('JACTION_DELETE')); ?>" aria-label="<?php echo htmlspecialchars(Text::_('JACTION_DELETE')); ?>">×</button>
            </td>
        </tr>
    </template>
    <template id="proveedor-externo-gastos-envio-template">
        <tr class="proveedor-externo-gastos-envio-row">
            <td class="col-qty align-middle">1</td>
            <td class="col-desc align-middle"><?php echo htmlspecialchars($colGastosEnvio); ?></td>
            <td class="col-price">
                <input type="number" class="form-control form-control-sm text-end js-gastos-envio-amount" name="gastos_envio" form="<?php echo htmlspecialchars($saveLinesFormId); ?>" min="0" step="0.01" value="0.00" aria-label="<?php echo htmlspecialchars($colGastosEnvio); ?>">
            </td>
            <?php if ($showVendorPupColumn) : ?>
            <td class="col-pup text-end align-middle text-muted">—</td>
            <?php endif; ?>
            <td class="col-total text-end align-middle">
                <span class="js-gastos-envio-total">Q 0.00</span>
            </td>
            <td class="col-actions text-center align-middle">
                <button type="button" class="btn btn-sm btn-outline-secondary btn-vendor-row-action js-remove-gastos-envio-row" title="<?php echo htmlspecialchars(Text::_('JACTION_DELETE')); ?>" aria-label="<?php echo htmlspecialchars(Text::_('JACTION_DELETE')); ?>">×</button>
            </td>
        </tr>
    </template>
    <script>
    (function() {
        var tbody = document.getElementById('proveedor-externo-lines-tbody');
        var tpl = document.getElementById('proveedor-externo-line-template');
        var gastosTpl = document.getElementById('proveedor-externo-gastos-envio-template');
        var btnAdd = document.getElementById('proveedor-externo-add-line');
        var btnAddGastos = document.getElementById('proveedor-externo-add-gastos-envio');
        var gastosPresentFlag = document.getElementById('gastos-envio-present-flag');
        if (!tbody || !tpl || !btnAdd) return;
        var nextIdx = tbody.querySelectorAll('tr.proveedor-externo-line-row').length;

        function setGastosEnvioPresent(isPresent) {
            if (gastosPresentFlag) {
                gastosPresentFlag.value = isPresent ? '1' : '0';
            }
            if (btnAddGastos) {
                btnAddGastos.classList.toggle('d-none', !!isPresent);
            }
        }

        function bindGastosEnvioRow(row) {
            var inp = row.querySelector('.js-gastos-envio-amount');
            var out = row.querySelector('.js-gastos-envio-total');
            if (inp && out) {
                inp.addEventListener('input', function() {
                    var v = Math.round(parseNum(inp) * 100) / 100;
                    out.textContent = 'Q ' + v.toFixed(2);
                });
                var v0 = Math.round(parseNum(inp) * 100) / 100;
                out.textContent = 'Q ' + v0.toFixed(2);
            }
            var rm = row.querySelector('.js-remove-gastos-envio-row');
            if (rm) {
                rm.addEventListener('click', function() {
                    row.parentNode.removeChild(row);
                    setGastosEnvioPresent(false);
                });
            }
        }

        function parseNum(el) {
            if (!el) return 0;
            var v = parseFloat(String(el.value).replace(',', '.'));
            return isFinite(v) ? v : 0;
        }

        function updateRowTotal(row) {
            var q = row.querySelector('.js-vendor-qty');
            var p = row.querySelector('.js-vendor-price');
            var out = row.querySelector('.js-vendor-line-total');
            if (!out) return;
            var qty = Math.max(1, Math.floor(parseNum(q) || 1));
            if (q && String(q.value) !== String(qty)) q.value = qty;
            var price = Math.round(parseNum(p) * 100) / 100;
            var t = Math.round(qty * price * 100) / 100;
            out.textContent = 'Q ' + t.toFixed(2);
        }

        function bindRow(row) {
            row.querySelectorAll('.js-vendor-qty, .js-vendor-price').forEach(function(el) {
                el.addEventListener('input', function() { updateRowTotal(row); });
            });
            var rm = row.querySelector('.js-remove-vendor-row');
            if (rm) {
                rm.addEventListener('click', function() {
                    if (tbody.querySelectorAll('tr.proveedor-externo-line-row').length <= 1) {
                        var q = row.querySelector('.js-vendor-qty');
                        var pr = row.querySelector('.js-vendor-price');
                        var pup = row.querySelector('.js-vendor-pup');
                        var ta = row.querySelector('textarea[name*="[vendor_descripcion]"]');
                        if (q) q.value = '1';
                        if (pr) pr.value = '0.00';
                        if (pup) pup.value = '0.00';
                        if (ta) ta.value = '';
                        updateRowTotal(row);
                        return;
                    }
                    row.parentNode.removeChild(row);
                });
            }
            updateRowTotal(row);
        }

        tbody.querySelectorAll('tr.proveedor-externo-line-row').forEach(bindRow);

        var existingGastosRow = tbody.querySelector('tr.proveedor-externo-gastos-envio-row');
        if (existingGastosRow) {
            bindGastosEnvioRow(existingGastosRow);
            setGastosEnvioPresent(true);
        } else {
            setGastosEnvioPresent(false);
        }

        if (btnAddGastos && gastosTpl) {
            btnAddGastos.addEventListener('click', function() {
                if (tbody.querySelector('tr.proveedor-externo-gastos-envio-row')) {
                    return;
                }
                var wrap = document.createElement('tbody');
                wrap.innerHTML = gastosTpl.innerHTML.trim();
                var row = wrap.firstElementChild;
                if (!row) return;
                tbody.appendChild(row);
                bindGastosEnvioRow(row);
                setGastosEnvioPresent(true);
                var inp = row.querySelector('.js-gastos-envio-amount');
                if (inp) {
                    inp.focus();
                }
            });
        }

        btnAdd.addEventListener('click', function() {
            var html = tpl.innerHTML.replace(/__I__/g, String(nextIdx));
            var wrap = document.createElement('tbody');
            wrap.innerHTML = html.trim();
            var row = wrap.firstElementChild;
            if (!row) return;
            tbody.appendChild(row);
            nextIdx++;
            bindRow(row);
        });
    })();
    </script>
    <?php endif; ?>

    <style>
    .margen-total-row td { background-color: #d4edda !important; color: #155724; font-weight: 500; }
    </style>
    <div class="table-responsive mt-4">
        <table class="table table-sm w-auto ms-auto">
            <tbody>
                <tr>
                    <td class="text-end pe-3"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_SUBTOTAL'); ?></td>
                    <td class="text-end fw-bold">Q <?php echo number_format($linesSubtotal, 2); ?></td>
                </tr>
                <?php $margenTotal = $margenAmount + $margenAdicional; ?>
                <?php if ($precotFooterShowIva) : ?>
                <tr>
                    <td class="text-end pe-3"><?php echo Text::_('COM_ORDENPRODUCCION_PARAM_IVA'); ?><?php echo $paramIva != 0 ? ' (' . number_format($paramIva, 1) . '%)' : ''; ?></td>
                    <td class="text-end">Q <?php echo number_format($ivaAmount, 2); ?></td>
                </tr>
                <?php endif; ?>
                <?php if ($precotFooterShowIsr) : ?>
                <tr>
                    <td class="text-end pe-3"><?php echo Text::_('COM_ORDENPRODUCCION_PARAM_ISR'); ?><?php echo $paramIsr != 0 ? ' (' . number_format($paramIsr, 1) . '%)' : ''; ?></td>
                    <td class="text-end">Q <?php echo number_format($isrAmount, 2); ?></td>
                </tr>
                <?php endif; ?>
                <?php if ($paramComision != 0) : ?>
                <tr>
                    <td class="text-end pe-3"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_BONO_VENTA'); ?> (<?php echo number_format($paramComision, 1); ?>%)</td>
                    <td class="text-end">Q <?php echo number_format($comisionAmount, 2); ?></td>
                </tr>
                <?php endif; ?>
                <?php if ($canSeePrecotInternalTax && $paramMargen != 0) : ?>
                <tr class="margen-total-row">
                    <td class="text-end pe-3"><?php echo Text::_('COM_ORDENPRODUCCION_PARAM_MARGEN_GANANCIA'); ?> (<?php echo htmlspecialchars($precotMargenPctText, ENT_QUOTES, 'UTF-8'); ?>%)</td>
                    <td class="text-end">Q <?php echo number_format($margenAmount, 2, '.', ''); ?></td>
                </tr>
                <tr class="margen-total-row">
                    <td class="text-end pe-3"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_MARGEN_ADICIONAL'); ?></td>
                    <td class="text-end">Q <?php echo number_format($margenAdicional, 2, '.', ''); ?></td>
                </tr>
                <?php endif; ?>
                <?php if ($margenAdicional > 0) : ?>
                <tr>
                    <td class="text-end pe-3"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_MARGEN_TOTAL'); ?></td>
                    <td class="text-end">Q <?php echo \number_format($margenTotal, 2, '.', ''); ?></td>
                </tr>
                <?php endif; ?>
                <tr class="table-secondary">
                    <td class="text-end pe-3 fw-bold"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TOTAL'); ?></td>
                    <td class="text-end fw-bold">Q <?php echo number_format($displayTotal, 2); ?></td>
                </tr>
                <?php if ($comisionMargenAdicionalAmount > 0) : ?>
                <?php $totalComision = $comisionAmount + $comisionMargenAdicionalAmount; ?>
                <tr>
                    <td class="text-end pe-3"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_COMISION_MARGEN_ADICIONAL'); ?> (<?php echo htmlspecialchars($precotComisionMaPctText, ENT_QUOTES, 'UTF-8'); ?>%) = Q.<?php echo \number_format($comisionMargenAdicionalAmount, 2, '.', ''); ?> &mdash; <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TOTAL_COMISION'); ?></td>
                    <td class="text-end fw-semibold"><?php echo 'Q ' . \number_format($totalComision, 2, '.', ''); ?></td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if (!$user->guest) : ?>
    <form id="vendor-quote-email-form" method="post" action="<?php echo htmlspecialchars($vendorQuoteSendEmailUrl); ?>" class="d-none" aria-hidden="true">
        <?php echo HTMLHelper::_('form.token'); ?>
        <input type="hidden" name="precot_id" value="<?php echo (int) $preCotizacionId; ?>">
        <input type="hidden" name="proveedor_id" id="vendor-quote-email-proveedor-id" value="">
    </form>

    <div class="modal fade" id="vendorQuoteModal" tabindex="-1" aria-labelledby="vendorQuoteModalTitle" aria-hidden="true"
         data-proveedores-url="<?php echo htmlspecialchars($vendorQuoteProveedoresUrl); ?>"
         data-ajax-index="<?php echo htmlspecialchars($vendorQuoteAjaxIndex); ?>"
         data-token-name="<?php echo htmlspecialchars($token); ?>"
         data-precot-id="<?php echo (int) $preCotizacionId; ?>">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title h5" id="vendorQuoteModalTitle"><?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_MODAL_TITLE'); ?></h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo htmlspecialchars(Text::_('JCLOSE')); ?>"></button>
                </div>
                <div class="modal-body">
                    <p class="small text-muted mb-2" id="vendor-quote-status"><?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_SELECT_VENDOR'); ?></p>
                    <div class="row g-3">
                        <div class="col-md-5">
                            <div class="list-group small" id="vendor-quote-proveedor-list" role="listbox" aria-label="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_SELECT_VENDOR')); ?>"></div>
                        </div>
                        <div class="col-md-7">
                            <div id="vendor-quote-detail-panel" class="d-none border rounded p-2 mb-3 small bg-light">
                                <div class="fw-bold mb-2"><?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_VENDOR_DETAIL_TITLE'); ?></div>
                                <dl class="row mb-0" id="vendor-quote-detail-dl"></dl>
                            </div>
                            <div id="vendor-quote-method-wrap" class="d-none">
                                <div class="fw-bold mb-2"><?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_METHOD_LABEL'); ?></div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="vendor_quote_method" id="vqm-email" value="email" checked>
                                    <label class="form-check-label" for="vqm-email"><?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_METHOD_EMAIL'); ?></label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="vendor_quote_method" id="vqm-cell" value="cellphone">
                                    <label class="form-check-label" for="vqm-cell"><?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_METHOD_CELLPHONE'); ?></label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="vendor_quote_method" id="vqm-pdf" value="pdf">
                                    <label class="form-check-label" for="vqm-pdf"><?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_METHOD_PDF'); ?></label>
                                </div>
                            </div>
                            <div id="vendor-quote-cell-panel" class="mt-3 d-none">
                                <label class="form-label fw-bold" for="vendor-quote-cell-text"><?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_COMPOSE_MESSAGE'); ?></label>
                                <textarea id="vendor-quote-cell-text" class="form-control font-monospace small" rows="6" readonly></textarea>
                                <div class="d-flex flex-wrap gap-2 mt-2">
                                    <button type="button" class="btn btn-outline-secondary btn-sm" id="vendor-quote-copy-msg"><?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_COPY_MESSAGE'); ?></button>
                                    <a href="#" class="btn btn-outline-primary btn-sm d-none" id="vendor-quote-tel-link"><?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_OPEN_TEL'); ?></a>
                                </div>
                                <p class="small text-muted mt-2 mb-0" id="vendor-quote-phone-hint"></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer flex-wrap gap-2">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo Text::_('JCANCEL'); ?></button>
                    <button type="button" class="btn btn-primary d-none" id="vendor-quote-btn-primary"><?php echo Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_ACTION_SEND_EMAIL'); ?></button>
                </div>
            </div>
        </div>
    </div>
    <script>
    (function() {
        var modalEl = document.getElementById('vendorQuoteModal');
        if (!modalEl) return;

        var msgs = {
            loading: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_LOADING_PROVEEDORES')); ?>,
            loadError: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_LOAD_ERROR')); ?>,
            selectFirst: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_SELECT_VENDOR_FIRST')); ?>,
            copied: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_COPIED')); ?>,
            noPhone: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_NO_PHONE')); ?>,
            sendEmail: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_ACTION_SEND_EMAIL')); ?>,
            composeCell: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_ACTION_COMPOSE_CELL')); ?>,
            downloadPdf: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_ACTION_DOWNLOAD_PDF')); ?>,
            procesar: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_ACTION_PROCESAR')); ?>,
            det: {
                name: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PROVEEDORES_NAME')); ?>,
                nit: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PROVEEDORES_NIT')); ?>,
                address: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PROVEEDORES_ADDRESS')); ?>,
                phone: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PROVEEDORES_PHONE')); ?>,
                contact_name: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PROVEEDORES_CONTACT_NAME')); ?>,
                contact_cellphone: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PROVEEDORES_CONTACT_CELL')); ?>,
                contact_email: <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PROVEEDORES_CONTACT_EMAIL')); ?>
            }
        };

        var listEl = document.getElementById('vendor-quote-proveedor-list');
        var statusEl = document.getElementById('vendor-quote-status');
        var methodWrap = document.getElementById('vendor-quote-method-wrap');
        var cellPanel = document.getElementById('vendor-quote-cell-panel');
        var cellText = document.getElementById('vendor-quote-cell-text');
        var btnPrimary = document.getElementById('vendor-quote-btn-primary');
        var btnCopy = document.getElementById('vendor-quote-copy-msg');
        var telLink = document.getElementById('vendor-quote-tel-link');
        var phoneHint = document.getElementById('vendor-quote-phone-hint');
        var emailProveedorInput = document.getElementById('vendor-quote-email-proveedor-id');
        var emailForm = document.getElementById('vendor-quote-email-form');

        var proveedoresUrl = modalEl.getAttribute('data-proveedores-url') || '';
        var ajaxIndex = modalEl.getAttribute('data-ajax-index') || '';
        var tokenName = modalEl.getAttribute('data-token-name') || '';
        var precotId = modalEl.getAttribute('data-precot-id') || '0';

        var selectedId = 0;
        var cellLoaded = false;
        var uiMode = 'default';
        var detailPanel = document.getElementById('vendor-quote-detail-panel');
        var detailDl = document.getElementById('vendor-quote-detail-dl');

        /**
         * Build index.php?option=com_ordenproduccion&task=... URLs with proper query string (works with SEF on the site).
         *
         * @param {string} task
         * @param {Record<string, string>} extraParams
         * @param {boolean} useFormatJson
         * @return {string}
         */
        function buildComponentTaskUrl(task, extraParams, useFormatJson) {
            var base = ajaxIndex || (window.location.origin + '/index.php');
            var u = new URL(base, window.location.href);
            u.searchParams.set('option', 'com_ordenproduccion');
            u.searchParams.set('task', task);
            if (useFormatJson !== false) {
                u.searchParams.set('format', 'json');
            }
            if (tokenName) {
                u.searchParams.set(tokenName, '1');
            }
            if (extraParams) {
                Object.keys(extraParams).forEach(function(k) {
                    u.searchParams.set(k, extraParams[k]);
                });
            }
            return u.toString();
        }

        function setStatus(t) {
            if (statusEl) statusEl.textContent = t;
        }

        function getMethod() {
            var r = modalEl.querySelector('input[name="vendor_quote_method"]:checked');
            return r ? r.value : 'email';
        }

        function updatePrimaryButton() {
            if (!btnPrimary) return;
            var m = getMethod();
            cellPanel.classList.add('d-none');
            if (uiMode === 'procesar') {
                btnPrimary.textContent = msgs.procesar;
                btnPrimary.classList.remove('d-none');
                return;
            }
            if (m === 'email') {
                btnPrimary.textContent = msgs.sendEmail;
                btnPrimary.classList.remove('d-none');
            } else if (m === 'cellphone') {
                btnPrimary.textContent = msgs.composeCell;
                btnPrimary.classList.remove('d-none');
            } else {
                btnPrimary.textContent = msgs.downloadPdf;
                btnPrimary.classList.remove('d-none');
            }
        }

        function fillVendorDetail(p) {
            if (!detailDl || !detailPanel || !p) {
                return;
            }
            detailDl.innerHTML = '';
            var L = msgs.det || {};
            function addRow(label, val) {
                var s = val == null ? '' : String(val).trim();
                if (!s) {
                    return;
                }
                var dt = document.createElement('dt');
                dt.className = 'col-sm-4 text-muted';
                dt.textContent = label;
                var dd = document.createElement('dd');
                dd.className = 'col-sm-8 mb-1';
                dd.textContent = s;
                detailDl.appendChild(dt);
                detailDl.appendChild(dd);
            }
            addRow(L.name || '', p.name);
            addRow(L.nit || '', p.nit);
            addRow(L.address || '', p.address);
            addRow(L.phone || '', p.phone);
            addRow(L.contact_name || '', p.contact_name);
            addRow(L.contact_cellphone || '', p.contact_cellphone);
            addRow(L.contact_email || '', p.contact_email);
            detailPanel.classList.remove('d-none');
        }

        function resetModal() {
            selectedId = 0;
            cellLoaded = false;
            listEl.innerHTML = '';
            methodWrap.classList.add('d-none');
            cellPanel.classList.add('d-none');
            cellText.value = '';
            btnPrimary.classList.add('d-none');
            telLink.classList.add('d-none');
            phoneHint.textContent = '';
            if (emailProveedorInput) emailProveedorInput.value = '';
            if (detailPanel) detailPanel.classList.add('d-none');
            if (detailDl) detailDl.innerHTML = '';
        }

        function renderDetail() {
            methodWrap.classList.remove('d-none');
            updatePrimaryButton();
        }

        function selectProveedor(id) {
            selectedId = id;
            cellLoaded = false;
            cellPanel.classList.add('d-none');
            listEl.querySelectorAll('.list-group-item').forEach(function(el) {
                el.classList.toggle('active', parseInt(el.getAttribute('data-id'), 10) === id);
            });
            if (emailProveedorInput) emailProveedorInput.value = String(id);
            var url = buildComponentTaskUrl('precotizacion.vendorQuoteProveedorJson', { proveedor_id: String(id) }, true);
            setStatus(msgs.loading);
            fetch(url, { credentials: 'same-origin' })
                .then(function(r) {
                    return r.text().then(function(t) {
                        try {
                            return JSON.parse(t);
                        } catch (e) {
                            return null;
                        }
                    });
                })
                .then(function(data) {
                    if (!data || !data.ok || !data.proveedor) {
                        setStatus(msgs.loadError);
                        return;
                    }
                    fillVendorDetail(data.proveedor);
                    renderDetail();
                    setStatus('');
                })
                .catch(function() { setStatus(msgs.loadError); });
        }

        function loadProveedores() {
            setStatus(msgs.loading);
            fetch(proveedoresUrl, { credentials: 'same-origin' })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    listEl.innerHTML = '';
                    if (!data || !data.ok || !Array.isArray(data.proveedores)) {
                        setStatus(msgs.loadError);
                        return;
                    }
                    if (data.proveedores.length === 0) {
                        setStatus(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PROVEEDORES_EMPTY')); ?>);
                        return;
                    }
                    data.proveedores.forEach(function(pr) {
                        var a = document.createElement('button');
                        a.type = 'button';
                        a.className = 'list-group-item list-group-item-action';
                        a.setAttribute('data-id', String(pr.id));
                        a.textContent = pr.name || ('#' + pr.id);
                        a.addEventListener('click', function() { selectProveedor(parseInt(pr.id, 10)); });
                        listEl.appendChild(a);
                    });
                    setStatus(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_VENDOR_QUOTE_SELECT_VENDOR')); ?>);
                })
                .catch(function() {
                    listEl.innerHTML = '';
                    setStatus(msgs.loadError);
                });
        }

        modalEl.addEventListener('show.bs.modal', function(ev) {
            var trg = ev.relatedTarget || null;
            uiMode = (trg && trg.getAttribute('data-vendor-quote-mode') === 'procesar') ? 'procesar' : 'default';
            resetModal();
            loadProveedores();
        });

        modalEl.querySelectorAll('input[name="vendor_quote_method"]').forEach(function(inp) {
            inp.addEventListener('change', function() {
                cellPanel.classList.add('d-none');
                cellLoaded = false;
                updatePrimaryButton();
            });
        });

        if (btnCopy && cellText) {
            btnCopy.addEventListener('click', function() {
                cellText.select();
                document.execCommand('copy');
                if (phoneHint) {
                    phoneHint.textContent = msgs.copied;
                    setTimeout(function() { if (phoneHint.textContent === msgs.copied) phoneHint.textContent = ''; }, 2000);
                }
            });
        }

        if (btnPrimary) {
            btnPrimary.addEventListener('click', function() {
                if (selectedId < 1) {
                    setStatus(msgs.selectFirst);
                    return;
                }
                var m = getMethod();
                if (m === 'email') {
                    if (emailForm) emailForm.submit();
                    return;
                }
                if (m === 'pdf') {
                    var pdfUrl = buildComponentTaskUrl(
                        'precotizacion.vendorQuoteDownloadPdf',
                        { precot_id: String(precotId), proveedor_id: String(selectedId) },
                        false
                    );
                    window.open(pdfUrl, '_blank', 'noopener,noreferrer');
                    var modalApi = window.bootstrap && window.bootstrap.Modal;
                    if (modalApi) {
                        var inst = modalApi.getInstance(modalEl);
                        if (inst) {
                            inst.hide();
                        }
                    }
                    window.location.reload();
                    return;
                }
                if (m === 'cellphone') {
                    if (cellLoaded) {
                        cellPanel.classList.remove('d-none');
                        return;
                    }
                    var fd = new FormData();
                    fd.append(tokenName, '1');
                    fd.append('precot_id', precotId);
                    fd.append('proveedor_id', String(selectedId));
                    setStatus(msgs.loading);
                    fetch(buildComponentTaskUrl('precotizacion.vendorQuoteCellphoneJson', {}, true), { method: 'POST', body: fd, credentials: 'same-origin' })
                        .then(function(r) { return r.json(); })
                        .then(function(data) {
                            setStatus('');
                            if (!data || !data.ok) {
                                setStatus(msgs.loadError);
                                return;
                            }
                            cellText.value = data.message_text || '';
                            cellLoaded = true;
                            cellPanel.classList.remove('d-none');
                            var ph = (data.phone || '').trim();
                            if (ph) {
                                telLink.href = 'tel:' + ph.replace(/\s+/g, '');
                                telLink.classList.remove('d-none');
                                phoneHint.textContent = ph;
                            } else {
                                telLink.classList.add('d-none');
                                phoneHint.textContent = msgs.noPhone;
                            }
                        })
                        .catch(function() { setStatus(msgs.loadError); });
                }
            });
        }
    })();
    </script>
    <?php endif; ?>

    <?php
    $vendorQuoteEvents = $this->precotVendorQuoteEvents ?? [];
    ?>
    <?php if ($canViewVendorQuoteRequestLog && !empty($vendorQuoteEvents)) : ?>
    <section class="precot-vendor-quote-event-log mt-4 pt-4 border-top" aria-label="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_LOG_TITLE')); ?>">
        <h2 class="h6 mb-2"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_LOG_TITLE'); ?></h2>
        <p class="small text-muted mb-3"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_LOG_ATTACH_HINT'); ?></p>
        <div class="table-responsive">
            <table class="table table-sm table-bordered align-middle">
                <thead class="table-light">
                    <tr>
                        <th scope="col"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_COL_DATE'); ?></th>
                        <th scope="col"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_COL_USER'); ?></th>
                        <th scope="col"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_COL_ACTION'); ?></th>
                        <th scope="col"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_COL_VENDOR'); ?></th>
                        <th scope="col"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_COL_DETAIL'); ?></th>
                        <th scope="col" class="col-evt-spacer p-1" aria-hidden="true"></th>
                        <th scope="col" class="col-evt-attach text-center" title="<?php echo htmlspecialchars($colAttach); ?>"><span class="visually-hidden"><?php echo htmlspecialchars($colAttach); ?></span><i class="fas fa-paperclip" aria-hidden="true"></i></th>
                        <th scope="col" class="col-evt-save text-center" title="<?php echo htmlspecialchars($labelSaveEventCondiciones); ?>"><span class="visually-hidden"><?php echo htmlspecialchars($labelSaveEventCondiciones); ?></span><i class="fas fa-save" aria-hidden="true"></i></th>
                        <th scope="col" class="col-evt-oc text-center" title="<?php echo htmlspecialchars($colOrdenCompra); ?>">
                            <span class="visually-hidden"><?php echo htmlspecialchars($colOrdenCompra); ?></span>
                            <span class="d-inline-flex flex-column align-items-center gap-0 lh-1" aria-hidden="true">
                                <i class="fas fa-file-pdf text-secondary" style="font-size: 0.65rem;"></i>
                                <i class="fas fa-money-bill-wave"></i>
                            </span>
                        </th>
                        <th scope="col" class="col-evt-delete text-center" title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_DELETE')); ?>"><span class="visually-hidden"><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_DELETE')); ?></span><i class="fas fa-trash" aria-hidden="true"></i></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($vendorQuoteEvents as $ev) :
                        $meta = [];
                        if (!empty($ev->meta)) {
                            $decoded = json_decode((string) $ev->meta, true);
                            $meta    = is_array($decoded) ? $decoded : [];
                        }
                        $etype = (string) ($ev->event_type ?? '');
                        $actionLabel = $etype;
                        if ($etype === 'email_sent') {
                            $actionLabel = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_EMAIL_SENT');
                        } elseif ($etype === 'pdf_download') {
                            $actionLabel = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_PDF_DOWNLOAD');
                        } elseif ($etype === 'cellphone_compose') {
                            $actionLabel = Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_CELLPHONE_COMPOSE');
                        }
                        $detail = '';
                        if ($etype === 'email_sent') {
                            $detail = trim((string) ($meta['to_email'] ?? ''));
                            $subj   = trim((string) ($meta['subject'] ?? ''));
                            if ($subj !== '') {
                                $detail .= ($detail !== '' ? ' — ' : '') . $subj;
                            }
                        } elseif ($etype === 'pdf_download') {
                            $detail = (string) ($meta['filename'] ?? '');
                        } elseif ($etype === 'cellphone_compose') {
                            $detail = (string) ($meta['phone'] ?? '');
                        }
                        $actor = trim((string) ($meta['actor_name'] ?? ''));
                        if ($actor === '' && !empty($ev->created_by)) {
                            $actor = '#' . (int) $ev->created_by;
                        }
                        $provName = trim((string) ($meta['proveedor_name'] ?? ''));
                        if ($provName === '' && !empty($ev->proveedor_id)) {
                            $provName = '#' . (int) $ev->proveedor_id;
                        }
                        $evtId = (int) ($ev->id ?? 0);
                        $evtProveedorId = (int) ($ev->proveedor_id ?? 0);
                        $evtCondiciones = isset($ev->condiciones_entrega) ? trim((string) $ev->condiciones_entrega) : '';
                        $evtAttachRel = isset($ev->vendor_quote_attachment) ? trim((string) $ev->vendor_quote_attachment) : '';
                        $evtAttachHref = $evtAttachRel !== ''
                            ? rtrim(Uri::root(), '/') . '/' . str_replace('\\', '/', ltrim($evtAttachRel, '/'))
                            : '';
                        $evtAttachExt = $evtAttachRel !== '' ? strtolower(pathinfo($evtAttachRel, PATHINFO_EXTENSION)) : '';
                        ?>
                    <tr class="precot-vendor-evt-main-row">
                        <td class="text-nowrap small"><?php echo htmlspecialchars(HTMLHelper::_('date', $ev->created, Text::_('DATE_FORMAT_LC6'))); ?></td>
                        <td class="small"><?php echo htmlspecialchars($actor); ?></td>
                        <td class="small"><?php echo htmlspecialchars($actionLabel); ?></td>
                        <td class="small"><?php echo htmlspecialchars($provName); ?></td>
                        <td class="small"><?php echo htmlspecialchars($detail); ?></td>
                        <td class="col-evt-spacer small p-1 bg-light bg-opacity-25" aria-hidden="true">&nbsp;</td>
                        <td class="col-evt-attach text-center align-middle" rowspan="2">
                            <div class="d-flex justify-content-center align-items-center gap-1 flex-wrap">
                                <?php if ($evtAttachHref !== '') : ?>
                                <button type="button" class="btn btn-sm btn-outline-primary js-vendor-line-view p-1"
                                        data-url="<?php echo htmlspecialchars($evtAttachHref); ?>"
                                        data-ext="<?php echo htmlspecialchars($evtAttachExt); ?>"
                                        title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_ATTACH_VIEW')); ?>"
                                        aria-label="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_ATTACH_VIEW')); ?>">
                                    <i class="fas fa-eye" aria-hidden="true"></i>
                                </button>
                                <?php endif; ?>
                                <?php if ($canEditVendorQuoteEventLogRow && $evtId > 0) : ?>
                                <form method="post" enctype="multipart/form-data" action="<?php echo htmlspecialchars($uploadVendorQuoteUrl); ?>" class="d-inline mb-0">
                                    <?php echo HTMLHelper::_('form.token'); ?>
                                    <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>">
                                    <input type="hidden" name="event_id" value="<?php echo (int) $evtId; ?>">
                                    <input type="file" name="vendor_quote_file" id="vendor-event-file-<?php echo (int) $evtId; ?>"
                                           class="d-none js-vendor-event-file"
                                           accept=".pdf,.jpg,.jpeg,.png,image/jpeg,image/png,application/pdf"
                                           aria-label="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_ATTACH_UPLOAD')); ?>">
                                    <label for="vendor-event-file-<?php echo (int) $evtId; ?>"
                                           class="btn btn-sm btn-outline-secondary p-1 mb-0"
                                           title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_ATTACH_UPLOAD')); ?>">
                                        <i class="fas fa-paperclip" aria-hidden="true"></i><span class="visually-hidden"><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_ATTACH_UPLOAD')); ?></span>
                                    </label>
                                </form>
                                <?php elseif ($evtAttachHref === '') : ?>
                                <span class="text-muted small">—</span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td class="col-evt-save text-center align-middle" rowspan="2">
                            <?php if ($canEditVendorQuoteEventLogRow && $evtId > 0) : ?>
                            <form id="vendor-evt-cond-form-<?php echo (int) $evtId; ?>" method="post" action="<?php echo htmlspecialchars($saveVendorQuoteEventCondicionesUrl); ?>" class="mb-0">
                                <?php echo HTMLHelper::_('form.token'); ?>
                                <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>">
                                <input type="hidden" name="event_id" value="<?php echo (int) $evtId; ?>">
                                <button type="submit" class="btn btn-sm btn-outline-primary p-1" title="<?php echo htmlspecialchars($labelSaveEventCondiciones); ?>" aria-label="<?php echo htmlspecialchars($labelSaveEventCondiciones); ?>">
                                    <i class="fas fa-save" aria-hidden="true"></i>
                                </button>
                            </form>
                            <?php else : ?>
                            <span class="text-muted small">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="col-evt-oc text-center align-middle" rowspan="2">
                            <?php
                            $ocRowSnap = isset($ordenCompraLatestByProveedor[$evtProveedorId]) ? $ordenCompraLatestByProveedor[$evtProveedorId] : null;
                            $ocViewId  = $ocRowSnap ? (int) ($ocRowSnap->id ?? 0) : 0;
                            $ocViewHref = '';
                            if ($ocViewId > 0 && $ordenCompraTablesAvailable) {
                                $ocSt = strtolower((string) ($ocRowSnap->workflow_status ?? ''));
                                $ocPdfTask = ($ocSt === 'approved') ? 'ordencompra.pdf' : 'ordencompra.previewPdf';
                                $ocViewHref = Route::_(
                                    'index.php?option=com_ordenproduccion&task=' . $ocPdfTask . '&id=' . $ocViewId . '&tmpl=component&' . $token . '=1',
                                    false,
                                    Route::TLS_IGNORE,
                                    true
                                );
                            }
                            ?>
                            <div class="d-flex flex-column align-items-center gap-1">
                                <?php if ($ocViewHref !== '') : ?>
                                <a href="<?php echo htmlspecialchars($ocViewHref, ENT_QUOTES, 'UTF-8'); ?>"
                                   class="btn btn-sm btn-outline-secondary p-1"
                                   target="_blank" rel="noopener noreferrer"
                                   title="<?php echo htmlspecialchars($labelOrdenCompraViewPdf, ENT_QUOTES, 'UTF-8'); ?>"
                                   aria-label="<?php echo htmlspecialchars($labelOrdenCompraViewPdf, ENT_QUOTES, 'UTF-8'); ?>">
                                    <i class="fas fa-file-pdf" aria-hidden="true"></i>
                                </a>
                                <?php endif; ?>
                                <?php if ($canShowOrdenCompraButton && $evtProveedorId > 0) : ?>
                                <button type="button" class="btn btn-sm btn-outline-success p-1 js-orden-compra-open-editor"
                                        data-open-url="<?php echo htmlspecialchars($openOrdenCompraEditorUrl, ENT_QUOTES, 'UTF-8'); ?>"
                                        data-save-url="<?php echo htmlspecialchars($saveOrdenCompraDraftUrl, ENT_QUOTES, 'UTF-8'); ?>"
                                        data-submit-url="<?php echo htmlspecialchars($submitOrdenCompraApprovalUrl, ENT_QUOTES, 'UTF-8'); ?>"
                                        data-delete-url="<?php echo htmlspecialchars($deleteOrdenCompraUrl, ENT_QUOTES, 'UTF-8'); ?>"
                                        data-token-name="<?php echo htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>"
                                        data-precot-id="<?php echo (int) $preCotizacionId; ?>"
                                        data-proveedor-id="<?php echo (int) $evtProveedorId; ?>"
                                        data-event-id="<?php echo (int) $evtId; ?>"
                                        data-existing-count="<?php echo (int) $ordenCompraExistingCountForPrecot; ?>"
                                        data-confirm-existing-msg="<?php echo htmlspecialchars($ordenCompraConfirmExistingMsg, ENT_QUOTES, 'UTF-8'); ?>"
                                        title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_ORDEN_COMPRA_SUBMIT')); ?>"
                                        aria-label="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_ORDEN_COMPRA_SUBMIT')); ?>">
                                    <i class="fas fa-money-bill-wave" aria-hidden="true"></i>
                                </button>
                                <?php elseif ($ocViewHref === '') : ?>
                                <span class="text-muted small">—</span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td class="col-evt-delete text-center align-middle" rowspan="2">
                            <?php if ($canViewVendorQuoteRequestLog) : ?>
                            <form method="post" action="<?php echo htmlspecialchars($deleteVendorQuoteEventUrl); ?>" class="mb-0 js-vendor-evt-delete-form"
                                  data-confirm="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_DELETE_CONFIRM')); ?>">
                                <?php echo HTMLHelper::_('form.token'); ?>
                                <input type="hidden" name="id" value="<?php echo (int) $preCotizacionId; ?>">
                                <input type="hidden" name="proveedor_id" value="<?php echo (int) $evtProveedorId; ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger p-1" title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_DELETE')); ?>" aria-label="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_EVENT_DELETE')); ?>">
                                    <i class="fas fa-trash" aria-hidden="true"></i>
                                </button>
                            </form>
                            <?php else : ?>
                            <span class="text-muted small">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr class="precot-vendor-evt-cond-row">
                        <td class="col-evt-cond-label small border-top-0 py-2 pe-2 align-top">
                            <?php if ($canEditVendorQuoteEventLogRow && $evtId > 0) : ?>
                            <label class="d-block mb-0 fw-semibold" for="vendor-evt-cond-<?php echo (int) $evtId; ?>"><?php echo htmlspecialchars($colEventCondiciones); ?></label>
                            <?php else : ?>
                            <span class="d-block fw-semibold"><?php echo htmlspecialchars($colEventCondiciones); ?></span>
                            <?php endif; ?>
                        </td>
                        <td colspan="5" class="col-evt-cond small p-2 border-top-0 w-100">
                            <?php if ($canEditVendorQuoteEventLogRow && $evtId > 0) : ?>
                            <textarea name="condiciones_entrega" id="vendor-evt-cond-<?php echo (int) $evtId; ?>" class="form-control" form="vendor-evt-cond-form-<?php echo (int) $evtId; ?>"
                                      rows="2" autocomplete="off"><?php echo htmlspecialchars($evtCondiciones); ?></textarea>
                            <?php else : ?>
                            <div class="form-control-plaintext bg-light px-2 py-2 rounded mb-0 small" style="min-height: calc(2 * 1.25em + 0.75rem); line-height: 1.25;"><?php echo $evtCondiciones !== '' ? nl2br(htmlspecialchars($evtCondiciones, ENT_QUOTES, 'UTF-8')) : '<span class="text-muted">—</span>'; ?></div>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
    <section class="precot-vendor-line-viewer mt-3 pt-3 border-top" id="precot-vendor-line-viewer" aria-label="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_LINE_VIEWER_TITLE')); ?>">
        <h2 class="h6 mb-2"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_LINE_VIEWER_TITLE'); ?></h2>
        <p class="small text-muted mb-2" id="precot-vendor-line-viewer-hint"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_LINE_VIEWER_HINT'); ?></p>
        <div id="precot-vendor-line-viewer-body"></div>
    </section>
    <script>
    (function() {
        document.addEventListener('change', function(e) {
            var t = e.target;
            if (t && t.classList && t.classList.contains('js-vendor-event-file') && t.files && t.files.length) {
                t.form.submit();
            }
        });
        document.addEventListener('submit', function(e) {
            var f = e.target;
            if (!f || !f.classList || !f.classList.contains('js-vendor-evt-delete-form')) {
                return;
            }
            var msg = f.getAttribute('data-confirm') || '';
            if (msg && !window.confirm(msg)) {
                e.preventDefault();
            }
        }, true);
    })();
    </script>
    <script>
    (function() {
        var viewer = document.getElementById('precot-vendor-line-viewer');
        var bodyEl = document.getElementById('precot-vendor-line-viewer-body');
        var hintEl = document.getElementById('precot-vendor-line-viewer-hint');
        if (!viewer || !bodyEl) return;

        var pdfHint = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ATTACH_VIEWER_PDF_HINT')); ?>;
        var openLabel = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ATTACH_VIEW')); ?>;
        var fallback = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ATTACH_VIEWER_FALLBACK')); ?>;
        var viewerTitle = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_LINE_VIEWER_TITLE')); ?>;

        function escAttr(s) {
            return String(s == null ? '' : s)
                .replace(/&/g, '&amp;')
                .replace(/"/g, '&quot;')
                .replace(/</g, '&lt;');
        }

        function showVendorLinePreview(url, ext) {
            url = (url || '').trim();
            if (!url) {
                return;
            }
            ext = (ext || '').toLowerCase();
            if (hintEl) {
                hintEl.classList.add('d-none');
            }
            bodyEl.innerHTML = '';
            var isImg = ext === 'jpg' || ext === 'jpeg' || ext === 'png';
            if (isImg) {
                bodyEl.innerHTML = '<div class="text-center bg-light rounded border p-2">'
                    + '<img src="' + escAttr(url) + '" alt="' + escAttr(viewerTitle) + '" class="img-fluid rounded shadow-sm" style="max-height:85vh;width:auto;">'
                    + '</div>';
                return;
            }
            if (ext === 'pdf') {
                bodyEl.innerHTML = '<div class="border rounded overflow-hidden bg-light shadow-sm">'
                    + '<iframe src="' + escAttr(url) + '#toolbar=1" class="w-100 border-0 d-block" style="min-height:70vh;" title="' + escAttr(viewerTitle) + '"></iframe>'
                    + '</div>'
                    + '<p class="small text-muted mt-2 mb-0">' + escAttr(pdfHint)
                    + ' <a href="' + escAttr(url) + '" target="_blank" rel="noopener">' + escAttr(openLabel) + '</a></p>';
                return;
            }
            bodyEl.innerHTML = '<p class="small text-muted mb-0">' + escAttr(fallback)
                + ' <a href="' + escAttr(url) + '" target="_blank" rel="noopener">' + escAttr(openLabel) + '</a></p>';
        }

        document.addEventListener('click', function(e) {
            var btn = e.target && e.target.closest ? e.target.closest('.js-vendor-line-view') : null;
            if (!btn) {
                return;
            }
            e.preventDefault();
            showVendorLinePreview(btn.getAttribute('data-url'), btn.getAttribute('data-ext'));
        });

        var firstPreviewBtn = document.querySelector('.precot-vendor-quote-event-log .js-vendor-line-view[data-url]');
        if (firstPreviewBtn) {
            showVendorLinePreview(
                firstPreviewBtn.getAttribute('data-url'),
                firstPreviewBtn.getAttribute('data-ext')
            );
        }
    })();
    </script>
    <?php endif; ?>

    <?php if ($vendorQuoteAttachHref !== '') : ?>
    <section class="precot-vendor-attachment-viewer mt-4 pt-4 border-top" aria-label="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ATTACH_VIEWER_TITLE')); ?>">
        <h2 class="h6 mb-3"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ATTACH_VIEWER_TITLE'); ?></h2>
        <?php if ($vendorAttachIsImage) : ?>
        <div class="text-center bg-light rounded border p-2">
            <img src="<?php echo htmlspecialchars($vendorQuoteAttachHref); ?>"
                 alt="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ATTACH_VIEWER_TITLE')); ?>"
                 class="img-fluid rounded shadow-sm"
                 style="max-height: 85vh; width: auto;">
        </div>
        <?php elseif ($vendorAttachIsPdf) : ?>
        <div class="border rounded overflow-hidden bg-light shadow-sm">
            <iframe src="<?php echo htmlspecialchars($vendorQuoteAttachHref); ?>#toolbar=1"
                    class="w-100 border-0 d-block"
                    title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ATTACH_VIEWER_TITLE')); ?>"></iframe>
        </div>
        <p class="small text-muted mt-2 mb-0">
            <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ATTACH_VIEWER_PDF_HINT'); ?>
            <a href="<?php echo htmlspecialchars($vendorQuoteAttachHref); ?>" target="_blank" rel="noopener"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ATTACH_VIEW'); ?></a>
        </p>
        <?php else : ?>
        <p class="small text-muted mb-0">
            <?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ATTACH_VIEWER_FALLBACK'); ?>
            <a href="<?php echo htmlspecialchars($vendorQuoteAttachHref); ?>" target="_blank" rel="noopener"><?php echo Text::_('COM_ORDENPRODUCCION_PRE_COT_VENDOR_ATTACH_VIEW'); ?></a>
        </p>
        <?php endif; ?>
    </section>
    <?php endif; ?>

    <div class="modal fade" id="ordenCompraEditorModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title h5" id="ordenCompraEditorModalTitle"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_TITLE'); ?></h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo htmlspecialchars(Text::_('JCLOSE')); ?>"></button>
                </div>
                <div class="modal-body">
                    <p class="small text-muted mb-2" id="ordenCompraEditorMeta"></p>
                    <div class="table-responsive mb-3">
                        <table class="table table-sm table-bordered align-middle" id="ordenCompraEditorTable">
                            <thead class="table-light">
                                <tr>
                                    <th><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_COL_QTY'); ?></th>
                                    <th><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_COL_DESC'); ?></th>
                                    <th class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_COL_UNIT'); ?></th>
                                    <th class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_COL_SUB'); ?></th>
                                </tr>
                            </thead>
                            <tbody id="ordenCompraEditorTbody"></tbody>
                            <tfoot>
                                <tr class="table-secondary fw-semibold">
                                    <td colspan="3" class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_TOTAL'); ?></td>
                                    <td class="text-end" id="ordenCompraEditorTotalCell">—</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class="mb-3 border rounded p-3 bg-light" id="ordenCompraApproveEmailBlock">
                        <div class="mb-2">
                            <span class="text-muted small"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_VENDOR_EMAIL_LABEL'); ?></span>
                            <span id="ordenCompraVendorEmailDisplay" class="fw-semibold ms-1"></span>
                        </div>
                        <p class="small text-warning mb-2 d-none" id="ordenCompraVendorEmailMissing" role="status"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_VENDOR_EMAIL_MISSING'); ?></p>
                        <fieldset class="mb-0">
                            <legend class="col-form-label small pt-0 fw-semibold"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_APPROVE_EMAIL_LEGEND'); ?></legend>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="oc_approve_email_cc_vendor" id="ocApproveEmailCc0" value="0" checked>
                                <label class="form-check-label" for="ocApproveEmailCc0"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_APPROVE_EMAIL_REQUESTER_ONLY'); ?></label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="oc_approve_email_cc_vendor" id="ocApproveEmailCc1" value="1">
                                <label class="form-check-label" for="ocApproveEmailCc1"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_APPROVE_EMAIL_CC_VENDOR'); ?></label>
                            </div>
                        </fieldset>
                    </div>
                    <div class="d-flex flex-wrap gap-2 mb-3 align-items-center">
                        <button type="button" class="btn btn-outline-danger" id="ordenCompraEditorDeleteBtn"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_DELETE'); ?></button>
                        <span class="flex-grow-1"></span>
                        <button type="button" class="btn btn-primary" id="ordenCompraEditorSaveBtn"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_SAVE'); ?></button>
                        <button type="button" class="btn btn-success" id="ordenCompraEditorSubmitBtn"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_SUBMIT_APPROVAL'); ?></button>
                    </div>
                    <h3 class="h6 mb-2"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_VENDOR_PREVIEW_TITLE'); ?></h3>
                    <div class="border rounded overflow-hidden bg-light position-relative" style="min-height: 50vh;">
                        <iframe id="ordenCompraVendorQuotePdf" class="w-100 border-0 d-block" style="min-height: 50vh; display: none;" title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_VENDOR_PREVIEW_TITLE')); ?>"></iframe>
                        <div id="ordenCompraVendorQuoteImgWrap" class="p-2 text-center d-none" style="min-height: 50vh;">
                            <img id="ordenCompraVendorQuoteImg" class="img-fluid rounded shadow-sm" alt="" style="max-height: 75vh; width: auto;">
                        </div>
                        <p id="ordenCompraVendorQuoteEmpty" class="small text-muted p-4 mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_VENDOR_PREVIEW_EMPTY'); ?></p>
                    </div>
                    <p class="small text-muted mt-2 mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_VENDOR_PREVIEW_HINT'); ?></p>
                </div>
            </div>
        </div>
    </div>
    <script>
    (function() {
        var modalEl = document.getElementById('ordenCompraEditorModal');
        if (!modalEl) {
            return;
        }
        var modalInstance = null;
        function getBsModal() {
            if (modalInstance) {
                return modalInstance;
            }
            if (typeof bootstrap === 'undefined' || !bootstrap.Modal) {
                return null;
            }
            modalInstance = bootstrap.Modal.getOrCreateInstance(modalEl);
            return modalInstance;
        }
        var tbody = document.getElementById('ordenCompraEditorTbody');
        var totalCell = document.getElementById('ordenCompraEditorTotalCell');
        var titleEl = document.getElementById('ordenCompraEditorModalTitle');
        var metaEl = document.getElementById('ordenCompraEditorMeta');
        var vendorPdfFrame = document.getElementById('ordenCompraVendorQuotePdf');
        var vendorImgWrap = document.getElementById('ordenCompraVendorQuoteImgWrap');
        var vendorImg = document.getElementById('ordenCompraVendorQuoteImg');
        var vendorEmpty = document.getElementById('ordenCompraVendorQuoteEmpty');
        var saveBtn = document.getElementById('ordenCompraEditorSaveBtn');
        var submitBtn = document.getElementById('ordenCompraEditorSubmitBtn');
        var deleteBtn = document.getElementById('ordenCompraEditorDeleteBtn');
        var state = { ordenCompraId: 0, currency: 'Q', saveUrl: '', submitUrl: '', deleteUrl: '', tokenName: '' };

        function esc(s) {
            var d = document.createElement('div');
            d.textContent = s == null ? '' : String(s);
            return d.innerHTML;
        }

        function parseNum(v) {
            var n = parseFloat(String(v).replace(',', '.'));
            return isFinite(n) ? n : 0;
        }

        function recalcTotal() {
            if (!tbody || !totalCell) {
                return;
            }
            var sum = 0;
            tbody.querySelectorAll('tr').forEach(function(tr) {
                var q = tr.querySelector('.js-oc-qty');
                var u = tr.querySelector('.js-oc-unit');
                if (q && u) {
                    var qty = Math.max(1, parseInt(String(q.value), 10) || 1);
                    var unit = Math.round(parseNum(u.value) * 100) / 100;
                    sum += Math.round(qty * unit * 100) / 100;
                }
            });
            totalCell.textContent = state.currency + ' ' + sum.toFixed(2);
        }

        function updateRowSub(tr) {
            var q = tr.querySelector('.js-oc-qty');
            var u = tr.querySelector('.js-oc-unit');
            var subEl = tr.querySelector('.js-oc-line-sub');
            if (!q || !u || !subEl) {
                return;
            }
            var qty = Math.max(1, parseInt(String(q.value), 10) || 1);
            if (String(q.value) !== String(qty)) {
                q.value = qty;
            }
            var unit = Math.round(parseNum(u.value) * 100) / 100;
            u.value = unit.toFixed(2);
            var sub = Math.round(qty * unit * 100) / 100;
            subEl.textContent = state.currency + ' ' + sub.toFixed(2);
        }

        function renderLines(lines) {
            if (!tbody) {
                return;
            }
            tbody.innerHTML = '';
            (lines || []).forEach(function(ln) {
                var tr = document.createElement('tr');
                tr.innerHTML = ''
                    + '<td><input type="number" class="form-control form-control-sm js-oc-qty" min="1" step="1" value="' + esc(ln.quantity) + '" data-line-id="' + esc(ln.id) + '"></td>'
                    + '<td><textarea class="form-control form-control-sm js-oc-desc" rows="2">' + esc(ln.descripcion) + '</textarea></td>'
                    + '<td class="text-end"><input type="number" class="form-control form-control-sm text-end js-oc-unit" min="0" step="0.01" value="' + esc(Number(ln.vendor_unit_price).toFixed(2)) + '"></td>'
                    + '<td class="text-end js-oc-line-sub">' + esc(state.currency + ' ' + Number(ln.line_total).toFixed(2)) + '</td>';
                tbody.appendChild(tr);
            });
            tbody.querySelectorAll('tr').forEach(function(tr) {
                tr.querySelectorAll('.js-oc-qty, .js-oc-unit').forEach(function(inp) {
                    inp.addEventListener('input', function() { updateRowSub(tr); recalcTotal(); });
                });
                updateRowSub(tr);
            });
            recalcTotal();
        }

        function approveEmailCcValue() {
            var r1 = document.getElementById('ocApproveEmailCc1');
            if (r1 && r1.checked && !r1.disabled) {
                return '1';
            }
            return '0';
        }

        function applyApproveEmailUi(data) {
            var ve = document.getElementById('ordenCompraVendorEmailDisplay');
            var vm = document.getElementById('ordenCompraVendorEmailMissing');
            var r0 = document.getElementById('ocApproveEmailCc0');
            var r1 = document.getElementById('ocApproveEmailCc1');
            if (!ve || !r0 || !r1) {
                return;
            }
            var vem = (data && data.vendor_email) ? String(data.vendor_email).trim() : '';
            if (vem) {
                ve.textContent = vem;
                if (vm) {
                    vm.classList.add('d-none');
                }
                r1.disabled = false;
            } else {
                ve.textContent = '—';
                if (vm) {
                    vm.classList.remove('d-none');
                }
                r1.disabled = true;
                if (r1.checked) {
                    r0.checked = true;
                }
            }
            if (parseInt(data && data.approve_email_cc_vendor, 10) === 1 && !r1.disabled) {
                r1.checked = true;
            } else {
                r0.checked = true;
            }
        }

        function collectLinesPayload() {
            var rows = [];
            tbody.querySelectorAll('tr').forEach(function(tr) {
                var q = tr.querySelector('.js-oc-qty');
                if (!q) {
                    return;
                }
                rows.push({
                    id: parseInt(q.getAttribute('data-line-id'), 10) || 0,
                    quantity: Math.max(1, parseInt(String(q.value), 10) || 1),
                    descripcion: tr.querySelector('.js-oc-desc') ? String(tr.querySelector('.js-oc-desc').value) : '',
                    vendor_unit_price: parseNum(tr.querySelector('.js-oc-unit') ? tr.querySelector('.js-oc-unit').value : '0')
                });
            });
            return rows;
        }

        function postForm(url, fields) {
            var fd = new FormData();
            fd.append(state.tokenName, '1');
            Object.keys(fields || {}).forEach(function(k) {
                if (k === 'lines') {
                    (fields.lines || []).forEach(function(row, i) {
                        Object.keys(row).forEach(function(k2) {
                            fd.append('lines[' + i + '][' + k2 + ']', row[k2]);
                        });
                    });
                } else {
                    fd.append(k, fields[k]);
                }
            });
            return fetch(url, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function(r) { return r.json(); });
        }

        function showVendorQuotePreview(kind, url) {
            if (vendorPdfFrame) {
                vendorPdfFrame.style.display = 'none';
                vendorPdfFrame.src = 'about:blank';
            }
            if (vendorImgWrap) {
                vendorImgWrap.classList.add('d-none');
            }
            if (vendorImg) {
                vendorImg.removeAttribute('src');
            }
            if (vendorEmpty) {
                vendorEmpty.style.display = 'block';
            }
            if (!url || !kind) {
                return;
            }
            if (vendorEmpty) {
                vendorEmpty.style.display = 'none';
            }
            var ts = '_ts=' + Date.now();
            var sep = url.indexOf('?') >= 0 ? '&' : '?';
            if (kind === 'pdf' && vendorPdfFrame) {
                vendorPdfFrame.style.display = 'block';
                vendorPdfFrame.src = url + sep + ts + (url.indexOf('#') >= 0 ? '' : '#toolbar=1');
                return;
            }
            if (kind === 'image' && vendorImg && vendorImgWrap) {
                vendorImg.src = url + sep + ts;
                vendorImgWrap.classList.remove('d-none');
            }
        }

        function openEditor(btn) {
            var n = parseInt(btn.getAttribute('data-existing-count') || '0', 10);
            var msg = btn.getAttribute('data-confirm-existing-msg') || '';
            var confirmVal = '0';
            if (n > 0) {
                if (btn.getAttribute('data-oc-confirmed') !== '1') {
                    if (!window.confirm(msg)) {
                        return;
                    }
                    btn.setAttribute('data-oc-confirmed', '1');
                }
                confirmVal = '1';
            }
            var openUrl = btn.getAttribute('data-open-url');
            state.saveUrl = btn.getAttribute('data-save-url');
            state.submitUrl = btn.getAttribute('data-submit-url');
            state.deleteUrl = btn.getAttribute('data-delete-url');
            state.tokenName = btn.getAttribute('data-token-name');
            postForm(openUrl, {
                id: btn.getAttribute('data-precot-id'),
                proveedor_id: btn.getAttribute('data-proveedor-id'),
                event_id: btn.getAttribute('data-event-id'),
                confirm_existing_orden_compra: confirmVal
            }).then(function(data) {
                if (!data || !data.success) {
                    window.alert(data && data.message ? data.message : 'Error');
                    return;
                }
                state.ordenCompraId = data.orden_compra_id;
                state.currency = data.currency || 'Q';
                if (titleEl) {
                    titleEl.textContent = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_TITLE')); ?>
                        + (data.number ? ' - ' + data.number : '');
                }
                var meta = [];
                if (data.proveedor_name) {
                    meta.push(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_COL_PROVEEDOR')); ?> + ': ' + data.proveedor_name);
                }
                if (data.condiciones_entrega) {
                    meta.push(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_COL_CONDICIONES')); ?> + ': ' + data.condiciones_entrega);
                }
                if (metaEl) {
                    metaEl.innerHTML = meta.map(esc).join('<br>');
                }
                renderLines(data.lines);
                applyApproveEmailUi(data);
                showVendorQuotePreview(data.vendor_quote_kind || '', data.vendor_quote_url || '');
                if (submitBtn) {
                    submitBtn.disabled = !data.workflow_published;
                    submitBtn.title = data.workflow_published ? '' : <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_WORKFLOW_NOT_AVAILABLE')); ?>;
                }
                var m = getBsModal();
                if (!m) {
                    window.alert(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_BOOTSTRAP_MISSING')); ?>);
                    return;
                }
                m.show();
            }).catch(function() {
                window.alert('Error de red');
            });
        }

        document.addEventListener('click', function(e) {
            var btn = e.target && e.target.closest ? e.target.closest('.js-orden-compra-open-editor') : null;
            if (!btn) {
                return;
            }
            e.preventDefault();
            openEditor(btn);
        });

        if (saveBtn) {
            saveBtn.addEventListener('click', function() {
                if (!state.ordenCompraId || !state.saveUrl) {
                    return;
                }
                saveBtn.disabled = true;
                postForm(state.saveUrl, {
                    orden_compra_id: String(state.ordenCompraId),
                    approve_email_cc_vendor: approveEmailCcValue(),
                    lines: collectLinesPayload()
                }).then(function(data) {
                    saveBtn.disabled = false;
                    if (!data || !data.success) {
                        window.alert(data && data.message ? data.message : 'Error');
                        return;
                    }
                    if (data.lines) {
                        state.currency = state.currency || 'Q';
                        renderLines(data.lines);
                    }
                }).catch(function() {
                    saveBtn.disabled = false;
                    window.alert('Error de red');
                });
            });
        }

        if (submitBtn) {
            submitBtn.addEventListener('click', function() {
                if (!state.ordenCompraId || !state.submitUrl) {
                    return;
                }
                if (!window.confirm(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_MODAL_SUBMIT_CONFIRM')); ?>)) {
                    return;
                }
                submitBtn.disabled = true;
                postForm(state.submitUrl, {
                    orden_compra_id: String(state.ordenCompraId),
                    approve_email_cc_vendor: approveEmailCcValue()
                }).then(function(data) {
                    submitBtn.disabled = false;
                    if (!data || !data.success) {
                        window.alert(data && data.message ? data.message : 'Error');
                        return;
                    }
                    var mh = getBsModal();
                    if (mh) {
                        mh.hide();
                    }
                    if (data.message) {
                        window.alert(data.message);
                    }
                    window.location.reload();
                }).catch(function() {
                    submitBtn.disabled = false;
                    window.alert('Error de red');
                });
            });
        }

        if (deleteBtn) {
            deleteBtn.addEventListener('click', function() {
                if (!state.ordenCompraId || !state.deleteUrl) {
                    return;
                }
                if (!window.confirm(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_ORDENCOMPRA_DELETE_CONFIRM')); ?>)) {
                    return;
                }
                deleteBtn.disabled = true;
                postForm(state.deleteUrl, { orden_compra_id: String(state.ordenCompraId) }).then(function(data) {
                    deleteBtn.disabled = false;
                    if (!data || !data.success) {
                        window.alert(data && data.message ? data.message : 'Error');
                        return;
                    }
                    var md = getBsModal();
                    if (md) {
                        md.hide();
                    }
                    state.ordenCompraId = 0;
                    document.querySelectorAll('.js-orden-compra-open-editor').forEach(function(b) {
                        b.removeAttribute('data-oc-confirmed');
                    });
                    if (data.message) {
                        window.alert(data.message);
                    }
                    window.location.reload();
                }).catch(function() {
                    deleteBtn.disabled = false;
                    window.alert('Error de red');
                });
            });
        }
    })();
    </script>

<?php if ($showCreacionOtApprovalBanner) : ?>
<!-- Modal: Creación OT — aprobación (fecha + completar / rechazar) -->
<div class="modal fade" id="precotCreacionOtApprovalModal" tabindex="-1" aria-labelledby="precotCreacionOtApprovalModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="precotCreacionOtApprovalModalLabel"><?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_MODAL_TITLE'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo htmlspecialchars(Text::_('JCLOSE'), ENT_QUOTES, 'UTF-8'); ?>"></button>
            </div>
            <div class="modal-body">
                <p class="small text-muted mb-3"><?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_MODAL_INTRO'); ?></p>
                <div class="mb-3">
                    <label for="precotCreacionOtFechaInput" class="form-label"><?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_FECHA_ENTREGA_LABEL'); ?> <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" id="precotCreacionOtFechaInput" name="ot_fecha_entrega" required
                        value="<?php echo htmlspecialchars($fechaDefaultCreacionOt, ENT_QUOTES, 'UTF-8'); ?>" />
                </div>
                <div id="precotCreacionOtApprovalErr" class="alert alert-danger py-2 small" style="display:none;" role="alert"></div>
            </div>
            <div class="modal-footer flex-wrap gap-2">
                <button type="button" class="btn btn-outline-danger" id="precotCreacionOtRejectBtn"><?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_BTN_REJECT'); ?></button>
                <button type="button" class="btn btn-success" id="precotCreacionOtApproveBtn"><?php echo Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_BTN_COMPLETE'); ?></button>
            </div>
        </div>
    </div>
</div>
<script>
(function() {
    var url = <?php echo json_encode($decideCreacionOtUrl, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    var tok = <?php echo json_encode(Session::getFormToken(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    var reqId = <?php echo (int) $pendingCreacionOtReq; ?>;
    var preId = <?php echo (int) $preCotizacionId; ?>;
    var errEl = document.getElementById('precotCreacionOtApprovalErr');
    function showErr(msg) {
        if (!errEl) return;
        errEl.textContent = msg || '';
        errEl.style.display = msg ? 'block' : 'none';
    }
    function postDecision(action) {
        showErr('');
        var fe = document.getElementById('precotCreacionOtFechaInput');
        var fd = new FormData();
        fd.append('request_id', String(reqId));
        fd.append('pre_cotizacion_id', String(preId));
        fd.append('decision', action);
        if (tok) fd.append(tok, '1');
        if (action === 'approve' && fe && fe.value) {
            fd.append('ot_fecha_entrega', String(fe.value));
        }
        var ab = document.getElementById('precotCreacionOtApproveBtn');
        var rb = document.getElementById('precotCreacionOtRejectBtn');
        if (ab) ab.disabled = true;
        if (rb) rb.disabled = true;
        fetch(url, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function(r) { return r.text().then(function(t) { try { return JSON.parse(t); } catch (e) { return { success: false, message: t.substring(0, 200) }; } }); })
            .then(function(data) {
                if (data && data.success && data.redirect_url) {
                    window.location.href = String(data.redirect_url);
                    return;
                }
                var m = (data && data.message) ? data.message : 'Error.';
                showErr(m);
                if (ab) ab.disabled = false;
                if (rb) rb.disabled = false;
            })
            .catch(function() {
                showErr(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_INSTRUCCIONES_MODAL_NETWORK_ERROR'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>);
                if (ab) ab.disabled = false;
                if (rb) rb.disabled = false;
            });
    }
    var abtn = document.getElementById('precotCreacionOtApproveBtn');
    var rbtn = document.getElementById('precotCreacionOtRejectBtn');
    if (abtn) abtn.addEventListener('click', function() {
        var fe = document.getElementById('precotCreacionOtFechaInput');
        if (!fe || !fe.value) {
            showErr(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_OT_WIZARD_STEP3_ERR_FECHA'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>);
            return;
        }
        postDecision('approve');
    });
    if (rbtn) rbtn.addEventListener('click', function() {
        if (!window.confirm(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_CREACION_OT_APPROVAL_REJECT_CONFIRM'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>)) {
            return;
        }
        postDecision('reject');
    });
})();
</script>
<?php endif; ?>
</div>
