<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_ordenproduccion
 *
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Grimpsa\Component\Ordenproduccion\Site\Helper\AccessHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\FelInvoiceHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\InvoiceGrimpsaTemplatePdfHelper;

/** @var \Grimpsa\Component\Ordenproduccion\Site\View\Ordenes\HtmlView $this */

// Get user groups for access control (for columns and action buttons)
$isVentas = AccessHelper::isInVentasGroup();
$isProduccion = AccessHelper::isInProduccionGroup();
$anulacionUrl = $this->anulacionUrl;
$currentUser = $this->user;
$isAdministracionOtAgentFilter = AccessHelper::isInStrictAdministracionGroup();
?>

<div class="com-ordenproduccion-ordenes">
    <div class="container-fluid">
        <!-- Page Header -->
        <div class="row mb-4">
            <div class="col-12">
                <h1 class="page-title">
                    <?php echo Text::_('COM_ORDENPRODUCCION_ORDENES_TITLE'); ?>
                </h1>
                <?php if ($this->params->get('show_page_heading')) : ?>
                    <p class="page-description">
                        <?php echo $this->params->get('page_heading'); ?>
                    </p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Filters -->
        <div class="row mb-4">
            <div class="col-12">
<?php
$t = function ($key, $fallback) {
    $v = Text::_($key);
    return ($v !== $key) ? $v : $fallback;
};
$l = function ($key, $fallbackEn, $fallbackEs = null) {
    $translated = Text::_($key);
    if ($translated !== $key && strpos((string) $translated, 'COM_ORDENPRODUCCION_') !== 0) {
        if ($fallbackEs !== null && stripos(Factory::getApplication()->getLanguage()->getTag(), 'es') !== false && $translated === $fallbackEn) {
            return $fallbackEs;
        }

        return $translated;
    }
    if ($fallbackEs !== null && stripos(Factory::getApplication()->getLanguage()->getTag(), 'es') !== false) {
        return $fallbackEs;
    }

    return $fallbackEn;
};
$labelFilterSearch = $t('COM_ORDENPRODUCCION_FILTER_SEARCH', 'Buscar');
$labelFilterSearchPlaceholder = $t('COM_ORDENPRODUCCION_FILTER_SEARCH_PLACEHOLDER', 'Buscar por n?mero de orden, cliente o descripci?n...');
$labelFilterStatus = $t('COM_ORDENPRODUCCION_FILTER_STATUS', 'Estado');
$labelSelectStatus = $t('COM_ORDENPRODUCCION_SELECT_STATUS', 'Seleccionar Estado');
$labelFilterDateFrom = $t('COM_ORDENPRODUCCION_FILTER_DATE_FROM', 'Fecha Desde');
$labelFilterDateTo = $t('COM_ORDENPRODUCCION_FILTER_DATE_TO', 'Fecha Hasta');
$labelFilterPaymentStatus = $t('COM_ORDENPRODUCCION_FILTER_PAYMENT_STATUS', 'Estado de Pago');
$labelFilterNit = $t('COM_ORDENPRODUCCION_ORDENES_FILTER_NIT', 'NIT');
$labelFilterNitPlaceholder = $t('COM_ORDENPRODUCCION_ORDENES_FILTER_NIT_PLACEHOLDER', 'NIT o parte');
$labelFilterApply = $t('COM_ORDENPRODUCCION_FILTER_APPLY', 'Aplicar Filtros');
$labelFilterClear = $t('COM_ORDENPRODUCCION_FILTER_CLEAR', 'Limpiar Filtros');
$labelViewCotizacion = $t('COM_ORDENPRODUCCION_VIEW_COTIZACION', 'Ver Cotizaci?n');
$labelNoCotizacion = $t('COM_ORDENPRODUCCION_NO_COTIZACION', 'Sin cotizaci?n');
$labelCotizacionNoPermission = $t('COM_ORDENPRODUCCION_COTIZACION_NO_PERMISSION', 'Sin permiso para ver la cotizaci?n');
$labelPickInvoicePdf = $l('COM_ORDENPRODUCCION_ORDENES_PICK_INVOICE_PDF', 'Select invoice PDF', 'Seleccionar PDF de factura');
$labelPickInvoicePdfIntro = $l('COM_ORDENPRODUCCION_ORDENES_PICK_INVOICE_PDF_INTRO', 'This work order has more than one linked invoice. Choose which PDF to open.', 'Esta orden tiene más de una factura vinculada. Elija qué PDF abrir.');
$clearFiltersUrl = Route::_('index.php?option=com_ordenproduccion&view=ordenes&filter_search=&filter_status=&filter_payment_status=&filter_client_name=&filter_nit=&filter_date_from=&filter_date_to=&filter_sales_agent=');
?>
                        <form method="get" action="<?php echo Route::_('index.php?option=com_ordenproduccion&view=ordenes'); ?>">
                            <input type="hidden" name="option" value="com_ordenproduccion">
                            <input type="hidden" name="view" value="ordenes">
                            <div class="ordenes-filters-compact d-flex flex-wrap align-items-end gap-3">
                                <div class="ordenes-filter-item">
                                    <label for="filter_search" class="form-label"><?php echo htmlspecialchars($labelFilterSearch); ?></label>
                                    <input type="text" 
                                           name="filter_search" 
                                           id="filter_search" 
                                           class="form-control form-control-sm" 
                                           value="<?php echo htmlspecialchars($this->state->get('filter.search')); ?>"
                                           placeholder="<?php echo htmlspecialchars($labelFilterSearchPlaceholder); ?>">
                                </div>
                                <div class="ordenes-filter-item">
                                    <label for="filter_status" class="form-label"><?php echo htmlspecialchars($labelFilterStatus); ?></label>
                                    <select name="filter_status" id="filter_status" class="form-control form-control-sm">
                                        <option value=""><?php echo htmlspecialchars($labelSelectStatus); ?></option>
                                        <?php foreach ($this->getModel()->getStatusOptions() as $value => $text) : ?>
                                            <?php if ($value !== '') : ?>
                                                <option value="<?php echo htmlspecialchars($value); ?>" 
                                                        <?php echo $this->state->get('filter.status') == $value ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($text); ?>
                                                </option>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="ordenes-filter-item">
                                    <label for="filter_date_from" class="form-label"><?php echo htmlspecialchars($labelFilterDateFrom); ?></label>
                                    <input type="date" 
                                           name="filter_date_from" 
                                           id="filter_date_from" 
                                           class="form-control form-control-sm" 
                                           value="<?php echo htmlspecialchars($this->state->get('filter.date_from')); ?>">
                                </div>
                                <div class="ordenes-filter-item">
                                    <label for="filter_date_to" class="form-label"><?php echo htmlspecialchars($labelFilterDateTo); ?></label>
                                    <input type="date" 
                                           name="filter_date_to" 
                                           id="filter_date_to" 
                                           class="form-control form-control-sm" 
                                           value="<?php echo htmlspecialchars($this->state->get('filter.date_to')); ?>">
                                </div>
                                <div class="ordenes-filter-item">
                                    <label for="filter_nit" class="form-label"><?php echo htmlspecialchars($labelFilterNit); ?></label>
                                    <input type="text"
                                           name="filter_nit"
                                           id="filter_nit"
                                           class="form-control form-control-sm"
                                           value="<?php echo htmlspecialchars($this->state->get('filter.nit')); ?>"
                                           placeholder="<?php echo htmlspecialchars($labelFilterNitPlaceholder); ?>">
                                </div>
                                <div class="ordenes-filter-item">
                                    <label for="filter_payment_status" class="form-label"><?php echo htmlspecialchars($labelFilterPaymentStatus); ?></label>
                                    <select name="filter_payment_status" id="filter_payment_status" class="form-control form-control-sm">
                                        <?php foreach ($this->getModel()->getPaymentStatusOptions() as $value => $text) : ?>
                                            <option value="<?php echo htmlspecialchars($value); ?>"
                                                    <?php echo $this->state->get('filter.payment_status') === $value ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($text); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <?php if (!empty($isAdministracionOtAgentFilter)) : ?>
                                <div class="ordenes-filter-item">
                                    <label for="filter_sales_agent" class="form-label"><?php echo htmlspecialchars($t('COM_ORDENPRODUCCION_ORDEN_AGENTE_VENTAS', 'Agente de Ventas')); ?></label>
                                    <select name="filter_sales_agent" id="filter_sales_agent" class="form-control form-control-sm">
                                        <?php foreach ($this->getModel()->getSalesAgentFilterOptions() as $value => $text) : ?>
                                            <option value="<?php echo htmlspecialchars((string) $value); ?>"
                                                    <?php echo ($this->state->get('filter.sales_agent', '') === (string) $value) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($text); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <?php endif; ?>
                                <div class="ordenes-filter-buttons d-flex gap-1">
                                    <button type="submit" class="btn btn-primary btn-sm">
                                        <i class="fas fa-search"></i>
                                        <?php echo htmlspecialchars($labelFilterApply); ?>
                                    </button>
                                    <a href="<?php echo $clearFiltersUrl; ?>" 
                                       class="btn btn-secondary btn-sm d-inline-flex align-items-center"
                                       title="<?php echo htmlspecialchars($labelFilterClear); ?>">
                                        <i class="fas fa-times"></i>
                                        <?php echo htmlspecialchars($labelFilterClear); ?>
                                    </a>
                                </div>
                            </div>
                        </form>
            </div>
        </div>

        <!-- Orders List -->
        <?php if (empty($this->items)) : ?>
            <div class="row">
                <div class="col-12">
                    <div class="alert alert-warning text-center">
                        <i class="fas fa-exclamation-triangle"></i>
                        <?php echo Text::_('COM_ORDENPRODUCCION_NO_ORDENES_FOUND'); ?>
                    </div>
                </div>
            </div>
        <?php else : ?>
            <div class="row">
                <div class="col-12">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-sm">
                            <thead class="thead-dark">
                                <tr>
                                    <th scope="col">
                                        <?php echo Text::_('COM_ORDENPRODUCCION_ORDEN_NUMERO'); ?>
                                    </th>
                                    <th scope="col">
                                        <?php echo Text::_('COM_ORDENPRODUCCION_ORDEN_CLIENTE'); ?>
                                    </th>
                                    <th scope="col">Fechas</th>
                                    <th scope="col">
                                        <?php echo Text::_('COM_ORDENPRODUCCION_ORDEN_ESTADO'); ?>
                                    </th>
                                    <?php if ($isVentas || ($isVentas && $isProduccion)) : ?>
                                        <th scope="col">
                                            <?php echo Text::_('COM_ORDENPRODUCCION_ORDEN_AGENTE_VENTAS'); ?>
                                        </th>
                                    <?php endif; ?>
                                    <th scope="col">
                                        <?php echo Text::_('COM_ORDENPRODUCCION_ACTIONS'); ?>
                                    </th>
                                </tr>
                            </thead>
                            <?php
                            $grimpsaListaPdfOk = InvoiceGrimpsaTemplatePdfHelper::isTemplateAvailable();
                            ?>
                            <tbody>
                                <?php foreach ($this->items as $item) : ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo $this->getOrderRoute($item->id); ?>" 
                                               class="font-weight-bold text-primary">
                                                <?php echo htmlspecialchars($item->order_number); ?>
                                            </a>
                                        </td>
                                        <td style="font-size: 0.82em;">
                                            <?php echo htmlspecialchars($item->client_name); ?>
                                        </td>
                                        <td style="white-space: nowrap; font-size: 0.82em; padding: 4px 6px; line-height: 1.3;">
                                            <span class="text-muted" style="font-size: 0.78em;">Sol.&nbsp;</span><?php echo $this->formatDate($item->request_date); ?><br>
                                            <span class="text-muted" style="font-size: 0.78em;">Ent.&nbsp;</span><?php echo $this->formatDate($item->delivery_date); ?>
                                        </td>
                                        <td>
                                            <span class="badge <?php echo $this->getStatusBadgeClass($item->status); ?>" style="color: #333 !important;">
                                                <?php echo $this->translateStatus($item->status); ?>
                                            </span>
                                        </td>
                                        <?php if ($isVentas || ($isVentas && $isProduccion)) : ?>
                                            <td style="font-size: 0.82em;">
                                                <?php echo htmlspecialchars($item->sales_agent); ?>
                                            </td>
                                        <?php endif; ?>
                                        <td>
                                            <div class="btn-group ordenes-actions" role="group">
                                                <!-- Create Invoice - groups from Settings or Administraci?n by default -->
                                                <?php if ($this->canShowCrearFactura()) : ?>
                                                <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=invoice&order_id=' . $item->id); ?>"
                                                   class="btn btn-sm btn-outline-primary"
                                                   title="<?php echo Text::_('COM_ORDENPRODUCCION_CREATE_INVOICE'); ?>"
                                                   aria-label="<?php echo Text::_('COM_ORDENPRODUCCION_CREATE_INVOICE'); ?>">
                                                    <i class="fas fa-file-invoice fa-sm" aria-hidden="true"></i>
                                                </a>
                                                <?php endif; ?>
                                                <!-- Registrar comprobante de pago - groups from Settings or default -->
                                                <?php if ($this->canShowRegistrarPago()) : ?>
                                                <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=paymentproof&order_id=' . (int) $item->id); ?>"
                                                   class="btn btn-sm btn-outline-success"
                                                   title="<?php echo Text::_('COM_ORDENPRODUCCION_REGISTER_PAYMENT_PROOF'); ?>"
                                                   aria-label="<?php echo Text::_('COM_ORDENPRODUCCION_REGISTER_PAYMENT_PROOF'); ?>">
                                                    <i class="fas fa-credit-card fa-sm" aria-hidden="true"></i>
                                                </a>
                                                <?php endif; ?>
                                                <?php
                                                $hasQuotation = false;
                                                $cotizacionFileUrl = '';
                                                if (!empty($item->quotation_files) && $item->quotation_files !== '[]' && $item->quotation_files !== '""') {
                                                    $filePath = '';
                                                    if (strpos((string) $item->quotation_files, '[') === 0) {
                                                        $decoded = json_decode($item->quotation_files, true);
                                                        if (is_array($decoded) && !empty($decoded[0])) {
                                                            $filePath = is_string($decoded[0]) ? str_replace('\/', '/', $decoded[0]) : '';
                                                        }
                                                    } else {
                                                        $filePath = (string) $item->quotation_files;
                                                    }
                                                    if ($filePath !== '') {
                                                        if (strpos($filePath, 'http') === 0) {
                                                            $cotizacionFileUrl = $filePath;
                                                        } else {
                                                            $uri = Uri::getInstance();
                                                            $baseUrl = $uri->toString(['scheme', 'host', 'port']);
                                                            $cotizacionFileUrl = (strpos($filePath, '/') === 0) ? ($baseUrl . $filePath) : ($baseUrl . '/' . ltrim($filePath, '/'));
                                                        }
                                                        $hasQuotation = true;
                                                    }
                                                }
                                                $canViewCotizacionPdf = $this->canViewCotizacionPdf($item);
                                                if ($hasQuotation && $cotizacionFileUrl !== '' && $canViewCotizacionPdf) : ?>
                                                <button type="button" class="btn btn-sm btn-outline-info cotizacion-popup-btn"
                                                        data-cotizacion-url="<?php echo htmlspecialchars($cotizacionFileUrl); ?>"
                                                        title="<?php echo htmlspecialchars($labelViewCotizacion); ?>"
                                                        aria-label="<?php echo htmlspecialchars($labelViewCotizacion); ?>">
                                                    <i class="fas fa-file-pdf fa-sm" aria-hidden="true"></i>
                                                </button>
                                                <?php elseif ($hasQuotation && $cotizacionFileUrl !== '' && !$canViewCotizacionPdf) : ?>
                                                <span class="btn btn-sm btn-outline-secondary disabled" title="<?php echo htmlspecialchars($labelCotizacionNoPermission); ?>">
                                                    <i class="fas fa-file-pdf fa-sm" aria-hidden="true"></i>
                                                </span>
                                                <?php else : ?>
                                                <span class="btn btn-sm btn-outline-secondary disabled" title="<?php echo htmlspecialchars($labelNoCotizacion); ?>">
                                                    <i class="fas fa-file-pdf fa-sm" aria-hidden="true"></i>
                                                </span>
                                                <?php endif; ?>
                                                <?php
                                                $linkedInvoiceOpens = [];
                                                if (isset($item->linked_invoice_opens) && \is_array($item->linked_invoice_opens)) {
                                                    foreach ($item->linked_invoice_opens as $openRow) {
                                                        if (!\is_object($openRow)) {
                                                            continue;
                                                        }
                                                        $openUrl = trim((string) ($openRow->url ?? ''));
                                                        if ($openUrl === '') {
                                                            continue;
                                                        }
                                                        $linkedInvoiceOpens[] = [
                                                            'id'    => (int) ($openRow->id ?? 0),
                                                            'label' => trim((string) ($openRow->label ?? '')),
                                                            'url'   => $openUrl,
                                                        ];
                                                    }
                                                }
                                                if ($linkedInvoiceOpens === [] && $this->canOpenInvoiceFromOrdenesList()) {
                                                    $linkedInvoiceIds = is_array($item->linked_invoice_ids ?? null)
                                                        ? array_values(array_filter(array_map('intval', $item->linked_invoice_ids), static fn ($id) => $id > 0))
                                                        : [];
                                                    if ($linkedInvoiceIds === [] && (int) ($item->linked_invoice_id ?? 0) > 0) {
                                                        $linkedInvoiceIds = [(int) $item->linked_invoice_id];
                                                    }
                                                    $manualInvPdfPrimary = trim((string) ($item->linked_invoice_manual_pdf_rel ?? ''));
                                                    foreach ($linkedInvoiceIds as $linkedInvoiceId) {
                                                        $linkedInvoiceOpens[] = [
                                                            'id'    => $linkedInvoiceId,
                                                            'label' => (string) $linkedInvoiceId,
                                                            'url'   => FelInvoiceHelper::resolveOpenUrlForOrdenesList(
                                                                $linkedInvoiceId,
                                                                $manualInvPdfPrimary,
                                                                $grimpsaListaPdfOk
                                                            ),
                                                        ];
                                                    }
                                                }
                                                if ($linkedInvoiceOpens !== [] && $this->canOpenInvoiceFromOrdenesList()) :
                                                    if (count($linkedInvoiceOpens) === 1) :
                                                        $singleOpen = $linkedInvoiceOpens[0];
                                                        $openLabel  = $l('COM_ORDENPRODUCCION_OPEN_INVOICE', 'View invoice', 'Ver factura');
                                                        ?>
                                                <a href="<?php echo htmlspecialchars($singleOpen['url'], ENT_QUOTES, 'UTF-8'); ?>"
                                                   class="btn btn-sm btn-outline-dark"
                                                   target="_blank"
                                                   rel="noopener noreferrer"
                                                   title="<?php echo htmlspecialchars($openLabel, ENT_QUOTES, 'UTF-8'); ?>"
                                                   aria-label="<?php echo htmlspecialchars($openLabel, ENT_QUOTES, 'UTF-8'); ?>">
                                                    <i class="fas fa-file-invoice-dollar fa-sm" aria-hidden="true"></i>
                                                </a>
                                                    <?php else :
                                                        $pickJson = json_encode($linkedInvoiceOpens, JSON_UNESCAPED_UNICODE);
                                                        if ($pickJson === false) {
                                                            $pickJson = '[]';
                                                        }
                                                        ?>
                                                <button type="button"
                                                    class="btn btn-sm btn-outline-dark orden-invoice-pick-btn"
                                                    title="<?php echo htmlspecialchars($labelPickInvoicePdf, ENT_QUOTES, 'UTF-8'); ?>"
                                                    aria-label="<?php echo htmlspecialchars($labelPickInvoicePdf, ENT_QUOTES, 'UTF-8'); ?>"
                                                    data-invoice-picks="<?php echo htmlspecialchars($pickJson, ENT_QUOTES, 'UTF-8'); ?>">
                                                    <i class="fas fa-file-invoice-dollar fa-sm" aria-hidden="true"></i>
                                                </button>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <!-- Solicitar anulaci?n - groups from Settings or super user / order owner -->
                                                <?php if ($this->canShowSolicitarAnulacion($item)) :
                                                    $isAnulada    = (strtolower((string) ($item->status ?? '')) === 'anulada');
                                                    $hasShipping  = !empty($item->shipping_count) && (int) $item->shipping_count > 0;
                                                    if ($isAnulada) : ?>
                                                <button type="button"
                                                        class="btn btn-sm btn-outline-secondary"
                                                        title="<?php echo Text::_('COM_ORDENPRODUCCION_SOLICITAR_ANULACION'); ?>"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#anulacionYaAnuladaModal">
                                                    <i class="fas fa-ban fa-sm" aria-hidden="true"></i>
                                                </button>
                                                    <?php elseif ($hasShipping) : ?>
                                                <button type="button"
                                                        class="btn btn-sm btn-outline-secondary"
                                                        title="<?php echo Text::_('COM_ORDENPRODUCCION_SOLICITAR_ANULACION'); ?>"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#anulacionBloqueadaModal">
                                                    <i class="fas fa-ban fa-sm" aria-hidden="true"></i>
                                                </button>
                                                    <?php else :
                                                        $anulacionHref = rtrim($anulacionUrl, '?&') . '?'
                                                            . 'user_id=' . (int) $currentUser->id
                                                            . '&orden_id=' . urlencode($item->order_number)
                                                            . '&requester=' . urlencode($currentUser->name);
                                                    ?>
                                                <a href="<?php echo htmlspecialchars($anulacionHref, ENT_QUOTES, 'UTF-8'); ?>"
                                                   class="btn btn-sm btn-outline-danger"
                                                   title="<?php echo Text::_('COM_ORDENPRODUCCION_SOLICITAR_ANULACION'); ?>"
                                                   aria-label="<?php echo Text::_('COM_ORDENPRODUCCION_SOLICITAR_ANULACION'); ?>">
                                                    <i class="fas fa-ban fa-sm" aria-hidden="true"></i>
                                                </a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Pagination -->
            <?php if ($this->pagination->pagesTotal > 1) : ?>
                <div class="row mt-4">
                    <div class="col-12">
                        <nav aria-label="<?php echo Text::_('COM_ORDENPRODUCCION_PAGINATION'); ?>">
                            <?php echo $this->pagination->getPagesLinks(); ?>
                        </nav>
                        <div class="pagination-info text-center mt-2">
                            <?php echo $this->pagination->getResultsCounter(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <?php
        // Modals need to exist if the anulaci?n button appears for ANY row.
        $anyCanAnulacion = false;
        foreach ($this->items as $_item) {
            if ($this->canShowSolicitarAnulacion($_item)) { $anyCanAnulacion = true; break; }
        }
        ?>
        <!-- Anulaci?n Bloqueada Modal -->
        <?php if ($anyCanAnulacion) : ?>
        <div class="modal fade" id="anulacionBloqueadaModal" tabindex="-1" aria-labelledby="anulacionBloqueadaModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-warning">
                        <h5 class="modal-title" id="anulacionBloqueadaModalLabel">
                            <i class="fas fa-exclamation-triangle me-2" aria-hidden="true"></i>
                            Anulaci?n No Disponible
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <p>Esta orden de trabajo tiene transacciones asociadas y no puede ser anulada, favor enviar su solicitud via correo a administracion.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo Text::_('JCLOSE'); ?></button>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Anulaci?n Ya Anulada Modal -->
        <?php if ($anyCanAnulacion) : ?>
        <div class="modal fade" id="anulacionYaAnuladaModal" tabindex="-1" aria-labelledby="anulacionYaAnuladaModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-danger text-white">
                        <h5 class="modal-title" id="anulacionYaAnuladaModalLabel">
                            <i class="fas fa-ban me-2" aria-hidden="true"></i>
                            Orden Ya Anulada
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <p>Esta orden de trabajo ya fue anulada anteriormente y no puede procesarse una nueva solicitud de anulaci?n.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo Text::_('JCLOSE'); ?></button>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Payment Info Modal (for users who can see payment info) -->
        <?php 
        $hasPaymentInfoAccess = false;
        foreach ($this->items as $it) {
            if ($this->canSeeInvoiceValue($it)) { $hasPaymentInfoAccess = true; break; }
        }
        if ($hasPaymentInfoAccess && !empty($this->items)) : 
            $paymentInfoBaseUrl = \Joomla\CMS\Uri\Uri::base() . 'index.php?option=com_ordenproduccion&task=ajax.getOrderPayments&format=raw';
            $paymentInfoToken = \Joomla\CMS\Session\Session::getFormToken();
        ?>
        <script>window.paymentInfoBaseUrl='<?php echo $paymentInfoBaseUrl; ?>';window.paymentInfoToken='<?php echo $paymentInfoToken; ?>';</script>
        <?php include __DIR__ . '/../payment_info_modal.php'; ?>
        <?php endif; ?>

        <!-- Linked invoice PDF picker (multiple invoices per OT) -->
        <div class="modal fade" id="ordenInvoicePickModal" tabindex="-1" aria-labelledby="ordenInvoicePickModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ordenInvoicePickModalLabel"><?php echo htmlspecialchars($labelPickInvoicePdf); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo Text::_('JCLOSE'); ?>"></button>
                    </div>
                    <div class="modal-body">
                        <p class="small text-muted mb-3"><?php echo htmlspecialchars($labelPickInvoicePdfIntro); ?></p>
                        <div class="list-group" id="ordenInvoicePickList" role="list"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Cotizaci?n file popup modal -->
        <div class="modal fade" id="cotizacionPopupModal" tabindex="-1" aria-labelledby="cotizacionPopupModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="cotizacionPopupModalLabel"><?php echo htmlspecialchars($labelViewCotizacion); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo Text::_('JCLOSE'); ?>"></button>
                    </div>
                    <div class="modal-body p-0" style="min-height: 70vh;">
                        <iframe id="cotizacionPopupIframe" style="width:100%; height:70vh; border:0;" title="<?php echo htmlspecialchars($labelViewCotizacion); ?>"></iframe>
                    </div>
                </div>
            </div>
        </div>
        <script>
        (function() {
            var pickModal = document.getElementById('ordenInvoicePickModal');
            var pickList = document.getElementById('ordenInvoicePickList');
            if (pickModal && pickList) {
                document.querySelectorAll('.orden-invoice-pick-btn').forEach(function(btn) {
                    btn.addEventListener('click', function() {
                        var raw = this.getAttribute('data-invoice-picks') || '[]';
                        var picks = [];
                        try {
                            picks = JSON.parse(raw);
                        } catch (e) {
                            picks = [];
                        }
                        if (!Array.isArray(picks) || picks.length === 0) {
                            return;
                        }
                        pickList.innerHTML = '';
                        picks.forEach(function(pick) {
                            if (!pick || !pick.url) {
                                return;
                            }
                            var label = pick.label || ('#' + (pick.id || ''));
                            var a = document.createElement('a');
                            a.href = pick.url;
                            a.target = '_blank';
                            a.rel = 'noopener noreferrer';
                            a.className = 'list-group-item list-group-item-action d-flex align-items-center gap-2';
                            var icon = document.createElement('i');
                            icon.className = 'fas fa-file-pdf text-danger';
                            icon.setAttribute('aria-hidden', 'true');
                            var span = document.createElement('span');
                            span.textContent = label;
                            a.appendChild(icon);
                            a.appendChild(span);
                            pickList.appendChild(a);
                        });
                        bootstrap.Modal.getOrCreateInstance(pickModal).show();
                    });
                });
            }

            var modal = document.getElementById('cotizacionPopupModal');
            var iframe = document.getElementById('cotizacionPopupIframe');
            if (modal && iframe) {
                document.querySelectorAll('.cotizacion-popup-btn').forEach(function(btn) {
                    btn.addEventListener('click', function() {
                        var url = this.getAttribute('data-cotizacion-url');
                        if (url) {
                            iframe.src = url;
                            var bsModal = bootstrap.Modal.getOrCreateInstance(modal);
                            bsModal.show();
                        }
                    });
                });
                modal.addEventListener('hidden.bs.modal', function() {
                    iframe.src = 'about:blank';
                });
            }
        })();
        </script>
    </div>
</div>
