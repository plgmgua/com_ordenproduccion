<?php
/**
 * Single Invoice (detail) template - layout matches SAT FEL PDF
 *
 * @package     Grimpsa\Component\Ordenproduccion\Site\View\Invoice
 * @since       3.97.0
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Grimpsa\Component\Ordenproduccion\Site\Helper\AccessHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\FelInvoiceHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\FelXmlHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\InvoiceFacturaTemplateHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\InvoiceGrimpsaTemplatePdfHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\InvoiceListHelper;

/** @var \Grimpsa\Component\Ordenproduccion\Site\View\Invoice\HtmlView $this */
$item = $this->item;
$lineItems = is_array($item->line_items ?? null) ? $item->line_items : [];
$isFelImport = !empty($item->invoice_source) && $item->invoice_source === 'fel_import';
$isCotizacionFel = !empty($item->invoice_source) && $item->invoice_source === 'cotizacion_fel';
$isFel = $isFelImport || $isCotizacionFel;
$felExtra = [];
if (!empty($item->fel_extra) && is_string($item->fel_extra)) {
    $felExtra = json_decode($item->fel_extra, true) ?: [];
}

if ($isFel && (($felExtra['autorizacion_serie'] ?? '') === '' || ($felExtra['autorizacion_numero_dte'] ?? '') === '')) {
    $xmlRaw = '';
    $relXml = trim((string) ($item->fel_local_xml_path ?? ''));
    if ($relXml !== '' && is_file(JPATH_ROOT . '/' . $relXml)) {
        $fromDisk = @file_get_contents(JPATH_ROOT . '/' . $relXml);
        if ($fromDisk !== false && $fromDisk !== '') {
            $xmlRaw = $fromDisk;
        }
    }
    if ($xmlRaw === '' && !empty($item->fel_response_json) && is_string($item->fel_response_json)) {
        $xmlRaw = FelXmlHelper::tryExtractXmlFromDigifactResponseBody($item->fel_response_json);
    }
    if ($xmlRaw !== '') {
        $meta = FelXmlHelper::extractCertificacionDisplayMeta($xmlRaw);
        if ($meta['autorizacion_serie'] !== '') {
            $felExtra['autorizacion_serie'] = $meta['autorizacion_serie'];
        }
        if ($meta['autorizacion_numero_dte'] !== '') {
            $felExtra['autorizacion_numero_dte'] = $meta['autorizacion_numero_dte'];
        }
        if (!empty($meta['certificacion']) && is_array($meta['certificacion'])) {
            $prevCert = isset($felExtra['certificacion']) && is_array($felExtra['certificacion']) ? $felExtra['certificacion'] : [];
            foreach (['nit_certificador', 'nombre_certificador', 'fecha_hora_certificacion'] as $ck) {
                if (($prevCert[$ck] ?? '') === '' && ($meta['certificacion'][$ck] ?? '') !== '') {
                    $prevCert[$ck] = $meta['certificacion'][$ck];
                }
            }
            if ($prevCert !== []) {
                $felExtra['certificacion'] = $prevCert;
            }
        }
    }
}

$l = function ($key, $fallback) {
    $t = Text::_($key);
    return ($t !== '' && $t !== $key) ? $t : $fallback;
};

$allowManualPdf = !InvoiceListHelper::isMockupInvoice($item);
$manualPdfRel   = trim((string) ($item->manual_pdf_path ?? ''));
$manualPdfUrl   = '';
if ($manualPdfRel !== '' && $allowManualPdf) {
    $manualPdfUrl = Route::_('index.php?option=com_ordenproduccion&task=invoice.downloadManualPdf&invoice_id=' . (int) ($item->id ?? 0));
}

$moneda = htmlspecialchars($item->currency ?? 'Q', ENT_QUOTES, 'UTF-8');
$canSuperInvoice = !empty($this->canSuperUserInvoiceActions);
$invoiceCancelled = !empty($this->invoiceIsCancelled);
?>
<div class="com-ordenproduccion-invoice-detail invoice-pdf-style container py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <h1 class="h5 mb-0"><?php echo $l('COM_ORDENPRODUCCION_INVOICE', 'Factura'); ?> <?php echo htmlspecialchars(InvoiceListHelper::resolveInvoiceHeadingNumber($item), ENT_QUOTES, 'UTF-8'); ?></h1>
        <div class="d-flex flex-wrap align-items-center gap-2">
        <?php if ($canSuperInvoice) : ?>
        <?php if (!$invoiceCancelled) : ?>
        <form method="post" action="<?php echo Route::_('index.php?option=com_ordenproduccion'); ?>" class="d-inline"
              onsubmit="return window.confirm(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_INVOICE_ANULAR_CONFIRM')); ?>);">
            <?php echo HTMLHelper::_('form.token'); ?>
            <input type="hidden" name="task" value="invoice.anularInvoice" />
            <input type="hidden" name="invoice_id" value="<?php echo (int) ($item->id ?? 0); ?>" />
            <button type="submit" class="btn btn-outline-danger btn-sm"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_ANULAR_BUTTON'); ?></button>
        </form>
        <?php else : ?>
        <form method="post" action="<?php echo Route::_('index.php?option=com_ordenproduccion'); ?>" class="d-inline"
              onsubmit="return window.confirm(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_INVOICE_REACTIVAR_CONFIRM')); ?>);">
            <?php echo HTMLHelper::_('form.token'); ?>
            <input type="hidden" name="task" value="invoice.reactivarInvoice" />
            <input type="hidden" name="invoice_id" value="<?php echo (int) ($item->id ?? 0); ?>" />
            <button type="submit" class="btn btn-outline-success btn-sm"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_REACTIVAR_BUTTON'); ?></button>
        </form>
        <?php endif; ?>
        <?php
        $duplicateManualFelDisabledTitle = trim((string) ($this->duplicateManualFelDisabledTitle ?? ''));
        $hasManualFelDuplicateModal = !empty($this->showManualFelDuplicateModal);
        if ($hasManualFelDuplicateModal) :
            ?>
        <button type="button" id="invoice-duplicate-manual-fel-trigger" class="btn btn-outline-success btn-sm">
            <i class="fas fa-copy" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_DUPLICATE_MANUAL_FEL_BTN'); ?>
        </button>
        <?php else : ?>
        <button type="button" class="btn btn-outline-success btn-sm" disabled<?php if ($duplicateManualFelDisabledTitle !== '') : ?> title="<?php echo htmlspecialchars($duplicateManualFelDisabledTitle, ENT_QUOTES, 'UTF-8'); ?>"<?php endif; ?>>
            <i class="fas fa-copy" aria-hidden="true"></i> <?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_DUPLICATE_MANUAL_FEL_BTN'); ?>
        </button>
        <?php endif; ?>
        <?php endif; ?>
        <?php if (InvoiceGrimpsaTemplatePdfHelper::isTemplateAvailable()) : ?>
        <a href="<?php echo htmlspecialchars(FelInvoiceHelper::downloadGrimpsaFacturaPdfUrl((int) ($item->id ?? 0)), ENT_QUOTES, 'UTF-8'); ?>"
           target="_blank" rel="noopener noreferrer" class="btn btn-outline-primary btn-sm">
            <i class="fas fa-file-pdf"></i> <?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_DOWNLOAD_GRIMPSA_PDF'); ?>
        </a>
        <?php endif; ?>
        <?php if (AccessHelper::isInAdministracionOrAdmonGroup()) : ?>
        <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices'); ?>" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-arrow-left"></i> <?php echo $l('COM_ORDENPRODUCCION_BACK_TO_INVOICES', 'Volver a Facturas'); ?>
        </a>
        <?php endif; ?>
        </div>
    </div>

    <?php if ($invoiceCancelled) : ?>
    <div class="alert alert-danger mb-3" role="alert"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_CANCELLED_BANNER'); ?></div>
    <?php endif; ?>

    <div class="invoice-pdf-layout border rounded p-3 bg-white">
        <!-- Row: Emisor (left) | Autorización / Fechas / Moneda (right) -->
        <div class="row mb-3">
            <div class="col-md-6">
                <?php if ($isFel && !empty($item->fel_emisor_nombre)) : ?>
                <div class="fw-bold"><?php echo htmlspecialchars($item->fel_emisor_nombre, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php if (!empty($item->fel_emisor_nit)) : ?>
                <div class="small">NIT Emisor: <?php echo htmlspecialchars($item->fel_emisor_nit); ?></div>
                <?php endif; ?>
                <?php if (!empty($felExtra['emisor_nombre_comercial'])) : ?>
                <div class="small"><?php echo htmlspecialchars($felExtra['emisor_nombre_comercial'], ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
                <?php
                $ed = $felExtra['emisor_direccion'] ?? null;
                if (!empty($ed) && is_array($ed)) :
                    $addrParts = array_filter([$ed['direccion'] ?? '', $ed['codigo_postal'] ?? '', ($ed['municipio'] ?? '') . (isset($ed['departamento']) && $ed['departamento'] !== '' ? ', ' . $ed['departamento'] : ''), $ed['pais'] ?? '']);
                    if (!empty($addrParts)) :
                ?>
                <div class="small text-break"><?php echo htmlspecialchars(implode(' ', $addrParts), ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; endif; ?>
                <?php elseif (!$isFel && !empty($item->client_name)) : ?>
                <div class="fw-bold"><?php echo htmlspecialchars($item->client_name, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
            </div>
            <div class="col-md-6 text-md-end small">
                <?php
                $showFelAutorizacion = $isFel && (
                    !empty($item->fel_autorizacion_uuid)
                    || !empty($item->felplex_uuid)
                    || !empty($felExtra['autorizacion_serie'])
                );
                ?>
                <?php if ($showFelAutorizacion) : ?>
                <?php
                $authDisp = trim((string) ($item->fel_autorizacion_uuid ?? ''));
                if ($authDisp === '') {
                    $authDisp = trim((string) ($item->felplex_uuid ?? ''));
                }
                ?>
                <div><strong>Número de autorización:</strong><br><?php echo $authDisp !== '' ? htmlspecialchars($authDisp, ENT_QUOTES, 'UTF-8') : '—'; ?></div>
                <?php if (!empty($felExtra['autorizacion_serie']) || !empty($felExtra['autorizacion_numero_dte'])) : ?>
                <div class="mt-1">Serie: <?php echo htmlspecialchars($felExtra['autorizacion_serie'] ?? '-'); ?> | Numero: <?php echo htmlspecialchars($felExtra['autorizacion_numero_dte'] ?? '-'); ?></div>
                <?php endif; ?>
                <?php
                $fechaEmisionDisplay = InvoiceFacturaTemplateHelper::formatEmissionDateTimeForDisplay($item);
                if ($fechaEmisionDisplay !== '') :
                ?>
                <div class="mt-1">Fecha de Emision: <?php echo htmlspecialchars($fechaEmisionDisplay, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
                <?php
                $cert = $felExtra['certificacion'] ?? null;
                if (!empty($cert['fecha_hora_certificacion'])) :
                    $certDate = is_numeric(strtotime($cert['fecha_hora_certificacion'])) ? date('d-m-Y H:i:s', strtotime($cert['fecha_hora_certificacion'])) : $cert['fecha_hora_certificacion'];
                ?>
                <div>Fecha y hora de certificación: <?php echo htmlspecialchars($certDate); ?></div>
                <?php endif; ?>
                <?php endif; ?>
                <div>Moneda: <?php echo $moneda; ?></div>
            </div>
        </div>

        <!-- Receptor (header: NIT, Cliente, Direccion) -->
        <div class="row mb-3 small">
            <div class="col-12">
                <?php
                $receptorNit  = InvoiceListHelper::displayReceptorTaxId($item);
                $receptorNom  = InvoiceListHelper::displayReceptorName($item);
                $receptorAddr = InvoiceListHelper::displayReceptorAddress($item);
                ?>
                <?php if ($receptorNit !== '') : ?>
                <div><strong>NIT:</strong> <?php echo htmlspecialchars($receptorNit, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
                <div><strong>Cliente:</strong> <?php echo htmlspecialchars($receptorNom !== '' ? $receptorNom : '-', ENT_QUOTES, 'UTF-8'); ?></div>
                <?php if ($receptorAddr !== '') : ?>
                <div><strong>Direccion:</strong> <?php echo htmlspecialchars($receptorAddr, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Items table (PDF columns) -->
        <?php if (!empty($lineItems)) : ?>
        <div class="table-responsive mb-3">
            <table class="table table-bordered table-sm mb-0 invoice-items-table">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Cantidad</th>
                        <th>Descripcion</th>
                        <th class="text-end">Precio Unitario (<?php echo $moneda; ?>)</th>
                        <th class="text-end">Total Factura (<?php echo $moneda; ?>)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($lineItems as $idx => $row) : ?>
                    <?php
                    $qtyRow = (float) ($row['cantidad'] ?? 0);
                    $subRow = (float) ($row['subtotal'] ?? 0);
                    $puRow  = (float) ($row['precio_unitario'] ?? $row['valor_unitario'] ?? 0);
                    if ($puRow <= 0.00001 && $qtyRow > 0 && $subRow > 0) {
                        $puRow = $subRow / $qtyRow;
                    }
                    ?>
                    <tr>
                        <td><?php echo (int) ($row['numero_linea'] ?? $idx + 1); ?></td>
                        <td><?php echo htmlspecialchars($row['cantidad'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                        <td><?php echo htmlspecialchars($row['descripcion'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                        <td class="text-end"><?php echo number_format($puRow, 2); ?></td>
                        <td class="text-end"><?php echo number_format($subRow, 2); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot class="table-light fw-bold">
                    <tr>
                        <td colspan="4" class="text-end">TOTALES:</td>
                        <td class="text-end"><?php echo number_format((float) ($item->invoice_amount ?? 0), 2); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <?php endif; ?>

        <?php
        $nucAddRows = FelInvoiceHelper::parseNucAdditionalDocumentRowsFromFelRequest(
            isset($item->fel_request_json) ? (string) $item->fel_request_json : null
        );
        if ($nucAddRows !== []) :
            ?>
        <div class="border rounded p-2 mb-3 small invoice-nuc-additional">
            <div class="fw-bold mb-2"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_NUC_ADDITIONAL_SECTION'); ?></div>
            <dl class="row mb-0">
                <?php foreach ($nucAddRows as $ar) : ?>
                <dt class="col-sm-3 text-muted"><?php echo htmlspecialchars($ar['label'], ENT_QUOTES, 'UTF-8'); ?></dt>
                <dd class="col-sm-9 mb-1 text-break"><?php echo htmlspecialchars($ar['value'], ENT_QUOTES, 'UTF-8'); ?></dd>
                <?php endforeach; ?>
            </dl>
        </div>
        <?php endif; ?>

        <!-- Frases (notes) -->
        <?php
        $frases = $felExtra['frases'] ?? [];
        if (!empty($frases) && is_array($frases)) :
            $frasesText = [
                '1' => ['1' => '', '2' => '', '3' => '', '4' => '* Exportaciones. Exenta del IVA (art. 7 núm. 2 Ley del IVA)'],
                '2' => ['1' => '* Sujeto a retención definitiva ISR'],
            ];
            $toShow = [];
            foreach ($frases as $f) {
                $esc = $f['codigo_escenario'] ?? '';
                $tipo = $f['tipo_frase'] ?? '';
                if (isset($frasesText[$esc][$tipo]) && $frasesText[$esc][$tipo] !== '') {
                    $toShow[] = $frasesText[$esc][$tipo];
                }
            }
            if (empty($toShow) && ($felExtra['complemento_exportacion'] ?? null)) {
                $toShow[] = '* Exportaciones. Exenta del IVA (art. 7 núm. 2 Ley del IVA)';
            }
            if (!empty($toShow)) :
        ?>
        <div class="small text-muted mb-3">
            <?php foreach ($toShow as $txt) : ?>
            <div><?php echo $txt; ?></div>
            <?php endforeach; ?>
        </div>
        <?php endif; endif; ?>

        <!-- Complemento Exportación -->
        <?php
        $exp = $felExtra['complemento_exportacion'] ?? null;
        if (!empty($exp) && is_array($exp)) :
        ?>
        <div class="border rounded p-2 mb-3 small">
            <div class="fw-bold mb-2">COMPLEMENTO EXPORTACIÓN</div>
            <?php if (!empty($exp['lugar_expedicion'])) : ?>
            <div>Lugar de expedición: <?php echo htmlspecialchars($exp['lugar_expedicion'], ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>
            <?php if (!empty($exp['nombre_consignatario'])) : ?>
            <div>Nombre consignatario: <?php echo htmlspecialchars($exp['nombre_consignatario'], ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>
            <?php if (!empty($exp['direccion_consignatario'])) : ?>
            <div>Dirección consignatario: <?php echo htmlspecialchars($exp['direccion_consignatario'], ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>
            <?php if (!empty($exp['pais_consignatario'])) : ?>
            <div>País del consignatario: <?php echo htmlspecialchars($exp['pais_consignatario'], ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>
            <?php if (isset($exp['incoterm']) && $exp['incoterm'] !== '') : ?>
            <div>Términos (INCOTERM): <?php echo htmlspecialchars($exp['incoterm'], ENT_QUOTES, 'UTF-8'); ?> <?php if ($exp['incoterm'] === 'ZZZ') : ?>- Otros<?php endif; ?></div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- Complemento Abonos (FCAM) -->
        <?php
        $abonos = $felExtra['complemento_abonos'] ?? [];
        if (!empty($abonos) && is_array($abonos)) :
        ?>
        <div class="border rounded p-2 mb-3 small">
            <div class="fw-bold mb-2">Abonos / Fechas de vencimiento</div>
            <ul class="mb-0 ps-3">
            <?php foreach ($abonos as $ab) : ?>
                <li>Abono <?php echo (int) ($ab['numero_abono'] ?? 0); ?>: Vence <?php echo htmlspecialchars($ab['fecha_vencimiento'] ?? ''); ?> — <?php echo $moneda; ?> <?php echo number_format((float) ($ab['monto_abono'] ?? 0), 2); ?></li>
            <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>

        <!-- Datos del certificador (footer) -->
        <?php
        $cert = $felExtra['certificacion'] ?? null;
        if (!empty($cert) && is_array($cert) && (!empty($cert['nombre_certificador']) || !empty($cert['nit_certificador']))) :
        ?>
        <div class="pt-2 mt-2 border-top small text-muted">
            <strong>Datos del certificador</strong><br>
            <?php if (!empty($cert['nombre_certificador'])) : ?>
            <?php echo htmlspecialchars($cert['nombre_certificador'], ENT_QUOTES, 'UTF-8'); ?>
            <?php endif; ?>
            <?php if (!empty($cert['nit_certificador'])) : ?>
            <?php if (!empty($cert['nombre_certificador'])) : ?> NIT: <?php endif; ?><?php echo htmlspecialchars($cert['nit_certificador']); ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php
        $assocLinks = is_array($this->associatedOrdenLinks ?? null) ? $this->associatedOrdenLinks : [];
        $detailDropdown = is_array($this->invoiceDetailOrdenDropdown ?? null) ? $this->invoiceDetailOrdenDropdown : [];
        $matchTbl = (bool) ($this->invoiceOrdenMatchTableAvailable ?? false);
        $assocNitVal = trim((string) ($this->invoiceAssocNit ?? ''));
        $invoicesByNit = is_array($this->invoicesForAssocNitList ?? null) ? $this->invoicesForAssocNitList : [];
        $invoiceUrlBase = Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . (int) ($item->id ?? 0), false);
        ?>
        <div class="pt-3 mt-3 border-top invoice-work-orders-footer">
            <div class="fw-bold mb-2"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_WORK_ORDERS_SECTION'); ?></div>
            <?php if ($invoiceCancelled && $canSuperInvoice && !empty($assocLinks)) : ?>
            <p class="small text-muted mb-2"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_CANCELLED_DISSOCIATE_HINT'); ?></p>
            <?php endif; ?>
            <?php if ($isFel && $matchTbl && AccessHelper::isInAdministracionOrAdmonGroup() && !$invoiceCancelled) : ?>
            <div class="mb-3 p-2 border rounded bg-light">
                <form method="get" action="<?php echo Route::_('index.php'); ?>" class="row g-2 align-items-end flex-wrap">
                    <input type="hidden" name="option" value="com_ordenproduccion" />
                    <input type="hidden" name="view" value="invoice" />
                    <input type="hidden" name="id" value="<?php echo (int) ($item->id ?? 0); ?>" />
                    <div class="col-md-5 col-lg-4">
                        <label for="invoice-assoc-nit" class="form-label small mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_ASSOC_NIT_LABEL'); ?></label>
                        <input type="text" name="assoc_nit" id="invoice-assoc-nit" class="form-control form-control-sm"
                               value="<?php echo htmlspecialchars($assocNitVal, ENT_QUOTES, 'UTF-8'); ?>"
                               placeholder="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_NIT'), ENT_QUOTES, 'UTF-8'); ?>"
                               maxlength="48" autocomplete="off" />
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-sm btn-outline-primary"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_ASSOC_NIT_APPLY'); ?></button>
                    </div>
                    <?php if ($assocNitVal !== '') : ?>
                    <div class="col-auto">
                        <a href="<?php echo htmlspecialchars($invoiceUrlBase, ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-sm btn-outline-secondary"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_ASSOC_NIT_CLEAR'); ?></a>
                    </div>
                    <?php endif; ?>
                </form>
                <p class="small text-muted mb-2 mb-md-3"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_ASSOC_NIT_INTRO'); ?></p>
                <?php if ($assocNitVal !== '' && !empty($invoicesByNit)) : ?>
                <div class="fw-bold small mb-1"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_ASSOC_NIT_LIST_TITLE'); ?></div>
                <div class="table-responsive">
                    <table class="table table-sm table-bordered mb-0 bg-white">
                        <thead class="table-light">
                            <tr>
                                <th><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE'); ?></th>
                                <th><?php echo Text::_('COM_ORDENPRODUCCION_CLIENT'); ?></th>
                                <th class="text-end"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_ORDEN_MATCH_INV_TOTAL'); ?></th>
                                <th><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_DATE'); ?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($invoicesByNit as $invRow) :
                                $iid = (int) ($invRow->id ?? 0);
                                if ($iid < 1) {
                                    continue;
                                }
                                $dtRaw = $invRow->fel_fecha_emision ?? $invRow->invoice_date ?? null;
                                ?>
                            <tr>
                                <td><?php echo htmlspecialchars((string) ($invRow->invoice_number ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars((string) ($invRow->client_name ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
                                <td class="text-end text-nowrap"><?php echo number_format((float) ($invRow->invoice_amount ?? 0), 2); ?> <?php echo $moneda; ?></td>
                                <td class="text-nowrap small"><?php echo $dtRaw ? HTMLHelper::_('date', $dtRaw, Text::_('DATE_FORMAT_LC4')) : '—'; ?></td>
                                <td class="text-nowrap">
                                    <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . $iid); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-primary py-0"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_ASSOC_NIT_OPEN'); ?></a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php elseif ($assocNitVal !== '') : ?>
                <p class="small text-muted mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_ASSOC_NIT_LIST_EMPTY'); ?></p>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <?php if (!empty($assocLinks)) : ?>
                <ul class="mb-2 ps-3 list-unstyled">
                    <?php foreach ($assocLinks as $lnk) :
                        $oid = (int) ($lnk['orden_id'] ?? 0);
                        $onum = htmlspecialchars((string) ($lnk['orden_num'] ?? ''), ENT_QUOTES, 'UTF-8');
                        $oUrl = Route::_('index.php?option=com_ordenproduccion&view=orden&id=' . $oid);
                        ?>
                    <li class="d-flex flex-wrap align-items-center gap-2 mb-1">
                        <a href="<?php echo $oUrl; ?>" target="_blank" rel="noopener noreferrer"><?php echo $onum !== '' ? $onum : ('#' . $oid); ?></a>
                        <?php if ($canSuperInvoice && $oid > 0) : ?>
                        <form method="post" action="<?php echo Route::_('index.php?option=com_ordenproduccion'); ?>" class="d-inline"
                              onsubmit="return window.confirm(<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_INVOICE_DISSOCIATE_CONFIRM')); ?>);">
                            <?php echo HTMLHelper::_('form.token'); ?>
                            <input type="hidden" name="task" value="invoice.removeInvoiceOrden" />
                            <input type="hidden" name="invoice_id" value="<?php echo (int) ($item->id ?? 0); ?>" />
                            <input type="hidden" name="orden_id" value="<?php echo $oid; ?>" />
                            <button type="submit" class="btn btn-sm btn-outline-secondary py-0 px-1" title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_INVOICE_DISSOCIATE_ORDEN'), ENT_QUOTES, 'UTF-8'); ?>">
                                <span class="visually-hidden"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_DISSOCIATE_ORDEN'); ?></span>&times;
                            </button>
                        </form>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; ?>
                </ul>
            <?php else : ?>
                <p class="text-muted small mb-2"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_NO_ORDEN_LINKED'); ?></p>
            <?php endif; ?>

            <?php if ($isFel && $matchTbl && AccessHelper::isInAdministracionOrAdmonGroup() && !$invoiceCancelled) : ?>
                <?php if (!empty($detailDropdown)) : ?>
                <form method="post" action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=invoice.associateOrden'); ?>" class="d-flex flex-wrap align-items-end gap-2">
                    <?php echo HTMLHelper::_('form.token'); ?>
                    <input type="hidden" name="invoice_id" value="<?php echo (int) ($item->id ?? 0); ?>" />
                    <?php if ($assocNitVal !== '') : ?>
                    <input type="hidden" name="assoc_nit" value="<?php echo htmlspecialchars($assocNitVal, ENT_QUOTES, 'UTF-8'); ?>" />
                    <?php endif; ?>
                    <div>
                        <label for="invoice-detail-orden-id" class="form-label small mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_ASSOCIATE_ORDEN_LABEL'); ?></label>
                        <select name="orden_id" id="invoice-detail-orden-id" class="form-select form-select-sm" style="min-width: 280px;">
                            <option value=""><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_ORDEN_MATCH_SELECT_ORDEN'); ?></option>
                            <?php foreach ($detailDropdown as $opt) :
                                $oid = (int) ($opt['id'] ?? 0);
                                $lab = (string) ($opt['label'] ?? '');
                                if ($oid <= 0) {
                                    continue;
                                }
                                ?>
                            <option value="<?php echo $oid; ?>"><?php echo htmlspecialchars($lab, ENT_QUOTES, 'UTF-8'); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_ASSOCIATE_ORDEN_BUTTON'); ?></button>
                </form>
                <?php else : ?>
                <p class="small text-muted mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_ASSOCIATE_ORDEN_NONE_AVAILABLE'); ?></p>
                <?php endif; ?>
            <?php endif; ?>

            <?php
            $invoiceDetailAdmin = AccessHelper::isInAdministracionOrAdmonGroup();
            $showManualPdfBlock = $allowManualPdf && ($invoiceDetailAdmin || ($manualPdfRel !== '' && $manualPdfUrl !== ''));
            ?>
            <?php if ($showManualPdfBlock) : ?>
            <div class="mt-3 pt-2 border-top invoice-manual-pdf-block">
                <div class="fw-bold small mb-1"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_SECTION'); ?></div>
                <?php if ($invoiceDetailAdmin && !$invoiceCancelled) : ?>
                <p class="small text-muted mb-2"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_HELP'); ?></p>
                <form method="post" action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=invoice.uploadManualPdf'); ?>" enctype="multipart/form-data" class="d-flex flex-wrap align-items-end gap-2 mb-3">
                    <?php echo HTMLHelper::_('form.token'); ?>
                    <input type="hidden" name="invoice_id" value="<?php echo (int) ($item->id ?? 0); ?>" />
                    <div>
                        <label for="invoice-manual-pdf-file" class="form-label small mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_FILE_LABEL'); ?></label>
                        <input type="file" name="manual_pdf" id="invoice-manual-pdf-file" class="form-control form-control-sm" accept=".pdf,application/pdf" style="max-width: 320px;" />
                    </div>
                    <button type="submit" class="btn btn-outline-primary btn-sm"><?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_UPLOAD'); ?></button>
                </form>
                <?php endif; ?>
                <?php if ($manualPdfRel !== '' && $manualPdfUrl !== '') : ?>
                <p class="small mb-2">
                    <a href="<?php echo htmlspecialchars($manualPdfUrl, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener noreferrer" class="text-decoration-none">
                        <i class="fas fa-external-link-alt"></i> <?php echo Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_VIEW_LINK'); ?>
                    </a>
                </p>
                <div class="invoice-manual-pdf-embed-wrap">
                    <iframe
                        src="<?php echo htmlspecialchars($manualPdfUrl, ENT_QUOTES, 'UTF-8'); ?>"
                        class="invoice-manual-pdf-embed"
                        title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_EMBED_TITLE'), ENT_QUOTES, 'UTF-8'); ?>"
                        loading="lazy"
                    ></iframe>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if (!$isFel) : ?>
    <div class="mt-3 small">
        <strong><?php echo $l('COM_ORDENPRODUCCION_INVOICE_DATE', 'Fecha'); ?>:</strong> <?php echo $item->invoice_date ? HTMLHelper::_('date', $item->invoice_date, Text::_('DATE_FORMAT_LC3')) : '-'; ?>
        | <strong><?php echo $l('COM_ORDENPRODUCCION_STATUS', 'Estado'); ?>:</strong>
        <?php
        $statusKey = 'COM_ORDENPRODUCCION_STATUS_' . strtoupper((string) ($item->status ?? 'sent'));
        $statusLabel = Text::_($statusKey);
        echo ($statusLabel !== $statusKey) ? $statusLabel : htmlspecialchars($item->status ?? 'sent');
        ?>
    </div>
    <?php endif; ?>
</div>

<style>
.invoice-pdf-style .invoice-pdf-layout { max-width: 900px; }
.invoice-pdf-style .invoice-items-table { font-size: 0.9rem; }
.invoice-pdf-style .invoice-items-table th { white-space: nowrap; }
.invoice-manual-pdf-embed-wrap {
    width: 100%;
    max-width: 100%;
    border: 1px solid #dee2e6;
    border-radius: 6px;
    overflow: hidden;
    background: #e9ecef;
}
.invoice-manual-pdf-embed {
    width: 100%;
    height: min(70vh, 720px);
    min-height: 360px;
    border: 0;
    display: block;
}
</style>
<?php include __DIR__ . '/manual_fel_duplicate.php'; ?>
