<?php
/**
 * Invoice Controller for Com Orden Produccion
 * 
 * Handles invoice creation and management
 * 
 * @package     Grimpsa\Component\Ordenproduccion\Site\Controller
 * @subpackage  Invoice
 * @since       3.42.0
 */

namespace Grimpsa\Component\Ordenproduccion\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Log\Log;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Grimpsa\Component\Ordenproduccion\Site\Helper\AccessHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\CertificadorFactNitLookupHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\FelInvoiceHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\InvoiceGrimpsaTemplatePdfHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\InvoiceListHelper;
use Grimpsa\Component\Ordenproduccion\Site\Model\InvoiceOrdenMatchModel;
use Grimpsa\Component\Ordenproduccion\Site\Service\FelInvoiceIssuanceService;
use Joomla\Database\DatabaseInterface;

class InvoiceController extends BaseController
{
    /**
     * Create a new invoice from quotation form data
     */
    public function create()
    {
        // Check CSRF token
        if (!Session::checkToken()) {
            $this->app->enqueueMessage(Text::_('JINVALID_TOKEN'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=workorders'));
            return false;
        }

        // Facturas: only Administrator or Admon user groups may create invoices
        if (!AccessHelper::isInAdministracionOrAdmonGroup()) {
            $this->app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=resumen', false));
            return false;
        }

        try {
            $input = $this->app->input;
            
            // Get form data
            $orderId = $input->getInt('order_id', 0);
            $orderNumber = $input->getString('order_number', '');
            $cliente = $input->getString('cliente', '');
            $nit = $input->getString('nit', '');
            $direccion = $input->getString('direccion', '');
            $items = $input->get('items', [], 'array');
            
            // Validate required fields
            if (empty($orderId) || empty($orderNumber) || empty($cliente) || empty($nit)) {
                $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_ERROR_MISSING_REQUIRED_FIELDS'), 'error');
                $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=workorders'));
                return false;
            }

            // Get work order data directly from database
            $db = Factory::getDbo();
            $query = $db->getQuery(true)
                ->select('*')
                ->from($db->quoteName('#__ordenproduccion_ordenes'))
                ->where($db->quoteName('id') . ' = ' . (int) $orderId);
            
            $db->setQuery($query);
            $workOrder = $db->loadObject();
            
            if (!$workOrder) {
                $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_ERROR_ORDER_NOT_FOUND'), 'error');
                $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=workorders'));
                return false;
            }

            // Generate autonumeric invoice number
            $invoiceNumber = $this->generateInvoiceNumber();
            
            // Calculate total amount from items
            $totalAmount = 0;
            $lineItems = [];
            
            foreach ($items as $item) {
                if (!empty($item['cantidad']) && !empty($item['precio_unitario'])) {
                    $cantidad = floatval($item['cantidad']);
                    $precioUnitario = floatval($item['precio_unitario']);
                    $subtotal = $cantidad * $precioUnitario;
                    
                    $lineItems[] = [
                        'cantidad' => $cantidad,
                        'descripcion' => $item['descripcion'] ?? '',
                        'precio_unitario' => $precioUnitario,
                        'subtotal' => $subtotal
                    ];
                    
                    $totalAmount += $subtotal;
                }
            }

            // Prepare invoice data (matching actual database schema)
            $invoiceData = [
                'invoice_number' => $invoiceNumber,
                'orden_id' => $orderId,
                'orden_de_trabajo' => $orderNumber,
                'client_name' => $cliente,
                'client_nit' => $nit,
                // Note: Your schema doesn't have client_address column in invoices table
                'sales_agent' => $workOrder->sales_agent ?? '',
                'request_date' => $workOrder->request_date ? Factory::getDate($workOrder->request_date)->format('Y-m-d') : null,
                'delivery_date' => $workOrder->delivery_date ?? null,
                'invoice_date' => Factory::getDate()->format('Y-m-d'),  // DATE format, not DATETIME
                'invoice_amount' => $totalAmount,
                'currency' => 'Q',
                'work_description' => $workOrder->work_description ?? '',
                'material' => $workOrder->material ?? '',
                'dimensions' => $workOrder->dimensions ?? '',  // Your schema uses 'dimensions', not 'medidas'
                'print_color' => $workOrder->print_color ?? '',
                'line_items' => json_encode($lineItems),  // TEXT column, must be JSON string
                'quotation_file' => $workOrder->quotation_files ?? '',
                'extraction_status' => 'manual',
                'status' => 'created',
                'notes' => 'Created from quotation form',
                'state' => 1
            ];

            // Save invoice
            $invoiceModel = $this->getModel('Invoice');
            $result = $invoiceModel->save($invoiceData);

            if ($result) {
                // Update work order with invoice number
                $this->updateWorkOrderInvoiceNumber($orderId, $invoiceNumber);
                
                $message = Text::sprintf('COM_ORDENPRODUCCION_INVOICE_CREATED_SUCCESS', $invoiceNumber);
                $this->app->enqueueMessage($message, 'success');
            } else {
                $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_ERROR_CREATING_INVOICE'), 'error');
            }

        } catch (\Exception $e) {
            $this->app->enqueueMessage('Error: ' . $e->getMessage(), 'error');
        }

        // Redirect back to work orders
        $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=workorders'));
        return true;
    }

    /**
     * Associate a work order to the current FEL invoice (same NIT). Redirects back to invoice detail.
     *
     * @return  void
     * @since   3.100.4
     */
    public function associateOrden()
    {
        if (!Session::checkToken('post')) {
            $this->app->enqueueMessage(Text::_('JINVALID_TOKEN'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices', false));
            return;
        }

        if (!AccessHelper::isInAdministracionOrAdmonGroup()) {
            $this->app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=resumen', false));
            return;
        }

        $invoiceId = $this->input->post->getInt('invoice_id', 0);
        $ordenId = $this->input->post->getInt('orden_id', 0);
        $back = Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . (int) $invoiceId, false);

        if ($invoiceId <= 0 || $ordenId <= 0) {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_ASSOCIATE_ORDEN_INVALID'), 'warning');
            $this->setRedirect($back);
            return;
        }

        try {
            $invModel = $this->getModel('Invoice');
            $invRow   = $invModel ? $invModel->getItem($invoiceId) : null;
            if ($invRow && isset($invRow->status) && strtolower((string) $invRow->status) === 'cancelled') {
                $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_LOCKED_CANCELLED'), 'error');
                $this->setRedirect($back);

                return;
            }

            $model = $this->getModel('InvoiceOrdenMatch', 'Site', ['ignore_request' => true]);
            if (!$model) {
                $model = $this->app->bootComponent('com_ordenproduccion')->getMVCFactory()->createModel('InvoiceOrdenMatch', 'Site');
            }
            if (!$model || !$model->isTableAvailable()) {
                $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_ORDEN_MATCH_TABLE_MISSING'), 'error');
                $this->setRedirect($back);
                return;
            }

            $assocNit = trim((string) $this->input->post->getString('assoc_nit', ''));
            $dAssoc   = InvoiceOrdenMatchModel::normalizeNitDigits($assocNit);
            $db       = Factory::getContainer()->get(DatabaseInterface::class);
            $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('nit'))
                    ->from($db->quoteName('#__ordenproduccion_ordenes'))
                    ->where($db->quoteName('id') . ' = ' . (int) $ordenId)
            );
            $dOrd = InvoiceOrdenMatchModel::normalizeNitDigits((string) $db->loadResult());
            $dInv = InvoiceOrdenMatchModel::normalizeNitDigits(
                (string) ($invRow->fel_receptor_id ?? $invRow->client_nit ?? '')
            );
            $allowCross = $dAssoc !== ''
                && $dOrd !== ''
                && $dAssoc === $dOrd
                && $dInv !== $dOrd;

            $ok = $model->addManualInvoiceOrdenAssociation($invoiceId, $ordenId, $allowCross);
            $this->app->enqueueMessage(
                $ok ? Text::_('COM_ORDENPRODUCCION_INVOICE_ASSOCIATE_ORDEN_SUCCESS') : Text::_('COM_ORDENPRODUCCION_INVOICE_ASSOCIATE_ORDEN_NOOP'),
                $ok ? 'success' : 'notice'
            );
        } catch (\Throwable $e) {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_ASSOCIATE_ORDEN_ERROR') . ': ' . $e->getMessage(), 'error');
        }

        $keepNit = trim((string) $this->input->post->getString('assoc_nit', ''));
        if ($keepNit !== '' && $invoiceId > 0) {
            $back = Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . (int) $invoiceId . '&assoc_nit=' . rawurlencode($keepNit), false);
        }

        $this->setRedirect($back);
    }

    /**
     * Upload a manual PDF attachment for a regular invoice (not mock cotización FEL).
     *
     * POST: invoice_id, manual_pdf (file)
     *
     * @return  void
     *
     * @since   3.103.3
     */
    public function uploadManualPdf()
    {
        // Use default (request), not post-only: multipart/form-data token must validate like other upload flows.
        if (!Session::checkToken()) {
            $this->app->enqueueMessage(Text::_('JINVALID_TOKEN'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices', false));

            return;
        }

        if (!AccessHelper::isInAdministracionOrAdmonGroup()) {
            $this->app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=resumen', false));

            return;
        }

        $invoiceId = $this->input->post->getInt('invoice_id', 0);
        $back        = Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . (int) $invoiceId, false);

        if ($invoiceId <= 0) {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_INVALID'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices', false));

            return;
        }

        $model = $this->getModel('Invoice');
        $inv   = $model ? $model->getItem($invoiceId) : null;
        if (!$inv) {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_ERROR_INVOICE_NOT_FOUND'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices', false));

            return;
        }

        if (InvoiceListHelper::isMockupInvoice($inv)) {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_MOCKUP_DISABLED'), 'notice');
            $this->setRedirect($back);

            return;
        }

        if (isset($inv->status) && strtolower((string) $inv->status) === 'cancelled') {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_LOCKED_CANCELLED'), 'error');
            $this->setRedirect($back);

            return;
        }

        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $cols = $db->getTableColumns('#__ordenproduccion_invoices', false);
        $cols = \is_array($cols) ? array_change_key_case($cols, CASE_LOWER) : [];
        if (!isset($cols['manual_pdf_path'])) {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_DB_REQUIRED'), 'error');
            $this->setRedirect($back);

            return;
        }

        $file = $this->input->files->get('manual_pdf', null, 'array');
        if (!\is_array($file) || empty($file['tmp_name']) || (int) ($file['error'] ?? 0) !== \UPLOAD_ERR_OK) {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_NO_FILE'), 'warning');
            $this->setRedirect($back);

            return;
        }

        $origName = (string) ($file['name'] ?? '');
        $ext      = strtolower((string) pathinfo($origName, PATHINFO_EXTENSION));
        if ($ext !== 'pdf') {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_NOT_PDF'), 'error');
            $this->setRedirect($back);

            return;
        }

        $maxBytes = 15 * 1024 * 1024;
        if ((int) ($file['size'] ?? 0) > $maxBytes) {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_TOO_LARGE'), 'error');
            $this->setRedirect($back);

            return;
        }

        $uploadDir = JPATH_ROOT . '/media/com_ordenproduccion/invoice_manual_pdf';
        if (!is_dir($uploadDir)) {
            if (!@mkdir($uploadDir, 0755, true)) {
                $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_DIR_ERROR'), 'error');
                $this->setRedirect($back);

                return;
            }
        }

        $destName = 'invoice_' . $invoiceId . '_' . date('Ymd_His') . '_' . substr(sha1((string) microtime(true)), 0, 8) . '.pdf';
        $destAbs  = $uploadDir . '/' . $destName;
        $relPath  = 'media/com_ordenproduccion/invoice_manual_pdf/' . $destName;

        if (!move_uploaded_file($file['tmp_name'], $destAbs)) {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_SAVE_ERROR'), 'error');
            $this->setRedirect($back);

            return;
        }

        $head = @\file_get_contents($destAbs, false, null, 0, 5);
        if ($head !== '%PDF-') {
            @unlink($destAbs);
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_NOT_PDF'), 'error');
            $this->setRedirect($back);

            return;
        }

        $oldRel = \trim((string) ($inv->manual_pdf_path ?? ''));
        if ($oldRel !== '' && \strpos($oldRel, 'media/com_ordenproduccion/invoice_manual_pdf/') === 0) {
            $oldAbs = JPATH_ROOT . '/' . \str_replace('\\', '/', $oldRel);
            if (\is_file($oldAbs) && $oldAbs !== $destAbs) {
                @unlink($oldAbs);
            }
        }

        $query = $db->getQuery(true)
            ->update($db->quoteName('#__ordenproduccion_invoices'))
            ->set($db->quoteName('manual_pdf_path') . ' = ' . $db->quote($relPath))
            ->set($db->quoteName('modified') . ' = ' . $db->quote(Factory::getDate()->toSql()))
            ->where($db->quoteName('id') . ' = ' . (int) $invoiceId);
        $db->setQuery($query);
        $db->execute();

        $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_SUCCESS'), 'success');
        $this->setRedirect($back);
    }

    /**
     * Stream manually uploaded invoice PDF (administración only).
     *
     * GET: invoice_id. Session cookie + group check (no CSRF in URL): safe for iframe and new tab without token mismatch.
     *
     * @return  void
     *
     * @since   3.103.3
     */
    public function downloadManualPdf()
    {
        $app  = $this->app;
        $user = Factory::getUser();

        if ($user->guest) {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_ERROR_LOGIN_REQUIRED'), 'error');
            $app->redirect(Route::_('index.php?option=com_users&view=login', false));

            return;
        }

        $invoiceId = $this->input->getInt('invoice_id', 0);
        if ($invoiceId < 1 || !AccessHelper::canViewInvoiceDetail($invoiceId)) {
            $app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');
            $app->redirect(
                Route::_(
                    AccessHelper::isInAdministracionOrAdmonGroup()
                        ? 'index.php?option=com_ordenproduccion&view=administracion&tab=invoices'
                        : 'index.php?option=com_ordenproduccion&view=ordenes',
                    false
                )
            );

            return;
        }

        $model = $this->getModel('Invoice');
        $inv   = $model ? $model->getItem($invoiceId) : null;
        if (!$inv) {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_ERROR_INVOICE_NOT_FOUND'), 'error');
            $app->redirect(
                Route::_(
                    AccessHelper::isInAdministracionOrAdmonGroup()
                        ? 'index.php?option=com_ordenproduccion&view=administracion&tab=invoices'
                        : 'index.php?option=com_ordenproduccion&view=ordenes',
                    false
                )
            );

            return;
        }

        $rel = \trim((string) ($inv->manual_pdf_path ?? ''));
        if ($rel === '' || \strpos($rel, 'media/com_ordenproduccion/invoice_manual_pdf/') !== 0) {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_INVALID'), 'error');
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . $invoiceId, false));

            return;
        }

        $abs = JPATH_ROOT . '/' . \ltrim(\str_replace('\\', '/', $rel), '/');
        if (!\is_file($abs)) {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_INVALID'), 'error');
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . $invoiceId, false));

            return;
        }

        $size = @\filesize($abs);
        if ($size === false || $size < 24) {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_INVALID'), 'error');
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . $invoiceId, false));

            return;
        }

        $head = @\file_get_contents($abs, false, null, 0, 5);
        if ($head !== '%PDF-') {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_MANUAL_PDF_INVALID'), 'error');
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . $invoiceId, false));

            return;
        }

        if (\function_exists('ini_set')) {
            @\ini_set('zlib.output_compression', '0');
        }
        while (\ob_get_level() > 0) {
            \ob_end_clean();
        }

        $invNum = \preg_replace('/[^A-Za-z0-9\-_]/', '_', (string) ($inv->invoice_number ?? ('FAC-' . $invoiceId)));
        $fname  = $invNum . '-adjunto.pdf';

        if (\method_exists($app, 'clearHeaders')) {
            $app->clearHeaders();
        }
        $app->setHeader('Content-Type', 'application/pdf', true);
        $app->setHeader('Content-Disposition', 'inline; filename="' . $fname . '"', true);
        $app->setHeader('Content-Length', (string) $size, true);
        $app->setHeader('Cache-Control', 'private, max-age=0', true);
        $app->sendHeaders();
        \readfile($abs);
        $app->close();
    }

    /**
     * PDF factura formato Grimpsa (plantilla FPDI + datos de la factura).
     *
     * GET: invoice_id, optional download=1. Session + canViewInvoiceDetail (sin token en URL).
     *
     * @return  void
     *
     * @since   3.118.54
     */
    public function downloadGrimpsaFacturaPdf()
    {
        $app = $this->app;

        if (Factory::getUser()->guest) {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_ERROR_LOGIN_REQUIRED'), 'error');
            $app->redirect(Route::_('index.php?option=com_users&view=login', false));

            return;
        }

        $invoiceId = $this->input->getInt('invoice_id', 0);
        if ($invoiceId < 1 || !AccessHelper::canViewInvoiceDetail($invoiceId)) {
            $app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');
            $app->redirect(
                Route::_(
                    AccessHelper::isInAdministracionOrAdmonGroup()
                        ? 'index.php?option=com_ordenproduccion&view=administracion&tab=invoices'
                        : 'index.php?option=com_ordenproduccion&view=ordenes',
                    false
                )
            );

            return;
        }

        if (!InvoiceGrimpsaTemplatePdfHelper::isTemplateAvailable()) {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_GRIMPSA_PDF_NO_TEMPLATE'), 'error');
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . $invoiceId, false));

            return;
        }

        $model = $this->getModel('Invoice');
        $inv   = $model ? $model->getItem($invoiceId) : null;
        if (!$inv) {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_ERROR_INVOICE_NOT_FOUND'), 'error');
            $app->redirect(
                Route::_(
                    AccessHelper::isInAdministracionOrAdmonGroup()
                        ? 'index.php?option=com_ordenproduccion&view=administracion&tab=invoices'
                        : 'index.php?option=com_ordenproduccion&view=ordenes',
                    false
                )
            );

            return;
        }

        try {
            $doc = $app->getDocument();
            if ($doc !== null && \method_exists($doc, 'setTitle')) {
                $doc->setTitle(
                    InvoiceGrimpsaTemplatePdfHelper::resolvePdfDocumentTitleForInvoice($inv)
                );
            }

            $binary = InvoiceGrimpsaTemplatePdfHelper::build($inv);
        } catch (\Throwable $e) {
            Log::add('invoice.grimpsa.pdf: ' . $e->getMessage(), Log::ERROR, 'com_ordenproduccion');
            $msg = Text::_('COM_ORDENPRODUCCION_INVOICE_GRIMPSA_PDF_ERROR')
                . (JDEBUG ? ' ' . $e->getMessage() : '');
            $app->enqueueMessage($msg, 'error');
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . $invoiceId, false));

            return;
        }

        if ($binary === '') {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_GRIMPSA_PDF_ERROR'), 'error');
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . $invoiceId, false));

            return;
        }

        if (\function_exists('ini_set')) {
            @\ini_set('zlib.output_compression', '0');
        }
        while (\ob_get_level() > 0) {
            \ob_end_clean();
        }

        $invNum = \preg_replace('/[^A-Za-z0-9\-_]/', '_', (string) ($inv->invoice_number ?? ('FAC-' . $invoiceId)));
        $fname  = $invNum . '-grimpsa.pdf';
        $forceDownload = (int) $this->input->getInt('download', 0) === 1;
        $disposition   = $forceDownload ? 'attachment' : 'inline';

        if (\method_exists($app, 'clearHeaders')) {
            $app->clearHeaders();
        }
        $app->setHeader('Content-Type', 'application/pdf', true);
        $app->setHeader('Content-Disposition', $disposition . '; filename="' . $fname . '"', true);
        $app->setHeader('Content-Length', (string) \strlen($binary), true);
        $app->setHeader('Cache-Control', 'private, max-age=0', true);
        $app->sendHeaders();
        echo $binary;
        $app->close();
    }

    /**
     * Queue FEL mock invoice from cotización (JSON). Step 1: create pending row.
     *
     * @return  void
     *
     * @since   3.101.50
     */
    public function issueFromQuotation()
    {
        $app = $this->app;
        $app->setHeader('Content-Type', 'application/json; charset=utf-8', true);

        if (!Session::checkToken('request')) {
            echo json_encode(['success' => false, 'message' => Text::_('JINVALID_TOKEN')]);
            $app->close();
        }

        $user = Factory::getUser();
        if ($user->guest) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_ERROR_LOGIN_REQUIRED')]);
            $app->close();
        }

        if (!AccessHelper::isSuperUser()) {
            echo json_encode(['success' => false, 'message' => Text::_('JERROR_ALERTNOAUTHOR')]);
            $app->close();
        }

        $quotationId = $this->input->getInt('quotation_id', 0);
        if ($quotationId < 1) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_FEL_ISSUE_QUOTATION_INVALID')]);
            $app->close();
        }

        $service = new FelInvoiceIssuanceService();
        if (!$service->isEngineAvailable() || !$service->hasQuotationIdColumn()) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_FEL_ISSUE_ENGINE_UNAVAILABLE')]);
            $app->close();
        }

        $existing = $service->getInvoiceByQuotationId($quotationId);
        if ($existing) {
            echo json_encode([
                'success'    => true,
                'invoice_id' => (int) $existing->id,
                'existing'   => true,
                'status'     => (string) ($existing->fel_issue_status ?? ''),
            ]);
            $app->close();
        }

        $invoiceId = $service->createPendingInvoiceFromQuotation($quotationId, (int) $user->id);
        if ($invoiceId < 1) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_FEL_ISSUE_CREATE_FAILED')]);
            $app->close();
        }

        echo json_encode([
            'success'    => true,
            'invoice_id' => $invoiceId,
            'existing'   => false,
            'status'     => 'pending',
        ]);
        $app->close();
    }

    /**
     * Process pending FEL invoice (JSON). Digifact when certifier URLs + token are active; otherwise mock certify + files.
     *
     * @return  void
     *
     * @since   3.101.50
     */
    public function processFelIssuance()
    {
        $app = $this->app;
        $app->setHeader('Content-Type', 'application/json; charset=utf-8', true);

        if (!Session::checkToken('request')) {
            echo json_encode(['success' => false, 'message' => Text::_('JINVALID_TOKEN')]);
            $app->close();
        }

        $user = Factory::getUser();
        if ($user->guest) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_ERROR_LOGIN_REQUIRED')]);
            $app->close();
        }

        if (!AccessHelper::isSuperUser()) {
            echo json_encode(['success' => false, 'message' => Text::_('JERROR_ALERTNOAUTHOR')]);
            $app->close();
        }

        $invoiceId = $this->input->getInt('invoice_id', 0);
        if ($invoiceId < 1) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_FEL_ISSUE_INVOICE_INVALID')]);
            $app->close();
        }

        $forceScheduled = $this->input->getInt('force', 0) === 1;

        $service = new FelInvoiceIssuanceService();
        $result = $service->processInvoice($invoiceId, $forceScheduled);
        if (!empty($result['success'])) {
            $result['message'] = Text::_('COM_ORDENPRODUCCION_FEL_ISSUE_SUCCESS');
        }

        echo json_encode($result);
        $app->close();
    }

    /**
     * JSON status for polling (fel_issue_*).
     *
     * @return  void
     *
     * @since   3.101.50
     */
    public function felIssuanceStatus()
    {
        $app = $this->app;
        $app->setHeader('Content-Type', 'application/json; charset=utf-8', true);

        if (!Session::checkToken('request')) {
            echo json_encode(['success' => false, 'message' => Text::_('JINVALID_TOKEN')]);
            $app->close();
        }

        $user = Factory::getUser();
        if ($user->guest) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_ERROR_LOGIN_REQUIRED')]);
            $app->close();
        }

        if (!AccessHelper::isSuperUser()) {
            echo json_encode(['success' => false, 'message' => Text::_('JERROR_ALERTNOAUTHOR')]);
            $app->close();
        }

        $invoiceId = $this->input->getInt('invoice_id', 0);
        if ($invoiceId < 1) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_FEL_ISSUE_INVOICE_INVALID')]);
            $app->close();
        }

        $model = $this->getModel('Invoice');
        $inv = $model ? $model->getItem($invoiceId) : null;
        if (!$inv) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_FEL_ISSUE_INVOICE_NOT_FOUND')]);
            $app->close();
        }

        echo json_encode([
            'success'              => true,
            'fel_issue_status'     => (string) ($inv->fel_issue_status ?? ''),
            'fel_issue_error'      => (string) ($inv->fel_issue_error ?? ''),
            'invoice_number'       => (string) ($inv->invoice_number ?? ''),
            'fel_local_pdf_path'   => (string) ($inv->fel_local_pdf_path ?? ''),
            'fel_local_xml_path'   => (string) ($inv->fel_local_xml_path ?? ''),
        ]);
        $app->close();
    }

    /**
     * Stream mock FEL PDF/XML from disk with correct Content-Type (avoids saving HTML/login pages as .pdf).
     *
     * GET: invoice_id, type=pdf|xml, CSRF token, optional download=1 (same as cotizacion.downloadPdf: inline in browser by default).
     *
     * @return  void
     *
     * @since   3.101.57
     */
    public function downloadFelArtifact()
    {
        $app = $this->app;

        if (!Session::checkToken('request')) {
            $app->enqueueMessage(Text::_('JINVALID_TOKEN'), 'error');
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices', false));

            return;
        }

        $user = Factory::getUser();
        if ($user->guest) {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_ERROR_LOGIN_REQUIRED'), 'error');
            $app->redirect(Route::_('index.php?option=com_users&view=login', false));

            return;
        }

        $invoiceId = $this->input->getInt('invoice_id', 0);
        $kind      = $this->input->getCmd('type', 'pdf');
        if ($invoiceId < 1 || !\in_array($kind, ['pdf', 'xml'], true)) {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_FEL_ISSUE_INVOICE_INVALID'), 'error');
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices', false));

            return;
        }

        $model = $this->getModel('Invoice');
        $inv   = $model ? $model->getItem($invoiceId) : null;
        if (!$inv) {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_FEL_ISSUE_INVOICE_NOT_FOUND'), 'error');
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices', false));

            return;
        }

        if (FelInvoiceHelper::isMockFelplexQuotationArtifactInvoice($inv) && !AccessHelper::isSuperUser()) {
            $app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');
            $qid = (int) ($inv->quotation_id ?? 0);
            $app->redirect(Route::_($qid > 0
                ? 'index.php?option=com_ordenproduccion&view=cotizacion&id=' . $qid
                : 'index.php?option=com_ordenproduccion&view=administracion&tab=invoices', false));

            return;
        }

        if (!AccessHelper::isInVentasGroup() && !AccessHelper::isInAdministracionOrAdmonGroup() && !AccessHelper::isSuperUser()) {
            $app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices', false));

            return;
        }

        $rel = $kind === 'xml' ? \trim((string) ($inv->fel_local_xml_path ?? '')) : \trim((string) ($inv->fel_local_pdf_path ?? ''));
        if ($rel === '') {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_FEL_ISSUE_INVOICE_INVALID'), 'error');
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . $invoiceId, false));

            return;
        }

        $abs = JPATH_ROOT . '/' . \ltrim(\str_replace('\\', '/', $rel), '/');
        if (!\is_file($abs)) {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_FEL_ISSUE_INVOICE_INVALID'), 'error');
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . $invoiceId, false));

            return;
        }

        $size = @\filesize($abs);
        if ($size === false || $size < 24) {
            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_FEL_ISSUE_INVOICE_INVALID'), 'error');
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . $invoiceId, false));

            return;
        }

        if ($kind === 'pdf') {
            $head = @\file_get_contents($abs, false, null, 0, 5);
            if ($head !== '%PDF-') {
                $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_FEL_ISSUE_INVOICE_INVALID'), 'error');
                $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . $invoiceId, false));

                return;
            }
        }

        // Binary body must not be prefixed by buffer output or zlib (breaks Chrome PDF viewer).
        if (\function_exists('ini_set')) {
            @\ini_set('zlib.output_compression', '0');
        }
        while (\ob_get_level() > 0) {
            \ob_end_clean();
        }

        $invNum = \preg_replace('/[^A-Za-z0-9\-_]/', '_', (string) ($inv->invoice_number ?? ('FAC-' . $invoiceId)));
        $fname  = $kind === 'xml' ? $invNum . '-fel.xml' : $invNum . '-fel.pdf';
        $mime   = $kind === 'xml' ? 'application/xml' : 'application/pdf';
        // Match cotizacion.downloadPdf: open in browser unless download=1 (force attachment).
        $forceDownload = (int) $this->input->getInt('download', 0) === 1;
        $disposition     = $forceDownload ? 'attachment' : 'inline';

        if (\method_exists($app, 'clearHeaders')) {
            $app->clearHeaders();
        }
        $app->setHeader('Content-Type', $mime, true);
        $app->setHeader('Content-Disposition', $disposition . '; filename="' . $fname . '"', true);
        $app->setHeader('Content-Length', (string) $size, true);
        $app->setHeader('Cache-Control', 'private, max-age=0', true);
        $app->sendHeaders();
        \readfile($abs);
        $app->close();
    }

    /**
     * Generate autonumeric invoice number based on table ID
     */
    private function generateInvoiceNumber()
    {
        $db = Factory::getDbo();
        
        // Get the next ID from the invoice table
        $query = $db->getQuery(true)
            ->select('AUTO_INCREMENT')
            ->from('INFORMATION_SCHEMA.TABLES')
            ->where($db->quoteName('TABLE_SCHEMA') . ' = ' . $db->quote($db->getDatabase()))
            ->where($db->quoteName('TABLE_NAME') . ' = ' . $db->quote($db->getPrefix() . 'ordenproduccion_invoices'));

        $db->setQuery($query);
        $nextId = $db->loadResult();

        if (!$nextId) {
            // Fallback: get max ID + 1
            $query = $db->getQuery(true)
                ->select('MAX(id) + 1')
                ->from($db->quoteName('#__ordenproduccion_invoices'));

            $db->setQuery($query);
            $nextId = $db->loadResult() ?: 1;
        }

        return 'FAC-' . str_pad($nextId, 6, '0', STR_PAD_LEFT);
    }

    /**
     * Update work order with invoice number
     */
    private function updateWorkOrderInvoiceNumber($orderId, $invoiceNumber)
    {
        try {
            $db = Factory::getDbo();
            $query = $db->getQuery(true)
                ->update($db->quoteName('#__ordenproduccion_ordenes'))
                ->set($db->quoteName('invoice_number') . ' = ' . $db->quote($invoiceNumber))
                ->where($db->quoteName('id') . ' = ' . (int) $orderId);

            $db->setQuery($query);
            $db->execute();
            
            return true;
        } catch (\Exception $e) {
            // Log error but don't fail the invoice creation
            Factory::getApplication()->enqueueMessage('Warning: Could not update work order with invoice number', 'warning');
            return false;
        }
    }

    /**
     * Super user only: mark invoice as cancelled in the system (does not void with SAT).
     *
     * POST: invoice_id, optional return URL via redirect
     *
     * @since  3.104.6
     */
    public function anularInvoice()
    {
        if (!Session::checkToken('post')) {
            $this->app->enqueueMessage(Text::_('JINVALID_TOKEN'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices', false));

            return;
        }

        if (!AccessHelper::isSuperUser()) {
            $this->app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=ordenes', false));

            return;
        }

        $invoiceId = $this->input->post->getInt('invoice_id', 0);
        $back        = Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . (int) $invoiceId, false);

        if ($invoiceId <= 0) {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_ERROR_INVOICE_NOT_FOUND'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices', false));

            return;
        }

        $model = $this->getModel('Invoice');
        if (!$model || !method_exists($model, 'markCancelledBySuperUser')) {
            $this->app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');
            $this->setRedirect($back);

            return;
        }

        $ok = $model->markCancelledBySuperUser($invoiceId, (int) Factory::getUser()->id);
        $this->app->enqueueMessage(
            $ok ? Text::_('COM_ORDENPRODUCCION_INVOICE_ANULAR_SUCCESS') : Text::_('COM_ORDENPRODUCCION_INVOICE_ANULAR_NOOP'),
            $ok ? 'success' : 'notice'
        );

        $this->setRedirect($back);
    }

    /**
     * Super user only: undo in-app void and restore invoice to active status (does not affect SAT).
     *
     * POST: invoice_id
     *
     * @since  3.119.138
     */
    public function reactivarInvoice()
    {
        if (!Session::checkToken('post')) {
            $this->app->enqueueMessage(Text::_('JINVALID_TOKEN'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices', false));

            return;
        }

        if (!AccessHelper::isSuperUser()) {
            $this->app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=ordenes', false));

            return;
        }

        $invoiceId = $this->input->post->getInt('invoice_id', 0);
        $back      = Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . (int) $invoiceId, false);

        if ($invoiceId <= 0) {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_ERROR_INVOICE_NOT_FOUND'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices', false));

            return;
        }

        $model = $this->getModel('Invoice');
        if (!$model || !method_exists($model, 'restoreActiveBySuperUser')) {
            $this->app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');
            $this->setRedirect($back);

            return;
        }

        $ok = $model->restoreActiveBySuperUser($invoiceId, (int) Factory::getUser()->id);
        $this->app->enqueueMessage(
            $ok ? Text::_('COM_ORDENPRODUCCION_INVOICE_REACTIVAR_SUCCESS') : Text::_('COM_ORDENPRODUCCION_INVOICE_REACTIVAR_NOOP'),
            $ok ? 'success' : 'notice'
        );

        $this->setRedirect($back);
    }

    /**
     * Super user only: unlink one work order from this invoice.
     * Allowed on voided (cancelled) invoices so OT links can be cleared without editing the invoice.
     *
     * POST: invoice_id, orden_id
     *
     * @since  3.104.6
     */
    public function removeInvoiceOrden()
    {
        if (!Session::checkToken('post')) {
            $this->app->enqueueMessage(Text::_('JINVALID_TOKEN'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices', false));

            return;
        }

        if (!AccessHelper::isSuperUser()) {
            $this->app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_ordenproduccion&view=ordenes', false));

            return;
        }

        $invoiceId = $this->input->post->getInt('invoice_id', 0);
        $ordenId     = $this->input->post->getInt('orden_id', 0);
        $back        = Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . (int) $invoiceId, false);

        if ($invoiceId <= 0 || $ordenId <= 0) {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_DISSOCIATE_INVALID'), 'warning');
            $this->setRedirect($back);

            return;
        }

        try {
            $model = $this->getModel('InvoiceOrdenMatch', 'Site', ['ignore_request' => true]);
            if (!$model) {
                $model = $this->app->bootComponent('com_ordenproduccion')->getMVCFactory()->createModel('InvoiceOrdenMatch', 'Site');
            }
            if (!$model || !method_exists($model, 'removeInvoiceOrdenAssociation')) {
                $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_ORDEN_MATCH_TABLE_MISSING'), 'error');
                $this->setRedirect($back);

                return;
            }
            $ok = $model->removeInvoiceOrdenAssociation($invoiceId, $ordenId);
            $this->app->enqueueMessage(
                $ok ? Text::_('COM_ORDENPRODUCCION_INVOICE_DISSOCIATE_SUCCESS') : Text::_('COM_ORDENPRODUCCION_INVOICE_DISSOCIATE_NOOP'),
                $ok ? 'success' : 'notice'
            );
        } catch (\Throwable $e) {
            $this->app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_DISSOCIATE_ERROR') . ': ' . $e->getMessage(), 'error');
        }

        $this->setRedirect($back);
    }

    /**
     * JSON: preview manual FEL from invoice duplicate modal (invoice data only).
     *
     * @since  3.119.178
     */
    public function manualFelPreviewFromInvoiceDuplicate(): void
    {
        $this->respondManualFelFromInvoiceDuplicate(true);
    }

    /**
     * JSON: issue manual FEL from invoice duplicate modal (invoice data only).
     *
     * @since  3.119.178
     */
    public function manualFelIssueFromInvoiceDuplicate(): void
    {
        $this->respondManualFelFromInvoiceDuplicate(false);
    }

    /**
     * @since  3.119.178
     */
    protected function respondManualFelFromInvoiceDuplicate(bool $previewOnly): void
    {
        $app = Factory::getApplication();
        $app->setHeader('Content-Type', 'application/json; charset=utf-8', true);

        $lang = $app->getLanguage();
        $tag  = $lang->getTag();
        $lang->load('com_ordenproduccion', JPATH_SITE, $tag, true);
        $lang->load('com_ordenproduccion', JPATH_SITE . '/components/com_ordenproduccion', $tag, true);

        if (!Session::checkToken()) {
            echo json_encode(['success' => false, 'message' => Text::_('JINVALID_TOKEN')], JSON_UNESCAPED_UNICODE);
            $app->close();
        }

        $user = Factory::getUser();
        if ($user->guest) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_ERROR_LOGIN_REQUIRED')], JSON_UNESCAPED_UNICODE);
            $app->close();
        }

        if (!AccessHelper::isSuperUser()) {
            echo json_encode(['success' => false, 'message' => Text::_('JERROR_ALERTNOAUTHOR')], JSON_UNESCAPED_UNICODE);
            $app->close();
        }

        $sourceInvoiceId = $app->input->getInt('source_invoice_id', 0);
        if ($sourceInvoiceId < 1) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_ERROR_INVOICE_NOT_FOUND')], JSON_UNESCAPED_UNICODE);
            $app->close();
        }

        $invModel = $this->getModel('Invoice', 'Site', ['ignore_request' => true]);
        $sourceInv = $invModel && \is_callable([$invModel, 'getItem']) ? $invModel->getItem($sourceInvoiceId) : null;
        if (!$sourceInv) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_ERROR_INVOICE_NOT_FOUND')], JSON_UNESCAPED_UNICODE);
            $app->close();
        }

        $buyerName = trim((string) $app->input->post->getString('manual_buyer_name', ''));
        $buyerNit  = trim((string) $app->input->post->getString('manual_buyer_nit', ''));
        $buyerAddr = trim((string) $app->input->post->getString('manual_buyer_address', 'Ciudad'));

        $linesRaw = $app->input->post->getString('manual_lines_json', '');
        $linesDec = \json_decode($linesRaw, true);
        if (!\is_array($linesDec) || $linesDec === []) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_MANUAL_FEL_LINES_REQUIRED')], JSON_UNESCAPED_UNICODE);
            $app->close();
        }

        $manualLines = [];
        foreach ($linesDec as $line) {
            if (!\is_array($line)) {
                continue;
            }
            $desc = trim((string) ($line['descripcion'] ?? ''));
            $qty  = (float) ($line['cantidad'] ?? 0);
            $unit = (float) ($line['precio_unitario'] ?? 0);
            if ($desc === '' || $qty < 0.000001 || $unit < 0) {
                continue;
            }
            $manualLines[] = [
                'descripcion'     => $desc,
                'cantidad'        => $qty,
                'precio_unitario' => $unit,
            ];
        }
        if ($manualLines === []) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_MANUAL_FEL_LINES_REQUIRED')], JSON_UNESCAPED_UNICODE);
            $app->close();
        }

        $issueDateYmd = trim((string) $app->input->post->getString('manual_issue_date', ''));
        $nucOptions   = $this->parseManualFelNucOptionsFromPost($app->input);

        $ordenIdsRaw = $app->input->post->getString('manual_orden_ids_json', '[]');
        $ordenIdsDec = \json_decode($ordenIdsRaw, true);
        $ordenIds    = [];
        if (\is_array($ordenIdsDec)) {
            foreach ($ordenIdsDec as $oid) {
                $oid = (int) $oid;
                if ($oid > 0) {
                    $ordenIds[] = $oid;
                }
            }
        }

        $fel = new FelInvoiceIssuanceService();
        if (!$fel->isEngineAvailable()) {
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_DIGIFACT_DIRECT_FEL_UNAVAILABLE')], JSON_UNESCAPED_UNICODE);
            $app->close();
        }

        $nitRaw    = $buyerNit !== '' ? $buyerNit : trim((string) ($sourceInv->client_nit ?? ''));
        $isCf      = CertificadorFactNitLookupHelper::billingIdIndicatesConsumidorFinal($nitRaw);
        $cuiPost   = trim((string) $app->input->post->getString('digifact_buyer_cui', ''));
        $cuiDigits = CertificadorFactNitLookupHelper::digitsOnlyBillingId($cuiPost);
        $cuiOverride = null;

        if ($isCf) {
            if ($previewOnly) {
                if ($cuiDigits !== '') {
                    $cuiOverride = $cuiDigits;
                }
            } else {
                if ($cuiDigits === '') {
                    echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_DIGIFACT_DIRECT_CUI_REQUIRED')], JSON_UNESCAPED_UNICODE);
                    $app->close();
                }
                $verify = $fel->verifyDigifactCui($cuiPost);
                if (empty($verify['success'])) {
                    echo json_encode([
                        'success' => false,
                        'message' => (string) ($verify['message'] ?? Text::_('COM_ORDENPRODUCCION_CLIENTE_DIGIFACT_CUI_NOT_FOUND')),
                    ], JSON_UNESCAPED_UNICODE);
                    $app->close();
                }
                $cuiOverride = $cuiDigits;
            }
        }

        try {
            if ($previewOnly) {
                $built = $fel->buildManualFelNucPayloadFromInvoiceDuplicate(
                    $sourceInvoiceId,
                    $manualLines,
                    $buyerName,
                    $nitRaw,
                    $buyerAddr,
                    $cuiOverride,
                    $issueDateYmd,
                    $nucOptions
                );
                if (empty($built['success']) || !isset($built['payload']) || !\is_array($built['payload'])) {
                    echo json_encode([
                        'success' => false,
                        'message' => (string) ($built['message'] ?? Text::_('COM_ORDENPRODUCCION_MANUAL_FEL_PREVIEW_FAILED')),
                    ], JSON_UNESCAPED_UNICODE);
                    $app->close();
                }
                $preview = $fel->buildManualFelPreviewArtifacts($built['payload']);
                echo json_encode($preview, JSON_UNESCAPED_UNICODE);
                $app->close();
            }

            $result = $fel->issueDigifactNucManualFromInvoiceDuplicate(
                $sourceInvoiceId,
                (int) $user->id,
                $manualLines,
                $buyerName,
                $nitRaw,
                $buyerAddr,
                $ordenIds,
                $cuiOverride,
                $issueDateYmd,
                $nucOptions
            );
            if (!empty($result['success']) && !empty($result['invoice_id'])) {
                $result['invoice_url'] = Route::_(
                    'index.php?option=com_ordenproduccion&view=invoice&id=' . (int) $result['invoice_id'],
                    false
                );
            }
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } catch (\Throwable $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        }
        $app->close();
    }

    /**
     * @return  array<string, mixed>
     *
     * @since  3.119.178
     */
    protected function parseManualFelNucOptionsFromPost(\Joomla\Input\Input $input): array
    {
        $docType = strtoupper(trim((string) $input->post->getString('manual_doc_type', 'FACT')));
        if (!\in_array($docType, ['FACT', 'FCAM'], true)) {
            $docType = 'FACT';
        }

        $observaciones = trim((string) $input->post->getString('manual_observaciones', ''));

        $fcamAbonos = [];
        $fcamRaw    = $input->post->getString('manual_fcam_abonos_json', '[]');
        $fcamDec    = \json_decode($fcamRaw, true);
        if (\is_array($fcamDec)) {
            foreach ($fcamDec as $ab) {
                if (!\is_array($ab)) {
                    continue;
                }
                $fcamAbonos[] = $ab;
            }
        }

        $currency = strtoupper(trim((string) $input->post->getString('manual_currency', 'GTQ')));
        if (!\in_array($currency, ['GTQ', 'USD'], true)) {
            $currency = 'GTQ';
        }

        $exchangeRate = null;
        if ($currency === 'USD') {
            $rateRaw = $input->post->getString('manual_exchange_rate', '');
            if ($rateRaw !== '') {
                $rate = (float) $rateRaw;
                if ($rate > 0.000001) {
                    $exchangeRate = $rate;
                }
            }
        }

        return [
            'doc_type'       => $docType,
            'observaciones'  => $observaciones,
            'fcam_abonos'    => $fcamAbonos,
            'currency'       => $currency,
            'exchange_rate'  => $exchangeRate,
        ];
    }
}
