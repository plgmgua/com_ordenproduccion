<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_ordenproduccion
 *
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Grimpsa\Component\Ordenproduccion\Site\View\Administracion;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Router\Route;
use Joomla\Database\DatabaseInterface;
use Grimpsa\Component\Ordenproduccion\Site\Helper\AccessHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\ApprovalWorkflowEntityHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\QuotationEnvioFelPendingHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\OutboundEmailLogHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\UserImpersonationHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\UserSessionAuditHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\OtWizardCreationLogHelper;
use Grimpsa\Component\Ordenproduccion\Site\Model\AdministracionModel;
use Grimpsa\Component\Ordenproduccion\Site\Model\InvoiceOrdenMatchModel;
use Grimpsa\Component\Ordenproduccion\Site\Service\ApprovalWorkflowService;
use Grimpsa\Component\Ordenproduccion\Site\Service\FelInvoiceIssuanceService;

/**
 * Administracion Dashboard View
 *
 * @since  3.1.0
 */
class HtmlView extends BaseHtmlView
{
    /**
     * Dashboard statistics
     *
     * @var    object
     * @since  3.1.0
     */
    protected $stats;

    /**
     * Current month
     *
     * @var    string
     * @since  3.1.0
     */
    protected $currentMonth;

    /**
     * Current year
     *
     * @var    string
     * @since  3.1.0
     */
    protected $currentYear;

    /**
     * Invoices list
     *
     * @var    array
     * @since  3.2.0
     */
    protected $invoices = [];

    /**
     * Invoices pagination
     *
     * @var    object|null
     * @since  3.2.0
     */
    protected $invoicesPagination = null;

    /**
     * Model state
     *
     * @var    object
     * @since  3.2.0
     */
    protected $state;

    /**
     * Banks list
     *
     * @var    array
     * @since  3.5.1
     */
    protected $banks = [];

    /**
     * Payment types list
     *
     * @var    array
     * @since  3.65.0
     */
    protected $paymentTypes = [];

    /**
     * Bank accounts (cuentas bancarias) for herramientas subtab
     *
     * @var    array
     * @since  3.118.0
     */
    protected $bankAccounts = [];

    /**
     * Active subtab for herramientas tab
     *
     * @var    string
     * @since  3.5.2
     */
    protected $activeSubTab = 'banks';

    /**
     * Activity statistics (for resumen tab)
     *
     * @var    object
     * @since  3.6.0
     */
    protected $activityStats;

    /**
     * Activity statistics grouped by sales agent (for resumen tab)
     *
     * @var    array
     * @since  3.6.0
     */
    protected $activityStatsByAgent = [];

    /**
     * Status changes statistics grouped by sales agent (for resumen tab)
     *
     * @var    object
     * @since  3.6.0
     */
    protected $statusChangesByAgent = null;

    /**
     * Payment proofs statistics grouped by sales agent (for resumen tab)
     *
     * @var    array
     * @since  3.6.0
     */
    protected $paymentProofsByAgent = [];

    /**
     * Shipping slips statistics grouped by sales agent (for resumen tab)
     *
     * @var    array
     * @since  3.6.0
     */
    protected $shippingSlipsByAgent = [];

    /**
     * Selected period for activity statistics (day, week, month)
     *
     * @var    string
     * @since  3.6.0
     */
    protected $selectedPeriod = 'day';

    /**
     * Report work orders (for reportes tab)
     *
     * @var    array
     * @since  3.6.0
     */
    protected $reportWorkOrders = [];

    /**
     * Distinct clients for report filter dropdown
     *
     * @var    array
     * @since  3.6.0
     */
    protected $reportClients = [];

    /**
     * Report filter: date from
     *
     * @var    string
     * @since  3.6.0
     */
    protected $reportDateFrom = '';

    /**
     * Report filter: date to
     *
     * @var    string
     * @since  3.6.0
     */
    protected $reportDateTo = '';

    /**
     * Report filter: client name
     *
     * @var    string
     * @since  3.6.0
     */
    protected $reportClient = '';

    /**
     * Report filter: NIT
     *
     * @var    string
     * @since  3.6.0
     */
    protected $reportNit = '';

    /**
     * Report filter: sales agent
     *
     * @var    string
     * @since  3.6.0
     */
    protected $reportSalesAgent = '';

    /**
     * Report payment status filter: '', 'paid', 'unpaid', 'balance_due'
     *
     * @var string
     */
    protected $reportPaymentStatus = '';

    /**
     * Report: hide rows where diferencia (paid - invoice) is zero.
     *
     * @var bool
     *
     * @since 3.119.143
     */
    protected $reportHideZeroDiferencia = false;

    /**
     * Report pagination (total, limit, limitstart)
     *
     * @var    \Joomla\CMS\Pagination\Pagination|null
     * @since  3.78.0
     */
    protected $reportPagination = null;

    /**
     * Report total count (full result set)
     *
     * @var    int
     * @since  3.78.0
     */
    protected $reportTotal = 0;

    /**
     * Report total invoice value (full result set)
     *
     * @var    float
     * @since  3.78.0
     */
    protected $reportTotalValue = 0.0;

    /**
     * Report list limit (page size)
     *
     * @var    int
     * @since  3.78.0
     */
    protected $reportLimit = 20;

    /**
     * Report list offset (limitstart)
     *
     * @var    int
     * @since  3.78.0
     */
    protected $reportLimitStart = 0;

    /**
     * Clients list with totals (for clientes tab)
     *
     * @var    array
     * @since  3.54.0
     */
    protected $clients = [];

    /**
     * Whether current user can merge clients (super user only)
     *
     * @var    bool
     * @since  3.55.0
     */
    protected $canMergeClients = false;

    /**
     * Sales agents list for report dropdown
     *
     * @var    array
     * @since  3.6.0
     */
    protected $reportSalesAgents = [];

    /**
     * Clientes tab: sales agent filter, client name filter, NIT filter
     *
     * @var    string
     * @since  3.79.0
     */
    protected $clientesSalesAgent = '';
    protected $clientesClientName = '';
    protected $clientesNit = '';
    protected $clientesLimit = 20;
    protected $clientesLimitStart = 0;
    protected $clientesTotal = 0;
    protected $clientesTotalSaldo = 0.0;
    protected $clientesTotalCompras = 0.0;
    protected $clientesTotalOrders = 0;
    protected $clientesPagination = null;
    protected $clientesSalesAgents = [];
    /** Whether to show the sales agent filter dropdown (false when Ventas: only own data) */
    protected $clientesShowSalesAgentFilter = true;
    /** Clientes subtab: estado_cuenta | dias_credito */
    protected $clientesSubtab = 'estado_cuenta';
    /** Orders without payment proof by age buckets (0_15, 16_30, 31_45, 45_plus) for Días de crédito subtab */
    protected $clientesDiasCreditoBuckets = [];
    /** Orders without payment proof summarized by client for Rango de días detail subtable */
    protected $clientesDiasCreditoByClient = [];
    /** Orders without payment proof summarized by sales agent for Rango de días summary level */
    protected $clientesDiasCreditoByAgent = [];

    /** Rango de días: sort column (client, 0_15, …, total) */
    protected $clientesDiasCreditoOrdering = 'client';

    /** Rango de días: asc | desc */
    protected $clientesDiasCreditoDirection = 'asc';

    /** Rango de días: clients grouped by sales_agent key, each list sorted (for agent expand rows) */
    protected $clientesDiasCreditoGroupedByAgent = [];

    /**
     * Cotización PDF template settings (Encabezado, Términos y Condiciones, Pie de página) for Ajustes > Ajustes de Cotización
     *
     * @var    array
     * @since  3.78.0
     */
    protected $cotizacionPdfSettings = [];

    /**
     * Invoice HTML header/footer templates (Ajustes > Plantilla de Factura).
     *
     * @var    array<string, mixed>
     * @since  3.118.81
     */
    protected $invoiceFacturaPlantillaSettings = [
        'header_izq_html'   => '',
        'header_der_html'   => '',
        'footer_html'       => '',
        'logo_path'         => '',
        'logo_x'            => 15,
        'logo_y'            => 15,
        'logo_width'        => 50,
        'encabezado_izq_x'  => 15,
        'encabezado_izq_y'  => 15,
        'encabezado_der_x'  => 115,
        'encabezado_der_y'  => 15,
        'qr_x'              => 150,
        'qr_y'              => 18,
        'qr_size_mm'        => 0,
        'pie_x'             => 0,
        'pie_y'             => 0,
    ];

    /**
     * Solicitud de Orden URL (webhook) for ajustes > solicitud_orden subtab.
     *
     * @var    string
     * @since  3.92.0
     */
    protected $solicitudOrdenUrl = '';

    /**
     * Certificador de Fact (FEL) settings for Ajustes > Certificador de Fact (without clave values in layout).
     *
     * @var    array<string, array<string, string>>
     * @since  3.118.4
     */
    protected $certificadorFactSettings = [];

    /**
     * Whether clave is already stored per environment (for password placeholder hints).
     *
     * @var    array{test: bool, prod: bool}
     * @since  3.118.4
     */
    protected $certificadorFactClaveSet = ['test' => false, 'prod' => false];

    /**
     * Active certifier mode: test (Modo Prueba) or prod (Modo producción).
     *
     * @var    string
     * @since  3.118.5
     */
    protected $certificadorFactModo = 'test';

    /**
     * MT-940 mailbox / IMAP settings (Ajustes > MT940).
     *
     * @var    array<string, string|int>
     * @since  3.119.146
     */
    protected $mt940Settings = [];

    /**
     * Whether MT-940 IMAP password is stored (for placeholder hint).
     *
     * @var    bool
     * @since  3.119.146
     */
    protected $mt940PasswordSet = false;

    /**
     * MT-940 import panel (Ajustes → MT-940 → Importar datos).
     *
     * @var    bool
     * @since  3.119.157
     */
    protected $ajustesMt940SchemaOk = false;

    /**
     * @var    array<int, string>
     * @since  3.119.157
     */
    protected $ajustesMt940BankAccountOptions = [];

    /**
     * Copy-paste crontab line for daily MT-940 import (Ajustes → Importar datos).
     *
     * @var    string
     * @since  3.119.158
     */
    protected $mt940CronCrontabLine = '';

    /**
     * @var    bool
     * @since  3.119.158
     */
    protected $mt940CronKeyConfigured = false;

    /**
     * @var    array<int, object>
     * @since  3.119.160
     */
    protected $mt940RunLogRows = [];

    /**
     * @var    int
     * @since  3.119.160
     */
    protected $mt940RunLogTotal = 0;

    /**
     * @var    \Joomla\CMS\Pagination\Pagination|null
     * @since  3.119.160
     */
    protected $mt940RunLogPagination = null;

    /**
     * @var    bool
     * @since  3.119.160
     */
    protected $mt940RunLogTableOk = false;

    /**
     * @var    int
     * @since  3.119.160
     */
    protected $mt940RunLogListLimit = 25;

    /**
     * Show Digifact NIT-verify curl debug on Mis Clientes (Ajustes certificador toggle).
     *
     * @var    bool
     * @since  3.118.17
     */
    protected $certificadorFactFrontendDebug = false;

    /**
     * Active modo settings as one map for layouts (same keys as stored fields; clave never included, use clave_configured).
     *
     * @var    array{env: string, url_autenticacion: string, url_info: string, url_cert_cf: string, url_cert_nit: string, url_cert_cui: string, branch_code: string, branch_name: string, branch_address: string, branch_city: string, branch_district: string, branch_state: string, branch_country: string, nit: string, usuario: string, clave_configured: bool}
     * @since  3.118.6
     */
    protected $certificadorFactActive = [];

    /**
     * Active modo (duplicate of certificadorFactModo while on Certificador page); empty string elsewhere.
     *
     * @var    string
     * @since  3.118.6
     */
    protected $certificadorFactActiveEnv = '';

    /** @var string @since 3.118.6 */
    protected $certificadorFactActiveUrlAutenticacion = '';

    /** @var string @since 3.118.6 */
    protected $certificadorFactActiveUrlInfo = '';

    /** @var string @since 3.118.6 */
    protected $certificadorFactActiveUrlCertCf = '';

    /** @var string @since 3.118.6 */
    protected $certificadorFactActiveUrlCertNit = '';

    /** @var string @since 3.118.6 */
    protected $certificadorFactActiveUrlCertCui = '';

    /** @var string @since 3.118.6 */
    protected $certificadorFactActiveNit = '';

    /** @var string @since 3.118.6 */
    protected $certificadorFactActiveUsuario = '';

    /**
     * Whether clave is stored for the active modo (never expose the value on the view).
     *
     * @var    bool
     * @since  3.118.6
     */
    protected $certificadorFactActiveClaveConfigured = false;

    /**
     * Last FEL bearer token maintenance run (for Ajustes > Certificador).
     *
     * @var    array{at: string, summary: array{test: string, prod: string, errors: array<int, string>, forced: bool}}
     * @since  3.118.10
     */
    protected $certificadorTokenMaintainLastLog = [
        'at'      => '',
        'summary' => ['test' => '', 'prod' => '', 'errors' => [], 'forced' => false],
    ];

    /**
     * Digifact HTTP audit log rows (Ajustes → Cert. Logs).
     *
     * @var    array<int, object>
     * @since  3.118.50
     */
    protected $certificadorDigifactLogRows = [];

    /** @var \Joomla\CMS\Pagination\Pagination|null @since 3.118.50 */
    protected $certificadorDigifactLogPagination = null;

    /** @var bool @since 3.118.50 */
    protected $certificadorDigifactLogTableAvailable = false;

    /** @var int @since 3.118.50 */
    protected $certificadorDigifactLogTotal = 0;

    /**
     * Active Digifact log list filter (NIT/CUI substring), normalized.
     *
     * @var    string
     * @since  3.118.78
     */
    protected $certificadorDigifactLogSearch = '';

    /**
     * Work order numbering settings (next_order_number, order_prefix, order_format) for ajustes > numeracion_ordenes.
     *
     * @var    \stdClass|null
     * @since  3.113.94
     */
    protected $workOrderNumbering = null;

    /**
     * Orden de compra numbering for ajustes > numeracion_ordenes.
     *
     * @var    \stdClass|null
     * @since  3.113.96
     */
    protected $ordenCompraNumbering = null;

    /**
     * Solicitud de cotización a proveedor: templates per channel (Ajustes → Solicitud de cotización).
     *
     * @var    array<string, \stdClass|null>
     * @since  3.113.0
     */
    protected $vendorQuoteTemplates = [];

    /**
     * @var    bool
     * @since  3.113.0
     */
    protected $vendorQuoteTemplatesSchemaOk = false;

    /**
     * Outbound email log rows (tab=email_log).
     *
     * @var    array<int, object>
     * @since  3.113.39
     */
    protected $outboundEmailLogRows = [];

    /**
     * @var    int
     * @since  3.113.39
     */
    protected $outboundEmailLogTotal = 0;

    /**
     * @var    \Joomla\CMS\Pagination\Pagination|null
     * @since  3.113.39
     */
    protected $outboundEmailLogPagination = null;

    /**
     * @var    bool
     * @since  3.113.39
     */
    protected $outboundEmailLogTableAvailable = false;

    /**
     * @var    int
     * @since  3.113.39
     */
    protected $outboundEmailLogLimit = 20;

    /**
     * @var    int
     * @since  3.113.39
     */
    protected $outboundEmailLogLimitStart = 0;

    /**
     * Email log tab (super users only): list is always global; template hides Ventas-only hint when true.
     *
     * @var    bool
     * @since  3.113.39
     */
    protected $outboundEmailLogSeeAllUsers = false;

    /**
     * User session audit rows (tab=user_audit).
     *
     * @var    array<int, object>
     * @since  3.119.111
     */
    protected $userSessionAuditRows = [];

    /**
     * @var    int
     * @since  3.119.111
     */
    protected $userSessionAuditTotal = 0;

    /**
     * @var    \Joomla\CMS\Pagination\Pagination|null
     * @since  3.119.111
     */
    protected $userSessionAuditPagination = null;

    /**
     * @var    bool
     * @since  3.119.111
     */
    protected $userSessionAuditTableAvailable = false;

    /**
     * @var    int
     * @since  3.119.111
     */
    protected $userSessionAuditLimit = 20;

    /**
     * @var    int
     * @since  3.119.111
     */
    protected $userSessionAuditLimitStart = 0;

    /**
     * @var    array<int, string>
     * @since  3.119.111
     */
    protected $userSessionAuditUserFilterOptions = [];

    /**
     * @var    int
     * @since  3.119.111
     */
    protected $userSessionAuditFilterUserId = 0;

    /**
     * @var    string
     * @since  3.119.111
     */
    protected $userSessionAuditFilterIp = '';

    /**
     * @var    string
     * @since  3.119.111
     */
    protected $userSessionAuditFilterDateFrom = '';

    /**
     * @var    string
     * @since  3.119.111
     */
    protected $userSessionAuditFilterDateTo = '';

    /**
     * Users a super user may impersonate (tab=user_audit).
     *
     * @var  array<int, string>
     *
     * @since  3.119.192
     */
    protected $impersonatableUserOptions = [];

    /**
     * Ajustes → Creación OT: lines from Joomla logs (createOrdenFromQuotation failures).
     *
     * @var    array<int, array<string,mixed>>
     * @since  3.115.9
     */
    protected $otWizardLogEntries = [];

    /**
     * Directories scanned for OT wizard log lines (for UI hint).
     *
     * @var    string[]
     * @since  3.115.9
     */
    protected $otWizardLogScannedDirs = [];

    /**
     * Financiero subtab: listado | bonos.
     *
     * @var    string
     * @since  3.115.24
     */
    protected $financieroSubtab = 'listado';

    /**
     * Pre-cotizaciones rows for Financiero tab (paginated).
     *
     * @var    array<int, object>
     * @since  3.115.24
     */
    protected $financieroRows = [];

    /**
     * Total PRE count for Financiero pagination.
     *
     * @var    int
     * @since  3.115.24
     */
    protected $financieroTotal = 0;

    /**
     * @var    \Joomla\CMS\Pagination\Pagination|null
     * @since  3.115.24
     */
    protected $financieroPagination = null;

    /**
     * Footer sums across all pre-cotizaciones.
     *
     * @var    \stdClass|null
     * @since  3.115.24
     */
    protected $financieroAggregates = null;

    /**
     * @var    bool
     * @since  3.115.24
     */
    protected $financieroJoinQuotations = false;

    /**
     * Financiero listado: filter — PRE created date from (YYYY-MM-DD).
     *
     * @var    string
     * @since  3.115.26
     */
    protected $financieroFilterDateFrom = '';

    /**
     * Financiero listado: filter — PRE created date to (YYYY-MM-DD).
     *
     * @var    string
     * @since  3.115.26
     */
    protected $financieroFilterDateTo = '';

    /**
     * Financiero listado: filter — agent label (exact match).
     *
     * @var    string
     * @since  3.115.26
     */
    protected $financieroFilterAgent = '';

    /**
     * Financiero listado: filter facturar — '' | '1' | '0'.
     *
     * @var    string
     * @since  3.115.26
     */
    protected $financieroFilterFacturar = '';

    /**
     * Financiero listado: filter Cotiz. confirmada — '' | '1' | '0'.
     *
     * @var    string
     * @since  3.119.09
     */
    protected $financieroFilterCotizConfirmada = '';

    /**
     * Distinct agent labels for the financiero_filter_agent dropdown (respects date, facturar, Cotiz. confirm.; ignores agent filter).
     *
     * @var    string[]
     * @since  3.115.26
     */
    protected $financieroAgentFilterOptions = [];

    /**
     * Page size applied for financiero listado (persists filter form hidden).
     *
     * @var    int
     * @since  3.115.26
     */
    protected $financieroListLimit = 15;

    /**
     * Active menu Itemid for Financiero (query or active Site menu entry). Used so filter GET survives SEF/component URLs.
     *
     * @var    int
     * @since  3.119.08
     */
    protected $financieroResolvedItemId = 0;

    /**
     * Bonos summary by agent label.
     *
     * @var    array<int|string, mixed>
     * @since  3.115.24
     */
    protected $financieroBonosByAgent = [];

    /**
     * MT-940 imported transactions (Financiero → Cuentas bancarias).
     *
     * @var    array<int, object>
     * @since  3.119.149
     */
    protected $financieroMt940Rows = [];

    /**
     * @var    int
     * @since  3.119.149
     */
    protected $financieroMt940Total = 0;

    /**
     * @var    \Joomla\CMS\Pagination\Pagination|null
     * @since  3.119.149
     */
    protected $financieroMt940Pagination = null;

    /**
     * @var    bool
     * @since  3.119.149
     */
    protected $financieroMt940SchemaOk = false;

    /**
     * @var    int
     * @since  3.119.149
     */
    protected $financieroMt940FilterBankAccountId = 0;

    /**
     * @var    string
     * @since  3.119.149
     */
    protected $financieroMt940FilterDateFrom = '';

    /**
     * @var    string
     * @since  3.119.149
     */
    protected $financieroMt940FilterDateTo = '';

    /**
     * @var    int
     * @since  3.119.154
     */
    protected $financieroMt940FilterMonth = 0;

    /**
     * @var    int
     * @since  3.119.154
     */
    protected $financieroMt940FilterYear = 0;

    /**
     * @var    array<int, string>
     * @since  3.119.149
     */
    protected $financieroMt940BankAccountOptions = [];

    /**
     * @var    int
     * @since  3.119.149
     */
    protected $financieroMt940ListLimit = 25;

    /**
     * @var  array<int, object>
     *
     * @since  3.119.186
     */
    protected $financieroMt940BalanceRows = [];

    /**
     * @var  array<int, object>
     *
     * @since  3.119.151
     */
    protected $financieroMt940ImportRows = [];

    /**
     * @var  int
     *
     * @since  3.119.151
     */
    protected $financieroMt940ImportTotal = 0;

    /**
     * Facturas tab subtab: lista (default) | match (conciliar facturas con órdenes)
     *
     * @var    string
     * @since  3.99.0
     */
    protected $invoicesSubtab = 'lista';

    /**
     * Rows for invoice ↔ orden match UI
     *
     * @var    array
     * @since  3.99.0
     */
    protected $invoiceOrdenMatchRows = [];

    /**
     * Whether #__ordenproduccion_invoice_orden_suggestions exists
     *
     * @var    bool
     * @since  3.99.0
     */
    protected $invoiceOrdenMatchTableAvailable = false;

    /**
     * Filter for match list: '', pending, approved, rejected
     *
     * @var    string
     * @since  3.99.0
     */
    protected $invoiceOrdenMatchStatusFilter = '';

    /**
     * Conciliar subtab: filter by client group key (NIT digits or _unknown_{id}); empty = all
     *
     * @var    string
     * @since  3.100.7
     */
    protected $invoiceOrdenMatchClientFilter = '';

    /**
     * Conciliar subtab: dropdown options for client filter
     *
     * @var    array<int, array{value: string, label: string}>
     * @since  3.100.7
     */
    protected $invoiceOrdenMatchClientOptions = [];

    /**
     * Conciliar subtab: FEL invoices grouped by client (super users only)
     *
     * @var    array
     * @since  3.100.0
     */
    protected $invoiceOrdenMatchGrouped = [];

    /**
     * Whether current user may open Conciliar con órdenes (global Super Users / core.admin)
     *
     * @var    bool
     * @since  3.100.0
     */
    protected $canAccessInvoiceMatchSubtab = false;

    /**
     * Per-invoice dropdown options for manual orden association (invoice id => options)
     *
     * @var    array<int, array<int, array{id: int, label: string}>>
     * @since  3.100.0
     */
    protected $invoiceOrdenMatchDropdownOptions = [];

    /**
     * Total FEL invoices in DB (for conciliation empty state when all are already linked)
     *
     * @var    int
     * @since  3.100.3
     */
    protected $invoiceOrdenMatchFelInvoiceTotal = 0;

    /**
     * FEL cotización queue (pending / scheduled / processing)
     *
     * @var    array
     * @since  3.101.51
     */
    protected $invoiceFelQueueRows = [];

    /**
     * @var    object|null
     * @since  3.101.51
     */
    protected $invoiceFelQueuePagination = null;

    /**
     * @var    bool
     * @since  3.101.51
     */
    protected $invoiceFelQueueAvailable = false;

    /**
     * Cotizaciones pendientes de FEL hasta envío completo en todas las OT (facturación con envío).
     *
     * @var    array<int, object>
     * @since  3.119.13
     */
    protected $invoiceEnvioFelPendingRows = [];

    /**
     * @var    \Joomla\CMS\Pagination\Pagination|null
     * @since  3.119.13
     */
    protected $invoiceEnvioFelPendingPagination = null;

    /**
     * @var    bool
     * @since  3.119.13
     */
    protected $invoiceEnvioFelPendingSectionAvailable = false;

    /**
     * Pending approval rows for current user (tab aprobaciones).
     *
     * @var    array<int, object>
     * @since  3.102.1
     */
    protected $approvalPendingRows = [];

    /**
     * Whether approval workflow tables exist.
     *
     * @var    bool
     * @since  3.102.1
     */
    protected $approvalWorkflowSchemaAvailable = false;

    /**
     * Workflow definitions + steps for Ajustes → Flujos de aprobaciones.
     *
     * @var    array<int, array{workflow: object, steps: object[]}>
     * @since  3.109.58
     */
    protected $approvalWorkflowsAdmin = [];

    /**
     * Flujos list: workflow rows with steps_count.
     *
     * @var    array<int, object>
     * @since  3.109.64
     */
    protected $approvalWorkflowsListSummary = [];

    /**
     * Flujos edit: workflow id from request (0 = list only).
     *
     * @var    int
     * @since  3.109.64
     */
    protected $approvalWorkflowEditId = 0;

    /**
     * Flujos edit: single workflow + steps or null.
     *
     * @var    array{workflow: object, steps: object[]}|null
     * @since  3.109.64
     */
    protected $approvalWorkflowEditBundle = null;

    /**
     * Dropdown: published component approval groups.
     *
     * @var    array<int, object>
     * @since  3.109.64
     */
    protected $approvalComponentGroupsForSelect = [];

    /**
     * Multiselect: active Joomla users (workflow step approvers).
     *
     * @var    array<int, object>
     * @since  3.109.65
     */
    protected $approvalJoomlaUsersForSelect = [];

    /**
     * Whether ordenproduccion_approval_groups tables exist.
     *
     * @var    bool
     * @since  3.109.64
     */
    protected $approvalGroupsSchemaAvailable = false;

    /**
     * Grupos CRUD: -1 list, 0 new, >0 edit.
     *
     * @var    int
     * @since  3.109.64
     */
    protected $approvalGroupEditorId = -1;

    /**
     * Grupos editor row or null.
     *
     * @var    object|null
     * @since  3.109.64
     */
    protected $approvalGroupEditorRow = null;

    /**
     * Grupos editor: member Joomla user ids.
     *
     * @var    array<int, int>
     * @since  3.109.64
     */
    protected $approvalGroupEditorMemberIds = [];

    /**
     * Ajustes → Grupos de aprobaciones: Joomla user groups (id, title, member count).
     *
     * @var    array<int, object>
     * @since  3.109.63
     */
    protected $approvalReferenceJoomlaGroups = [];

    /**
     * Workflow steps with human-readable approver hint (grupos tab).
     *
     * @var    array<int, object>
     * @since  3.109.63
     */
    protected $approvalWorkflowStepsApproverRows = [];

    /**
     * Get the layout data for the view (ensures 'invoices' key exists for AbstractView/layouts).
     *
     * @return  array
     * @since   3.97.0
     */
    protected function getLayoutData()
    {
        $data = parent::getLayoutData();
        // Guarantee keys exist so AbstractView line 197 never sees undefined "invoices"
        $data = array_merge(
            ['invoices' => [], 'invoicesPagination' => null],
            $data,
            [
                'invoices' => is_array($this->invoices) ? $this->invoices : [],
                'invoicesPagination' => $this->invoicesPagination ?? null,
                'invoicesSubtab' => $this->invoicesSubtab ?? 'lista',
                'invoiceOrdenMatchRows' => is_array($this->invoiceOrdenMatchRows ?? null) ? $this->invoiceOrdenMatchRows : [],
                'invoiceOrdenMatchTableAvailable' => (bool) ($this->invoiceOrdenMatchTableAvailable ?? false),
                'invoiceOrdenMatchStatusFilter' => (string) ($this->invoiceOrdenMatchStatusFilter ?? ''),
                'invoiceOrdenMatchClientFilter' => (string) ($this->invoiceOrdenMatchClientFilter ?? ''),
                'invoiceOrdenMatchClientOptions' => is_array($this->invoiceOrdenMatchClientOptions ?? null) ? $this->invoiceOrdenMatchClientOptions : [],
                'invoiceOrdenMatchGrouped' => is_array($this->invoiceOrdenMatchGrouped ?? null) ? $this->invoiceOrdenMatchGrouped : [],
                'canAccessInvoiceMatchSubtab' => (bool) ($this->canAccessInvoiceMatchSubtab ?? false),
                'invoiceOrdenMatchDropdownOptions' => is_array($this->invoiceOrdenMatchDropdownOptions ?? null) ? $this->invoiceOrdenMatchDropdownOptions : [],
                'invoiceOrdenMatchFelInvoiceTotal' => (int) ($this->invoiceOrdenMatchFelInvoiceTotal ?? 0),
                'invoiceFelQueueRows' => is_array($this->invoiceFelQueueRows ?? null) ? $this->invoiceFelQueueRows : [],
                'invoiceFelQueuePagination' => $this->invoiceFelQueuePagination ?? null,
                'invoiceFelQueueAvailable' => (bool) ($this->invoiceFelQueueAvailable ?? false),
                'invoiceEnvioFelPendingRows' => is_array($this->invoiceEnvioFelPendingRows ?? null) ? $this->invoiceEnvioFelPendingRows : [],
                'invoiceEnvioFelPendingPagination' => $this->invoiceEnvioFelPendingPagination ?? null,
                'invoiceEnvioFelPendingSectionAvailable' => (bool) ($this->invoiceEnvioFelPendingSectionAvailable ?? false),
                'approvalPendingRows' => is_array($this->approvalPendingRows ?? null) ? $this->approvalPendingRows : [],
                'approvalWorkflowSchemaAvailable' => (bool) ($this->approvalWorkflowSchemaAvailable ?? false),
                'approvalWorkflowsAdmin' => is_array($this->approvalWorkflowsAdmin ?? null) ? $this->approvalWorkflowsAdmin : [],
                'approvalWorkflowsListSummary' => is_array($this->approvalWorkflowsListSummary ?? null) ? $this->approvalWorkflowsListSummary : [],
                'approvalWorkflowEditId' => (int) ($this->approvalWorkflowEditId ?? 0),
                'approvalWorkflowEditBundle' => $this->approvalWorkflowEditBundle ?? null,
                'approvalComponentGroupsForSelect' => is_array($this->approvalComponentGroupsForSelect ?? null) ? $this->approvalComponentGroupsForSelect : [],
                'approvalJoomlaUsersForSelect' => is_array($this->approvalJoomlaUsersForSelect ?? null) ? $this->approvalJoomlaUsersForSelect : [],
                'approvalGroupsSchemaAvailable' => (bool) ($this->approvalGroupsSchemaAvailable ?? false),
                'approvalGroupEditorId' => (int) ($this->approvalGroupEditorId ?? -1),
                'approvalGroupEditorRow' => $this->approvalGroupEditorRow ?? null,
                'approvalGroupEditorMemberIds' => is_array($this->approvalGroupEditorMemberIds ?? null) ? $this->approvalGroupEditorMemberIds : [],
                'approvalReferenceJoomlaGroups' => is_array($this->approvalReferenceJoomlaGroups ?? null) ? $this->approvalReferenceJoomlaGroups : [],
                'approvalWorkflowStepsApproverRows' => is_array($this->approvalWorkflowStepsApproverRows ?? null) ? $this->approvalWorkflowStepsApproverRows : [],
            ]
        );
        return $data;
    }

    /**
     * Get a property value (avoids "Undefined array key" in AbstractView when layouts request 'invoices').
     *
     * @param   string  $property  Property name (e.g. 'invoices', 'invoicesPagination')
     * @param   mixed   $default   Default value if not set
     * @return  mixed
     * @since   3.97.0
     */
    public function get($property, $default = null)
    {
        if ($property === 'invoices') {
            return isset($this->invoices) && is_array($this->invoices) ? $this->invoices : [];
        }
        if ($property === 'invoicesPagination') {
            return $this->invoicesPagination ?? null;
        }
        if ($property === 'invoicesSubtab') {
            return $this->invoicesSubtab ?? 'lista';
        }
        if ($property === 'invoiceOrdenMatchRows') {
            return is_array($this->invoiceOrdenMatchRows ?? null) ? $this->invoiceOrdenMatchRows : [];
        }
        if ($property === 'invoiceOrdenMatchTableAvailable') {
            return (bool) ($this->invoiceOrdenMatchTableAvailable ?? false);
        }
        if ($property === 'invoiceOrdenMatchStatusFilter') {
            return (string) ($this->invoiceOrdenMatchStatusFilter ?? '');
        }
        if ($property === 'invoiceOrdenMatchClientFilter') {
            return (string) ($this->invoiceOrdenMatchClientFilter ?? '');
        }
        if ($property === 'invoiceOrdenMatchClientOptions') {
            return is_array($this->invoiceOrdenMatchClientOptions ?? null) ? $this->invoiceOrdenMatchClientOptions : [];
        }
        if ($property === 'invoiceOrdenMatchGrouped') {
            return is_array($this->invoiceOrdenMatchGrouped ?? null) ? $this->invoiceOrdenMatchGrouped : [];
        }
        if ($property === 'canAccessInvoiceMatchSubtab') {
            return (bool) ($this->canAccessInvoiceMatchSubtab ?? false);
        }
        if ($property === 'invoiceOrdenMatchDropdownOptions') {
            return is_array($this->invoiceOrdenMatchDropdownOptions ?? null) ? $this->invoiceOrdenMatchDropdownOptions : [];
        }
        if ($property === 'invoiceOrdenMatchFelInvoiceTotal') {
            return (int) ($this->invoiceOrdenMatchFelInvoiceTotal ?? 0);
        }
        if ($property === 'invoiceFelQueueRows') {
            return is_array($this->invoiceFelQueueRows ?? null) ? $this->invoiceFelQueueRows : [];
        }
        if ($property === 'invoiceFelQueuePagination') {
            return $this->invoiceFelQueuePagination ?? null;
        }
        if ($property === 'invoiceFelQueueAvailable') {
            return (bool) ($this->invoiceFelQueueAvailable ?? false);
        }
        if ($property === 'invoiceEnvioFelPendingRows') {
            return is_array($this->invoiceEnvioFelPendingRows ?? null) ? $this->invoiceEnvioFelPendingRows : [];
        }
        if ($property === 'invoiceEnvioFelPendingPagination') {
            return $this->invoiceEnvioFelPendingPagination ?? null;
        }
        if ($property === 'invoiceEnvioFelPendingSectionAvailable') {
            return (bool) ($this->invoiceEnvioFelPendingSectionAvailable ?? false);
        }
        if ($property === 'approvalPendingRows') {
            return is_array($this->approvalPendingRows ?? null) ? $this->approvalPendingRows : [];
        }
        if ($property === 'approvalWorkflowSchemaAvailable') {
            return (bool) ($this->approvalWorkflowSchemaAvailable ?? false);
        }
        if ($property === 'approvalWorkflowsAdmin') {
            return is_array($this->approvalWorkflowsAdmin ?? null) ? $this->approvalWorkflowsAdmin : [];
        }
        if ($property === 'approvalWorkflowsListSummary') {
            return is_array($this->approvalWorkflowsListSummary ?? null) ? $this->approvalWorkflowsListSummary : [];
        }
        if ($property === 'approvalWorkflowEditId') {
            return (int) ($this->approvalWorkflowEditId ?? 0);
        }
        if ($property === 'approvalWorkflowEditBundle') {
            return $this->approvalWorkflowEditBundle ?? null;
        }
        if ($property === 'approvalComponentGroupsForSelect') {
            return is_array($this->approvalComponentGroupsForSelect ?? null) ? $this->approvalComponentGroupsForSelect : [];
        }
        if ($property === 'approvalJoomlaUsersForSelect') {
            return is_array($this->approvalJoomlaUsersForSelect ?? null) ? $this->approvalJoomlaUsersForSelect : [];
        }
        if ($property === 'approvalGroupsSchemaAvailable') {
            return (bool) ($this->approvalGroupsSchemaAvailable ?? false);
        }
        if ($property === 'approvalGroupEditorId') {
            return (int) ($this->approvalGroupEditorId ?? -1);
        }
        if ($property === 'approvalGroupEditorRow') {
            return $this->approvalGroupEditorRow ?? null;
        }
        if ($property === 'approvalGroupEditorMemberIds') {
            return is_array($this->approvalGroupEditorMemberIds ?? null) ? $this->approvalGroupEditorMemberIds : [];
        }
        if ($property === 'approvalReferenceJoomlaGroups') {
            return is_array($this->approvalReferenceJoomlaGroups ?? null) ? $this->approvalReferenceJoomlaGroups : [];
        }
        if ($property === 'approvalWorkflowStepsApproverRows') {
            return is_array($this->approvalWorkflowStepsApproverRows ?? null) ? $this->approvalWorkflowStepsApproverRows : [];
        }
        return parent::get($property, $default);
    }

    /**
     * Display the view
     *
     * @param   string  $tpl  The name of the template file to parse
     *
     * @return  void
     *
     * @since   3.1.0
     */
    public function display($tpl = null)
    {
        $app = Factory::getApplication();
        $input = $app->input;

        // Legacy URLs: tab=proveedores or administración layout proveedores → standalone view=com_ordenproduccion&view=proveedores
        if ($this->getLayout() === 'proveedores' || $input->get('tab', '', 'string') === 'proveedores') {
            $parts = [
                'option' => 'com_ordenproduccion',
                'view'   => 'proveedores',
            ];
            $pid = $input->getInt('proveedor_id', -1);

            if ($pid >= 0) {
                $parts['proveedor_id'] = $pid;
            }

            $search = $input->getString('proveedores_search', '');

            if ($search !== '') {
                $parts['proveedores_search'] = $search;
            }

            $st = $input->getString('proveedores_state', '');

            if ($st !== '') {
                $parts['proveedores_state'] = $st;
            }

            $app->redirect(Route::_('index.php?' . http_build_query($parts), false));

            return;
        }

        // Load component language files - standard Joomla way
        $lang = $app->getLanguage();
        // Load site language (usually in components/com_ordenproduccion/language)
        $lang->load('com_ordenproduccion', JPATH_SITE);
        // Also try loading from component directory directly
        $lang->load('com_ordenproduccion', JPATH_SITE . '/components/com_ordenproduccion');
        // Load admin language
        $lang->load('com_ordenproduccion', JPATH_ADMINISTRATOR . '/components/com_ordenproduccion');

        // Get filter parameters
        $this->currentMonth = $input->getInt('month', 0); // 0 = All Year, 1-12 = specific month
        $this->currentYear = $input->getInt('year', date('Y'));

        // Get active tab - default to resumen for better UX. workorders tab removed → redirect to resumen
        $activeTab = $input->get('tab', 'resumen', 'string');
        if ($activeTab === 'workorders') {
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=resumen', false));
            return;
        }

        // Ventas: only Ventas tabs (resumen, statistics, reportes, clientes). Admin-only tabs: invoices, herramientas, ajustes
        if (!AccessHelper::isInAdministracionOrAdmonGroup() && in_array($activeTab, ['invoices', 'herramientas', 'ajustes'], true)) {
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=resumen', false));
            return;
        }

        if ($activeTab === 'aprobaciones' && !AccessHelper::canViewApprovalWorkflowTab()) {
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=resumen', false));
            return;
        }

        if ($activeTab === 'email_log' && !AccessHelper::isSuperUser()) {
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=resumen', false));
            return;
        }

        if ($activeTab === 'user_audit' && !AccessHelper::isSuperUser()) {
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=resumen', false));
            return;
        }

        if ($activeTab === 'financiero' && !AccessHelper::isSuperUser()) {
            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=resumen', false));
            return;
        }

        // Sales agent filter: only Administracion/Admon see all; everyone else sees only their own records
        $salesAgentFilter = AccessHelper::getSalesAgentFilterForAdministracionView();
        // Ventas: statistics tab only from Jan 1, 2026 (year dropdown minimum; clamp so UI matches data)
        $this->statisticsMinYear = $salesAgentFilter !== null ? 2026 : 2020;
        if ($salesAgentFilter !== null && $this->currentYear < 2026) {
            $this->currentYear = 2026;
            $this->currentMonth = 0; // All year
        }

        // Get active subtab: for herramientas default banks, for ajustes default ajustes_cotizacion
        $activeSubTab = $input->get('subtab', ($activeTab === 'ajustes' ? 'ajustes_cotizacion' : 'banks'), 'string');
        if ($activeTab === 'ajustes' && $activeSubTab === 'cotizaciones') {
            $activeSubTab = 'ajustes_cotizacion';
        }
        if ($activeTab === 'herramientas' && !in_array($activeSubTab, ['banks', 'paymenttypes', 'bankaccounts'], true)) {
            $activeSubTab = 'banks';
        }
        $this->activeSubTab = $activeSubTab;

        // Get statistics model and data (filtered by sales agent when Ventas)
        $statsModel = $this->getModel('Administracion');
        $this->stats = $statsModel->getStatistics($this->currentMonth, $this->currentYear, $salesAgentFilter);

        // Load activity statistics if resumen tab is active
        if ($activeTab === 'resumen') {
            try {
                // Get selected period from request, default to 'week'
                $selectedPeriod = $input->get('period', 'week', 'string'); // week, month, year
                $this->activityStats = $statsModel->getActivityStatistics($selectedPeriod, $salesAgentFilter);
                // Get activity statistics grouped by sales agent (filtered to one agent when Ventas)
                $this->activityStatsByAgent = $statsModel->getActivityStatisticsByAgent($selectedPeriod, $salesAgentFilter);
                // Get status changes grouped by sales agent
                $this->statusChangesByAgent = $statsModel->getStatusChangesByAgent($selectedPeriod, $salesAgentFilter);
                // Get payment proofs grouped by sales agent
                $this->paymentProofsByAgent = $statsModel->getPaymentProofsByAgent($selectedPeriod, $salesAgentFilter);
                // Get shipping slips grouped by sales agent
                $this->shippingSlipsByAgent = $statsModel->getShippingSlipsByAgent($selectedPeriod, $salesAgentFilter);
                // Store selected period for template
                $this->selectedPeriod = $selectedPeriod;
            } catch (\Exception $e) {
                $app->enqueueMessage('Error loading activity statistics: ' . $e->getMessage(), 'error');
                $this->activityStats = (object) [
                    'weekly' => [],
                    'monthly' => [],
                    'yearly' => []
                ];
                $this->activityStatsByAgent = [];
                $this->statusChangesByAgent = null;
                $this->paymentProofsByAgent = [];
                $this->shippingSlipsByAgent = [];
                $this->selectedPeriod = 'week';
            }
        }

        // Initialize data arrays - ensure all properties are set before parent::display()
        $this->invoices = [];
        $this->invoicesPagination = null;
        $this->state = new \Joomla\Registry\Registry();
        $this->banks = [];
        $this->bankAccounts = [];
        $this->reportWorkOrders = [];
        $this->reportClients = [];
        $this->clients = [];
        $this->canMergeClients = false;
        $this->reportDateFrom = '';
        $this->reportDateTo = '';
        $this->reportClient = '';
        $this->reportNit = '';
        $this->reportSalesAgent = '';
        $this->reportPaymentStatus = '';
        $this->reportHideZeroDiferencia = false;
        $this->reportSalesAgents = [];
        $this->reportSubTab = 'ordenes';
        $this->envios = [];
        $this->enviosPagination = null;
        $this->enviosFilterClient = '';
        $this->enviosFilterTipo = '';
        $this->enviosFilterDateFrom = '';
        $this->enviosFilterDateTo = '';
        $this->invoicesSubtab = 'lista';
        $this->invoiceOrdenMatchRows = [];
        $this->invoiceOrdenMatchTableAvailable = false;
        $this->invoiceOrdenMatchStatusFilter = '';
        $this->invoiceOrdenMatchClientFilter = '';
        $this->invoiceOrdenMatchClientOptions = [];
        $this->invoiceOrdenMatchGrouped = [];
        $this->canAccessInvoiceMatchSubtab = false;
        $this->invoiceOrdenMatchDropdownOptions = [];
        $this->invoiceOrdenMatchFelInvoiceTotal = 0;
        $this->invoiceFelQueueRows = [];
        $this->invoiceFelQueuePagination = null;
        $this->invoiceFelQueueAvailable = false;
        $this->invoiceEnvioFelPendingRows = [];
        $this->invoiceEnvioFelPendingPagination = null;
        $this->invoiceEnvioFelPendingSectionAvailable = false;
        $this->approvalPendingRows = [];
        $this->approvalWorkflowSchemaAvailable = false;
        $this->approvalWorkflowsAdmin = [];
        $this->approvalWorkflowsListSummary = [];
        $this->approvalWorkflowEditId = 0;
        $this->approvalWorkflowEditBundle = null;
        $this->approvalComponentGroupsForSelect = [];
        $this->approvalJoomlaUsersForSelect = [];
        $this->approvalGroupsSchemaAvailable = false;
        $this->approvalGroupEditorId = -1;
        $this->approvalGroupEditorRow = null;
        $this->approvalGroupEditorMemberIds = [];
        $this->approvalReferenceJoomlaGroups       = [];
        $this->approvalWorkflowStepsApproverRows = [];
        $this->outboundEmailLogRows              = [];
        $this->outboundEmailLogTotal             = 0;
        $this->outboundEmailLogPagination        = null;
        $this->outboundEmailLogTableAvailable    = false;
        $this->outboundEmailLogLimit             = 20;
        $this->outboundEmailLogLimitStart        = 0;
        $this->outboundEmailLogSeeAllUsers       = false;
        $this->otWizardLogEntries                = [];
        $this->otWizardLogScannedDirs            = [];
        $this->certificadorDigifactLogRows       = [];
        $this->certificadorDigifactLogPagination = null;
        $this->certificadorDigifactLogTableAvailable = false;
        $this->certificadorDigifactLogTotal      = 0;
        $this->certificadorDigifactLogSearch     = '';
        $this->financieroSubtab                   = 'listado';
        $this->financieroRows                     = [];
        $this->financieroTotal                    = 0;
        $this->financieroPagination               = null;
        $this->financieroAggregates               = null;
        $this->financieroJoinQuotations           = false;
        $this->financieroFilterDateFrom            = '';
        $this->financieroFilterDateTo               = '';
        $this->financieroFilterAgent                = '';
        $this->financieroFilterFacturar             = '';
        $this->financieroFilterCotizConfirmada      = '';
        $this->financieroAgentFilterOptions         = [];
        $this->financieroListLimit                  = 15;
        $this->financieroResolvedItemId            = 0;
        $this->financieroBonosByAgent               = [];
        $this->financieroMt940Rows                  = [];
        $this->financieroMt940Total                 = 0;
        $this->financieroMt940Pagination            = null;
        $this->financieroMt940SchemaOk              = false;
        $this->financieroMt940FilterBankAccountId   = 0;
        $this->financieroMt940FilterDateFrom        = '';
        $this->financieroMt940FilterDateTo          = '';
        $this->financieroMt940FilterMonth           = 0;
        $this->financieroMt940FilterYear            = 0;
        $this->financieroMt940BankAccountOptions    = [];
        $this->financieroMt940ListLimit             = 25;
        $this->financieroMt940ImportRows            = [];
        $this->financieroMt940ImportTotal           = 0;
        $this->financieroMt940BalanceRows           = [];
        $this->ajustesMt940SchemaOk                 = false;
        $this->ajustesMt940BankAccountOptions       = [];
        $this->mt940CronCrontabLine                 = '';
        $this->mt940CronKeyConfigured               = false;
        $this->mt940RunLogRows                      = [];
        $this->mt940RunLogTotal                     = 0;
        $this->mt940RunLogPagination                = null;
        $this->mt940RunLogTableOk                  = false;
        $this->mt940RunLogListLimit                 = 25;

        // Ensure banks is always an array
        if (!isset($this->banks) || !is_array($this->banks)) {
            $this->banks = [];
        }
        if (!isset($this->bankAccounts) || !is_array($this->bankAccounts)) {
            $this->bankAccounts = [];
        }

        // Load invoices data if invoices tab is active (lista) or match data for conciliar subtab
        if ($activeTab === 'invoices') {
            $this->invoicesSubtab = $input->getString('invoices_subtab', 'lista');
            if (!in_array($this->invoicesSubtab, ['lista', 'match', 'cola'], true)) {
                $this->invoicesSubtab = 'lista';
            }
            $this->invoiceOrdenMatchStatusFilter = $input->getString('match_status', '');
            if (!in_array($this->invoiceOrdenMatchStatusFilter, ['', 'pending', 'approved', 'rejected'], true)) {
                $this->invoiceOrdenMatchStatusFilter = '';
            }

            $rawClientKey = trim($input->getString('match_client', ''));
            $this->invoiceOrdenMatchClientFilter = '';
            if ($rawClientKey !== '' && InvoiceOrdenMatchModel::isValidMatchClientGroupKey($rawClientKey)) {
                $this->invoiceOrdenMatchClientFilter = $rawClientKey;
            }

            $this->canAccessInvoiceMatchSubtab = AccessHelper::isSuperUser();

            if ($this->invoicesSubtab === 'match') {
                if (!$this->canAccessInvoiceMatchSubtab) {
                    $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_ORDEN_MATCH_SUPERUSER_ONLY'), 'warning');
                    $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=invoices&invoices_subtab=lista', false));
                    return;
                }
                $this->invoices = [];
                $this->invoicesPagination = null;
                $this->state = new \Joomla\Registry\Registry();
                try {
                    $matchModel = $this->getModel('InvoiceOrdenMatch');
                    if (!$matchModel && class_exists(\Grimpsa\Component\Ordenproduccion\Site\Model\InvoiceOrdenMatchModel::class)) {
                        $matchModel = Factory::getApplication()->bootComponent('com_ordenproduccion')
                            ->getMVCFactory()->createModel('InvoiceOrdenMatch', 'Site', ['ignore_request' => false]);
                    }
                    if ($matchModel) {
                        $this->invoiceOrdenMatchTableAvailable = $matchModel->isTableAvailable();
                        $this->invoiceOrdenMatchFelInvoiceTotal = $matchModel->countFelImportInvoices();
                        $this->invoiceOrdenMatchRows = $matchModel->getSuggestionRows($this->invoiceOrdenMatchStatusFilter);
                        $this->invoiceOrdenMatchClientOptions = $matchModel->getConciliationClientFilterOptions();
                        $this->invoiceOrdenMatchGrouped = $matchModel->getConciliationGroupedByClient(
                            $this->invoiceOrdenMatchStatusFilter,
                            $this->invoiceOrdenMatchClientFilter
                        );
                        $invIds = [];
                        foreach ($this->invoiceOrdenMatchGrouped as $grp) {
                            foreach (($grp['invoices'] ?? []) as $block) {
                                $inv = $block['invoice'] ?? null;
                                if ($inv && isset($inv->id)) {
                                    $invIds[] = (int) $inv->id;
                                }
                            }
                        }
                        $invIds = array_values(array_unique(array_filter($invIds)));
                        $this->invoiceOrdenMatchDropdownOptions = $matchModel->getOrdnesDropdownBatchForInvoices($invIds);
                    }
                } catch (\Throwable $e) {
                    $this->invoiceOrdenMatchRows = [];
                    $this->invoiceOrdenMatchGrouped = [];
                    $this->invoiceOrdenMatchFelInvoiceTotal = 0;
                    $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_ORDEN_MATCH_LOAD_ERROR') . ': ' . $e->getMessage(), 'warning');
                }
            } elseif ($this->invoicesSubtab === 'cola') {
                $this->invoices = [];
                $this->invoicesPagination = null;
                $this->state = new \Joomla\Registry\Registry();

                $dbCola = Factory::getContainer()->get(DatabaseInterface::class);
                $this->invoiceEnvioFelPendingRows                = [];
                $this->invoiceEnvioFelPendingPagination          = null;
                $this->invoiceEnvioFelPendingSectionAvailable    = QuotationEnvioFelPendingHelper::schemaSupportsPendingList($dbCola);

                if ($this->invoiceEnvioFelPendingSectionAvailable) {
                    try {
                        $epLimit = max(5, min(100, (int) $input->getInt('enviofel_limit', 25)));
                        $epStart = max(0, (int) $input->getInt('enviofel_limitstart', 0));
                        $ep      = QuotationEnvioFelPendingHelper::getPagedRows($epStart, $epLimit);
                        $this->invoiceEnvioFelPendingRows = $ep['items'];
                        $totalEp                          = (int) $ep['total'];
                        $this->invoiceEnvioFelPendingPagination = new \Joomla\CMS\Pagination\Pagination($totalEp, $epStart, $epLimit, 'enviofel_');
                        $this->invoiceEnvioFelPendingPagination->setAdditionalUrlParam('option', 'com_ordenproduccion');
                        $this->invoiceEnvioFelPendingPagination->setAdditionalUrlParam('view', 'administracion');
                        $this->invoiceEnvioFelPendingPagination->setAdditionalUrlParam('tab', 'invoices');
                        $this->invoiceEnvioFelPendingPagination->setAdditionalUrlParam('invoices_subtab', 'cola');
                        $this->invoiceEnvioFelPendingPagination->setAdditionalUrlParam('enviofel_limit', $epLimit);
                        $invLs = (int) $input->getInt('limitstart', 0);
                        $invLm = (int) $input->getInt('limit', 0);
                        if ($invLs > 0) {
                            $this->invoiceEnvioFelPendingPagination->setAdditionalUrlParam('limitstart', $invLs);
                        }
                        if ($invLm > 0) {
                            $this->invoiceEnvioFelPendingPagination->setAdditionalUrlParam('limit', $invLm);
                        }
                    } catch (\Throwable $e) {
                        $this->invoiceEnvioFelPendingRows = [];
                        $this->invoiceEnvioFelPendingPagination = null;
                        $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_ENVIO_PENDING_LOAD_ERROR') . ': ' . $e->getMessage(), 'warning');
                    }
                }

                $felSvc = new FelInvoiceIssuanceService();
                if ($felSvc->isEngineAvailable() && $felSvc->hasQuotationIdColumn() && $felSvc->hasFelScheduledAtColumn()) {
                    $felSvc->processDueScheduledInvoices(30);
                    $this->invoiceFelQueueAvailable = true;
                    try {
                        $qModel = $this->getModel('InvoiceFelQueue');
                        if (!$qModel && class_exists(\Grimpsa\Component\Ordenproduccion\Site\Model\InvoiceFelQueueModel::class)) {
                            $qModel = Factory::getApplication()->bootComponent('com_ordenproduccion')
                                ->getMVCFactory()->createModel('InvoiceFelQueue', 'Site', ['ignore_request' => false]);
                        }
                        if ($qModel) {
                            $this->invoiceFelQueueRows = $qModel->getItems();
                            $this->invoiceFelQueuePagination = $qModel->getPagination();
                            $this->state = $qModel->getState();
                            if ($this->invoiceFelQueuePagination) {
                                $st = $this->state;
                                $this->invoiceFelQueuePagination->setAdditionalUrlParam('option', 'com_ordenproduccion');
                                $this->invoiceFelQueuePagination->setAdditionalUrlParam('view', 'administracion');
                                $this->invoiceFelQueuePagination->setAdditionalUrlParam('tab', 'invoices');
                                $this->invoiceFelQueuePagination->setAdditionalUrlParam('invoices_subtab', 'cola');
                                $this->invoiceFelQueuePagination->setAdditionalUrlParam('limit', (int) $st->get('list.limit', 50) ?: 50);
                                $efLs = (int) $input->getInt('enviofel_limitstart', 0);
                                $efLm = (int) $input->getInt('enviofel_limit', 0);
                                if ($efLs > 0) {
                                    $this->invoiceFelQueuePagination->setAdditionalUrlParam('enviofel_limitstart', $efLs);
                                }
                                if ($efLm > 0) {
                                    $this->invoiceFelQueuePagination->setAdditionalUrlParam('enviofel_limit', $efLm);
                                }
                            }
                        }
                    } catch (\Throwable $e) {
                        $this->invoiceFelQueueRows = [];
                        $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_FEL_QUEUE_LOAD_ERROR') . ': ' . $e->getMessage(), 'warning');
                    }
                } else {
                    $this->invoiceFelQueueAvailable = false;
                    $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICE_FEL_QUEUE_MIGRATION_REQUIRED'), 'notice');
                }
            } else {
                try {
                    $invoicesModel = $this->getModel('Invoices');
                    if (!$invoicesModel && class_exists(\Grimpsa\Component\Ordenproduccion\Site\Model\InvoicesModel::class)) {
                        $invoicesModel = Factory::getApplication()->bootComponent('com_ordenproduccion')
                            ->getMVCFactory()->createModel('Invoices', 'Site', ['ignore_request' => false]);
                    }
                    if ($invoicesModel) {
                        if ($salesAgentFilter !== null) {
                            $invoicesModel->setState('filter.sales_agent', $salesAgentFilter);
                        }
                        $this->invoices = $invoicesModel->getItems();
                        $this->invoicesPagination = $invoicesModel->getPagination();
                        $this->state = $invoicesModel->getState();
                        // Preserve option, view, tab, limit and filter params in pagination links (default 20 per page)
                        if ($this->invoicesPagination) {
                            $st = $this->state;
                            $this->invoicesPagination->setAdditionalUrlParam('option', 'com_ordenproduccion');
                            $this->invoicesPagination->setAdditionalUrlParam('view', 'administracion');
                            $this->invoicesPagination->setAdditionalUrlParam('tab', 'invoices');
                            $this->invoicesPagination->setAdditionalUrlParam('invoices_subtab', 'lista');
                            $this->invoicesPagination->setAdditionalUrlParam('limit', (int) $st->get('list.limit', 20) ?: 20);
                            $this->invoicesPagination->setAdditionalUrlParam('filter_nit', $st->get('filter.nit', ''));
                            $this->invoicesPagination->setAdditionalUrlParam('filter_cliente', $st->get('filter.cliente', ''));
                            $this->invoicesPagination->setAdditionalUrlParam('filter_fecha_from', $st->get('filter.fecha_from', ''));
                            $this->invoicesPagination->setAdditionalUrlParam('filter_fecha_to', $st->get('filter.fecha_to', ''));
                            $this->invoicesPagination->setAdditionalUrlParam('filter_total_min', $st->get('filter.total_min', ''));
                            $this->invoicesPagination->setAdditionalUrlParam('filter_total_max', $st->get('filter.total_max', ''));
                            $this->invoicesPagination->setAdditionalUrlParam('filter_tipo', $st->get('filter.tipo', ''));
                        }
                    } else {
                        $this->invoices = [];
                    }
                } catch (\Throwable $e) {
                    $this->invoices = [];
                    $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_INVOICES_LOAD_ERROR') . ': ' . $e->getMessage(), 'warning');
                }
            }
        }

        // Load clientes tab data: all clients with sum of valor a facturar (filtered by sales agent when Ventas)
        if ($activeTab === 'clientes') {
            $clientesSubtab = $input->getString('subtab', 'estado_cuenta');
            if (!in_array($clientesSubtab, ['estado_cuenta', 'dias_credito'], true)) {
                $clientesSubtab = 'estado_cuenta';
            }
            $this->clientesSubtab = $clientesSubtab;
            try {
                $statsModel = $this->getModel('Administracion');
                $clientesOrdering = $input->getString('filter_clientes_ordering', 'name');
                if (!in_array($clientesOrdering, ['name', 'compras', 'saldo'], true)) {
                    $clientesOrdering = 'name';
                }
                $clientesDirection = $input->getString('filter_clientes_direction', 'asc');
                if (!in_array($clientesDirection, ['asc', 'desc'], true)) {
                    $clientesDirection = 'asc';
                }
                $clientesHideZero = (bool) $input->getInt('filter_clientes_hide_zero', 0);
                $this->clientesSalesAgent = $salesAgentFilter !== null ? $salesAgentFilter : $input->getString('filter_clientes_sales_agent', '');
                $this->clientesClientName = $input->getString('filter_clientes_client', '');
                $this->clientesNit = $input->getString('filter_clientes_nit', '');
                $this->clientesLimit = max(5, min(100, (int) $input->getInt('clientes_limit', 20)));
                $this->clientesLimitStart = max(0, (int) $input->getInt('clientes_limitstart', 0));
                $this->clientesSalesAgents = $statsModel->getReportSalesAgents($salesAgentFilter);
                if ($clientesSubtab === 'dias_credito') {
                    $agentFilter = $this->clientesSalesAgent !== '' ? $this->clientesSalesAgent : null;
                    $clientFilter = $this->clientesClientName;
                    $this->clientesDiasCreditoBuckets = $statsModel->getOrdersWithoutPaymentProofByAgeBuckets($agentFilter, $clientFilter);
                    $this->clientesDiasCreditoByAgent = $statsModel->getOrdersWithoutPaymentProofSummaryByAgent($agentFilter, $clientFilter);
                    $this->clientesDiasCreditoByClient = $statsModel->getOrdersWithoutPaymentProofSummaryByClient($agentFilter, $clientFilter);
                    $diasCreditoOrdering = $input->getString('filter_dias_credito_ordering', 'client');
                    if (!in_array($diasCreditoOrdering, ['client', '0_15', '16_30', '31_45', '45_plus', 'total'], true)) {
                        $diasCreditoOrdering = 'client';
                    }
                    $diasCreditoDirection = $input->getString('filter_dias_credito_direction', 'asc');
                    if (!in_array($diasCreditoDirection, ['asc', 'desc'], true)) {
                        $diasCreditoDirection = 'asc';
                    }
                    $this->clientesDiasCreditoOrdering = $diasCreditoOrdering;
                    $this->clientesDiasCreditoDirection = $diasCreditoDirection;
                    $rawClients = $this->clientesDiasCreditoByClient;
                    $grouped = [];
                    foreach ($rawClients as $row) {
                        $key = isset($row->sales_agent) ? (string) $row->sales_agent : (string) $this->clientesSalesAgent;
                        if (!isset($grouped[$key])) {
                            $grouped[$key] = [];
                        }
                        $grouped[$key][] = $row;
                    }
                    foreach ($grouped as $k => $list) {
                        $grouped[$k] = $statsModel->sortDiasCreditoRows($list, $diasCreditoOrdering, $diasCreditoDirection, false);
                    }
                    $this->clientesDiasCreditoGroupedByAgent = $grouped;
                    $this->clientesDiasCreditoByAgent = $statsModel->sortDiasCreditoRows(
                        $this->clientesDiasCreditoByAgent,
                        $diasCreditoOrdering,
                        $diasCreditoDirection,
                        true
                    );
                    $this->clientesDiasCreditoByClient = $statsModel->sortDiasCreditoRows(
                        $rawClients,
                        $diasCreditoOrdering,
                        $diasCreditoDirection,
                        false
                    );
                } else {
                    $this->clientesDiasCreditoBuckets = ['0_15' => ['count' => 0, 'total_value' => 0.0], '16_30' => ['count' => 0, 'total_value' => 0.0], '31_45' => ['count' => 0, 'total_value' => 0.0], '45_plus' => ['count' => 0, 'total_value' => 0.0]];
                    $this->clientesDiasCreditoByAgent = [];
                    $this->clientesDiasCreditoByClient = [];
                    $this->clientesDiasCreditoGroupedByAgent = [];
                }
                if ($clientesSubtab === 'estado_cuenta') {
                    $fullList = $statsModel->getClientsWithTotals(
                        $clientesOrdering,
                        $clientesDirection,
                        $clientesHideZero,
                        $this->clientesSalesAgent !== '' ? $this->clientesSalesAgent : null,
                        $this->clientesClientName,
                        $this->clientesNit,
                        0,
                        0
                    );
                    $this->clientesTotal = count($fullList);
                    $this->clientesTotalSaldo = 0.0;
                    $this->clientesTotalCompras = 0.0;
                    $this->clientesTotalOrders = 0;
                    foreach ($fullList as $c) {
                        $this->clientesTotalSaldo += (float) ($c->saldo ?? 0);
                        $this->clientesTotalCompras += (float) ($c->compras ?? 0);
                        $this->clientesTotalOrders += (int) ($c->order_count ?? 0);
                    }
                    $this->clients = array_slice($fullList, $this->clientesLimitStart, $this->clientesLimit);
                    $this->clientesPagination = new \Joomla\CMS\Pagination\Pagination(
                        $this->clientesTotal,
                        $this->clientesLimitStart,
                        $this->clientesLimit,
                        'clientes_'
                    );
                    $this->clientesPagination->setAdditionalUrlParam('option', 'com_ordenproduccion');
                    $this->clientesPagination->setAdditionalUrlParam('view', 'administracion');
                    $this->clientesPagination->setAdditionalUrlParam('tab', 'clientes');
                    $this->clientesPagination->setAdditionalUrlParam('subtab', 'estado_cuenta');
                    $this->clientesPagination->setAdditionalUrlParam('filter_clientes_ordering', $clientesOrdering);
                    $this->clientesPagination->setAdditionalUrlParam('filter_clientes_direction', $clientesDirection);
                    $this->clientesPagination->setAdditionalUrlParam('clientes_limit', (string) $this->clientesLimit);
                    if ($clientesHideZero) {
                        $this->clientesPagination->setAdditionalUrlParam('filter_clientes_hide_zero', '1');
                    }
                    $this->clientesPagination->setAdditionalUrlParam('filter_clientes_sales_agent', $this->clientesSalesAgent);
                    $this->clientesPagination->setAdditionalUrlParam('filter_clientes_client', $this->clientesClientName);
                    $this->clientesPagination->setAdditionalUrlParam('filter_clientes_nit', $this->clientesNit);
                } else {
                    $this->clients = [];
                    $this->clientesTotal = 0;
                    $this->clientesTotalSaldo = 0.0;
                    $this->clientesTotalCompras = 0.0;
                    $this->clientesTotalOrders = 0;
                    $this->clientesPagination = null;
                }
                $this->clientesOrdering = $clientesOrdering;
                $this->clientesDirection = $clientesDirection;
                $this->clientesHideZero = $clientesHideZero;
                $this->clientesShowSalesAgentFilter = ($salesAgentFilter === null);
                $user = Factory::getUser();
                $this->canMergeClients = $user && $user->authorise('core.admin');
                $this->canInitializeOpeningBalances = $user && $user->authorise('core.admin');
            } catch (\Exception $e) {
                $app->enqueueMessage('Error loading clients: ' . $e->getMessage(), 'error');
                $this->clients = [];
                $this->canMergeClients = false;
                $this->canInitializeOpeningBalances = false;
            }
        }

        // Load reportes tab data: work orders by date/client/NIT/sales agent (Ventas: only own data)
        if ($activeTab === 'reportes') {
            // Envios subtab is visible to everyone who can access Reportes (Administracion sees all envios, Ventas see only their own)
            $this->canSeeEnviosSubtab = true;
            $this->reportSubTab = $input->get('subtab', 'ordenes', 'string');
            if ($this->reportSubTab !== 'ordenes' && $this->reportSubTab !== 'envios') {
                $this->reportSubTab = 'ordenes';
            }
            // Envios subtab: Administrator groups see all envios; Ventas see only their own orders' envios
            if ($this->reportSubTab === 'envios') {
                try {
                    $statsModel = $this->getModel('Administracion');
                    $enviosLimit = max(10, min(100, (int) $input->getInt('envios_limit', 25)));
                    $enviosStart = max(0, (int) $input->getInt('envios_limitstart', 0));
                    $this->enviosFilterClient = $input->getString('filter_envios_client', '');
                    $this->enviosFilterTipo = $input->getString('filter_envios_tipo', '');
                    $this->enviosFilterDateFrom = $input->getString('filter_envios_date_from', '');
                    $this->enviosFilterDateTo = $input->getString('filter_envios_date_to', '');
                    $user = Factory::getUser();
                    $enviosSalesFilter = (AccessHelper::isInAdministracionOrAdmonGroup() || $user->authorise('core.admin')) ? null : $salesAgentFilter;
                    $this->enviosTotal = $statsModel->getEnviosTotal($enviosSalesFilter, $this->enviosFilterClient, $this->enviosFilterTipo, $this->enviosFilterDateFrom, $this->enviosFilterDateTo);
                    $this->envios = $statsModel->getEnviosList($enviosLimit, $enviosStart, $enviosSalesFilter, $this->enviosFilterClient, $this->enviosFilterTipo, $this->enviosFilterDateFrom, $this->enviosFilterDateTo);
                    $this->enviosPagination = new \Joomla\CMS\Pagination\Pagination(
                        $this->enviosTotal,
                        $enviosStart,
                        $enviosLimit,
                        'envios_'
                    );
                    $this->enviosPagination->setAdditionalUrlParam('option', 'com_ordenproduccion');
                    $this->enviosPagination->setAdditionalUrlParam('view', 'administracion');
                    $this->enviosPagination->setAdditionalUrlParam('tab', 'reportes');
                    $this->enviosPagination->setAdditionalUrlParam('subtab', 'envios');
                    $this->enviosPagination->setAdditionalUrlParam('filter_envios_client', $this->enviosFilterClient);
                    $this->enviosPagination->setAdditionalUrlParam('filter_envios_tipo', $this->enviosFilterTipo);
                    $this->enviosPagination->setAdditionalUrlParam('filter_envios_date_from', $this->enviosFilterDateFrom);
                    $this->enviosPagination->setAdditionalUrlParam('filter_envios_date_to', $this->enviosFilterDateTo);
                } catch (\Exception $e) {
                    $app->enqueueMessage('Error loading envios: ' . $e->getMessage(), 'error');
                    $this->envios = [];
                    $this->enviosTotal = 0;
                    $this->enviosPagination = null;
                }
            }
            if ($this->reportSubTab === 'ordenes') {
            try {
                $statsModel = $this->getModel('Administracion');
                $this->reportSalesAgents = $statsModel->getReportSalesAgents($salesAgentFilter);
                $this->reportDateFrom = $input->getString('filter_report_date_from', '');
                $this->reportDateTo = $input->getString('filter_report_date_to', '');
                $this->reportClient = $input->getString('filter_report_client', '');
                $this->reportNit = $input->getString('filter_report_nit', '');
                // Ventas: force filter to own agent; Administracion: use request filter
                $this->reportSalesAgent = $salesAgentFilter !== null ? $salesAgentFilter : $input->getString('filter_report_sales_agent', '');
                $this->reportPaymentStatus = $input->getString('filter_report_payment_status', '');
                $this->reportHideZeroDiferencia = $input->getInt('filter_report_hide_zero_diferencia', 0) === 1;
                $this->reportLimit = max(5, min(100, (int) $input->getInt('report_limit', 20)));
                $this->reportLimitStart = max(0, (int) $input->getInt('report_limitstart', 0));
                $this->reportTotal = $statsModel->getReportWorkOrdersTotal(
                    $this->reportDateFrom,
                    $this->reportDateTo,
                    $this->reportClient,
                    $this->reportNit,
                    $this->reportSalesAgent,
                    $this->reportPaymentStatus,
                    $this->reportHideZeroDiferencia
                );
                $this->reportTotalValue = $statsModel->getReportWorkOrdersTotalValue(
                    $this->reportDateFrom,
                    $this->reportDateTo,
                    $this->reportClient,
                    $this->reportNit,
                    $this->reportSalesAgent,
                    $this->reportPaymentStatus,
                    $this->reportHideZeroDiferencia
                );
                $this->reportWorkOrders = $statsModel->getReportWorkOrders(
                    $this->reportDateFrom,
                    $this->reportDateTo,
                    $this->reportClient,
                    $this->reportNit,
                    $this->reportSalesAgent,
                    $this->reportLimit,
                    $this->reportLimitStart,
                    $this->reportPaymentStatus,
                    $this->reportHideZeroDiferencia
                );
                $this->reportPagination = new \Joomla\CMS\Pagination\Pagination(
                    $this->reportTotal,
                    $this->reportLimitStart,
                    $this->reportLimit,
                    'report_'
                );
                $this->reportPagination->setAdditionalUrlParam('option', 'com_ordenproduccion');
                $this->reportPagination->setAdditionalUrlParam('view', 'administracion');
                $this->reportPagination->setAdditionalUrlParam('tab', 'reportes');
                $this->reportPagination->setAdditionalUrlParam('filter_report_date_from', $this->reportDateFrom);
                $this->reportPagination->setAdditionalUrlParam('filter_report_date_to', $this->reportDateTo);
                $this->reportPagination->setAdditionalUrlParam('filter_report_client', $this->reportClient);
                $this->reportPagination->setAdditionalUrlParam('filter_report_nit', $this->reportNit);
                $this->reportPagination->setAdditionalUrlParam('filter_report_sales_agent', $this->reportSalesAgent);
                $this->reportPagination->setAdditionalUrlParam('filter_report_payment_status', $this->reportPaymentStatus);
                if ($this->reportHideZeroDiferencia) {
                    $this->reportPagination->setAdditionalUrlParam('filter_report_hide_zero_diferencia', '1');
                }
            } catch (\Exception $e) {
                $app->enqueueMessage('Error loading report: ' . $e->getMessage(), 'error');
                $this->reportWorkOrders = [];
            }
            }
        }

        if ($activeTab === 'email_log') {
            $this->outboundEmailLogTableAvailable = OutboundEmailLogHelper::isTableAvailable();
            $this->outboundEmailLogSeeAllUsers    = true;
            $filterUid                            = null;
            $this->outboundEmailLogLimit          = max(5, min(100, (int) $input->getInt('email_log_limit', 20)));
            $this->outboundEmailLogLimitStart     = max(0, (int) $input->getInt('email_log_limitstart', 0));
            $pack                                 = OutboundEmailLogHelper::getListForAdministracion(
                $this->outboundEmailLogLimitStart,
                $this->outboundEmailLogLimit,
                $filterUid
            );
            $this->outboundEmailLogRows  = $pack['rows'];
            $this->outboundEmailLogTotal = $pack['total'];
            if ($this->outboundEmailLogTableAvailable && $this->outboundEmailLogTotal > 0) {
                $this->outboundEmailLogPagination = new \Joomla\CMS\Pagination\Pagination(
                    $this->outboundEmailLogTotal,
                    $this->outboundEmailLogLimitStart,
                    $this->outboundEmailLogLimit,
                    'email_log_'
                );
                $this->outboundEmailLogPagination->setAdditionalUrlParam('option', 'com_ordenproduccion');
                $this->outboundEmailLogPagination->setAdditionalUrlParam('view', 'administracion');
                $this->outboundEmailLogPagination->setAdditionalUrlParam('tab', 'email_log');
                $this->outboundEmailLogPagination->setAdditionalUrlParam('email_log_limit', (string) $this->outboundEmailLogLimit);
            }
        }

        if ($activeTab === 'user_audit') {
            $this->userSessionAuditTableAvailable = UserSessionAuditHelper::isTableAvailable();
            $this->userSessionAuditFilterUserId   = max(0, (int) $input->getInt('user_audit_user_id', 0));
            $this->userSessionAuditFilterIp       = trim($input->getString('user_audit_ip', ''));
            $this->userSessionAuditFilterDateFrom = trim($input->getString('user_audit_date_from', ''));
            $this->userSessionAuditFilterDateTo   = trim($input->getString('user_audit_date_to', ''));
            $this->userSessionAuditLimit          = max(5, min(100, (int) $input->getInt('user_audit_limit', 20)));
            $this->userSessionAuditLimitStart     = max(0, (int) $input->getInt('user_audit_limitstart', 0));
            $this->userSessionAuditUserFilterOptions = UserSessionAuditHelper::getUserFilterOptions();
            $this->impersonatableUserOptions = UserImpersonationHelper::getImpersonatableUserOptions();

            $pack = UserSessionAuditHelper::getListForAdministracion(
                $this->userSessionAuditLimitStart,
                $this->userSessionAuditLimit,
                [
                    'user_id'   => $this->userSessionAuditFilterUserId,
                    'ip'        => $this->userSessionAuditFilterIp,
                    'date_from' => $this->userSessionAuditFilterDateFrom,
                    'date_to'   => $this->userSessionAuditFilterDateTo,
                ]
            );
            $this->userSessionAuditRows  = $pack['rows'];
            $this->userSessionAuditTotal = $pack['total'];

            if ($this->userSessionAuditTableAvailable && $this->userSessionAuditTotal > 0) {
                $this->userSessionAuditPagination = new \Joomla\CMS\Pagination\Pagination(
                    $this->userSessionAuditTotal,
                    $this->userSessionAuditLimitStart,
                    $this->userSessionAuditLimit,
                    'user_audit_'
                );
                $this->userSessionAuditPagination->setAdditionalUrlParam('option', 'com_ordenproduccion');
                $this->userSessionAuditPagination->setAdditionalUrlParam('view', 'administracion');
                $this->userSessionAuditPagination->setAdditionalUrlParam('tab', 'user_audit');
                $this->userSessionAuditPagination->setAdditionalUrlParam('user_audit_limit', (string) $this->userSessionAuditLimit);
                if ($this->userSessionAuditFilterUserId > 0) {
                    $this->userSessionAuditPagination->setAdditionalUrlParam(
                        'user_audit_user_id',
                        (string) $this->userSessionAuditFilterUserId
                    );
                }
                if ($this->userSessionAuditFilterIp !== '') {
                    $this->userSessionAuditPagination->setAdditionalUrlParam(
                        'user_audit_ip',
                        $this->userSessionAuditFilterIp
                    );
                }
                if ($this->userSessionAuditFilterDateFrom !== '') {
                    $this->userSessionAuditPagination->setAdditionalUrlParam(
                        'user_audit_date_from',
                        $this->userSessionAuditFilterDateFrom
                    );
                }
                if ($this->userSessionAuditFilterDateTo !== '') {
                    $this->userSessionAuditPagination->setAdditionalUrlParam(
                        'user_audit_date_to',
                        $this->userSessionAuditFilterDateTo
                    );
                }
            }
        }

        if ($activeTab === 'financiero') {
            $itemIdResolved = max(0, (int) $input->getInt('Itemid', 0));

            if ($itemIdResolved <= 0) {
                $menuCurrent = Factory::getApplication()->getMenu()->getActive();

                if ($menuCurrent !== null && (int) $menuCurrent->id > 0) {
                    $itemIdResolved = (int) $menuCurrent->id;
                }
            }

            $this->financieroResolvedItemId = $itemIdResolved;

            $fst = $input->getString('financiero_subtab', 'listado');

            if ($fst === 'listado_pre') {
                $fst = 'listado';
            }

            if ($fst === 'cuentas_bancarias_importar') {
                $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=ajustes&subtab=mt940_importar', false));
            }

            if (!in_array($fst, ['listado', 'bonos', 'cuentas_bancarias'], true)) {
                $fst = 'listado';
            }
            $this->financieroSubtab = $fst;
            try {
                $admFin = $this->getModel('Administracion');
                if (!$admFin && class_exists(AdministracionModel::class)) {
                    $admFin = Factory::getApplication()->bootComponent('com_ordenproduccion')
                        ->getMVCFactory()->createModel('Administracion', 'Site', ['ignore_request' => true]);
                }
                if ($admFin) {
                    if ($fst === 'listado') {
                        $ff = AdministracionModel::financieroFiltersFromInput($input);
                        $this->financieroFilterDateFrom   = $ff['date_from'];
                        $this->financieroFilterDateTo     = $ff['date_to'];
                        $this->financieroFilterAgent      = $ff['agent'];
                        $this->financieroFilterFacturar   = $ff['facturar'];
                        $this->financieroFilterCotizConfirmada = $ff['cotiz_confirmada'];
                        $this->financieroAgentFilterOptions = $admFin->getFinancieroAgentDistinctLabels($ff);

                        $limit      = max(5, min(200, (int) $input->getInt('financiero_limit', 15)));
                        $limitStart = max(0, (int) $input->getInt('financiero_limitstart', 0));
                        $this->financieroListLimit = $limit;
                        $pack       = $admFin->getFinancieroPrecotizacionesData($limit, $limitStart, $ff);
                        $this->financieroRows             = $pack['rows'] ?? [];
                        $this->financieroTotal             = (int) ($pack['total'] ?? 0);
                        $this->financieroAggregates        = $pack['aggregates'] ?? null;
                        $this->financieroJoinQuotations    = (bool) ($pack['joinQuotations'] ?? false);
                        if ($this->financieroTotal > 0) {
                            $this->financieroPagination = new \Joomla\CMS\Pagination\Pagination(
                                $this->financieroTotal,
                                $limitStart,
                                $limit,
                                'financiero_'
                            );
                            $this->financieroPagination->setAdditionalUrlParam('option', 'com_ordenproduccion');
                            $this->financieroPagination->setAdditionalUrlParam('view', 'administracion');
                            $this->financieroPagination->setAdditionalUrlParam('tab', 'financiero');
                            $this->financieroPagination->setAdditionalUrlParam('financiero_subtab', 'listado');
                            $this->financieroPagination->setAdditionalUrlParam('financiero_limit', (string) $limit);
                            $this->financieroPagination->setAdditionalUrlParam('financiero_filter_date_from', $this->financieroFilterDateFrom);
                            $this->financieroPagination->setAdditionalUrlParam('financiero_filter_date_to', $this->financieroFilterDateTo);
                            $this->financieroPagination->setAdditionalUrlParam('financiero_filter_agent', $this->financieroFilterAgent);
                            $this->financieroPagination->setAdditionalUrlParam('financiero_filter_facturar', $this->financieroFilterFacturar);
                            $this->financieroPagination->setAdditionalUrlParam('financiero_filter_cotiz_confirmada', $this->financieroFilterCotizConfirmada);

                            if ($this->financieroResolvedItemId > 0) {
                                $this->financieroPagination->setAdditionalUrlParam('Itemid', (string) $this->financieroResolvedItemId);
                            }
                        }
                    }
                    if ($fst === 'bonos') {
                        $this->financieroBonosByAgent = $admFin->getFinancieroBonosByAgentSummary();
                    }
                    if ($fst === 'cuentas_bancarias') {
                        $this->financieroMt940SchemaOk           = $admFin->isMt940TransactionsTableAvailable();
                        $this->financieroMt940BankAccountOptions = $admFin->getMt940ConfiguredBankAccountOptions();
                        $this->financieroMt940FilterBankAccountId = max(0, (int) $input->getInt('mt940_bank_account_id', 0));

                        $now       = Factory::getDate();
                        $curMonth  = (int) $now->format('n');
                        $curYear   = (int) $now->format('Y');
                        $hasPeriod = $input->get('mt940_filter_month', null) !== null
                            || $input->get('mt940_filter_year', null) !== null;
                        $filterMonth = $hasPeriod
                            ? max(1, min(12, (int) $input->getInt('mt940_filter_month', $curMonth)))
                            : $curMonth;
                        $filterYear  = $hasPeriod
                            ? max(2000, min(2100, (int) $input->getInt('mt940_filter_year', $curYear)))
                            : $curYear;

                        $this->financieroMt940FilterMonth = $filterMonth;
                        $this->financieroMt940FilterYear  = $filterYear;
                        $periodFrom                       = \sprintf('%04d-%02d-01', $filterYear, $filterMonth);
                        $this->financieroMt940FilterDateFrom = $periodFrom;
                        $this->financieroMt940FilterDateTo   = \date('Y-m-t', \strtotime($periodFrom));

                        if ($fst === 'cuentas_bancarias' && $this->financieroMt940SchemaOk) {
                            $limit      = max(10, min(200, (int) $input->getInt('mt940_limit', 25)));
                            $limitStart = max(0, (int) $input->getInt('mt940_limitstart', 0));
                            $this->financieroMt940ListLimit = $limit;

                            $dateFilters = [
                                'bank_account_id' => $this->financieroMt940FilterBankAccountId,
                                'date_from'       => $this->financieroMt940FilterDateFrom,
                                'date_to'         => $this->financieroMt940FilterDateTo,
                            ];

                            $pack = $admFin->getMt940TransactionsList($limit, $limitStart, $dateFilters);
                            $this->financieroMt940Rows  = $pack['rows'] ?? [];
                            $this->financieroMt940Total = (int) ($pack['total'] ?? 0);

                            $this->financieroMt940BalanceRows = $admFin->getMt940LatestBalancesByAccount([
                                'bank_account_id' => $this->financieroMt940FilterBankAccountId,
                            ]);

                            if ($this->financieroMt940Total > 0) {
                                $this->financieroMt940Pagination = new \Joomla\CMS\Pagination\Pagination(
                                    $this->financieroMt940Total,
                                    $limitStart,
                                    $limit,
                                    'mt940_'
                                );
                                $this->financieroMt940Pagination->setAdditionalUrlParam('option', 'com_ordenproduccion');
                                $this->financieroMt940Pagination->setAdditionalUrlParam('view', 'administracion');
                                $this->financieroMt940Pagination->setAdditionalUrlParam('tab', 'financiero');
                                $this->financieroMt940Pagination->setAdditionalUrlParam('financiero_subtab', 'cuentas_bancarias');
                                $this->financieroMt940Pagination->setAdditionalUrlParam('mt940_limit', (string) $limit);
                                $this->financieroMt940Pagination->setAdditionalUrlParam('mt940_bank_account_id', (string) $this->financieroMt940FilterBankAccountId);
                                $this->financieroMt940Pagination->setAdditionalUrlParam('mt940_filter_month', (string) $this->financieroMt940FilterMonth);
                                $this->financieroMt940Pagination->setAdditionalUrlParam('mt940_filter_year', (string) $this->financieroMt940FilterYear);
                                if ($this->financieroResolvedItemId > 0) {
                                    $this->financieroMt940Pagination->setAdditionalUrlParam('Itemid', (string) $this->financieroResolvedItemId);
                                }
                            }
                        }
                    }
                }
            } catch (\Throwable $e) {
                $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_FINANCIERO_LOAD_ERROR') . ': ' . $e->getMessage(), 'warning');
                $this->financieroRows = [];
            }
        }

        // Load banks data if herramientas tab is active and banks subtab is selected
        if ($activeTab === 'herramientas' && $activeSubTab === 'banks') {
            try {
                // Get Bank model using MVC factory
                $component = $app->bootComponent('com_ordenproduccion');
                $mvcFactory = $component->getMVCFactory();
                $bankModel = $mvcFactory->createModel('Bank', 'Site', ['ignore_request' => true]);
                
                if ($bankModel && method_exists($bankModel, 'getBanks')) {
                    $this->banks = $bankModel->getBanks();
                } else {
                    $this->banks = [];
                }
            } catch (\Exception $e) {
                $app->enqueueMessage('Error loading banks: ' . $e->getMessage(), 'warning');
                $this->banks = [];
            }
        } else {
            // Initialize banks as empty array if not banks subtab
            $this->banks = [];
        }

        // Load payment types if herramientas tab is active and paymenttypes subtab is selected
        if ($activeTab === 'herramientas' && $activeSubTab === 'paymenttypes') {
            try {
                $component = $app->bootComponent('com_ordenproduccion');
                $mvcFactory = $component->getMVCFactory();
                $paymenttypeModel = $mvcFactory->createModel('Paymenttype', 'Site', ['ignore_request' => true]);

                if ($paymenttypeModel && method_exists($paymenttypeModel, 'getPaymentTypes')) {
                    $this->paymentTypes = $paymenttypeModel->getPaymentTypes();
                } else {
                    $this->paymentTypes = [];
                }
            } catch (\Exception $e) {
                $app->enqueueMessage('Error loading payment types: ' . $e->getMessage(), 'warning');
                $this->paymentTypes = [];
            }
        } else {
            $this->paymentTypes = [];
        }

        if ($activeTab === 'herramientas' && $activeSubTab === 'bankaccounts') {
            try {
                $component = $app->bootComponent('com_ordenproduccion');
                $mvcFactory = $component->getMVCFactory();
                $bankAccountModel = $mvcFactory->createModel('Bankaccount', 'Site', ['ignore_request' => true]);

                if ($bankAccountModel && method_exists($bankAccountModel, 'getBankAccounts')) {
                    $this->bankAccounts = $bankAccountModel->getBankAccounts();
                } else {
                    $this->bankAccounts = [];
                }
            } catch (\Exception $e) {
                $app->enqueueMessage('Error loading bank accounts: ' . $e->getMessage(), 'warning');
                $this->bankAccounts = [];
            }
        } elseif ($activeTab === 'ajustes' && \in_array($activeSubTab, ['mt940', 'mt940_importar'], true)) {
            try {
                $component = $app->bootComponent('com_ordenproduccion');
                $mvcFactory = $component->getMVCFactory();
                $bankAccountModel = $mvcFactory->createModel('Bankaccount', 'Site', ['ignore_request' => true]);

                if ($bankAccountModel && method_exists($bankAccountModel, 'getBankAccounts')) {
                    $this->bankAccounts = $bankAccountModel->getBankAccounts();
                } else {
                    $this->bankAccounts = [];
                }
            } catch (\Exception $e) {
                $this->bankAccounts = [];
            }
        } else {
            $this->bankAccounts = [];
        }

        if ($activeTab === 'aprobaciones') {
            try {
                $approvalService = new ApprovalWorkflowService();
                $this->approvalWorkflowSchemaAvailable = $approvalService->hasSchema();
                if ($this->approvalWorkflowSchemaAvailable) {
                    $user = Factory::getUser();
                    $actorId = (int) $user->id;
                    if ($actorId > 0) {
                        $swept = ApprovalWorkflowEntityHelper::sweepOpenFacturacionManualApprovalsWhenFullyInvoiced(
                            Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class),
                            $actorId
                        );
                        if ($swept > 0) {
                            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_FACTURACION_MANUAL_APPROVAL_AUTO_COMPLETED'), 'success');
                        }
                    }
                    $this->approvalPendingRows = AccessHelper::getPendingApprovalRowsMerged($approvalService, (int) $user->id);
                    $preCotIds = [];
                    $ocIds     = [];
                    $manualFactQuotationIds = [];
                    foreach ($this->approvalPendingRows as $prow) {
                        $et = ApprovalWorkflowService::normalizeEntityType((string) ($prow->entity_type ?? ''));
                        if (
                            $et === ApprovalWorkflowService::ENTITY_SOLICITUD_DESCUENTO
                            || $et === ApprovalWorkflowService::ENTITY_SOLICITUD_COTIZACION
                            || $et === ApprovalWorkflowService::ENTITY_CREACION_ORDEN_TRABAJO
                        ) {
                            $eid = (int) ($prow->entity_id ?? 0);
                            if ($eid > 0) {
                                $preCotIds[$eid] = true;
                            }
                        } elseif ($et === ApprovalWorkflowService::ENTITY_COTIZACION_FACTURACION_MANUAL) {
                            $qmf = (int) ($prow->entity_id ?? 0);
                            if ($qmf > 0) {
                                $manualFactQuotationIds[$qmf] = true;
                            }
                        } elseif ($et === ApprovalWorkflowService::ENTITY_ORDEN_COMPRA) {
                            $oid = (int) ($prow->entity_id ?? 0);
                            if ($oid > 0) {
                                $ocIds[$oid] = true;
                            }
                        } elseif ($et === ApprovalWorkflowService::ENTITY_SERVICIOS_ELEMENTOS_EXTERNOS) {
                            $mr0 = isset($prow->metadata) ? trim((string) $prow->metadata) : '';
                            if ($mr0 !== '') {
                                $dm0 = json_decode($mr0, true);
                                if (is_array($dm0) && isset($dm0['pre_cotizacion_id'])) {
                                    $ppk = (int) $dm0['pre_cotizacion_id'];
                                    if ($ppk > 0) {
                                        $preCotIds[$ppk] = true;
                                    }
                                }
                            }
                        }
                    }
                    if ($preCotIds !== []) {
                        try {
                            $db  = Factory::getContainer()->get(DatabaseInterface::class);
                            $ids = array_keys($preCotIds);
                            $ids = array_values(array_filter(array_map('intval', $ids), static function ($v) {
                                return $v > 0;
                            }));
                            if ($ids !== []) {
                                $q = $db->getQuery(true)
                                    ->select($db->quoteName('id') . ', ' . $db->quoteName('number'))
                                    ->from($db->quoteName('#__ordenproduccion_pre_cotizacion'))
                                    ->where($db->quoteName('id') . ' IN (' . implode(',', $ids) . ')');
                                $db->setQuery($q);
                                $numRows = $db->loadObjectList() ?: [];
                                $byId = [];
                                foreach ($numRows as $nr) {
                                    $pid = (int) $nr->id;
                                    $raw = trim((string) ($nr->number ?? ''));
                                    $byId[$pid] = $raw !== '' ? $raw : ('PRE-' . str_pad((string) $pid, 5, '0', STR_PAD_LEFT));
                                }
                                foreach ($this->approvalPendingRows as $prow) {
                                    $et = ApprovalWorkflowService::normalizeEntityType((string) ($prow->entity_type ?? ''));
                                    if (
                                        $et === ApprovalWorkflowService::ENTITY_SOLICITUD_DESCUENTO
                                        || $et === ApprovalWorkflowService::ENTITY_SOLICITUD_COTIZACION
                                        || $et === ApprovalWorkflowService::ENTITY_CREACION_ORDEN_TRABAJO
                                    ) {
                                        $eid = (int) ($prow->entity_id ?? 0);
                                        $prow->precotizacion_number = $eid > 0
                                            ? ($byId[$eid] ?? ('PRE-' . str_pad((string) $eid, 5, '0', STR_PAD_LEFT)))
                                            : '';
                                    } elseif ($et === ApprovalWorkflowService::ENTITY_SERVICIOS_ELEMENTOS_EXTERNOS) {
                                        $prePk = 0;
                                        $mr    = isset($prow->metadata) ? trim((string) $prow->metadata) : '';
                                        if ($mr !== '') {
                                            $dm = json_decode($mr, true);
                                            if (is_array($dm) && isset($dm['pre_cotizacion_id'])) {
                                                $prePk = (int) $dm['pre_cotizacion_id'];
                                            }
                                        }
                                        $prow->precotizacion_number = $prePk > 0
                                            ? ($byId[$prePk] ?? ('PRE-' . str_pad((string) $prePk, 5, '0', STR_PAD_LEFT)))
                                            : '';
                                    }
                                }

                                $precotOdooClient = [];

                                try {
                                    $qc = $db->getTableColumns('#__ordenproduccion_quotations', false);

                                    $hasClientIdCol = false;

                                    foreach (array_keys($qc ?: []) as $cn) {
                                        if (strcasecmp((string) $cn, 'client_id') === 0) {
                                            $hasClientIdCol = true;
                                            break;
                                        }
                                    }

                                    $ic             = $db->getTableColumns('#__ordenproduccion_quotation_items', false);
                                    $hasPreCotFkCol = false;

                                    foreach (array_keys($ic ?: []) as $cn) {
                                        if (strcasecmp((string) $cn, 'pre_cotizacion_id') === 0) {
                                            $hasPreCotFkCol = true;
                                            break;
                                        }
                                    }

                                    if ($hasClientIdCol && $hasPreCotFkCol && $ids !== []) {
                                        $qb = $db->getQuery(true)
                                            ->select([
                                                $db->quoteName('qi.pre_cotizacion_id'),
                                                'MAX(' . $db->quoteName('q.client_id') . ') AS client_id_raw',
                                            ])
                                            ->from($db->quoteName('#__ordenproduccion_quotation_items', 'qi'))
                                            ->innerJoin(
                                                $db->quoteName('#__ordenproduccion_quotations', 'q')
                                                . ' ON ' . $db->quoteName('q.id')
                                                . ' = ' . $db->quoteName('qi.quotation_id')
                                            )
                                            ->where($db->quoteName('qi.pre_cotizacion_id') . ' IN (' . implode(',', $ids) . ')')
                                            ->where($db->quoteName('q.client_id') . ' IS NOT NULL')
                                            ->group($db->quoteName('qi.pre_cotizacion_id'));

                                        $db->setQuery($qb);

                                        foreach ($db->loadObjectList() ?: [] as $crow) {
                                            $ppid = (int) ($crow->pre_cotizacion_id ?? 0);
                                            $cid  = (int) ($crow->client_id_raw ?? 0);

                                            if ($ppid > 0 && $cid > 0) {
                                                $precotOdooClient[$ppid] = $cid;
                                            }
                                        }
                                    }
                                } catch (\Throwable $ignored) {
                                }

                                foreach ($this->approvalPendingRows as $prow) {
                                    $prePkResolve = 0;
                                    $etResolve    = ApprovalWorkflowService::normalizeEntityType((string) ($prow->entity_type ?? ''));

                                    if (
                                        $etResolve === ApprovalWorkflowService::ENTITY_SOLICITUD_DESCUENTO
                                        || $etResolve === ApprovalWorkflowService::ENTITY_SOLICITUD_COTIZACION
                                        || $etResolve === ApprovalWorkflowService::ENTITY_CREACION_ORDEN_TRABAJO
                                    ) {
                                        $prePkResolve = (int) ($prow->entity_id ?? 0);
                                    } elseif ($etResolve === ApprovalWorkflowService::ENTITY_SERVICIOS_ELEMENTOS_EXTERNOS) {
                                        $mr0 = isset($prow->metadata) ? trim((string) $prow->metadata) : '';

                                        if ($mr0 !== '') {
                                            $dm0 = json_decode($mr0, true);

                                            if (is_array($dm0) && isset($dm0['pre_cotizacion_id'])) {
                                                $prePkResolve = (int) $dm0['pre_cotizacion_id'];
                                            }
                                        }
                                    }

                                    $prow->odoo_partner_id = ($prePkResolve > 0 && isset($precotOdooClient[$prePkResolve]))
                                        ? (int) $precotOdooClient[$prePkResolve]
                                        : 0;
                                }
                            }
                        } catch (\Throwable $e) {
                            // leave rows without precotizacion_number
                        }
                    }
                    if ($ocIds !== []) {
                        try {
                            $db  = Factory::getContainer()->get(DatabaseInterface::class);
                            $ids = array_keys($ocIds);
                            $ids = array_values(array_filter(array_map('intval', $ids), static function ($v) {
                                return $v > 0;
                            }));
                            if ($ids !== []) {
                                $q = $db->getQuery(true)
                                    ->select($db->quoteName('id') . ', ' . $db->quoteName('number'))
                                    ->from($db->quoteName('#__ordenproduccion_orden_compra'))
                                    ->where($db->quoteName('id') . ' IN (' . implode(',', $ids) . ')');
                                $db->setQuery($q);
                                $ocRows = $db->loadObjectList() ?: [];
                                $byOcId = [];
                                foreach ($ocRows as $or) {
                                    $oid = (int) $or->id;
                                    $raw = trim((string) ($or->number ?? ''));
                                    $byOcId[$oid] = $raw !== '' ? $raw : ('ORC-' . str_pad((string) $oid, 5, '0', STR_PAD_LEFT));
                                }
                                foreach ($this->approvalPendingRows as $prow) {
                                    $et = ApprovalWorkflowService::normalizeEntityType((string) ($prow->entity_type ?? ''));
                                    if ($et === ApprovalWorkflowService::ENTITY_ORDEN_COMPRA) {
                                        $oid = (int) ($prow->entity_id ?? 0);
                                        $prow->orden_compra_number = $oid > 0
                                            ? ($byOcId[$oid] ?? ('ORC-' . str_pad((string) $oid, 5, '0', STR_PAD_LEFT)))
                                            : '';
                                    }
                                }
                            }
                        } catch (\Throwable $e) {
                        }
                    }
                    if ($manualFactQuotationIds !== []) {
                        try {
                            $dbQuote   = Factory::getContainer()->get(DatabaseInterface::class);
                            $qIds      = array_values(array_filter(array_map('intval', array_keys($manualFactQuotationIds)), static function ($v) {
                                return $v > 0;
                            }));
                            $qcols     = $dbQuote->getTableColumns('#__ordenproduccion_quotations', false);
                            $hasQnum   = false;
                            foreach (array_keys(is_array($qcols) ? $qcols : []) as $cn) {
                                if (strcasecmp((string) $cn, 'quotation_number') === 0) {
                                    $hasQnum = true;
                                    break;
                                }
                            }
                            $qSel = [$dbQuote->quoteName('id')];
                            if ($hasQnum) {
                                $qSel[] = $dbQuote->quoteName('quotation_number');
                            }
                            $qList = implode(',', $qIds);
                            $qb    = $dbQuote->getQuery(true)
                                ->select($qSel)
                                ->from($dbQuote->quoteName('#__ordenproduccion_quotations'))
                                ->where($dbQuote->quoteName('id') . ' IN (' . $qList . ')');
                            $dbQuote->setQuery($qb);
                            $qnByPk = [];
                            foreach ($dbQuote->loadObjectList() ?: [] as $qrow) {
                                $qk = (int) ($qrow->id ?? 0);
                                if ($qk < 1) {
                                    continue;
                                }
                                $rawqn = '';
                                if ($hasQnum && isset($qrow->quotation_number)) {
                                    $rawqn = trim((string) $qrow->quotation_number);
                                }
                                $qnByPk[$qk] = $rawqn !== '' ? $rawqn : ('COT-' . str_pad((string) $qk, 6, '0', STR_PAD_LEFT));
                            }
                            foreach ($this->approvalPendingRows as $prow) {
                                $etQ = ApprovalWorkflowService::normalizeEntityType((string) ($prow->entity_type ?? ''));
                                if ($etQ !== ApprovalWorkflowService::ENTITY_COTIZACION_FACTURACION_MANUAL) {
                                    continue;
                                }
                                $qidPk = (int) ($prow->entity_id ?? 0);
                                $prow->quotation_number = $qidPk > 0
                                    ? ($qnByPk[$qidPk] ?? ('COT-' . str_pad((string) $qidPk, 6, '0', STR_PAD_LEFT)))
                                    : '';
                            }
                        } catch (\Throwable $e) {
                        }
                    }
                    $approvalService->enrichPendingRowsWithSubmitterDisplay($this->approvalPendingRows);
                }
            } catch (\Throwable $e) {
                $this->approvalPendingRows = [];
                $this->approvalWorkflowSchemaAvailable = false;
            }
        }

        if ($activeTab === 'ajustes' && $activeSubTab === 'flujos_aprobaciones') {
            try {
                $approvalService = new ApprovalWorkflowService();
                $this->approvalWorkflowSchemaAvailable       = $approvalService->hasSchema();
                $this->approvalGroupsSchemaAvailable         = $approvalService->hasApprovalGroupsSchema();
                $this->approvalWorkflowEditId            = $input->getInt('wf_id', 0);
                $this->approvalComponentGroupsForSelect = $this->approvalGroupsSchemaAvailable
                    ? $approvalService->listComponentApprovalGroupsWithMemberCount()
                    : [];

                if ($this->approvalWorkflowSchemaAvailable) {
                    if ($this->approvalWorkflowEditId > 0) {
                        $this->approvalWorkflowEditBundle = $approvalService->getWorkflowBundleForAdmin($this->approvalWorkflowEditId);
                        if ($this->approvalWorkflowEditBundle === null) {
                            $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_AJUSTES_APPROVAL_WF_NOT_FOUND'), 'warning');
                            $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=ajustes&subtab=flujos_aprobaciones', false));
                            return;
                        }
                        try {
                            $this->approvalJoomlaUsersForSelect = $approvalService->listJoomlaUsersForApprovalPicker();
                        } catch (\Throwable $e) {
                            $this->approvalJoomlaUsersForSelect = [];
                        }
                    } else {
                        try {
                            $this->approvalWorkflowsListSummary = $approvalService->getWorkflowsListSummaryForAdmin();
                        } catch (\Throwable $e) {
                            $this->approvalWorkflowsListSummary = [];
                        }
                    }
                }
            } catch (\Throwable $e) {
                $this->approvalWorkflowSchemaAvailable = false;
                $this->approvalWorkflowsListSummary    = [];
                $this->approvalWorkflowEditBundle      = null;
            }
        }

        if ($activeTab === 'ajustes' && $activeSubTab === 'grupos_aprobaciones') {
            $this->approvalWorkflowStepsApproverRows = [];
            $db     = Factory::getContainer()->get(DatabaseInterface::class);
            $wfSvc  = new ApprovalWorkflowService();
            $this->approvalGroupsSchemaAvailable = $wfSvc->hasApprovalGroupsSchema();
            $this->approvalGroupEditorId         = $input->getInt('approval_group_id', -1);

            if ($this->approvalGroupsSchemaAvailable && $this->approvalGroupEditorId >= 0) {
                if ($this->approvalGroupEditorId === 0) {
                    $this->approvalGroupEditorRow = (object) [
                        'id'          => 0,
                        'title'       => '',
                        'description' => '',
                        'published'   => 1,
                    ];
                    $this->approvalGroupEditorMemberIds = [];
                } else {
                    $row = $wfSvc->getComponentApprovalGroup($this->approvalGroupEditorId);
                    if ($row === null) {
                        $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_APPROVAL_GROUP_NOT_FOUND'), 'warning');
                        $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=ajustes&subtab=grupos_aprobaciones', false));
                        return;
                    }
                    $this->approvalGroupEditorRow       = $row;
                    $this->approvalGroupEditorMemberIds = $wfSvc->getComponentApprovalGroupMemberIds($this->approvalGroupEditorId);
                }
                try {
                    $this->approvalJoomlaUsersForSelect = $wfSvc->listJoomlaUsersForApprovalPicker();
                } catch (\Throwable $e) {
                    $this->approvalJoomlaUsersForSelect = [];
                }
            } elseif ($this->approvalGroupsSchemaAvailable) {
                $this->approvalReferenceJoomlaGroups = $wfSvc->listComponentApprovalGroupsWithMemberCount();
            }

            try {
                $approvalService = new ApprovalWorkflowService();
                $this->approvalWorkflowSchemaAvailable = $approvalService->hasSchema();
                if ($approvalService->hasSchema()) {
                    $q2 = $db->getQuery(true)
                        ->select([
                            $db->quoteName('w.entity_type'),
                            $db->quoteName('w.name', 'workflow_name'),
                            $db->quoteName('s.step_number'),
                            $db->quoteName('s.step_name'),
                            $db->quoteName('s.approver_type'),
                            $db->quoteName('s.approver_value'),
                        ])
                        ->from($db->quoteName('#__ordenproduccion_approval_workflow_steps', 's'))
                        ->innerJoin(
                            $db->quoteName('#__ordenproduccion_approval_workflows', 'w')
                            . ' ON ' . $db->quoteName('w.id') . ' = ' . $db->quoteName('s.workflow_id')
                        )
                        ->order($db->quoteName('w.entity_type') . ' ASC, ' . $db->quoteName('s.step_number') . ' ASC');
                    $db->setQuery($q2);
                    $steps = $db->loadObjectList() ?: [];
                    foreach ($steps as $st) {
                        $st->approver_display = $this->buildApprovalApproverDisplayHint($db, $st, $wfSvc);
                    }
                    $this->approvalWorkflowStepsApproverRows = $steps;
                }
            } catch (\Throwable $e) {
                $this->approvalWorkflowStepsApproverRows = [];
            }
        }

        // Load cotización PDF settings if ajustes tab and Ajustes de Cotización subtab
        if ($activeTab === 'ajustes' && $activeSubTab === 'ajustes_cotizacion') {
            try {
                $this->cotizacionPdfSettings = $statsModel->getCotizacionPdfSettings();
            } catch (\Exception $e) {
                $this->cotizacionPdfSettings = ['encabezado' => '', 'terminos_condiciones' => '', 'pie_pagina' => ''];
            }
        }

        if ($activeTab === 'ajustes' && $activeSubTab === 'plantilla_factura') {
            try {
                $this->invoiceFacturaPlantillaSettings = $statsModel->getInvoiceFacturaPlantillaSettings();
            } catch (\Exception $e) {
                $this->invoiceFacturaPlantillaSettings = [
                    'header_izq_html'   => '',
                    'header_der_html'   => '',
                    'footer_html'       => '',
                    'logo_path'         => '',
                    'logo_x'            => 15,
                    'logo_y'            => 15,
                    'logo_width'        => 50,
                    'encabezado_izq_x'  => 15,
                    'encabezado_izq_y'  => 15,
                    'encabezado_der_x'  => 115,
                    'encabezado_der_y'  => 15,
                    'qr_x'              => 150,
                    'qr_y'              => 18,
                    'qr_size_mm'        => 0,
                    'pie_x'             => 0,
                    'pie_y'             => 0,
                ];
            }
        }

        // Load Solicitud de Orden URL if ajustes tab and Solicitud de Orden subtab
        $this->solicitudOrdenUrl = '';
        if ($activeTab === 'ajustes' && $activeSubTab === 'solicitud_orden') {
            try {
                $this->solicitudOrdenUrl = $statsModel->getSolicitudOrdenUrl();
            } catch (\Exception $e) {
                $this->solicitudOrdenUrl = '';
            }
        }

        $this->certificadorFactSettings = ['test' => [], 'prod' => []];
        $this->certificadorFactClaveSet = ['test' => false, 'prod' => false];
        $this->certificadorFactModo = 'test';
        $certAjustesSubtabs = ['certificador_fact', 'certificador_fact_logs'];
        if ($activeTab === 'ajustes' && in_array($activeSubTab, $certAjustesSubtabs, true)) {
            try {
                $this->certificadorFactModo = $statsModel->getCertificadorFactModo();
                if ($activeSubTab === 'certificador_fact') {
                    $this->certificadorFactFrontendDebug = $statsModel->getCertificadorFactFrontendDebug();
                    $full = $statsModel->getCertificadorFactSettings();
                    foreach (['test', 'prod'] as $env) {
                        $this->certificadorFactClaveSet[$env] = trim((string) ($full[$env]['clave'] ?? '')) !== '';
                        $full[$env]['clave'] = '';
                        $this->certificadorFactSettings[$env] = $full[$env];
                    }
                } else {
                    $this->certificadorFactFrontendDebug = false;
                    $this->certificadorFactSettings = [
                        'test' => [
                            'url_autenticacion' => '',
                            'url_info' => '',
                            'url_cert_cf' => '',
                            'url_cert_nit' => '',
                            'url_cert_cui' => '',
                            'branch_code' => '',
                            'branch_name' => '',
                            'branch_address' => '',
                            'branch_city' => '',
                            'branch_district' => '',
                            'branch_state' => '',
                            'branch_country' => '',
                            'nit' => '',
                            'usuario' => '',
                            'clave' => '',
                        ],
                        'prod' => [
                            'url_autenticacion' => '',
                            'url_info' => '',
                            'url_cert_cf' => '',
                            'url_cert_nit' => '',
                            'url_cert_cui' => '',
                            'branch_code' => '',
                            'branch_name' => '',
                            'branch_address' => '',
                            'branch_city' => '',
                            'branch_district' => '',
                            'branch_state' => '',
                            'branch_country' => '',
                            'nit' => '',
                            'usuario' => '',
                            'clave' => '',
                        ],
                    ];
                }
            } catch (\Throwable $e) {
                $this->certificadorFactModo = 'test';
                $this->certificadorFactFrontendDebug = false;
                $this->certificadorFactSettings = [
                    'test' => [
                        'url_autenticacion' => '',
                        'url_info' => '',
                        'url_cert_cf' => '',
                        'url_cert_nit' => '',
                        'url_cert_cui' => '',
                        'branch_code' => '',
                        'branch_name' => '',
                        'branch_address' => '',
                        'branch_city' => '',
                        'branch_district' => '',
                        'branch_state' => '',
                        'branch_country' => '',
                        'nit' => '',
                        'usuario' => '',
                        'clave' => '',
                    ],
                    'prod' => [
                        'url_autenticacion' => '',
                        'url_info' => '',
                        'url_cert_cf' => '',
                        'url_cert_nit' => '',
                        'url_cert_cui' => '',
                        'branch_code' => '',
                        'branch_name' => '',
                        'branch_address' => '',
                        'branch_city' => '',
                        'branch_district' => '',
                        'branch_state' => '',
                        'branch_country' => '',
                        'nit' => '',
                        'usuario' => '',
                        'clave' => '',
                    ],
                ];
            }
            if ($activeSubTab === 'certificador_fact') {
                try {
                    $this->certificadorTokenMaintainLastLog = $statsModel->getCertificadorTokenMaintainLastLog();
                } catch (\Throwable $e) {
                    $this->certificadorTokenMaintainLastLog = [
                        'at'      => '',
                        'summary' => ['test' => '', 'prod' => '', 'errors' => [], 'forced' => false],
                    ];
                }
                $this->syncCertificadorFactActiveViewFields();
            } else {
                $this->resetCertificadorFactActiveViewFields();
                try {
                    $this->certificadorDigifactLogTableAvailable = $statsModel->isCertificadorDigifactLogTableAvailable();
                    $logLimit                                     = 20;
                    $this->certificadorDigifactLogSearch         = $statsModel->normalizeCertificadorDigifactLogSearch($input->getString('digifact_log_search', ''));
                    $logSearchParam                               = $this->certificadorDigifactLogSearch;
                    $logStart                                     = max(0, (int) $input->getInt('digifact_log_limitstart', 0));
                    $this->certificadorDigifactLogTotal           = $statsModel->countCertificadorDigifactLogs($logSearchParam);
                    $this->certificadorDigifactLogRows           = $statsModel->listCertificadorDigifactLogs($logLimit, $logStart, $logSearchParam);
                    if ($this->certificadorDigifactLogTableAvailable && $this->certificadorDigifactLogTotal > 0) {
                        $this->certificadorDigifactLogPagination = new \Joomla\CMS\Pagination\Pagination(
                            $this->certificadorDigifactLogTotal,
                            $logStart,
                            $logLimit,
                            'digifact_log_'
                        );
                        $this->certificadorDigifactLogPagination->setAdditionalUrlParam('option', 'com_ordenproduccion');
                        $this->certificadorDigifactLogPagination->setAdditionalUrlParam('view', 'administracion');
                        $this->certificadorDigifactLogPagination->setAdditionalUrlParam('tab', 'ajustes');
                        $this->certificadorDigifactLogPagination->setAdditionalUrlParam('subtab', 'certificador_fact_logs');
                        if ($logSearchParam !== '') {
                            $this->certificadorDigifactLogPagination->setAdditionalUrlParam('digifact_log_search', $logSearchParam);
                        }
                    }
                } catch (\Throwable $e) {
                    $this->certificadorDigifactLogRows           = [];
                    $this->certificadorDigifactLogPagination      = null;
                    $this->certificadorDigifactLogTableAvailable = false;
                    $this->certificadorDigifactLogTotal          = 0;
                }
            }
        } else {
            $this->resetCertificadorFactActiveViewFields();
        }

        $this->workOrderNumbering   = null;
        $this->ordenCompraNumbering = null;
        if ($activeTab === 'ajustes' && $activeSubTab === 'numeracion_ordenes') {
            try {
                $settingsModel              = new \Grimpsa\Component\Ordenproduccion\Administrator\Model\SettingsModel();
                $this->workOrderNumbering   = $settingsModel->getWorkOrderNumberingRow();
                $this->ordenCompraNumbering = $settingsModel->getOrdenCompraNumberingRow();
            } catch (\Throwable $e) {
                $this->workOrderNumbering   = null;
                $this->ordenCompraNumbering = null;
            }
        }

        $this->vendorQuoteTemplates         = ['email' => null, 'cellphone' => null, 'pdf' => null];
        $this->vendorQuoteTemplatesSchemaOk = false;
        if ($activeTab === 'ajustes' && $activeSubTab === 'solicitud_cotizacion') {
            $this->vendorQuoteTemplatesSchemaOk = $statsModel->hasVendorQuoteTemplatesSchema();
            if ($this->vendorQuoteTemplatesSchemaOk) {
                $tplRows = $statsModel->getVendorQuoteTemplates();
                foreach (['email', 'cellphone', 'pdf'] as $ch) {
                    $this->vendorQuoteTemplates[$ch] = $tplRows[$ch] ?? null;
                }
            }
        }

        if ($activeTab === 'ajustes' && $activeSubTab === 'creacion_logs') {
            try {
                $this->otWizardLogEntries     = OtWizardCreationLogHelper::collectEntriesFromJoomlaLogs(150);
                $this->otWizardLogScannedDirs = OtWizardCreationLogHelper::getScannedDirectoryLabels();
            } catch (\Throwable $e) {
                $this->otWizardLogEntries     = [];
                $this->otWizardLogScannedDirs = OtWizardCreationLogHelper::getScannedDirectoryLabels();
            }
        }

        $this->mt940Settings    = [];
        $this->mt940PasswordSet = false;
        $this->ajustesMt940SchemaOk           = false;
        $this->ajustesMt940BankAccountOptions = [];
        if ($activeTab === 'ajustes' && $activeSubTab === 'mt940') {
            try {
                $full = $statsModel->getMt940Settings();
                $this->mt940PasswordSet = trim((string) ($full['imap_password'] ?? '')) !== '';
                $full['imap_password']  = '';
                $this->mt940Settings    = $full;
            } catch (\Throwable $e) {
                $this->mt940Settings    = [];
                $this->mt940PasswordSet = false;
            }
        }

        if ($activeTab === 'ajustes' && $activeSubTab === 'mt940_importar') {
            try {
                $admMt940 = $this->getModel('Administracion');
                if (!$admMt940 && class_exists(AdministracionModel::class)) {
                    $admMt940 = Factory::getApplication()->bootComponent('com_ordenproduccion')
                        ->getMVCFactory()->createModel('Administracion', 'Site', ['ignore_request' => true]);
                }
                if ($admMt940) {
                    $this->ajustesMt940SchemaOk           = $admMt940->isMt940TransactionsTableAvailable();
                    $this->ajustesMt940BankAccountOptions = $admMt940->getMt940ConfiguredBankAccountOptions();

                    $cronKey = $admMt940->getMt940CronKey();
                    $this->mt940CronCrontabLine       = $admMt940->getMt940CronCrontabLine();
                    $this->mt940CronKeyConfigured     = ($cronKey !== '');
                }
            } catch (\Throwable $e) {
                $this->ajustesMt940SchemaOk           = false;
                $this->ajustesMt940BankAccountOptions = [];
            }
        }

        if ($activeTab === 'ajustes' && $activeSubTab === 'mt940_registro') {
            try {
                $admMt940 = $this->getModel('Administracion');
                if (!$admMt940 && class_exists(AdministracionModel::class)) {
                    $admMt940 = Factory::getApplication()->bootComponent('com_ordenproduccion')
                        ->getMVCFactory()->createModel('Administracion', 'Site', ['ignore_request' => true]);
                }
                if ($admMt940) {
                    $this->mt940RunLogTableOk = $admMt940->isMt940RunLogTableAvailable();
                    if ($this->mt940RunLogTableOk) {
                        $limit      = max(10, min(200, (int) $input->getInt('mt940_run_limit', 25)));
                        $limitStart = max(0, (int) $input->getInt('mt940_run_limitstart', 0));
                        $this->mt940RunLogListLimit = $limit;
                        $pack                       = $admMt940->getMt940RunLogList($limit, $limitStart);
                        $this->mt940RunLogRows      = $pack['rows'] ?? [];
                        $this->mt940RunLogTotal     = (int) ($pack['total'] ?? 0);
                        if ($this->mt940RunLogTotal > 0) {
                            $this->mt940RunLogPagination = new \Joomla\CMS\Pagination\Pagination(
                                $this->mt940RunLogTotal,
                                $limitStart,
                                $limit,
                                'mt940_run_'
                            );
                            $this->mt940RunLogPagination->setAdditionalUrlParam('option', 'com_ordenproduccion');
                            $this->mt940RunLogPagination->setAdditionalUrlParam('view', 'administracion');
                            $this->mt940RunLogPagination->setAdditionalUrlParam('tab', 'ajustes');
                            $this->mt940RunLogPagination->setAdditionalUrlParam('subtab', 'mt940_registro');
                            $this->mt940RunLogPagination->setAdditionalUrlParam('mt940_run_limit', (string) $limit);
                        }
                    }
                }
            } catch (\Throwable $e) {
                $this->mt940RunLogTableOk  = false;
                $this->mt940RunLogRows     = [];
                $this->mt940RunLogTotal    = 0;
                $this->mt940RunLogPagination = null;
            }
        }

        // Final safeguard: Ensure layout data properties exist before parent::display()
        // This prevents "Undefined array key" errors in Joomla's AbstractView when loading sub-templates (e.g. invoices)
        if (!isset($this->invoices) || !is_array($this->invoices)) {
            $this->invoices = [];
        }
        if (!isset($this->invoicesPagination)) {
            $this->invoicesPagination = null;
        }
        if (!isset($this->banks) || !is_array($this->banks)) {
            $this->banks = [];
        }
        if (!isset($this->bankAccounts) || !is_array($this->bankAccounts)) {
            $this->bankAccounts = [];
        }

        // Also check via reflection to ensure property is initialized (PHP 7.4+)
        try {
            $reflection = new \ReflectionClass($this);
            $property = $reflection->getProperty('banks');
            if (!$property->isInitialized($this)) {
                $this->banks = [];
            }
        } catch (\ReflectionException $e) {
            // If reflection fails, just ensure it's an array
            $this->banks = [];
        } catch (\Error $e) {
            // PHP 7.3 compatibility - ReflectionProperty::isInitialized() doesn't exist
            $this->banks = [];
        }

        try {
            $reflection = new \ReflectionClass($this);
            $property = $reflection->getProperty('bankAccounts');
            if (!$property->isInitialized($this)) {
                $this->bankAccounts = [];
            }
        } catch (\ReflectionException $e) {
            $this->bankAccounts = [];
        } catch (\Error $e) {
            $this->bankAccounts = [];
        }
        
        // Prepare document
        $this->_prepareDocument();

        parent::display($tpl);
    }

    /**
     * Clear flattened Certificador FEL variables (not on Ajustes > Certificador).
     *
     * @return  void
     *
     * @since   3.118.6
     */
    protected function resetCertificadorFactActiveViewFields(): void
    {
        $this->certificadorFactActive                = [];
        $this->certificadorFactActiveEnv             = '';
        $this->certificadorFactActiveUrlAutenticacion = '';
        $this->certificadorFactActiveUrlInfo         = '';
        $this->certificadorFactActiveUrlCertCf          = '';
        $this->certificadorFactActiveUrlCertNit         = '';
        $this->certificadorFactActiveUrlCertCui      = '';
        $this->certificadorFactActiveNit             = '';
        $this->certificadorFactActiveUsuario         = '';
        $this->certificadorFactActiveClaveConfigured = false;
        $this->certificadorTokenMaintainLastLog      = [
            'at'      => '',
            'summary' => ['test' => '', 'prod' => '', 'errors' => [], 'forced' => false],
        ];
    }

    /**
     * Fill certificadorFactActive* from certificadorFactModo + certificadorFactSettings (no clave value).
     *
     * @return  void
     *
     * @since   3.118.6
     */
    protected function syncCertificadorFactActiveViewFields(): void
    {
        $env = ($this->certificadorFactModo === 'prod') ? 'prod' : 'test';
        $b   = isset($this->certificadorFactSettings[$env]) && is_array($this->certificadorFactSettings[$env])
            ? $this->certificadorFactSettings[$env]
            : [];

        $this->certificadorFactActiveEnv             = $env;
        $this->certificadorFactActiveUrlAutenticacion = (string) ($b['url_autenticacion'] ?? '');
        $this->certificadorFactActiveUrlInfo         = (string) ($b['url_info'] ?? '');
        $this->certificadorFactActiveUrlCertCf          = (string) ($b['url_cert_cf'] ?? '');
        $this->certificadorFactActiveUrlCertNit         = (string) ($b['url_cert_nit'] ?? '');
        $this->certificadorFactActiveUrlCertCui      = (string) ($b['url_cert_cui'] ?? '');
        $this->certificadorFactActiveNit             = (string) ($b['nit'] ?? '');
        $this->certificadorFactActiveUsuario         = (string) ($b['usuario'] ?? '');
        $this->certificadorFactActiveClaveConfigured = !empty($this->certificadorFactClaveSet[$env]);

        $this->certificadorFactActive = [
            'env'               => $env,
            'url_autenticacion' => $this->certificadorFactActiveUrlAutenticacion,
            'url_info'          => $this->certificadorFactActiveUrlInfo,
            'url_cert_cf'             => $this->certificadorFactActiveUrlCertCf,
            'url_cert_nit'             => $this->certificadorFactActiveUrlCertNit,
            'url_cert_cui'      => $this->certificadorFactActiveUrlCertCui,
            'branch_code'       => (string) ($b['branch_code'] ?? ''),
            'branch_name'       => (string) ($b['branch_name'] ?? ''),
            'branch_address'    => (string) ($b['branch_address'] ?? ''),
            'branch_city'       => (string) ($b['branch_city'] ?? ''),
            'branch_district'   => (string) ($b['branch_district'] ?? ''),
            'branch_state'      => (string) ($b['branch_state'] ?? ''),
            'branch_country'    => (string) ($b['branch_country'] ?? ''),
            'nit'               => $this->certificadorFactActiveNit,
            'usuario'           => $this->certificadorFactActiveUsuario,
            'clave_configured'  => $this->certificadorFactActiveClaveConfigured,
        ];
    }

    /**
     * Prepare document
     *
     * @return  void
     *
     * @since   3.1.0
     */
    protected function _prepareDocument()
    {
        $app = Factory::getApplication();
        $this->document->setTitle(Text::_('COM_ORDENPRODUCCION_ADMINISTRACION_TITLE'));

        // Load Bootstrap and jQuery
        \Joomla\CMS\HTML\HTMLHelper::_('bootstrap.framework');
    }

    /**
     * Human-readable approver summary for Grupos de aprobaciones tab.
     *
     * @since  3.109.63
     */
    protected function buildApprovalApproverDisplayHint(DatabaseInterface $db, object $step, ?ApprovalWorkflowService $wfSvc = null): string
    {
        $type = strtolower(trim((string) ($step->approver_type ?? '')));
        $val  = trim((string) ($step->approver_value ?? ''));
        if ($val === '') {
            return '—';
        }

        if ($type === 'user') {
            $uids = array_unique(array_filter(array_map('intval', explode(',', $val)), static function ($id) {
                return $id > 0;
            }));
            if ($uids === []) {
                return '—';
            }
            $in = implode(',', $uids);
            $q  = $db->getQuery(true)
                ->select([
                    $db->quoteName('id'),
                    $db->quoteName('name'),
                    $db->quoteName('username'),
                ])
                ->from($db->quoteName('#__users'))
                ->where($db->quoteName('id') . ' IN (' . $in . ')')
                ->order($db->quoteName('name') . ' ASC');
            $db->setQuery($q);
            $rows = $db->loadObjectList() ?: [];
            $parts = [];
            foreach ($rows as $ur) {
                $parts[] = htmlspecialchars((string) ($ur->name ?? ''), ENT_QUOTES, 'UTF-8')
                    . ' (' . htmlspecialchars((string) ($ur->username ?? ''), ENT_QUOTES, 'UTF-8') . ')';
            }

            return $parts !== [] ? implode('; ', $parts) : $val;
        }

        if ($type === 'joomla_group') {
            $ids = array_unique(array_filter(array_map('intval', explode(',', $val))));
            if ($ids === []) {
                return $val;
            }
            $in = implode(',', $ids);
            $q  = $db->getQuery(true)
                ->select($db->quoteName('title'))
                ->from($db->quoteName('#__usergroups'))
                ->where($db->quoteName('id') . ' IN (' . $in . ')')
                ->order($db->quoteName('id') . ' ASC');
            $db->setQuery($q);
            $titles = $db->loadColumn() ?: [];

            return $titles !== []
                ? implode(', ', $titles) . ' (' . Text::_('COM_ORDENPRODUCCION_AJUSTES_APPROVAL_GROUPS_IDS') . ': ' . $in . ')'
                : $val;
        }

        if ($type === 'named_group') {
            return Text::_('COM_ORDENPRODUCCION_AJUSTES_APPROVAL_GROUPS_NAMED_MATCH') . ' ' . $val;
        }

        if ($type === 'approval_group') {
            $ids = array_unique(array_filter(array_map('intval', explode(',', $val))));
            if ($ids === []) {
                return '—';
            }
            if ($wfSvc !== null && $wfSvc->hasApprovalGroupsSchema()) {
                $in     = implode(',', $ids);
                $q      = $db->getQuery(true)
                    ->select($db->quoteName('title'))
                    ->from($db->quoteName('#__ordenproduccion_approval_groups'))
                    ->where($db->quoteName('id') . ' IN (' . $in . ')')
                    ->order($db->quoteName('id') . ' ASC');
                $db->setQuery($q);
                $titles = $db->loadColumn() ?: [];

                return $titles !== []
                    ? implode(', ', $titles) . ' (' . Text::_('COM_ORDENPRODUCCION_AJUSTES_APPROVAL_TYPE_APPROVAL_GROUP_SHORT') . ': ' . $in . ')'
                    : $val;
            }

            return $val;
        }

        return $val;
    }
}

