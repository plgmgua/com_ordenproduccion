<?php
/**
 * Invoices Model for Com Orden Produccion
 * 
 * Handles invoice list, filtering, and pagination
 * 
 * @package     Grimpsa\Component\Ordenproduccion\Site\Model
 * @subpackage  Invoices
 * @since       3.2.0
 */

namespace Grimpsa\Component\Ordenproduccion\Site\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;
use Grimpsa\Component\Ordenproduccion\Site\Helper\InvoiceListHelper;

class InvoicesModel extends ListModel
{
    /**
     * Constructor
     */
    public function __construct($config = [])
    {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = [
                'id', 'invoice_number', 'client_name', 'client_nit', 'invoice_date',
                'fel_fecha_emision', 'invoice_amount', 'status'
            ];
        }
        parent::__construct($config);
    }

    /**
     * Build SQL query to get invoices list
     */
    protected function getListQuery()
    {
        $db = $this->getDatabase();
        $query = $db->getQuery(true);

        $query->select('i.*')
            ->from($db->quoteName('#__ordenproduccion_invoices', 'i'))
            ->where($db->quoteName('i.state') . ' = 1');

        // Filter by NIT (client_nit or fel_receptor_id)
        $nit = trim((string) $this->getState('filter.nit', ''));
        if ($nit !== '') {
            $nitLike = $db->quote('%' . $db->escape($nit, true) . '%');
            $query->where('(' . $db->quoteName('i.client_nit') . ' LIKE ' . $nitLike .
                ' OR ' . $db->quoteName('i.fel_receptor_id') . ' LIKE ' . $nitLike . ')');
        }

        // Filter by Cliente (client name)
        $cliente = trim((string) $this->getState('filter.cliente', ''));
        if ($cliente !== '') {
            $query->where($db->quoteName('i.client_name') . ' LIKE ' . $db->quote('%' . $db->escape($cliente, true) . '%'));
        }

        // Filter by Tipo: valid = import/XML/other OR cotización FEL in producción (fel_extra.certificador_ambiente = prod)
        $tipo = (string) $this->getState('filter.tipo', '');
        if ($tipo === 'mockup' || $tipo === 'valid') {
            $felCol   = $db->quoteName('i.fel_extra');
            $jsonBlob = 'CASE WHEN ' . $felCol . ' IS NULL OR TRIM(' . $felCol . ') = ' . $db->quote('')
                . ' THEN ' . $db->quote('{}') . ' ELSE ' . $felCol . ' END';
            $ambExpr  = 'JSON_UNQUOTE(JSON_EXTRACT(' . $jsonBlob . ', ' . $db->quote('$.certificador_ambiente') . '))';

            if ($tipo === 'mockup') {
                $query->where($db->quoteName('i.invoice_source') . ' = ' . $db->quote(InvoiceListHelper::SOURCE_MOCKUP));
                $query->where(
                    '(' . $ambExpr . ' IS NULL OR ' . $ambExpr . ' = ' . $db->quote('')
                    . ' OR ' . $ambExpr . ' = ' . $db->quote('test') . ')'
                );
            } else {
                $query->where(
                    '('
                    . '(' . $db->quoteName('i.invoice_source') . ' IS NULL OR '
                    . $db->quoteName('i.invoice_source') . ' != ' . $db->quote(InvoiceListHelper::SOURCE_MOCKUP) . ')'
                    . ' OR ('
                    . $db->quoteName('i.invoice_source') . ' = ' . $db->quote(InvoiceListHelper::SOURCE_MOCKUP)
                    . ' AND ' . $ambExpr . ' = ' . $db->quote('prod')
                    . ')'
                    . ')'
                );
            }
        }

        // Filter by Fecha (date range: use fel_fecha_emision or invoice_date)
        $fechaFrom = trim((string) $this->getState('filter.fecha_from', ''));
        $fechaTo   = trim((string) $this->getState('filter.fecha_to', ''));
        if ($fechaFrom !== '') {
            $query->where('(COALESCE(i.fel_fecha_emision, i.invoice_date) >= ' . $db->quote($fechaFrom . ' 00:00:00') . ')');
        }
        if ($fechaTo !== '') {
            $query->where('(COALESCE(i.fel_fecha_emision, i.invoice_date) <= ' . $db->quote($fechaTo . ' 23:59:59') . ')');
        }

        // Filter by Total (min/max)
        $totalMin = $this->getState('filter.total_min', null);
        $totalMax = $this->getState('filter.total_max', null);
        if ($totalMin !== null && $totalMin !== '') {
            $val = (float) $totalMin;
            $query->where($db->quoteName('i.invoice_amount') . ' >= ' . $val);
        }
        if ($totalMax !== null && $totalMax !== '') {
            $val = (float) $totalMax;
            $query->where($db->quoteName('i.invoice_amount') . ' <= ' . $val);
        }

        // Ordering (default by emission date desc)
        $orderCol = $this->getState('list.ordering', 'i.fel_fecha_emision');
        $orderDir = $this->getState('list.direction', 'DESC');
        if ($orderCol === 'i.invoice_date' || $orderCol === 'i.fel_fecha_emision') {
            $query->order('COALESCE(i.fel_fecha_emision, i.invoice_date) ' . $db->escape($orderDir));
        } else {
            $query->order($db->escape($orderCol) . ' ' . $db->escape($orderDir));
        }

        return $query;
    }

    /**
     * Populate state (filters + list limit/start for pagination; default 20 per page)
     */
    protected function populateState($ordering = 'fel_fecha_emision', $direction = 'desc')
    {
        $app = Factory::getApplication();

        $this->setState('filter.nit', $app->getUserStateFromRequest($this->context . '.filter.nit', 'filter_nit', '', 'string'));
        $this->setState('filter.cliente', $app->getUserStateFromRequest($this->context . '.filter.cliente', 'filter_cliente', '', 'string'));
        $tipoRaw = strtolower(trim((string) $app->getUserStateFromRequest($this->context . '.filter.tipo', 'filter_tipo', '', 'string')));
        $this->setState('filter.tipo', \in_array($tipoRaw, ['valid', 'mockup'], true) ? $tipoRaw : '');
        $this->setState('filter.fecha_from', $app->getUserStateFromRequest($this->context . '.filter.fecha_from', 'filter_fecha_from', '', 'string'));
        $this->setState('filter.fecha_to', $app->getUserStateFromRequest($this->context . '.filter.fecha_to', 'filter_fecha_to', '', 'string'));
        $this->setState('filter.total_min', $app->getUserStateFromRequest($this->context . '.filter.total_min', 'filter_total_min', '', 'string'));
        $this->setState('filter.total_max', $app->getUserStateFromRequest($this->context . '.filter.total_max', 'filter_total_max', '', 'string'));

        parent::populateState($ordering, $direction);

        // Force pagination: default 20 per page (parent may set list.limit to 0 on site).
        // Read from request key 'limit' so pagination links (e.g. ?limit=20&limitstart=20) work.
        $limit = (int) $app->getUserStateFromRequest($this->context . '.list.limit', 'limit', 20, 'uint');
        if ($limit <= 0) {
            $limit = 20;
        }
        $this->setState('list.limit', $limit);
        $limitstart = (int) $app->input->get('limitstart', 0, 'uint');
        $this->setState('list.start', max(0, $limitstart));
    }

    /**
     * Get status options for filter
     */
    public function getStatusOptions()
    {
        return [
            'draft' => 'Borrador',
            'sent' => 'Enviada',
            'paid' => 'Pagada',
            'cancelled' => 'Cancelada'
        ];
    }

    /**
     * Get unique sales agents from invoices
     */
    public function getSalesAgents()
    {
        $db = $this->getDatabase();
        $query = $db->getQuery(true)
            ->select('DISTINCT ' . $db->quoteName('sales_agent'))
            ->from($db->quoteName('#__ordenproduccion_invoices'))
            ->where($db->quoteName('sales_agent') . ' IS NOT NULL')
            ->where($db->quoteName('sales_agent') . ' != ' . $db->quote(''))
            ->order($db->quoteName('sales_agent'));

        $db->setQuery($query);
        return $db->loadColumn();
    }
}

