<?php

/**
 * Sync + reload com_ordenproduccion language before Global Configuration renders strings.
 *
 * @copyright   (C) 2026 Grimpsa.
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Filter\InputFilter;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\DispatcherInterface;

/**
 * @since  3.114.17
 */
final class PlgSystemOpAdmlang extends CMSPlugin
{
    /** @var bool */
    private static $completedThisRequest = false;

    /**
     * @param   DispatcherInterface  $dispatcher  Event dispatcher
     * @param   array<string, mixed>  $config     Plugin configuration array
     */
    public function __construct(DispatcherInterface $dispatcher, array $config = [])
    {
        parent::__construct($dispatcher, $config);
        $this->autoloadLanguage = false;
    }

    /**
     * Runs before routing — input may lack parsed option; fallback to sanitized $_GET / $_REQUEST.
     */
    public function onAfterInitialise(): void
    {
        if (self::$completedThisRequest) {
            return;
        }

        if (!$this->isGlobalConfigTarget()) {
            return;
        }

        $this->runSyncAndReload();
    }

    /**
     * Fallback after Joomla has populated application input fully.
     */
    public function onAfterRoute(): void
    {
        if (self::$completedThisRequest) {
            return;
        }

        if (!$this->isGlobalConfigTarget()) {
            return;
        }

        $this->runSyncAndReload();
    }

    /**
     * Last chance before the component config form is rendered.
     *
     * @param   \Joomla\CMS\Form\Form  $form
     * @param   mixed                  $data
     *
     * @return  void
     */
    public function onContentPrepareForm($form, $data): void
    {
        if (self::$completedThisRequest || !\is_object($form) || !\method_exists($form, 'getName')) {
            return;
        }

        $name = (string) $form->getName();

        if ($name !== 'com_config.component' && $name !== 'config') {
            return;
        }

        $component = Factory::getApplication()->input->getCmd('component', '');

        if ($component !== 'com_ordenproduccion') {
            return;
        }

        $this->runSyncAndReload();
    }

    private function runSyncAndReload(): void
    {
        $syncClass = \Grimpsa\Component\Ordenproduccion\Administrator\Helper\AdminLanguageSync::class;

        if (!\class_exists($syncClass)) {
            foreach ([
                \JPATH_ADMINISTRATOR . '/components/com_ordenproduccion/src/Helper/AdminLanguageSync.php',
                \JPATH_ADMINISTRATOR . '/components/com_ordenproduccion/admin/src/Helper/AdminLanguageSync.php',
            ] as $syncFile) {
                if (\is_file($syncFile)) {
                    require_once $syncFile;
                    break;
                }
            }
        }

        if (!\class_exists($syncClass)) {
            return;
        }

        $syncClass::syncFromExtensionFolder();
        $syncClass::reloadMergedComponentLanguage();

        self::$completedThisRequest = true;
    }

    private function isGlobalConfigTarget(): bool
    {
        $app = Factory::getApplication();

        if (!$app->isClient('administrator')) {
            return false;
        }

        $filter = new InputFilter();

        $option = $app->input->getCmd('option');
        $view = $app->input->getCmd('view');
        $component = $app->input->getCmd('component');

        if (($option === '' || $view === '') && !empty($_GET)) {
            $option = $filter->clean($_GET['option'] ?? '', 'cmd');
            $view = $filter->clean($_GET['view'] ?? '', 'cmd');
        }

        if ($component === '' && isset($_GET['component'])) {
            $component = $filter->clean($_GET['component'], 'cmd');
        }

        return $option === 'com_config'
            && $view === 'component'
            && $component === 'com_ordenproduccion';
    }
}
