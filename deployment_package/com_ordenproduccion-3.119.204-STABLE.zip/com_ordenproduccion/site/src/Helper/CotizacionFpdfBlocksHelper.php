<?php
/**
 * Parse WYSIWYG HTML into FPDF blocks and render them (shared by cotización and vendor-quote PDFs).
 *
 * @package     Grimpsa\Component\Ordenproduccion\Site\Helper
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Grimpsa\Component\Ordenproduccion\Site\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

/**
 * @since  3.113.8
 */
class CotizacionFpdfBlocksHelper
{
    /** Left segment of {@see drawCmyBrandBar()} — cyan / PMS 2925C (#009FE3 sRGB approx.). */
    public const BRAND_BAR_CYAN_R = 0;

    public const BRAND_BAR_CYAN_G = 159;

    public const BRAND_BAR_CYAN_B = 227;

    /**
     * Full-width three-strip bar: Cyan (PMS 2925C) | Yellow (PMS 803C) | Magenta (PMS 213C).
     * Set position (e.g. SetY/SetX) before calling; restores fill colour to white.
     *
     * @param   \FPDF  $pdf
     * @param   float  $thirdW  Segment width (typically page width / 3, mm)
     * @param   float  $barH    Bar height (mm)
     * @param   int    $ln      Last FPDF::Cell() line parameter (0 or 1)
     *
     * @return  void
     *
     * @since   3.113.45
     */
    public static function drawCmyBrandBar(\FPDF $pdf, float $thirdW, float $barH, int $ln = 1): void
    {
        // #009FE3, #FFED00, #E6007E (sRGB approximations for print specs)
        $pdf->SetFillColor(self::BRAND_BAR_CYAN_R, self::BRAND_BAR_CYAN_G, self::BRAND_BAR_CYAN_B);
        $pdf->Cell($thirdW, $barH, '', 0, 0, 'L', true);
        $pdf->SetFillColor(255, 237, 0);
        $pdf->Cell($thirdW, $barH, '', 0, 0, 'L', true);
        $pdf->SetFillColor(230, 0, 126);
        $pdf->Cell($thirdW, $barH, '', 0, $ln, 'L', true);
        $pdf->SetFillColor(255, 255, 255);
    }

    /**
     * Bottom margin (mm) to reserve during flow layout so content does not overlap the pinned CMY bar.
     *
     * @param   float  $barH  Bar height in mm
     *
     * @return  float
     *
     * @since   3.119.109
     */
    public static function brandBarBottomReserveMm(float $barH = 4.0): float
    {
        return $barH + 6.0;
    }

    /**
     * Draw CMY brand bar flush to the bottom edge of the current page (fixed position, not flow).
     *
     * @param   \FPDF  $pdf
     * @param   float  $barH  Bar height in mm
     *
     * @return  void
     *
     * @since   3.119.109
     */
    public static function pinBottomBrandBar(\FPDF $pdf, float $barH = 4.0): void
    {
        $thirdW = $pdf->GetPageWidth() / 3;
        $pdf->SetAutoPageBreak(false);
        $pdf->SetXY(0.0, $pdf->GetPageHeight() - $barH);
        self::drawCmyBrandBar($pdf, $thirdW, $barH, 1);
    }

    /**
     * Parse HTML into blocks with alignment (preserve WYSIWYG: left/right/center and line breaks).
     * Used for encabezado, términos and pie. Block text preserves \n for MultiCell.
     *
     * @param   string    $html             HTML content (placeholders already replaced)
     * @param   callable  $fixSpanishChars  Reserved for API compatibility (encoding is done in render)
     *
     * @return  array<int, array<string, mixed>>
     */
    public static function parseHtmlBlocks($html, callable $fixSpanishChars)
    {
        $blocks = [];
        $html = trim((string) $html);
        if ($html === '') {
            return $blocks;
        }

        $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $html = str_replace("\xc2\xa0", ' ', $html);

        $html = preg_replace_callback(
            '/<\s*ol[^>]*>(.*?)<\s*\/\s*ol\s*>/is',
            static function ($m) {
                $idx   = 1;
                $lines = [];
                preg_match_all('/<\s*li[^>]*>(.*?)<\s*\/\s*li\s*>/is', $m[1], $ms);
                foreach ($ms[1] as $item) {
                    $lines[] = ($idx++) . '. ' . trim(strip_tags($item));
                }

                return '<__LISTBLOCK__>' . implode("\n", $lines) . '</__LISTBLOCK__>';
            },
            $html
        );

        $html = preg_replace_callback(
            '/<\s*ul[^>]*>(.*?)<\s*\/\s*ul\s*>/is',
            static function ($m) {
                $lines = [];
                preg_match_all('/<\s*li[^>]*>(.*?)<\s*\/\s*li\s*>/is', $m[1], $ms);
                foreach ($ms[1] as $item) {
                    $lines[] = '* ' . trim(strip_tags($item));
                }

                return '<__LISTBLOCK__>' . implode("\n", $lines) . '</__LISTBLOCK__>';
            },
            $html
        );

        $html = preg_replace_callback(
            '/<\s*table[^>]*>(.*?)<\s*\/\s*table\s*>/is',
            static function ($m) {
                $rows = [];
                preg_match_all('/<\s*tr[^>]*>(.*?)<\s*\/\s*tr\s*>/is', $m[1], $trMatches);
                foreach ($trMatches[1] as $trContent) {
                    $cells = [];
                    preg_match_all('/<\s*t[dh][^>]*>(.*?)<\s*\/\s*t[dh]\s*>/is', $trContent, $tdMatches, PREG_SET_ORDER);
                    foreach ($tdMatches as $tdMatch) {
                        $cellTag     = $tdMatch[0];
                        $cellContent = $tdMatch[1];

                        $cellAlign = 'L';
                        if (preg_match('/style\s*=\s*["\'][^"\']*text-align\s*:\s*right/i', $cellTag)) {
                            $cellAlign = 'R';
                        } elseif (preg_match('/style\s*=\s*["\'][^"\']*text-align\s*:\s*center/i', $cellTag)) {
                            $cellAlign = 'C';
                        }

                        $colspan = 1;
                        if (preg_match('/colspan\s*=\s*["\']?(\d+)["\']?/i', $cellTag, $csm)) {
                            $colspan = max(1, (int) $csm[1]);
                        }

                        $cellImages = [];
                        if (preg_match_all('/<img[^>]+>/i', $cellContent, $imgMatches)) {
                            foreach ($imgMatches[0] as $imgTag) {
                                if (preg_match('/src\s*=\s*["\']([^"\']+)["\']/', $imgTag, $srcM)) {
                                    $iw = 0;
                                    $ih = 0;
                                    if (preg_match('/width\s*=\s*["\']?(\d+)["\']?/i', $imgTag, $wm)) {
                                        $iw = (int) $wm[1];
                                    }
                                    if (preg_match('/height\s*=\s*["\']?(\d+)["\']?/i', $imgTag, $hm)) {
                                        $ih = (int) $hm[1];
                                    }
                                    $cellImages[] = ['src' => $srcM[1], 'width' => $iw, 'height' => $ih];
                                }
                            }
                        }

                        $cellStyle = '';
                        if (preg_match('/<(b|strong)\b/i', $cellContent)) {
                            $cellStyle .= 'B';
                        }
                        if (preg_match('/<(i|em)\b/i', $cellContent)) {
                            $cellStyle .= 'I';
                        }

                        $cellContent = self::expandAnchorHrefsForPdf($cellContent);
                        $cellText = preg_replace('/<br\s*\/?>/i', "\n", $cellContent);
                        $cellText = strip_tags($cellText);
                        $cellText = trim(preg_replace('/[ \t]+/', ' ', $cellText));

                        $cells[] = [
                            'text'    => $cellText,
                            'align'   => $cellAlign,
                            'style'   => $cellStyle,
                            'images'  => $cellImages,
                            'colspan' => $colspan,
                        ];
                    }
                    if (!empty($cells)) {
                        $rows[] = $cells;
                    }
                }
                if (!empty($rows)) {
                    return '<__TABLEBLOCK__>' . base64_encode(json_encode($rows)) . '</__TABLEBLOCK__>';
                }

                return '';
            },
            $html
        );

        $html = preg_replace('/<br\s*\/?>/i', "\n", $html);
        $chunks = preg_split('/<\s*\/\s*(?:p|div)\s*>/i', $html);

        foreach ($chunks as $chunk) {
            $chunk = trim($chunk);
            if ($chunk === '') {
                continue;
            }

            if (strpos($chunk, '<__TABLEBLOCK__>') !== false) {
                preg_match_all('/<__TABLEBLOCK__>(.*?)<\/__TABLEBLOCK__>/s', $chunk, $tbMatches);
                foreach ($tbMatches[1] as $encoded) {
                    $rows = json_decode(base64_decode($encoded), true);
                    if (!empty($rows)) {
                        $blocks[] = ['type' => 'table', 'rows' => $rows, 'text' => '', 'align' => 'L', 'list' => false, 'style' => ''];
                    }
                }
                $chunk = trim(preg_replace('/<__TABLEBLOCK__>.*?<\/__TABLEBLOCK__>/s', '', $chunk));
                if ($chunk === '') {
                    continue;
                }
            }

            $align = 'L';
            if (preg_match('/style\s*=\s*["\'][^"\']*text-align\s*:\s*right/i', $chunk)
                || preg_match('/class\s*=\s*["\'][^"\']*text-right/i', $chunk)) {
                $align = 'R';
            } elseif (preg_match('/style\s*=\s*["\'][^"\']*text-align\s*:\s*center/i', $chunk)
                || preg_match('/class\s*=\s*["\'][^"\']*text-center/i', $chunk)) {
                $align = 'C';
            }

            $fontStyle = '';
            if (preg_match('/<(b|strong)\b/i', $chunk)) {
                $fontStyle .= 'B';
            }
            if (preg_match('/<(i|em)\b/i', $chunk)) {
                $fontStyle .= 'I';
            }

            $waInline = self::tryExtractWaInlineBlock($chunk, $align, $fontStyle);
            if ($waInline !== null) {
                $blocks[] = $waInline;
                continue;
            }

            if (preg_match_all('/<img[^>]+>/i', $chunk, $imgMatches)) {
                foreach ($imgMatches[0] as $imgTag) {
                    if (preg_match('/src\s*=\s*["\']([^"\']+)["\']/', $imgTag, $srcM)) {
                        $iw = 0;
                        $ih = 0;
                        if (preg_match('/width\s*=\s*["\']?(\d+)["\']?/i', $imgTag, $wm)) {
                            $iw = (int) $wm[1];
                        }
                        if (preg_match('/height\s*=\s*["\']?(\d+)["\']?/i', $imgTag, $hm)) {
                            $ih = (int) $hm[1];
                        }
                        $blocks[] = ['type' => 'image', 'src' => $srcM[1], 'width' => $iw, 'height' => $ih, 'text' => '', 'align' => $align, 'list' => false, 'style' => ''];
                    }
                }
            }

            $isList = (strpos($chunk, '<__LISTBLOCK__>') !== false);

            if ($isList) {
                $textParts = [];
                $remaining = preg_replace_callback(
                    '/<__LISTBLOCK__>(.*?)<\/__LISTBLOCK__>/s',
                    static function ($lm) use (&$textParts) {
                        $textParts[] = trim($lm[1]);

                        return '';
                    },
                    $chunk
                );
                $extra = trim(strip_tags(self::expandAnchorHrefsForPdf($remaining)));
                if ($extra !== '') {
                    array_unshift($textParts, $extra);
                }
                $text = implode("\n", $textParts);
            } else {
                $text = strip_tags(self::expandAnchorHrefsForPdf($chunk));
            }

            $text = preg_replace('/[ \t]+/', ' ', $text);
            $text = trim(implode("\n", array_map('trim', explode("\n", $text))));

            if ($text !== '') {
                $blocks[] = ['type' => 'text', 'text' => $text, 'align' => $align, 'list' => $isList, 'style' => $fontStyle];
            }
        }

        if (empty($blocks)) {
            $text = preg_replace('/<__LISTBLOCK__>(.*?)<\/__LISTBLOCK__>/s', '$1', $html);
            $text = strip_tags(self::expandAnchorHrefsForPdf($text));
            $text = trim(preg_replace('/[ \t]+/', ' ', $text));
            if ($text !== '') {
                $blocks[] = ['type' => 'text', 'text' => $text, 'align' => 'L', 'list' => false, 'style' => ''];
            }
        }

        return $blocks;
    }

    /**
     * Resolve an image src (relative URL or root-relative) to an absolute filesystem path.
     *
     * @param   string  $src  Image src attribute value
     *
     * @return  string|null  Absolute path or null if not resolvable
     */
    public static function resolveImagePath($src)
    {
        if ($src === null || $src === '') {
            return null;
        }

        $src = trim((string) $src);
        if ($src === '' || stripos($src, 'data:') === 0) {
            return null;
        }

        // Drop cache-busters and com_media query strings before path mapping.
        $src = preg_replace('/[#?].*$/', '', $src);

        // Absolute filesystem path (rare).
        if (
            isset($src[0])
            && $src[0] === '/'
            && !preg_match('/^https?:\/\//i', $src)
            && strpos($src, '//') !== 0
        ) {
            if (is_file($src)) {
                return $src;
            }
            $underRoot = JPATH_ROOT . '/' . ltrim($src, '/');
            if (is_file($underRoot)) {
                return $underRoot;
            }
        }

        $relative = self::normaliseImageSrcToSiteRelativePath($src);
        if ($relative === null || $relative === '') {
            return null;
        }

        $candidate = JPATH_ROOT . '/' . $relative;

        return is_file($candidate) ? $candidate : null;
    }

    /**
     * Map an img src (relative or absolute URL) to a path under JPATH_ROOT.
     *
     * @param   string  $src  Raw src after query/fragment stripping
     *
     * @return  string|null  Site-relative path (no leading slash) or null
     */
    private static function normaliseImageSrcToSiteRelativePath(string $src): ?string
    {
        if (preg_match('/^https?:\/\//i', $src) || strpos($src, '//') === 0) {
            $normalised = strpos($src, '//') === 0 ? 'https:' . $src : $src;

            foreach (self::candidateSiteRootsForImageSrc() as $root) {
                if ($root !== '' && stripos($normalised, $root) === 0) {
                    $rel = ltrim(substr($normalised, strlen($root)), '/');

                    return self::sanitiseSiteRelativeImagePath($rel);
                }
            }

            $parsed = parse_url($normalised);
            $path   = isset($parsed['path']) ? ltrim((string) $parsed['path'], '/') : '';
            if ($path === '') {
                return null;
            }

            // Web paths under /administrator/… often map to JPATH_ROOT without that prefix.
            if (str_starts_with($path, 'administrator/')) {
                $alt = substr($path, strlen('administrator/'));
                if ($alt !== '' && is_file(JPATH_ROOT . '/' . $alt)) {
                    return self::sanitiseSiteRelativeImagePath($alt);
                }
            }

            return self::sanitiseSiteRelativeImagePath($path);
        }

        return self::sanitiseSiteRelativeImagePath(ltrim($src, '/'));
    }

    /**
     * @return list<string>  Normalised site URL roots (no trailing slash)
     */
    private static function candidateSiteRootsForImageSrc(): array
    {
        $roots = [rtrim(Uri::root(), '/')];

        try {
            $liveSite = rtrim((string) Factory::getApplication()->getConfig()->get('live_site', ''), '/');
            if ($liveSite !== '') {
                $roots[] = $liveSite;
            }
        } catch (\Throwable $e) {
            // Ignore config read failures.
        }

        return array_values(array_unique(array_filter($roots)));
    }

    /**
     * @param   string  $path  Candidate path relative to JPATH_ROOT
     *
     * @return  string|null
     */
    private static function sanitiseSiteRelativeImagePath(string $path): ?string
    {
        $path = str_replace('\\', '/', trim($path));
        if ($path === '' || str_contains($path, '..')) {
            return null;
        }

        return ltrim($path, '/');
    }

    /**
     * Render a list of parsed HTML blocks to an FPDF instance.
     *
     * @param   \FPDF    $pdf       FPDF instance
     * @param   array    $blocks    Block list from parseHtmlBlocks()
     * @param   float    $lineH     Line height in mm
     * @param   int      $fontSize  Font size in pt
     * @param   float    $pageW     Page width in mm
     * @param   float    $marginR   Right margin in mm
     * @param   float    $marginL   Left margin in mm
     * @param   float    $gap       Spacing added after each non-list text block (mm)
     * @param   callable|null $fixSpanishChars  Encoder for FPDF
     * @param   float    $maxWidth  Optional max width in mm; 0 = full width
     */
    public static function renderPdfBlocks($pdf, $blocks, $lineH, $fontSize, $pageW, $marginR, $marginL = 15, $gap = 4, ?callable $fixSpanishChars = null, $maxWidth = 0)
    {
        $encode = $fixSpanishChars ?? static function ($t) {
            return $t;
        };

        $contentStarted = false;

        foreach ($blocks as $block) {
            $type = $block['type'] ?? 'text';

            if ($type === 'image') {
                $imgPath = self::resolveImagePath($block['src'] ?? '');
                if ($imgPath) {
                    $contentStarted = true;
                    $imgWpx = (int) ($block['width'] ?? 0);
                    $imgWmm = $imgWpx > 0 ? min($imgWpx * 0.2646, $pageW - $marginL - $marginR) : 50;
                    $imgHpx = (int) ($block['height'] ?? 0);
                    $imgHmm = $imgHpx > 0 ? $imgHpx * 0.2646 : ($imgWmm * 0.5);
                    $pdf->Image($imgPath, $pdf->GetX(), $pdf->GetY(), $imgWmm);
                    $pdf->SetY($pdf->GetY() + $imgHmm + 2);
                }

                continue;
            }

            if ($type === 'wa_inline') {
                $contentStarted = true;
                $href  = $encode($block['href'] ?? '');
                $label = $encode($block['label'] ?? '');
                $st    = $block['style'] ?? '';
                $align = $block['align'] ?? 'L';
                $pdf->SetFont('Arial', $st, $fontSize);
                $usableW = $pageW - $marginL - $marginR;

                $iconWmm  = 0.0;
                $iconHmm  = $lineH;
                $imgMeta  = $block['img'] ?? null;
                $imgPath  = null;
                if (is_array($imgMeta) && !empty($imgMeta['src'])) {
                    $imgPath = self::resolveImagePath($imgMeta['src']);
                    if ($imgPath) {
                        $imgWpx = (int) ($imgMeta['width'] ?? 0);
                        $iconWmm = $imgWpx > 0 ? min($imgWpx * 0.2646, 6.0) : 4.5;
                        $imgHpx = (int) ($imgMeta['height'] ?? 0);
                        $iconHmm = $imgHpx > 0 ? min($imgHpx * 0.2646, $lineH * 1.2) : $iconWmm;
                    }
                }

                $gapMm  = 1.5;
                $textWid = $pdf->GetStringWidth($label);
                $totalW  = $iconWmm + ($iconWmm > 0 ? $gapMm : 0) + $textWid;

                $rowY = $pdf->GetY();
                if ($align === 'C') {
                    $startX = $marginL + max(0, ($usableW - $totalW) / 2);
                } elseif ($align === 'R') {
                    $startX = max($marginL, $pageW - $marginR - $totalW);
                } else {
                    $startX = $marginL;
                }

                if ($imgPath !== null && $iconWmm > 0) {
                    $pdf->Image($imgPath, $startX, $rowY + max(0, ($lineH - $iconHmm) / 2), $iconWmm);
                }
                $labelX = $startX + $iconWmm + ($iconWmm > 0 ? $gapMm : 0);
                $pdf->SetXY($labelX, $rowY);
                $pdf->Cell(0, $lineH, $label, 0, 0, 'L', false, $href);
                $rowBottom = $rowY + max($lineH, $iconHmm);
                $pdf->SetY($rowBottom);
                if ($gap > 0) {
                    $pdf->Ln($gap);
                }

                continue;
            }

            if ($type === 'table') {
                $contentStarted = true;
                $tableW = ($maxWidth > 0 ? $maxWidth : ($pageW - $marginL - $marginR));
                foreach ($block['rows'] as $row) {
                    $numCols = count($row);
                    if ($numCols === 0) {
                        continue;
                    }
                    $colW = $tableW / $numCols;
                    $rowY = $pdf->GetY();
                    $maxH = $lineH;
                    $curX = $marginL;

                    foreach ($row as $cell) {
                        $cw    = $colW * max(1, (int) ($cell['colspan'] ?? 1));
                        $cellY = $rowY;

                        foreach ($cell['images'] ?? [] as $img) {
                            $imgPath = self::resolveImagePath($img['src'] ?? '');
                            if ($imgPath) {
                                $imgWpx = (int) ($img['width'] ?? 0);
                                $imgWmm = $imgWpx > 0 ? min($imgWpx * 0.2646, $cw - 2) : min(50, $cw - 2);
                                $imgHpx = (int) ($img['height'] ?? 0);
                                $imgHmm = $imgHpx > 0 ? $imgHpx * 0.2646 : ($imgWmm * 0.5);
                                $pdf->Image($imgPath, $curX + 1, $cellY + 1, $imgWmm);
                                $maxH = max($maxH, $imgHmm + 3);
                            }
                        }

                        $cellText = $encode($cell['text'] ?? '');
                        if ($cellText !== '') {
                            $pdf->SetFont('Arial', $cell['style'] ?? '', $fontSize);
                            $pdf->SetXY($curX, $cellY);
                            $pdf->MultiCell($cw, $lineH, $cellText, 0, $cell['align'] ?? 'L');
                            $textH = $pdf->GetY() - $cellY;
                            $maxH  = max($maxH, $textH);
                        }

                        $curX += $cw;
                    }

                    $pdf->SetXY($marginL, $rowY + $maxH);
                }
                $pdf->Ln(2);

                continue;
            }

            if (trim($block['text'] ?? '') === '') {
                if ($contentStarted) {
                    $pdf->Ln($gap);
                }

                continue;
            }

            $contentStarted = true;

            $align  = $block['align'];
            $text   = $encode($block['text']);
            $isList = !empty($block['list']);
            $pdf->SetFont('Arial', $block['style'] ?? '', $fontSize);

            $textW = ($maxWidth > 0 ? $maxWidth : 0);
            if ($align === 'R') {
                foreach (explode("\n", $text) as $line) {
                    $line = trim($line);
                    if ($line === '') {
                        continue;
                    }
                    $w = $pdf->GetStringWidth($line);
                    $pdf->SetX($pageW - $marginR - $w);
                    $pdf->Cell($w, $lineH, $line, 0, 1, 'L');
                }
            } elseif ($align === 'L' && preg_match('#https?://#i', $text)) {
                self::renderLatin1TextLinesWithHttpLinks($pdf, $text, $lineH, $textW);
            } else {
                $pdf->MultiCell($textW, $lineH, $text, 0, $align);
            }
            $pdf->Ln($isList ? 1 : $gap);
        }
    }

    /**
     * Strip outer &lt;p&gt;/&lt;div&gt; wrappers TinyMCE adds so img+anchor sit in one detectable fragment.
     *
     * @since   3.113.43
     */
    private static function normalizeChunkForWaInline(string $chunk): string
    {
        $work = trim($chunk);
        for ($i = 0; $i < 5; $i++) {
            $before = $work;
            $work = preg_replace('#^<\s*p\b[^>]*>\s*#iu', '', $work);
            $work = preg_replace('#\s*</\s*p\s*>$#iu', '', $work);
            $work = preg_replace('#^<\s*div\b[^>]*>\s*#iu', '', $work);
            $work = preg_replace('#\s*</\s*div\s*>$#iu', '', $work);
            $work = trim($work);
            if ($work === $before) {
                break;
            }
        }

        return $work;
    }

    /**
     * Single-line WhatsApp control: optional one &lt;img&gt; + one wa.me (or api.whatsapp.com) &lt;a&gt;; used for PDF.
     *
     * @return  array<string, mixed>|null
     *
     * @since   3.113.42
     */
    private static function tryExtractWaInlineBlock(string $chunk, string $align, string $fontStyle): ?array
    {
        $chunk = self::normalizeChunkForWaInline(trim($chunk));
        if ($chunk === '') {
            return null;
        }

        $imgMeta = null;
        if (preg_match_all('#<img[^>]+>#i', $chunk, $imgMatches)) {
            $nImg = count($imgMatches[0]);
            if ($nImg > 1) {
                return null;
            }
            if ($nImg === 1) {
                $imgTag = $imgMatches[0][0];
                if (preg_match('/src\s*=\s*["\']([^"\']+)["\']/', $imgTag, $srcM)) {
                    $iw = 0;
                    $ih = 0;
                    if (preg_match('/width\s*=\s*["\']?(\d+)["\']?/i', $imgTag, $wm)) {
                        $iw = (int) $wm[1];
                    }
                    if (preg_match('/height\s*=\s*["\']?(\d+)["\']?/i', $imgTag, $hm)) {
                        $ih = (int) $hm[1];
                    }
                    $imgMeta = ['src' => $srcM[1], 'width' => $iw, 'height' => $ih];
                }
            }
        }

        $chunkNoImg = preg_replace('#<img[^>]+>#i', '', $chunk);
        $chunkNoImg = trim($chunkNoImg);
        if ($chunkNoImg === '' || !preg_match('#<\s*a\s#i', $chunkNoImg)) {
            return null;
        }

        $linkRe = '#<\s*a\s[^>]*\bhref\s*=\s*(["\'])(https://(?:wa\.me/[^"\']+|api\.whatsapp\.com/send\?[^"\']+))\1[^>]*>([\s\S]*?)</a>#i';
        if (!preg_match_all($linkRe, $chunkNoImg, $waAll, PREG_SET_ORDER) || count($waAll) !== 1) {
            return null;
        }

        $temp = preg_replace($linkRe, '', $chunkNoImg, 1);
        $temp = trim(strip_tags($temp ?? ''));

        if ($temp !== '') {
            return null;
        }

        $only  = $waAll[0];
        $href  = html_entity_decode(trim($only[2]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $label = trim(html_entity_decode($only[3], ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        if ($label === '') {
            $label = $href;
        }

        return [
            'type'   => 'wa_inline',
            'img'    => $imgMeta,
            'href'   => $href,
            'label'  => $label,
            'align'  => $align,
            'list'   => false,
            'style'  => $fontStyle,
            'text'   => '',
        ];
    }

    /**
     * FPDF strips &lt;a&gt; to inner text only; editors often keep a shortened label while href is correct.
     * Replace each anchor with href text when it is a WhatsApp URL, when inner is empty, or when inner is
     * a strict prefix of href (truncated URL in the label). Preserves full &lt;a&gt; when label is the formatted number.
     *
     * @param   string  $html  HTML fragment
     *
     * @return  string
     *
     * @since   3.113.40
     */
    public static function expandAnchorHrefsForPdf(string $html): string
    {
        if ($html === '' || stripos($html, '<a') === false) {
            return $html;
        }
        $out = preg_replace_callback(
            '/<\s*a\b[^>]*\bhref\s*=\s*(["\'])([^"\']*)\1[^>]*>(.*?)<\s*\/\s*a\s*>/is',
            static function (array $m): string {
                $href = html_entity_decode(trim($m[2]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $href = trim($href);
                $inner = trim(html_entity_decode(strip_tags($m[3]), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
                if ($href === '') {
                    return $inner;
                }
                if (preg_match('#^https?://(wa\.me/|api\.whatsapp\.com/)#i', $href)) {
                    if ($inner !== '') {
                        $innerNorm = rtrim($inner, '/');
                        $hrefNorm  = rtrim($href, '/');
                        $truncated = $innerNorm !== '' && strlen($hrefNorm) > strlen($innerNorm)
                            && stripos($hrefNorm, $innerNorm) === 0;
                        if ($truncated) {
                            return $href;
                        }

                        return $m[0];
                    }

                    return $href;
                }
                if (preg_match('#^https?://#i', $href)) {
                    if ($inner === '') {
                        return $href;
                    }
                    $innerNorm = rtrim($inner, '/');
                    $hrefNorm  = rtrim($href, '/');
                    if ($innerNorm !== '' && stripos($hrefNorm, $innerNorm) === 0 && strlen($hrefNorm) > strlen($innerNorm)) {
                        return $href;
                    }
                }

                return $inner !== '' ? $inner : $href;
            },
            $html
        );

        return $out !== null ? $out : $html;
    }

    /**
     * Left-aligned Latin-1 text with clickable http(s) segments (FPDF Write).
     *
     * @param   \FPDF   $pdf
     * @param   string  $latin1Text  Already passed through encodeTextForFpdf
     *
     * @since   3.113.40
     */
    private static function renderLatin1TextLinesWithHttpLinks(\FPDF $pdf, string $latin1Text, float $lineH, float $textW): void
    {
        $lines = explode("\n", $latin1Text);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') {
                $pdf->Ln($lineH);

                continue;
            }
            if (!preg_match('#https?://#i', $line)) {
                $pdf->MultiCell($textW, $lineH, $line, 0, 'L');

                continue;
            }
            $parts = preg_split('#(https?://[^\s]+)#i', $line, -1, PREG_SPLIT_DELIM_CAPTURE);
            if ($parts === false) {
                $pdf->MultiCell($textW, $lineH, $line, 0, 'L');

                continue;
            }
            foreach ($parts as $j => $part) {
                if ($part === '') {
                    continue;
                }
                $isUrl = ($j % 2 === 1);
                if ($isUrl) {
                    $pdf->SetTextColor(0, 0, 255);
                    $pdf->Write($lineH, $part, $part);
                    $pdf->SetTextColor(0, 0, 0);
                } else {
                    $pdf->Write($lineH, $part, '');
                }
            }
            $pdf->Ln($lineH);
        }
    }
}
