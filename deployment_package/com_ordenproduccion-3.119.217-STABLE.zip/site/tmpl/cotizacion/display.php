<?php
/**
 * Read-only display of a single quotation (view).
 *
 * @package     com_ordenproduccion
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Grimpsa\Component\Ordenproduccion\Site\Helper\CotizacionHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;
use Grimpsa\Component\Ordenproduccion\Site\Helper\AccessHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\ApprovalWorkflowEntityHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\FelInvoiceHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\QuotationLineImagesHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\CertificadorFactNitLookupHelper;
use Grimpsa\Component\Ordenproduccion\Site\Service\ApprovalWorkflowService;
use Grimpsa\Component\Ordenproduccion\Site\Service\FelInvoiceIssuanceService;

$l = function($key, $fallbackEn, $fallbackEs = null) {
    $t = Text::_($key);
    if ($t === $key || (is_string($t) && strpos($t, 'COM_ORDENPRODUCCION_') === 0)) {
        $lang = Factory::getApplication()->getLanguage()->getTag();
        return (strpos($lang, 'es') !== false && $fallbackEs !== null) ? $fallbackEs : $fallbackEn;
    }
    return $t;
};

$quotation = $this->quotation ?? null;
$items = $this->quotationItems ?? [];
$quotationId = $quotation ? (int) $quotation->id : 0;
if (!$quotation) {
    echo '<p class="text-muted p-3">' . htmlspecialchars($l('COM_ORDENPRODUCCION_QUOTATION_NOT_FOUND', 'Quotation not found.', 'Cotización no encontrada.')) . '</p>';
    return;
}

$currentUserCot = Factory::getUser();
$withdrawApprovalPostUrl = Route::_('index.php?option=com_ordenproduccion&task=cotizacion.withdrawCotizacionPendingApproval', false);
$uploadOrdenCompraPostUrl = Route::_('index.php?option=com_ordenproduccion&task=cotizacion.uploadOrdenCompraFacturacion', false);

$totalAmount = isset($quotation->total_amount) ? (float) $quotation->total_amount : 0;
$currency = $quotation->currency ?? 'Q';
$quotationConfirmed = isset($quotation->cotizacion_confirmada) && (int) $quotation->cotizacion_confirmada === 1;
$quotationLockedByOrdenTrabajo = !empty($this->quotationHasActiveOrdenTrabajo);
$pendingCotizacionConfirmation = $this->pendingCotizacionConfirmation ?? null;
if (!$quotationConfirmed && $quotationLockedByOrdenTrabajo) {
    $quotationConfirmed = true;
}
$quotationHasLinkedPreCotizacion = !empty($this->quotationHasLinkedPreCotizacion);
$wizClientIdTrimForOt = isset($quotation->client_id) ? trim((string) $quotation->client_id) : '';
$wizClientNumericForOt = $wizClientIdTrimForOt !== '' && ctype_digit($wizClientIdTrimForOt);
$editLockedHint = $l('COM_ORDENPRODUCCION_QUOTATION_LOCKED_EDIT_HINT', 'Cannot edit: quotation is confirmed.', 'No se puede editar: la cotización está confirmada.');
$editLockedHintOt = $l('COM_ORDENPRODUCCION_QUOTATION_LOCKED_EDIT_HINT_OT', 'Cannot edit: this quotation has an active work order.', 'No se puede editar: la cotización tiene una orden de trabajo activa.');
$pathCotAprobada = isset($quotation->cotizacion_aprobada_path) ? trim((string) $quotation->cotizacion_aprobada_path) : '';
$instruccionesFacturacionValue = isset($quotation->instrucciones_facturacion) ? (string) $quotation->instrucciones_facturacion : '';
$facturacionModoValue = isset($quotation->facturacion_modo) ? trim((string) $quotation->facturacion_modo) : '';
if ($facturacionModoValue !== 'fecha_especifica' && $facturacionModoValue !== 'con_envio') {
    $facturacionModoValue = 'con_envio';
}
$facturacionFechaValue = '';
if (!empty($quotation->facturacion_fecha)) {
    try {
        $facturacionFechaValue = (new \DateTime($quotation->facturacion_fecha))->format('Y-m-d');
    } catch (\Throwable $e) {
        $facturacionFechaValue = '';
    }
}
$facturarCotizacionExacta = isset($quotation->facturar_cotizacion_exacta) ? (int) $quotation->facturar_cotizacion_exacta : 1;
if ($facturarCotizacionExacta !== 0) {
    $facturarCotizacionExacta = 1;
}

$requiereOcParaFacturarView = isset($quotation->requiere_orden_compra_para_facturar)
    && (int) $quotation->requiere_orden_compra_para_facturar === 1;
$pendingFactManualView = $this->pendingCotizacionFacturacionManual ?? null;
$showOcUploadOnCotizacionView = $requiereOcParaFacturarView || $pendingFactManualView !== null;
$pathOrdenCompraView = isset($quotation->orden_compra_path) ? trim((string) $quotation->orden_compra_path) : '';
$ocFilePublicUrl     = '';
$ocFileViewKind      = 'pdf';
if ($pathOrdenCompraView !== '') {
    $ocFilePublicUrl = rtrim(Uri::root(), '/') . '/' . ltrim(str_replace('\\', '/', $pathOrdenCompraView), '/');
    $ocExt           = strtolower(pathinfo($pathOrdenCompraView, PATHINFO_EXTENSION));
    if (in_array($ocExt, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) {
        $ocFileViewKind = 'image';
    }
}
$ocPdfUploadedForFel           = $pathOrdenCompraView !== ''
    && strtolower(pathinfo($pathOrdenCompraView, PATHINFO_EXTENSION)) === 'pdf';
$digifactDirectBlockedByOcPdf = $requiereOcParaFacturarView && !$ocPdfUploadedForFel;

$itemsWithLineDetalles = $this->itemsWithLineDetalles ?? [];
$ordenesPorPre = isset($this->ordenesPorPreCotizacionId) && is_array($this->ordenesPorPreCotizacionId) ? $this->ordenesPorPreCotizacionId : [];
$pliegoPaperTypesIo = $this->pliegoPaperTypesModal ?? [];
$pliegoSizesIo = $this->pliegoSizesModal ?? [];
$elementosIo = $this->elementosModal ?? [];
$lineDetallesTableOk = true;
$precotMdlInstr = Factory::getApplication()->bootComponent('com_ordenproduccion')->getMVCFactory()
    ->createModel('Precotizacion', 'Site', ['ignore_request' => true]);
if ($precotMdlInstr) {
    $lineDetallesTableOk = $precotMdlInstr->lineDetallesTableExists();
}
$instruccionesSaveJsonUrl = Route::_('index.php?option=com_ordenproduccion&task=cotizacion.saveInstruccionesOrden&format=json', false);
$instruccionesSavedMsgJs = json_encode(Text::_('COM_ORDENPRODUCCION_INSTRUCCIONES_ORDEN_SAVED_FOR_LATER'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
$instruccionesJsErrNoForm = json_encode($l('COM_ORDENPRODUCCION_INSTRUCCIONES_MODAL_NO_FORM', 'Could not find the form for this pre-quotation.', 'No se encontró el formulario para esta pre-cotización.'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
$instruccionesJsErrSave = json_encode($l('COM_ORDENPRODUCCION_INSTRUCCIONES_MODAL_SAVE_ERROR', 'Could not save instructions.', 'No se pudieron guardar las instrucciones.'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
$instruccionesJsErrNet = json_encode($l('COM_ORDENPRODUCCION_INSTRUCCIONES_MODAL_NETWORK_ERROR', 'Network error. Try again.', 'Error de red. Intente de nuevo.'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

$paperNamesIo = [];
foreach ($pliegoPaperTypesIo as $p) {
    $paperNamesIo[(int) $p->id] = $p->name ?? '';
}
$sizeNamesIo = [];
foreach ($pliegoSizesIo as $s) {
    $sizeNamesIo[(int) $s->id] = $s->name ?? '';
}
$elementosByIdIo = [];
foreach ($elementosIo as $el) {
    $elementosByIdIo[(int) $el->id] = $el;
}
$instruccionesModalCanSave = $lineDetallesTableOk && !empty($itemsWithLineDetalles);

$felEngineAvailable = !empty($this->felEngineAvailable);
$felInv = isset($this->felInvoiceForQuotation) ? $this->felInvoiceForQuotation : null;
$felStatus = $felInv ? (string) ($felInv->fel_issue_status ?? '') : '';
$felInvoicesForQuotation = isset($this->felInvoicesForQuotation) && is_array($this->felInvoicesForQuotation) ? $this->felInvoicesForQuotation : [];
$felInvoicedCompletedTotal = 0.0;
$factManInvoicingFullyCovered = false;
$factManHasCompletedInvoice = false;
$factManShouldCloseApproval = false;
if ($quotation) {
    $felProgress = ApprovalWorkflowEntityHelper::getFacturacionManualInvoicingProgress(
        Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class),
        $quotationId
    );
    $felInvoicedCompletedTotal    = (float) ($felProgress['invoiced_completed'] ?? 0.0);
    $factManInvoicingFullyCovered = !empty($felProgress['is_fully_invoiced']);
    $factManHasCompletedInvoice   = !empty($felProgress['has_completed_invoice']);
    $factManShouldCloseApproval   = !empty($felProgress['should_close_fact_man_approval']);
}
$canCompleteFactManApproval = $factManShouldCloseApproval
    && AccessHelper::canViewApprovalWorkflowTab();
$completeFactManApprovalUrl = Route::_('index.php?option=com_ordenproduccion&task=cotizacion.completeFacturacionManualIfInvoiced', false);

$blinkPaymentTableAvailable = !empty($this->blinkPaymentTableAvailable);
$blinkPaymentAvailable = !empty($this->blinkPaymentAvailable);
$canShowPayLinkSection = $blinkPaymentTableAvailable && AccessHelper::isInStrictAdministracionGroup();

$blinkPaymentsForQuotation = is_array($this->blinkPaymentsForQuotation ?? null) ? $this->blinkPaymentsForQuotation : [];
$blinkInstallmentOptions = is_array($this->blinkInstallmentOptions ?? null) ? $this->blinkInstallmentOptions : [0 => 'VC00'];
$blinkPaymentLinkState = is_array($this->blinkPaymentLinkState ?? null) ? $this->blinkPaymentLinkState : [];
$blinkShowCreateButton = !empty($blinkPaymentLinkState['show_button']);
$blinkCuotasMismatch = !empty($blinkPaymentLinkState['show_cuotas_mismatch']);
$blinkPayReference = (string) ($blinkPaymentLinkState['reference'] ?? '');
$blinkPayTitle = (string) ($blinkPaymentLinkState['title'] ?? '');
$blinkPayMonto = round((float) ($blinkPaymentLinkState['monto'] ?? ($quotation->total_amount ?? 0)), 2);
$blinkPayCuotasLabel = (string) ($blinkPaymentLinkState['cuotas_label'] ?? '');
$blinkQuotationTotal = round((float) ($quotation->total_amount ?? 0), 2);
$blinkCreateJsonUrl = Route::_('index.php?option=com_ordenproduccion&task=cotizacion.createBlinkPayment&format=json', false);

$felForDirectCheck = new FelInvoiceIssuanceService();
$digifactCredsCheck = $felForDirectCheck->getActiveCertificadorCredentials();
$canSeeFacturaRelacionadaSection = $felEngineAvailable
    && (AccessHelper::isInStrictAdministracionGroup() || AccessHelper::isSuperUser());
$canDigifactEmitPermission = AccessHelper::isInStrictAdministracionGroup() || AccessHelper::isSuperUser();
$digifactCfgOk = (trim((string) ($digifactCredsCheck['url_cert_cf'] ?? '')) !== ''
    || trim((string) ($digifactCredsCheck['url_cert_nit'] ?? '')) !== '')
    && $felForDirectCheck->getActiveCertificadorBearerToken() !== '';
$canDigifactDirectIssue = $canSeeFacturaRelacionadaSection && $canDigifactEmitPermission && $digifactCfgOk;
// Factura manual: Administración group (and super users) only; same certificador gate as direct Digifact.
$canManualFelIssue = (AccessHelper::isInStrictAdministracionGroup() || AccessHelper::isSuperUser())
    && $felEngineAvailable
    && $digifactCfgOk
    && (!empty($items) || !empty($this->manualFelSeedFromInvoice));
$digifactDirectUrl = Route::_('index.php?option=com_ordenproduccion&task=cotizacion.digifactIssueDirectFromQuotation&format=json', false);
$digifactLinesSaveUrl = Route::_('index.php?option=com_ordenproduccion&task=cotizacion.saveQuotationLinesForFelDigifact&format=json', false);
$digifactQuotBillingIsCf = CertificadorFactNitLookupHelper::billingIdIndicatesConsumidorFinal(trim((string) ($quotation->client_nit ?? '')));
$digifactVerifyCuiUrl = Route::_('index.php?option=com_ordenproduccion&task=cliente.verifyDigifactCui&format=json', false);
$digifactBuyerNameInitial = trim((string) ($quotation->client_name ?? ''));
$manualFelIssueUrl = Route::_('index.php?option=com_ordenproduccion&task=cotizacion.manualFelIssueFromQuotation&format=json', false);
$manualFelPreviewUrl = Route::_('index.php?option=com_ordenproduccion&task=cotizacion.manualFelPreviewFromQuotation&format=json', false);
$manualFelBillingIsCf = $digifactQuotBillingIsCf;
$manualBuyerNameInitial = $digifactBuyerNameInitial;
$manualBuyerNitInitial = trim((string) ($quotation->client_nit ?? ''));
$manualFelQuotationRef = trim((string) ($quotation->quotation_number ?? ''));
if ($manualFelQuotationRef === '') {
    $manualFelQuotationRef = 'COT-' . $quotationId;
}
$manualFelLinePresets = isset($this->manualFelLinePresets) && is_array($this->manualFelLinePresets) ? $this->manualFelLinePresets : [];
$manualFelOrdensForClient = isset($this->manualFelOrdensForClient) && is_array($this->manualFelOrdensForClient) ? $this->manualFelOrdensForClient : [];
$manualFelOtherQuotations = isset($this->manualFelOtherQuotations) && is_array($this->manualFelOtherQuotations) ? $this->manualFelOtherQuotations : [];
$manualFelLinesUrl = Route::_('index.php?option=com_ordenproduccion&task=cotizacion.manualFelQuotationLines&format=json', false);
$manualFelExchangeRateUrl = Route::_('index.php?option=com_ordenproduccion&task=cotizacion.manualFelExchangeRate&format=json', false);
$manualFelIssueDateDefault = Factory::getDate('now', 'America/Guatemala')->format('Y-m-d');
$manualFelSeedFromInvoice = isset($this->manualFelSeedFromInvoice) && \is_array($this->manualFelSeedFromInvoice)
    ? $this->manualFelSeedFromInvoice
    : null;
if (\is_array($manualFelSeedFromInvoice) && !empty($manualFelSeedFromInvoice['buyer_name'])) {
    $manualBuyerNameInitial = trim((string) $manualFelSeedFromInvoice['buyer_name']);
}
if (\is_array($manualFelSeedFromInvoice) && !empty($manualFelSeedFromInvoice['buyer_nit'])) {
    $manualBuyerNitInitial = trim((string) $manualFelSeedFromInvoice['buyer_nit']);
}
if (\is_array($manualFelSeedFromInvoice) && trim((string) ($manualFelSeedFromInvoice['observaciones'] ?? '')) !== '') {
    $manualFelQuotationRef = trim((string) $manualFelSeedFromInvoice['observaciones']);
}
?>
<div class="cotizacion-container cotizacion-display">
    <div class="cotizaciones-header d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <h2 class="mb-0">
            <i class="fas fa-file-invoice"></i>
            <?php echo htmlspecialchars($quotation->quotation_number ?? ('COT-' . $quotationId)); ?>
        </h2>
        <div class="d-flex gap-2">
            <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=cotizaciones'); ?>" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i>
                <?php echo $l('COM_ORDENPRODUCCION_BACK_TO_LIST', 'Back to list', 'Volver a la lista'); ?>
            </a>
            <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&task=cotizacion.downloadPdf&id=' . $quotationId); ?>" class="btn btn-success" target="_blank">
                <i class="fas fa-file-pdf"></i>
                <?php echo $l('COM_ORDENPRODUCCION_GENERATE_PDF', 'Generate PDF', 'Generar PDF'); ?>
            </a>
            <?php if ($quotationConfirmed || $quotationLockedByOrdenTrabajo) : ?>
            <span class="btn btn-secondary disabled" tabindex="-1" style="opacity: 0.65; cursor: not-allowed;" title="<?php echo htmlspecialchars($quotationLockedByOrdenTrabajo ? $editLockedHintOt : $editLockedHint); ?>">
                <i class="fas fa-edit"></i>
                <?php echo $l('COM_ORDENPRODUCCION_EDIT', 'Edit', 'Editar'); ?>
            </span>
            <?php else : ?>
            <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=cotizacion&id=' . $quotationId . '&layout=edit'); ?>" class="btn btn-primary">
                <i class="fas fa-edit"></i>
                <?php echo $l('COM_ORDENPRODUCCION_EDIT', 'Edit', 'Editar'); ?>
            </a>
            <?php endif; ?>
        </div>
    </div>

    <?php
    $pendingFactManual = $this->pendingCotizacionFacturacionManual ?? null;
    if ($pendingFactManual) :
        $pmMeta   = [];
        $pmRaw    = isset($pendingFactManual->metadata) ? trim((string) $pendingFactManual->metadata) : '';
        if ($pmRaw !== '') {
            $dec = json_decode($pmRaw, true);
            $pmMeta = \is_array($dec) ? $dec : [];
        }
        $pmInstr = isset($pmMeta['instrucciones_facturacion']) ? trim((string) $pmMeta['instrucciones_facturacion']) : '';
        if ($pmInstr === '') {
            $pmInstr = trim($instruccionesFacturacionValue);
        }
        $canWithdrawFactManual = !$currentUserCot->guest && AccessHelper::userCanWithdrawCotizacionApprovalRequest(
            $quotation,
            (int) ($pendingFactManual->submitter_id ?? 0)
        );
        $withdrawManualConfirmJs = json_encode($l(
            'COM_ORDENPRODUCCION_COTIZACION_WITHDRAW_MANUAL_JS_CONFIRM',
            'Withdraw this request? You can edit the quotation and submit confirmation again.',
            '¿Retirar esta solicitud? Podrá editar la cotización y volver a confirmar.'
        ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
        ?>
    <div class="alert alert-warning border mb-3" role="status">
        <div class="d-flex flex-wrap justify-content-between align-items-start gap-2">
            <div class="flex-grow-1 min-w-0">
                <strong><i class="fas fa-file-invoice-dollar me-1"></i><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_FACTURACION_MANUAL_APPROVAL_BANNER_TITLE', 'Manual invoicing pending approval', 'Facturación manual — aprobación pendiente')); ?></strong>
                <div class="small mt-1"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_FACTURACION_MANUAL_APPROVAL_BANNER_DESC', 'Review the billing instructions stored on this quotation. Approve or reject from Administration → Approvals.', 'Revise las instrucciones de facturación de esta cotización. Apruebe o rechace desde Administración → Aprobaciones.')); ?></div>
                <?php if ($factManInvoicingFullyCovered && $felInvoicedCompletedTotal > 0) : ?>
                <p class="small text-success mb-0 mt-2">
                    <i class="fas fa-check-circle me-1"></i>
                    <?php echo htmlspecialchars($l(
                        'COM_ORDENPRODUCCION_FACTURACION_MANUAL_INVOICED_READY_HINT',
                        'Completed invoices cover this quotation total. You can close the approval without issuing more invoices.',
                        'Las facturas completadas cubren el total de la cotización. Puede cerrar la aprobación sin emitir más facturas.'
                    )); ?>
                    (Q <?php echo number_format($felInvoicedCompletedTotal, 2); ?> / Q <?php echo number_format($totalAmount, 2); ?>)
                </p>
                <?php elseif ($factManHasCompletedInvoice) : ?>
                <p class="small text-success mb-0 mt-2">
                    <i class="fas fa-check-circle me-1"></i>
                    <?php echo htmlspecialchars($l(
                        'COM_ORDENPRODUCCION_FACTURACION_MANUAL_INVOICE_ASSOCIATED_HINT',
                        'This quotation already has a completed related invoice. The manual invoicing approval can be closed.',
                        'Esta cotización ya tiene una factura relacionada completada. Puede cerrar la aprobación de facturación manual.'
                    )); ?>
                </p>
                <?php endif; ?>
                <?php if ($pmInstr !== '') : ?>
                <div class="mt-2 mb-0">
                    <div class="fw-semibold small text-uppercase text-muted mb-1"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_CONFIRMAR_STEP2_TITLE', 'Billing instructions', 'Instrucciones de facturación')); ?></div>
                    <div class="border rounded bg-white p-2 small text-break"><?php echo nl2br(htmlspecialchars($pmInstr, ENT_QUOTES, 'UTF-8')); ?></div>
                </div>
                <?php endif; ?>
                <?php if ($digifactDirectBlockedByOcPdf || ($showOcUploadOnCotizacionView && $pathOrdenCompraView === '')) : ?>
                <p class="mb-0 mt-2 text-danger" style="font-size: calc(16px + 2pt);"><?php echo htmlspecialchars($l(
                    'COM_ORDENPRODUCCION_OC_PDF_PENDING_LABEL',
                    'Purchase order PDF pending attachment',
                    'Orden de compra pendiente de adjuntar'
                )); ?></p>
                <?php endif; ?>
                <?php if ($showOcUploadOnCotizacionView) : ?>
                <div class="mt-3 pt-2 border-top">
                    <div class="fw-semibold small text-uppercase text-muted mb-1"><?php echo htmlspecialchars($l(
                        'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_UPLOAD_LABEL',
                        'Purchase order file',
                        'Archivo de orden de compra'
                    )); ?></div>
                    <?php if ($pathOrdenCompraView !== '') : ?>
                    <div class="mb-2 small d-flex flex-wrap align-items-center gap-2">
                        <span class="text-muted"><?php echo htmlspecialchars($l(
                            'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_CURRENT_FILE',
                            'Current file',
                            'Archivo actual'
                        )); ?>:</span>
                        <a href="<?php echo htmlspecialchars($ocFilePublicUrl); ?>" target="_blank" rel="noopener noreferrer" class="text-break"><?php echo htmlspecialchars(basename($pathOrdenCompraView)); ?></a>
                        <button type="button" class="btn btn-outline-secondary btn-sm py-0 px-2 cotizacion-confirm-file-view"
                            data-file-url="<?php echo htmlspecialchars($ocFilePublicUrl); ?>"
                            data-file-kind="<?php echo htmlspecialchars($ocFileViewKind); ?>"
                            title="<?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_OC_VIEWER_OPEN', 'View in window', 'Ver en ventana')); ?>">
                            <i class="fas fa-eye" aria-hidden="true"></i>
                            <span class="visually-hidden"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_OC_VIEWER_OPEN', 'View in window', 'Ver en ventana')); ?></span>
                        </button>
                    </div>
                    <?php endif; ?>
                    <?php if ($currentUserCot->guest) : ?>
                    <p class="small text-muted mb-0"><?php echo htmlspecialchars($l(
                        'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_LOGIN_TO_UPLOAD',
                        'Log in to upload or replace the purchase order file.',
                        'Inicie sesión para subir o reemplazar el archivo de orden de compra.'
                    )); ?></p>
                    <?php else : ?>
                    <form method="post" action="<?php echo htmlspecialchars($uploadOrdenCompraPostUrl); ?>" enctype="multipart/form-data" class="mt-1">
                        <?php echo HTMLHelper::_('form.token'); ?>
                        <input type="hidden" name="id" value="<?php echo (int) $quotationId; ?>">
                        <div class="d-flex flex-wrap align-items-end gap-2">
                            <div class="flex-grow-1" style="min-width: 12rem;">
                                <label for="orden_compra_facturacion_file_banner" class="visually-hidden"><?php echo htmlspecialchars($l(
                                    'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_UPLOAD_LABEL',
                                    'Purchase order file',
                                    'Archivo de orden de compra'
                                )); ?></label>
                                <input type="file" name="orden_compra" id="orden_compra_facturacion_file_banner" class="form-control form-control-sm" accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png"<?php echo $pathOrdenCompraView === '' ? ' required' : ''; ?>>
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm flex-shrink-0"><?php echo htmlspecialchars($l(
                                'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_SAVE',
                                'Upload',
                                'Subir'
                            )); ?></button>
                        </div>
                        <div class="form-text"><?php echo htmlspecialchars($l(
                            'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_UPLOAD_HELP',
                            'PDF, JPG or PNG — max 5 MB. Upload again to replace the file.',
                            'PDF, JPG o PNG — máx. 5 MB. Suba otro archivo para reemplazar.'
                        )); ?></div>
                    </form>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="d-flex flex-column flex-shrink-0 gap-2 align-items-stretch">
            <?php if ($canCompleteFactManApproval && !empty($pendingFactManual)) : ?>
            <form method="post" action="<?php echo htmlspecialchars($completeFactManApprovalUrl); ?>" class="mb-0" onsubmit="return confirm(<?php echo json_encode($l(
                'COM_ORDENPRODUCCION_FACTURACION_MANUAL_COMPLETE_JS_CONFIRM',
                'Close this manual invoicing approval? A completed invoice is already linked to this quotation.',
                '¿Cerrar esta aprobación de facturación manual? Ya hay una factura completada vinculada a esta cotización.'
            ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>);">
                <?php echo HTMLHelper::_('form.token'); ?>
                <input type="hidden" name="id" value="<?php echo (int) $quotationId; ?>">
                <button type="submit" class="btn btn-success btn-sm">
                    <i class="fas fa-check me-1"></i>
                    <?php echo htmlspecialchars($l(
                        'COM_ORDENPRODUCCION_FACTURACION_MANUAL_COMPLETE_BTN',
                        'Close approval (invoiced)',
                        'Cerrar aprobación (facturado)'
                    )); ?>
                </button>
            </form>
            <?php endif; ?>
            <?php if ($canWithdrawFactManual) : ?>
            <form method="post" action="<?php echo htmlspecialchars($withdrawApprovalPostUrl); ?>" class="mb-0" onsubmit="return confirm(<?php echo $withdrawManualConfirmJs; ?>);">
                <?php echo HTMLHelper::_('form.token'); ?>
                <input type="hidden" name="id" value="<?php echo (int) $quotationId; ?>">
                <input type="hidden" name="approval_kind" value="facturacion_manual">
                <button type="submit" class="btn btn-outline-danger btn-sm">
                    <?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_COTIZACION_BTN_RECHAZAR_SOLICITUD', 'Reject', 'Rechazar')); ?>
                </button>
            </form>
            <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php
    $pendingConfirmAppr = $pendingCotizacionConfirmation;
    if ($pendingConfirmAppr) :
        $canWithdrawConfirmAppr = !$currentUserCot->guest && AccessHelper::userCanWithdrawCotizacionApprovalRequest(
            $quotation,
            (int) ($pendingConfirmAppr->submitter_id ?? 0)
        );
        $withdrawConfirmJs = json_encode($l(
            'COM_ORDENPRODUCCION_COTIZACION_WITHDRAW_CONFIRMATION_JS_CONFIRM',
            'Withdraw this confirmation request? You can edit the quotation and confirm again.',
            '¿Retirar la solicitud de confirmación? Podrá editar la cotización y volver a confirmar.'
        ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    ?>
    <div class="alert alert-info border mb-3" role="status">
        <div class="d-flex flex-wrap justify-content-between align-items-start gap-2">
            <div class="flex-grow-1 min-w-0">
                <strong><i class="fas fa-hourglass-half me-1"></i><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_COTIZACION_CONFIRMATION_PENDING_BANNER_TITLE', 'Quotation confirmation pending approval', 'Confirmación de cotización — aprobación pendiente')); ?></strong>
                <div class="small mt-1"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_COTIZACION_CONFIRMATION_PENDING_BANNER_DESC', 'Waiting for an approver. You can withdraw to change the quotation and submit again.', 'En espera de un aprobador. Puede rechazar la solicitud para modificar la cotización y volver a enviar.')); ?></div>
            </div>
            <?php if ($canWithdrawConfirmAppr) : ?>
            <form method="post" action="<?php echo htmlspecialchars($withdrawApprovalPostUrl); ?>" class="flex-shrink-0" onsubmit="return confirm(<?php echo $withdrawConfirmJs; ?>);">
                <?php echo HTMLHelper::_('form.token'); ?>
                <input type="hidden" name="id" value="<?php echo (int) $quotationId; ?>">
                <input type="hidden" name="approval_kind" value="cotizacion_confirmation">
                <button type="submit" class="btn btn-outline-danger btn-sm">
                    <?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_COTIZACION_BTN_RECHAZAR_SOLICITUD', 'Reject', 'Rechazar')); ?>
                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Client Information -->
    <div class="client-info-section mb-4">
        <h4 class="section-title">
            <i class="fas fa-user"></i>
            <?php echo $l('COM_ORDENPRODUCCION_CLIENT_INFORMATION', 'Client Information', 'Información del cliente'); ?>
        </h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th style="width: 20%;"><?php echo $l('COM_ORDENPRODUCCION_CLIENT_NAME', 'Client Name', 'Nombre del cliente'); ?></th>
                    <th style="width: 15%;"><?php echo $l('COM_ORDENPRODUCCION_CLIENT_ID_API', 'Client ID (API)', 'Client ID (API)'); ?></th>
                    <th style="width: 15%;"><?php echo $l('COM_ORDENPRODUCCION_NIT', 'Tax ID (NIT)', 'NIT'); ?></th>
                    <th style="width: 30%;"><?php echo $l('COM_ORDENPRODUCCION_ADDRESS', 'Address', 'Dirección'); ?></th>
                    <th style="width: 20%;"><?php echo $l('COM_ORDENPRODUCCION_SALES_AGENT', 'Sales Agent', 'Agente de ventas'); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo htmlspecialchars($quotation->client_name ?? ''); ?></td>
                    <td><?php
                        $cid = isset($quotation->client_id) ? trim((string) $quotation->client_id) : '';
                        if ($cid !== '') {
                            echo '<code>' . htmlspecialchars($cid) . '</code>';
                        } else {
                            echo '<span class="text-muted">—</span>';
                        }
                    ?></td>
                    <td><?php echo htmlspecialchars($quotation->client_nit ?? ''); ?></td>
                    <td><?php echo htmlspecialchars($quotation->client_address ?? ''); ?></td>
                    <td><?php echo htmlspecialchars($quotation->sales_agent ?? ''); ?></td>
                </tr>
            </tbody>
        </table>
        <?php if (empty($quotation->client_id) || trim((string) $quotation->client_id) === ''): ?>
        <p class="small text-warning mb-0 mt-1">
            <?php echo $l('COM_ORDENPRODUCCION_CLIENT_ID_MISSING_NOTE', 'Client ID is empty. The pending pre-cotizaciones API requires client_id; edit the quotation and set the client ID (e.g. from Odoo) so this cotización appears when querying by client_id.', 'El Client ID está vacío. La API de pre-cotizaciones pendientes requiere client_id; edite la cotización y asigne el ID del cliente (ej. desde Odoo) para que aparezca al consultar por client_id.'); ?>
        </p>
        <?php endif; ?>
    </div>

    <!-- Contact Information -->
    <div class="contact-info-section mb-4">
        <h4 class="section-title">
            <i class="fas fa-address-book"></i>
            <?php echo $l('COM_ORDENPRODUCCION_CONTACT_INFORMATION', 'Contact Information', 'Información de contacto'); ?>
        </h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th style="width: 50%;"><?php echo $l('COM_ORDENPRODUCCION_CONTACT_NAME', 'Contact Name', 'Nombre de contacto'); ?></th>
                    <th style="width: 30%;"><?php echo $l('COM_ORDENPRODUCCION_CONTACT_PHONE', 'Contact Phone', 'Teléfono de contacto'); ?></th>
                    <th style="width: 20%;"><?php echo $l('COM_ORDENPRODUCCION_QUOTE_DATE', 'Quotation Date', 'Fecha de cotización'); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo htmlspecialchars($quotation->contact_name ?? ''); ?></td>
                    <td><?php echo htmlspecialchars($quotation->contact_phone ?? ''); ?></td>
                    <td><?php echo $quotation->quote_date ? htmlspecialchars(CotizacionHelper::formatQuoteDateYmd($quotation->quote_date)) : '—'; ?></td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Quotation Lines -->
    <div class="items-table-section">
        <h4 class="section-title">
            <i class="fas fa-list"></i>
            <?php echo $l('COM_ORDENPRODUCCION_QUOTATION_ITEMS', 'Quotation Details', 'Detalles de la cotización'); ?>
        </h4>
        <?php if (empty($items)) : ?>
            <p class="text-muted"><?php echo $l('COM_ORDENPRODUCCION_NO_LINES', 'No lines.', 'Sin líneas.'); ?></p>
        <?php else : ?>
            <div class="table-responsive cotizacion-display-lines-table-wrap">
            <table class="table table-bordered table-sm cotizacion-display-lines-table<?php echo $quotationConfirmed ? ' cotizacion-display-lines-table--has-action' : ''; ?>">
                <?php if ($quotationConfirmed) : ?>
                <colgroup>
                    <col class="col-cotizacion-pre">
                    <col class="col-cotizacion-qty">
                    <col class="col-cotizacion-desc">
                    <col class="col-cotizacion-unit">
                    <col class="col-cotizacion-sub">
                    <col class="col-cotizacion-images">
                    <col class="col-cotizacion-action">
                    <col class="col-cotizacion-ot">
                </colgroup>
                <?php else : ?>
                <colgroup>
                    <col class="col-cotizacion-pre">
                    <col class="col-cotizacion-qty">
                    <col class="col-cotizacion-desc">
                    <col class="col-cotizacion-unit">
                    <col class="col-cotizacion-sub">
                    <col class="col-cotizacion-images">
                    <col class="col-cotizacion-ot">
                </colgroup>
                <?php endif; ?>
                <thead>
                    <tr>
                        <th class="col-cotizacion-pre"><?php echo $l('COM_ORDENPRODUCCION_PRE_COTIZACION', 'Pre-Quotation', 'Pre-Cotización'); ?></th>
                        <th class="col-cotizacion-qty"><?php echo $l('COM_ORDENPRODUCCION_QUOTATION_TH_CANT', 'Qty', 'Cant.'); ?></th>
                        <th class="col-cotizacion-desc"><?php echo $l('COM_ORDENPRODUCCION_DESCRIPCION', 'Description', 'Descripción'); ?></th>
                        <th class="col-cotizacion-unit text-end"><?php echo $l('COM_ORDENPRODUCCION_PRECIO_UNIDAD', 'Unit price', 'Precio unidad.'); ?></th>
                        <th class="col-cotizacion-sub text-end"><?php echo $l('COM_ORDENPRODUCCION_SUBTOTAL', 'Subtotal', 'Subtotal'); ?></th>
                        <th class="col-cotizacion-images"><?php echo $l('COM_ORDENPRODUCCION_QUOTATION_LINE_IMAGES', 'Images', 'Imágenes'); ?></th>
                        <?php if ($quotationConfirmed) : ?>
                        <th class="col-cotizacion-action text-center"><?php echo $l('COM_ORDENPRODUCCION_ACTION', 'Action', 'Acción'); ?></th>
                        <?php endif; ?>
                        <th class="col-cotizacion-ot"><?php echo $l('COM_ORDENPRODUCCION_QUOTATION_COL_ORDEN_TRABAJO', 'Work orders', 'Orden de trabajo'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item) :
                        $preId = isset($item->pre_cotizacion_id) ? (int) $item->pre_cotizacion_id : 0;
                        $preNum = $preId > 0 ? (trim((string) ($item->pre_cotizacion_number ?? '')) ?: 'PRE-' . $preId) : '—';
                        $qty = isset($item->cantidad) ? (int) $item->cantidad : 1;
                        $lineTotal = (isset($item->valor_final) && $item->valor_final !== null && $item->valor_final !== '') ? (float) $item->valor_final : (isset($item->subtotal) ? (float) $item->subtotal : 0);
                        $unit = $qty > 0 ? ($lineTotal / $qty) : 0;
                        $lineImgsRaw = [];
                        if (!empty($item->line_images_json)) {
                            $lineImgsRaw = json_decode((string) $item->line_images_json, true) ?: [];
                        }
                        $imgRelBase = QuotationLineImagesHelper::REL_BASE;
                        $thumbPaths = [];
                        foreach ($lineImgsRaw as $p) {
                            if (!is_string($p) || $p === '' || str_contains($p, '..')) {
                                continue;
                            }
                            $norm = str_replace('\\', '/', ltrim($p, '/'));
                            if (!str_starts_with($norm, $imgRelBase . '/') && $norm !== $imgRelBase) {
                                continue;
                            }
                            $thumbPaths[] = $norm;
                        }
                        $storedOtNum       = isset($item->orden_de_trabajo) ? trim((string) $item->orden_de_trabajo) : '';
                        $otsLine           = ($preId > 0 && !empty($ordenesPorPre[$preId])) ? $ordenesPorPre[$preId] : [];
                        $lineHasExistingOt = $otsLine !== [] || ($storedOtNum !== '');
                    ?>
                        <tr>
                            <td class="col-cotizacion-pre"><?php if ($preId > 0) : ?><a href="#" class="precotizacion-detail-link" data-pre-id="<?php echo $preId; ?>" data-pre-number="<?php echo htmlspecialchars($preNum); ?>"><?php echo htmlspecialchars($preNum); ?></a><?php else : ?><?php echo htmlspecialchars($preNum); ?><?php endif; ?></td>
                            <td class="col-cotizacion-qty text-center"><?php echo (int) $qty; ?></td>
                            <td class="col-cotizacion-desc"><?php echo htmlspecialchars($item->descripcion ?? ''); ?></td>
                            <td class="col-cotizacion-unit text-end"><?php echo $currency . ' ' . number_format($unit, 4); ?></td>
                            <td class="col-cotizacion-sub text-end"><?php echo $currency . ' ' . number_format($lineTotal, 2); ?></td>
                            <td class="col-cotizacion-images align-middle cotizacion-line-images-cell">
                                <?php if ($thumbPaths !== []) : ?>
                                    <div class="cotizacion-display-line-images d-flex flex-wrap gap-1 align-items-center">
                                        <?php foreach ($thumbPaths as $rel) :
                                            $u = Uri::root() . ltrim($rel, '/');
                                            ?>
                                            <a href="<?php echo htmlspecialchars($u, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" class="cotizacion-display-line-image-link d-inline-block">
                                                <img src="<?php echo htmlspecialchars($u, ENT_QUOTES, 'UTF-8'); ?>" alt="" class="cotizacion-display-line-image-thumb rounded border" loading="lazy" decoding="async"/>
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else : ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <?php if ($quotationConfirmed) : ?>
                            <td class="col-cotizacion-action text-center align-middle">
                                <?php if ($preId > 0) : ?>
                                    <?php if ($wizClientNumericForOt) : ?>
                                    <button type="button"
                                        class="btn btn-sm btn-outline-success cotizacion-ot-wizard-trigger px-2 py-1"
                                        data-pre-cotizacion-id="<?php echo (int) $preId; ?>"
                                        data-quotation-id="<?php echo (int) $quotationId; ?>"
                                        data-client-id="<?php echo (int) $wizClientIdTrimForOt; ?>"
                                        data-client-name="<?php echo htmlspecialchars($quotation->client_name ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                        data-client-vat="<?php echo htmlspecialchars($quotation->client_nit ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                        data-ot-already-exists="<?php echo $lineHasExistingOt ? '1' : '0'; ?>"
                                        title="<?php echo htmlspecialchars(
                                            $lineHasExistingOt
                                                ? $l('COM_ORDENPRODUCCION_COT_PRE_OT_ALREADY_EXISTS', 'A work order already exists for this pre-quotation.', 'Ya existe una orden de trabajo asociada a esta pre-cotización.')
                                                : $l('COM_ORDENPRODUCCION_GENERAR_ORDEN_TRABAJO', 'Generate Work Order', 'Generar Orden de Trabajo'),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ); ?>">
                                        <i class="fas fa-print" aria-hidden="true"></i>
                                        <span class="visually-hidden"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_GENERAR_ORDEN_TRABAJO', 'Generate Work Order', 'Generar Orden de Trabajo')); ?></span>
                                    </button>
                                    <?php else : ?>
                                    <button type="button" class="btn btn-sm btn-outline-secondary px-2 py-1 disabled" disabled
                                        title="<?php echo htmlspecialchars($l(
                                            'COM_ORDENPRODUCCION_OT_WIZARD_CLIENT_ID_REQUIRED_HINT',
                                            'Set Client ID (API) on this quotation to load Odoo delivery addresses and contacts.',
                                            'Asigne Client ID (API) en esta cotización para cargar direcciones y contactos de Odoo.'
                                        )); ?>">
                                        <i class="fas fa-print" aria-hidden="true"></i>
                                        <span class="visually-hidden"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_GENERAR_ORDEN_TRABAJO', 'Generate Work Order', 'Generar Orden de Trabajo')); ?></span>
                                    </button>
                                    <?php endif; ?>
                                <?php else : ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <?php endif; ?>
                            <td class="col-cotizacion-ot align-middle small"><?php
                            if ($otsLine !== []) {
                                $oti = 0;
                                foreach ($otsLine as $ot) {
                                    if ($oti > 0) {
                                        echo '<span class="text-muted">, </span>';
                                    }
                                    $oti++;
                                    $ou = isset($ot['url']) ? (string) $ot['url'] : '';
                                    $ol = isset($ot['label']) ? (string) $ot['label'] : '';
                                    if ($ou !== '' && $ol !== '') {
                                        echo '<a href="' . htmlspecialchars($ou, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($ol, ENT_QUOTES, 'UTF-8') . '</a>';
                                    } elseif ($ol !== '') {
                                        echo htmlspecialchars($ol, ENT_QUOTES, 'UTF-8');
                                    }
                                }
                            } elseif ($storedOtNum !== '') {
                                echo htmlspecialchars($storedOtNum, ENT_QUOTES, 'UTF-8');
                            } else {
                                echo '<span class="text-muted">—</span>';
                            }
                            ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr class="table-secondary fw-bold">
                        <?php if ($quotationConfirmed) : ?>
                        <td colspan="4" class="text-end"><?php echo $l('COM_ORDENPRODUCCION_TOTAL', 'Total', 'Total'); ?>:</td>
                        <td class="text-end"><?php echo $currency . ' ' . number_format($totalAmount, 2); ?></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <?php else : ?>
                        <td colspan="4" class="text-end"><?php echo $l('COM_ORDENPRODUCCION_TOTAL', 'Total', 'Total'); ?>:</td>
                        <td class="text-end"><?php echo $currency . ' ' . number_format($totalAmount, 2); ?></td>
                        <td></td>
                        <td></td>
                        <?php endif; ?>
                    </tr>
                </tfoot>
            </table>
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-4 pt-3 border-top d-flex flex-wrap justify-content-between align-items-center gap-2">
        <div class="d-flex gap-2">
            <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=cotizaciones'); ?>" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i>
                <?php echo $l('COM_ORDENPRODUCCION_BACK_TO_LIST', 'Back to list', 'Volver a la lista'); ?>
            </a>
            <?php if ($quotationConfirmed || $quotationLockedByOrdenTrabajo) : ?>
            <span class="btn btn-secondary disabled" tabindex="-1" style="opacity: 0.65; cursor: not-allowed;" title="<?php echo htmlspecialchars($quotationLockedByOrdenTrabajo ? $editLockedHintOt : $editLockedHint); ?>">
                <i class="fas fa-edit"></i>
                <?php echo $l('COM_ORDENPRODUCCION_EDIT', 'Edit', 'Editar'); ?>
            </span>
            <?php else : ?>
            <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=cotizacion&id=' . $quotationId . '&layout=edit'); ?>" class="btn btn-primary">
                <i class="fas fa-edit"></i>
                <?php echo $l('COM_ORDENPRODUCCION_EDIT', 'Edit', 'Editar'); ?>
            </a>
            <?php endif; ?>
        </div>
        <div class="d-flex flex-wrap align-items-center gap-3">
            <?php if ($quotationConfirmed) : ?>
                <span class="badge bg-success"><i class="fas fa-check"></i> <?php echo $l('COM_ORDENPRODUCCION_CONFIRMAR_YA_FINALIZADA', 'Confirmation completed', 'Confirmación finalizada'); ?></span>
            <?php elseif ($pendingCotizacionConfirmation) : ?>
                <span class="badge bg-info text-dark"><i class="fas fa-hourglass-half"></i> <?php echo htmlspecialchars($l(
                    'COM_ORDENPRODUCCION_COTIZACION_CONFIRMATION_PENDING_BANNER_TITLE',
                    'Quotation confirmation pending approval',
                    'Confirmación de cotización — aprobación pendiente'
                ), ENT_QUOTES, 'UTF-8'); ?></span>
            <?php elseif (!$quotationHasLinkedPreCotizacion) : ?>
                <span class="text-muted small">
                    <i class="fas fa-info-circle"></i>
                    <?php echo htmlspecialchars($l(
                        'COM_ORDENPRODUCCION_CONFIRMAR_REQUIRES_PRE_COTIZACION_HINT',
                        'Link at least one pre-cotización to a line (Edit) before confirming.',
                        'Vincule al menos una pre-cotización a una línea (Editar) antes de confirmar.'
                    ), ENT_QUOTES, 'UTF-8'); ?>
                </span>
            <?php else : ?>
                <?php if (!empty($this->confirmarCotizacionSkipModal)) : ?>
            <form method="post" action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=cotizacion.finalizeConfirmacionCotizacion'); ?>" class="d-inline">
                <?php echo HTMLHelper::_('form.token'); ?>
                <input type="hidden" name="id" value="<?php echo (int) $quotationId; ?>">
                <input type="hidden" name="confirmar_sin_modal_facturacion" value="1">
                <?php if (!empty($this->facturacionUiAvailable)) : ?>
                <input type="hidden" name="facturacion_modo" value="con_envio">
                <input type="hidden" name="facturar_cotizacion_exacta" value="1">
                <?php endif; ?>
                <button type="submit" class="btn btn-success" onclick="this.disabled=true;this.form.submit();return false;">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $l('COM_ORDENPRODUCCION_CONFIRMAR_COTIZACION', 'Confirm Quotation', 'Confirmar Cotización'); ?>
                </button>
            </form>
                <?php else : ?>
            <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#confirmarCotizacionModal" id="btnConfirmarCotizacion">
                <i class="fas fa-check-circle"></i>
                <?php echo $l('COM_ORDENPRODUCCION_CONFIRMAR_COTIZACION', 'Confirm Quotation', 'Confirmar Cotización'); ?>
            </button>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($requiereOcParaFacturarView && empty($pendingFactManual)) : ?>
    <div class="mt-4 pt-3 border-top cotizacion-section-oc-facturacion">
        <h3 class="h6 text-uppercase text-muted mb-2"><?php echo htmlspecialchars($l(
            'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_SECTION_TITLE',
            'Purchase order for invoicing',
            'Orden de compra para facturación'
        )); ?></h3>
        <p class="small text-muted mb-3"><?php echo htmlspecialchars($l(
            'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_INTRO',
            'This quotation requires a purchase order to invoice. Review billing instructions and attach the document below.',
            'Esta cotización requiere orden de compra para facturar. Revise las instrucciones y adjunte el documento abajo.'
        )); ?></p>
        <label class="form-label fw-semibold"><?php echo htmlspecialchars($l(
            'COM_ORDENPRODUCCION_CONFIRMAR_STEP2_TITLE',
            'Billing instructions',
            'Instrucciones de facturación'
        )); ?></label>
        <?php if (trim($instruccionesFacturacionValue) !== '') : ?>
            <textarea class="form-control mb-3" rows="5" readonly><?php echo htmlspecialchars($instruccionesFacturacionValue, ENT_QUOTES, 'UTF-8'); ?></textarea>
        <?php else : ?>
            <p class="text-muted small mb-3"><?php echo htmlspecialchars($l(
                'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_NO_INSTRUCCIONES',
                'No billing instructions were entered.',
                'No se indicaron instrucciones de facturación.'
            )); ?></p>
        <?php endif; ?>
        <?php if ($digifactDirectBlockedByOcPdf) : ?>
        <p class="mb-3 text-danger" style="font-size: calc(16px + 2pt);"><?php echo htmlspecialchars($l(
            'COM_ORDENPRODUCCION_OC_PDF_PENDING_LABEL',
            'Purchase order PDF pending attachment',
            'Orden de compra pendiente de adjuntar'
        )); ?></p>
        <?php endif; ?>
        <label class="form-label fw-semibold"><?php echo htmlspecialchars($l(
            'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_UPLOAD_LABEL',
            'Purchase order file',
            'Archivo de orden de compra'
        )); ?></label>
        <?php if ($pathOrdenCompraView !== '') : ?>
        <div class="mb-2 d-flex flex-wrap align-items-center gap-2">
            <span class="text-muted small"><?php echo htmlspecialchars($l(
                'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_CURRENT_FILE',
                'Current file',
                'Archivo actual'
            )); ?>:</span>
            <a href="<?php echo htmlspecialchars($ocFilePublicUrl); ?>" target="_blank" rel="noopener noreferrer" class="small text-break"><?php echo htmlspecialchars(basename($pathOrdenCompraView)); ?></a>
            <button type="button" class="btn btn-outline-secondary btn-sm py-0 px-2 cotizacion-confirm-file-view"
                data-file-url="<?php echo htmlspecialchars($ocFilePublicUrl); ?>"
                data-file-kind="<?php echo htmlspecialchars($ocFileViewKind); ?>"
                title="<?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_OC_VIEWER_OPEN', 'View in window', 'Ver en ventana')); ?>">
                <i class="fas fa-eye" aria-hidden="true"></i>
                <span class="visually-hidden"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_OC_VIEWER_OPEN', 'View in window', 'Ver en ventana')); ?></span>
            </button>
        </div>
        <?php endif; ?>
        <?php if ($currentUserCot->guest) : ?>
            <p class="small text-muted mb-0"><?php echo htmlspecialchars($l(
                'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_LOGIN_TO_UPLOAD',
                'Log in to upload or replace the purchase order file.',
                'Inicie sesión para subir o reemplazar el archivo de orden de compra.'
            )); ?></p>
        <?php else : ?>
        <form method="post" action="<?php echo htmlspecialchars($uploadOrdenCompraPostUrl); ?>" enctype="multipart/form-data">
            <?php echo HTMLHelper::_('form.token'); ?>
            <input type="hidden" name="id" value="<?php echo (int) $quotationId; ?>">
            <div class="d-flex flex-wrap align-items-end gap-2">
                <div class="flex-grow-1" style="min-width: 12rem;">
                    <label for="orden_compra_facturacion_file" class="visually-hidden"><?php echo htmlspecialchars($l(
                        'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_UPLOAD_LABEL',
                        'Purchase order file',
                        'Archivo de orden de compra'
                    )); ?></label>
                    <input type="file" name="orden_compra" id="orden_compra_facturacion_file" class="form-control form-control-sm" accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png" required>
                </div>
                <button type="submit" class="btn btn-primary btn-sm flex-shrink-0"><?php echo htmlspecialchars($l(
                    'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_SAVE',
                    'Upload',
                    'Subir'
                )); ?></button>
            </div>
            <div class="form-text"><?php echo htmlspecialchars($l(
                'COM_ORDENPRODUCCION_OC_FACTURACION_VIEW_UPLOAD_HELP',
                'PDF, JPG or PNG — max 5 MB. Upload again to replace the file.',
                'PDF, JPG o PNG — máx. 5 MB. Suba otro archivo para reemplazar.'
            )); ?></div>
        </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if ($canShowPayLinkSection) : ?>
    <div class="mt-4 pt-3 border-top cotizacion-section-blink">
        <?php if ($blinkCuotasMismatch) : ?>
        <div class="alert alert-warning py-2 small mb-3">
            <?php echo htmlspecialchars($l(
                'COM_ORDENPRODUCCION_BLINK_PAY_LINK_CUOTAS_MISMATCH',
                'The number of installments must be the same on every pre-quotation with a credit card charge.',
                'La cantidad de cuotas debe ser igual en todas las pre-cotizaciones con cargo de tarjeta de crédito.'
            )); ?>
        </div>
        <?php endif; ?>
        <?php if ($blinkShowCreateButton) : ?>
        <button type="button" class="btn btn-primary btn-sm mb-3" data-bs-toggle="modal" data-bs-target="#blinkCreatePaymentModal" id="btn-blink-create-payment-link">
            <i class="fas fa-link"></i>
            <?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_CREATE_PAY_LINK_BTN', 'Create payment link', 'Crear Link de Pago')); ?>
        </button>
        <?php endif; ?>
        <div id="blink-link-alert" class="small mb-3 d-none" role="status"></div>
        <?php if (!empty($blinkPaymentsForQuotation)) : ?>
        <div class="table-responsive">
            <table class="table table-sm table-bordered mb-0">
                <thead class="table-light">
                    <tr>
                        <th><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_COL_DATE', 'Created', 'Creado')); ?></th>
                        <th><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_COL_REFERENCE', 'Reference', 'Referencia')); ?></th>
                        <th class="text-end"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_AMOUNT_LABEL', 'Amount', 'Monto')); ?></th>
                        <th><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_INSTALLMENTS_LABEL', 'Installments', 'Cuotas')); ?></th>
                        <th><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_STATUS', 'Status', 'Estado')); ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($blinkPaymentsForQuotation as $bp) :
                        $bpUrl = trim((string) ($bp->payment_url ?? ''));
                        $bpStatus = (string) ($bp->status ?? '');
                        ?>
                    <tr>
                        <td class="text-nowrap small"><?php echo !empty($bp->created) ? HTMLHelper::_('date', $bp->created, Text::_('DATE_FORMAT_LC2')) : '—'; ?></td>
                        <td class="small"><code><?php echo htmlspecialchars((string) ($bp->reference_id ?? '')); ?></code></td>
                        <td class="text-end text-nowrap">Q <?php echo htmlspecialchars(number_format((float) ($bp->amount ?? 0), 2)); ?></td>
                        <td class="small"><?php echo htmlspecialchars((string) ($bp->installments ?? '')); ?></td>
                        <td class="small"><?php echo htmlspecialchars($bpStatus); ?></td>
                        <td class="text-nowrap">
                            <?php if ($bpUrl !== '' && $bpStatus === 'created') : ?>
                            <a href="<?php echo htmlspecialchars($bpUrl, ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-sm btn-outline-primary py-0" target="_blank" rel="noopener noreferrer">
                                <?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_OPEN_LINK', 'Open', 'Abrir')); ?>
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <div class="modal fade" id="blinkCreatePaymentModal" tabindex="-1" aria-labelledby="blinkCreatePaymentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="blinkCreatePaymentModalLabel">
                        <?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_CREATE_PAY_LINK_BTN', 'Create payment link', 'Crear Link de Pago')); ?>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo htmlspecialchars(Text::_('JCLOSE')); ?>"></button>
                </div>
                <form id="blink-create-payment-form">
                    <div class="modal-body">
                        <?php echo HTMLHelper::_('form.token'); ?>
                        <input type="hidden" name="quotation_id" value="<?php echo (int) $quotationId; ?>" />
                        <div class="mb-3">
                            <label class="form-label" for="blink-pay-reference"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_COL_REFERENCE', 'Reference', 'Referencia')); ?></label>
                            <input type="text" class="form-control form-control-sm" id="blink-pay-reference" value="<?php echo htmlspecialchars($blinkPayReference); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="blink-pay-cuotas"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_INSTALLMENTS_LABEL', 'Installments', 'Cuotas')); ?></label>
                            <input type="text" class="form-control form-control-sm" id="blink-pay-cuotas" value="<?php echo htmlspecialchars($blinkPayCuotasLabel); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="blink-pay-monto"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_AMOUNT_LABEL', 'Amount', 'Monto')); ?></label>
                            <input type="text" class="form-control form-control-sm" id="blink-pay-monto" value="<?php echo htmlspecialchars('Q ' . number_format($blinkPayMonto, 2)); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="blink-pay-titulo"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_PAY_LINK_TITLE_LABEL', 'Title', 'Título')); ?></label>
                            <input type="text" class="form-control form-control-sm" id="blink-pay-titulo" value="<?php echo htmlspecialchars($blinkPayTitle); ?>" readonly>
                        </div>
                        <div class="mb-0">
                            <label class="form-label" for="blink-pay-descripcion"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_PAY_LINK_DESC_LABEL', 'Description', 'Descripción')); ?></label>
                            <textarea class="form-control form-control-sm" id="blink-pay-descripcion" name="description" rows="3" maxlength="500" placeholder="<?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_PAY_LINK_DESC_PLACEHOLDER', 'Optional note for the customer', 'Nota opcional para el cliente')); ?>"></textarea>
                        </div>
                        <div id="blink-create-modal-alert" class="small mt-3 d-none" role="alert"></div>
                        <div id="blink-create-result-box" class="d-none mt-3">
                            <label class="form-label small" for="blink-create-result-url"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_PAY_LINK_RESULT', 'Payment URL', 'URL de pago')); ?></label>
                            <div class="input-group input-group-sm">
                                <input type="text" class="form-control font-monospace" id="blink-create-result-url" readonly>
                                <a href="#" class="btn btn-outline-primary" id="blink-create-open-link" target="_blank" rel="noopener noreferrer">
                                    <?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_OPEN_LINK', 'Open', 'Abrir')); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal"><?php echo htmlspecialchars(Text::_('JCANCEL')); ?></button>
                        <button type="submit" class="btn btn-primary btn-sm" id="blink-create-payment-submit">
                            <i class="fas fa-link"></i>
                            <?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_BLINK_CREATE_PAY_LINK_BTN', 'Create payment link', 'Crear Link de Pago')); ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
    (function() {
        var form = document.getElementById('blink-create-payment-form');
        if (!form) { return; }
        var submitBtn = document.getElementById('blink-create-payment-submit');
        var alertEl = document.getElementById('blink-create-modal-alert');
        var resultBox = document.getElementById('blink-create-result-box');
        var resultUrl = document.getElementById('blink-create-result-url');
        var openLink = document.getElementById('blink-create-open-link');
        var outerAlert = document.getElementById('blink-link-alert');
        var url = <?php echo json_encode($blinkCreateJsonUrl); ?>;
        var msgNet = <?php echo json_encode($l('COM_ORDENPRODUCCION_INSTRUCCIONES_MODAL_NETWORK_ERROR', 'Network error. Try again.', 'Error de red. Intente de nuevo.')); ?>;
        var msgOk = <?php echo json_encode($l('COM_ORDENPRODUCCION_BLINK_PAYMENT_CREATED', 'Payment link created.', 'Enlace de pago creado.')); ?>;
        form.addEventListener('submit', function(ev) {
            ev.preventDefault();
            var fd = new FormData(form);
            var desc = document.getElementById('blink-pay-descripcion');
            if (desc) { fd.set('description', desc.value); }
            if (submitBtn) { submitBtn.disabled = true; }
            if (alertEl) { alertEl.className = 'small mt-3 d-none'; }
            fetch(url, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data && data.success && data.payment_url) {
                        if (resultBox) { resultBox.classList.remove('d-none'); }
                        if (resultUrl) { resultUrl.value = data.payment_url; }
                        if (openLink) { openLink.href = data.payment_url; }
                        if (alertEl) {
                            alertEl.className = 'small mt-3 text-success';
                            alertEl.textContent = msgOk;
                            alertEl.classList.remove('d-none');
                        }
                        if (outerAlert) {
                            outerAlert.className = 'small mb-3 text-success';
                            outerAlert.textContent = msgOk;
                            outerAlert.classList.remove('d-none');
                        }
                        return;
                    }
                    var msg = (data && data.message) ? data.message : 'Error';
                    if (alertEl) {
                        alertEl.className = 'small mt-3 text-danger';
                        alertEl.textContent = msg;
                        alertEl.classList.remove('d-none');
                    }
                })
                .catch(function() {
                    if (alertEl) {
                        alertEl.className = 'small mt-3 text-danger';
                        alertEl.textContent = msgNet;
                        alertEl.classList.remove('d-none');
                    }
                })
                .finally(function() {
                    if (submitBtn) { submitBtn.disabled = false; }
                });
        });
    })();
    </script>
    <?php endif; ?>

    <?php if ($canSeeFacturaRelacionadaSection) : ?>
    <div class="mt-4 pt-3 border-top cotizacion-section-factura-relacionada">
        <h3 class="h6 text-uppercase text-muted mb-2"><i class="fas fa-file-invoice-dollar me-1"></i><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_FACTURA_RELACIONADA_TITLE', 'Related invoice', 'Factura relacionada')); ?></h3>
        <p class="small text-muted mb-2"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_FACTURA_RELACIONADA_HELP', 'Related invoice (Digifact): Only the Administración group and super users see this block. Configure Certificador in Administration → Settings.', 'Factura relacionada (Digifact): Solo el grupo Administración y superusuarios ven este bloque. Configure el Certificador en Administración → Ajustes.')); ?></p>
        <?php if ($felInvoicesForQuotation !== []) : ?>
        <div class="mb-2 small">
            <?php foreach ($felInvoicesForQuotation as $felInvRow) :
                $felRowId = (int) ($felInvRow->id ?? 0);
                $felRowStatus = (string) ($felInvRow->fel_issue_status ?? '');
                $felRowNum = trim((string) ($felInvRow->invoice_number ?? ''));
                if ($felRowId < 1) {
                    continue;
                }
                ?>
            <div class="mb-1 d-flex flex-wrap align-items-center gap-1">
                <span class="text-muted"><?php echo htmlspecialchars($felRowNum !== '' ? $felRowNum : ('#' . $felRowId)); ?>:</span>
                <span class="badge bg-secondary"><?php echo htmlspecialchars($felRowStatus !== '' ? $felRowStatus : '—'); ?></span>
                <?php if ($felRowStatus === 'completed') : ?>
                <a class="btn btn-sm btn-outline-secondary py-0" target="_blank" rel="noopener" href="<?php echo htmlspecialchars(FelInvoiceHelper::downloadFelArtifactUrl($felRowId, 'pdf'), ENT_QUOTES, 'UTF-8'); ?>">PDF</a>
                <a class="btn btn-sm btn-outline-secondary py-0" target="_blank" rel="noopener" href="<?php echo htmlspecialchars(FelInvoiceHelper::downloadFelArtifactUrl($felRowId, 'xml', true), ENT_QUOTES, 'UTF-8'); ?>">XML</a>
                <a class="btn btn-sm btn-outline-primary py-0" href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=invoice&id=' . $felRowId); ?>"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_MANUAL_FEL_VIEW_INVOICE', 'View', 'Ver')); ?></a>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
            <?php if ($quotation && $felInvoicedCompletedTotal > 0) : ?>
            <div class="text-muted mt-1"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_MANUAL_FEL_INVOICED_TOTAL', 'Invoiced (completed)', 'Facturado (completadas)')); ?>: Q <?php echo number_format($felInvoicedCompletedTotal, 2); ?> / Q <?php echo number_format($totalAmount, 2); ?></div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php if ($canManualFelIssue) : ?>
        <?php if ($felStatus !== 'completed') : ?>
        <form id="digifact-direct-token-form" class="d-none"><?php echo HTMLHelper::_('form.token'); ?></form>
        <button type="button" class="btn btn-primary" id="digifact-direct-issue-btn"<?php echo $digifactDirectBlockedByOcPdf ? ' disabled' : ''; ?>
            <?php if ($digifactDirectBlockedByOcPdf) : ?> title="<?php echo htmlspecialchars($l(
                'COM_ORDENPRODUCCION_DIGIFACT_DIRECT_BLOCKED_OC_PDF_REQUIRED',
                'Attach a purchase order PDF on this quotation before issuing FEL.',
                'Adjunte un PDF de orden de compra en esta cotización antes de emitir el FEL.'
            )); ?>"<?php endif; ?>>
            <i class="fas fa-bolt"></i> <?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_DIGIFACT_DIRECT_BTN', 'Issue FEL via Digifact (direct)', 'Emitir FEL por Digifact (directo)')); ?>
        </button>
        <div id="digifact-direct-alert" class="small mt-2 d-none" role="status"></div>
        <div class="modal fade" id="digifact-fel-lines-modal" tabindex="-1" aria-labelledby="digifactFelLinesModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="digifactFelLinesModalLabel"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_DIGIFACT_LINES_MODAL_TITLE', 'Edit lines before FEL (Digifact)', 'Editar líneas antes del FEL (Digifact)')); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo htmlspecialchars(Text::_('JCLOSE')); ?>"></button>
                    </div>
                    <div class="modal-body">
                        <div id="digifact-fel-modal-alert" class="alert alert-danger py-2 small mb-3 d-none" role="alert"></div>
                        <p class="small text-muted mb-3"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_DIGIFACT_LINES_MODAL_INTRO', 'Adjust quantity and description for each line. «Timbrar» saves the cotización and certifies with Digifact.', 'Ajuste cantidad y descripción por línea. «Timbrar» guarda la cotización y certifica con Digifact.')); ?></p>
                        <div class="mb-3">
                            <label class="form-label small mb-1" for="digifact-fel-buyer-name-input"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_DIGIFACT_BUYER_NAME_LABEL', 'Client name on invoice (receptor)', 'Nombre del cliente en la factura (receptor)')); ?></label>
                            <input type="text" class="form-control" id="digifact-fel-buyer-name-input" name="digifact_fel_buyer_name" maxlength="500" autocomplete="organization"
                                value="<?php echo htmlspecialchars($digifactBuyerNameInitial, ENT_QUOTES, 'UTF-8'); ?>"
                                data-initial="<?php echo htmlspecialchars($digifactBuyerNameInitial, ENT_QUOTES, 'UTF-8'); ?>" />
                            <p class="form-text small text-muted mb-0"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_DIGIFACT_BUYER_NAME_DESC', 'Shown as Buyer.Name in the NUC sent to Digifact. Edit if it must differ from the cotización client name.', 'Se envía como nombre del receptor (Buyer.Name) a Digifact. Edítelo si debe diferir del cliente de la cotización.')); ?></p>
                        </div>
                        <?php if (!empty($digifactQuotBillingIsCf)) : ?>
                        <div id="digifact-fel-cf-cui-wrap" class="border rounded p-3 mb-3 bg-light">
                            <p class="small mb-2"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_DIGIFACT_CF_CUI_BLOCK_INTRO', 'Billing ID is consumidor final (CF). Enter the buyer\'s CUI and validate with Digifact before «Timbrar».', 'El NIT de facturación es consumidor final (CF). Ingrese el CUI del comprador y valídelo con Digifact antes de «Timbrar».')); ?></p>
                            <label class="form-label small mb-1" for="digifact-fel-cui-input"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_DIGIFACT_CF_CUI_LABEL', 'CUI', 'CUI')); ?></label>
                            <div class="d-flex flex-wrap gap-2 align-items-start">
                                <input type="text" class="form-control" id="digifact-fel-cui-input" name="digifact_fel_cui" inputmode="numeric" maxlength="32" autocomplete="off" placeholder="<?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_DIGIFACT_CF_CUI_PLACEHOLDER', 'Personal ID (CUI)', 'CUI del comprador'), ENT_QUOTES, 'UTF-8'); ?>" style="max-width: 16rem;" />
                                <button type="button" class="btn btn-outline-primary" id="digifact-fel-cui-validate-btn">
                                    <i class="fas fa-check-circle" aria-hidden="true"></i> <?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_DIGIFACT_CF_CUI_VALIDATE_BTN', 'Validate', 'Validar')); ?>
                                </button>
                            </div>
                            <div id="digifact-fel-cui-msg" class="small mt-2" role="status"></div>
                        </div>
                        <?php endif; ?>
                        <div class="table-responsive" style="max-height:65vh;">
                            <table class="table table-sm table-bordered align-middle w-100" style="table-layout: fixed;">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col" style="width:7rem;"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_PRE_COTIZACION', 'Pre-Quotation', 'Pre-Cotización')); ?></th>
                                        <th scope="col" style="width:6rem;"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_QUOTATION_TH_CANT', 'Qty', 'Cant.')); ?></th>
                                        <th scope="col"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_DIGIFACT_LINE_COL_NOTES', 'General instructions and notes', 'Instrucciones generales y Notas')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($items as $felLineItem) :
                                        $felPreId = isset($felLineItem->pre_cotizacion_id) ? (int) $felLineItem->pre_cotizacion_id : 0;
                                        $felPreNum = $felPreId > 0 ? (trim((string) ($felLineItem->pre_cotizacion_number ?? '')) ?: 'PRE-' . $felPreId) : '—';
                                        $felQtyVal = isset($felLineItem->cantidad) ? (float) $felLineItem->cantidad : 1.0;
                                        ?>
                                        <tr>
                                            <td><span class="small text-muted"><?php echo htmlspecialchars($felPreNum, ENT_QUOTES, 'UTF-8'); ?></span></td>
                                            <td>
                                                <label class="visually-hidden" for="digifact-line-qty-<?php echo (int) $felLineItem->id; ?>"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_QUOTATION_TH_CANT', 'Qty', 'Cant.')); ?></label>
                                                <input type="number" class="form-control form-control-sm digifact-fel-line-qty" id="digifact-line-qty-<?php echo (int) $felLineItem->id; ?>"
                                                    step="0.001" min="0.001" required
                                                    data-line-id="<?php echo (int) $felLineItem->id; ?>"
                                                    value="<?php echo htmlspecialchars((string) $felQtyVal, ENT_QUOTES, 'UTF-8'); ?>" autocomplete="off" />
                                            </td>
                                            <td class="align-top py-2" style="min-width: 0;">
                                                <label class="visually-hidden" for="digifact-line-desc-<?php echo (int) $felLineItem->id; ?>"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_DIGIFACT_LINE_COL_NOTES', 'General instructions and notes', 'Instrucciones generales y Notas')); ?></label>
                                                <textarea class="form-control form-control-sm digifact-fel-line-desc w-100" id="digifact-line-desc-<?php echo (int) $felLineItem->id; ?>"
                                                    style="width: 100%; box-sizing: border-box; resize: vertical;" rows="3" required data-line-id="<?php echo (int) $felLineItem->id; ?>"><?php echo htmlspecialchars((string) ($felLineItem->descripcion ?? ''), ENT_QUOTES, 'UTF-8'); ?></textarea>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal"><?php echo htmlspecialchars(Text::_('JCANCEL')); ?></button>
                        <button type="button" class="btn btn-primary" id="digifact-fel-timbrar-btn">
                            <i class="fas fa-stamp" aria-hidden="true"></i> <?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_DIGIFACT_LINES_TIMBRAR_BTN', 'Timbrar', 'Timbrar')); ?>
                        </button>
                    </div>
                    <?php if ($requiereOcParaFacturarView && $ocPdfUploadedForFel && $ocFilePublicUrl !== '') : ?>
                    <div class="digifact-fel-oc-pdf-panel border-top bg-light" id="digifact-fel-oc-pdf-panel">
                        <div class="px-3 py-2 border-bottom small fw-semibold text-uppercase text-muted mb-0">
                            <i class="fas fa-file-pdf text-danger me-1"></i><?php echo htmlspecialchars($l(
                                'COM_ORDENPRODUCCION_DIGIFACT_MODAL_OC_PDF_TITLE',
                                'Purchase order (PDF)',
                                'Orden de compra (PDF)'
                            )); ?>
                        </div>
                        <div class="digifact-fel-oc-pdf-viewport position-relative mx-3 mb-3 mt-2 rounded border overflow-hidden bg-white" style="height: 38vh; min-height: 280px; max-height: 520px;">
                            <?php $ocDigifactModalIframeSrc = $ocFilePublicUrl . '#view=FitH'; ?>
                            <iframe
                                id="digifact-fel-oc-pdf-iframe"
                                class="position-absolute top-0 start-0 w-100 h-100 border-0"
                                style="min-height: 0;"
                                title="<?php echo htmlspecialchars($l(
                                    'COM_ORDENPRODUCCION_DIGIFACT_MODAL_OC_PDF_TITLE',
                                    'Purchase order (PDF)',
                                    'Orden de compra (PDF)'
                                )); ?>"
                                src="<?php echo htmlspecialchars($ocDigifactModalIframeSrc, ENT_QUOTES, 'UTF-8'); ?>"></iframe>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <script>
        (function() {
            var openBtn = document.getElementById('digifact-direct-issue-btn');
            var form = document.getElementById('digifact-direct-token-form');
            var alertEl = document.getElementById('digifact-direct-alert');
            var saveLinesUrl = <?php echo json_encode($digifactLinesSaveUrl, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
            var issueUrl = <?php echo json_encode($digifactDirectUrl, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
            var qid = <?php echo (int) $quotationId; ?>;
            var modalEl = document.getElementById('digifact-fel-lines-modal');
            var timbrarBtn = document.getElementById('digifact-fel-timbrar-btn');
            var modalAlert = document.getElementById('digifact-fel-modal-alert');
            var buyerNameInput = document.getElementById('digifact-fel-buyer-name-input');
            var msgNet = <?php echo json_encode($l('COM_ORDENPRODUCCION_INSTRUCCIONES_MODAL_NETWORK_ERROR', 'Network error. Try again.', 'Error de red. Intente de nuevo.'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
            var msgBuyerNameRequired = <?php echo json_encode($l('COM_ORDENPRODUCCION_DIGIFACT_BUYER_NAME_REQUIRED', 'Enter the client name for the invoice.', 'Ingrese el nombre del cliente para la factura.'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
            var verifyCuiUrl = <?php echo json_encode($digifactVerifyCuiUrl, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
            var needsCfCui = <?php echo !empty($digifactQuotBillingIsCf) ? 'true' : 'false'; ?>;
            var cuiInput = document.getElementById('digifact-fel-cui-input');
            var cuiValidateBtn = document.getElementById('digifact-fel-cui-validate-btn');
            var cuiMsg = document.getElementById('digifact-fel-cui-msg');
            var cuiValidated = false;
            var msgCuiRequired = <?php echo json_encode($l('COM_ORDENPRODUCCION_DIGIFACT_DIRECT_CUI_REQUIRED', 'Enter and validate the buyer CUI before issuing (consumidor final).', 'Ingrese y valide el CUI del comprador antes de timbrar (consumidor final).'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
            var msgCuiNotValidated = <?php echo json_encode($l('COM_ORDENPRODUCCION_DIGIFACT_DIRECT_CUI_NOT_VALIDATED', 'Click «Validate» and wait for Digifact to confirm the CUI before «Timbrar».', 'Pulse «Validar» y espere la confirmación de Digifact antes de «Timbrar».'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
            var msgValidateBusy = <?php echo json_encode($l('COM_ORDENPRODUCCION_DIGIFACT_CF_CUI_VALIDATING', 'Validating…', 'Validando…'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
            if (!openBtn || !form || !modalEl || !timbrarBtn) return;

            function hideModalAlert() {
                if (modalAlert) {
                    modalAlert.classList.add('d-none');
                    modalAlert.textContent = '';
                }
            }
            function showModalAlert(msg) {
                var t = (msg !== undefined && msg !== null) ? String(msg) : '';
                if (modalAlert) {
                    modalAlert.classList.remove('d-none');
                    modalAlert.classList.add('alert-danger');
                    modalAlert.textContent = t;
                    return;
                }
                if (alertEl) {
                    alertEl.className = 'small mt-2 text-danger';
                    alertEl.textContent = t;
                    alertEl.classList.remove('d-none');
                }
            }

            function readJsonResponse(resp) {
                return resp.text().then(function(text) {
                    var data = null;
                    var parseErr = false;
                    try {
                        data = text ? JSON.parse(text) : null;
                    } catch (e) {
                        parseErr = true;
                    }
                    return { ok: resp.ok, status: resp.status, data: data, text: text, parseErr: parseErr };
                });
            }

            function showModal() {
                if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                    bootstrap.Modal.getOrCreateInstance(modalEl).show();
                }
            }
            function hideModal() {
                if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                    bootstrap.Modal.getOrCreateInstance(modalEl).hide();
                }
            }

            function resetCuiGate() {
                cuiValidated = false;
                if (cuiMsg) {
                    cuiMsg.textContent = '';
                    cuiMsg.className = 'small mt-2';
                }
                if (needsCfCui) {
                    timbrarBtn.disabled = true;
                }
            }

            openBtn.addEventListener('click', function() {
                if (alertEl) {
                    alertEl.classList.add('d-none');
                    alertEl.textContent = '';
                }
                hideModalAlert();
                if (buyerNameInput && buyerNameInput.getAttribute('data-initial') !== null) {
                    buyerNameInput.value = buyerNameInput.getAttribute('data-initial') || '';
                }
                if (needsCfCui && cuiInput) {
                    cuiInput.value = '';
                }
                resetCuiGate();
                if (!needsCfCui) {
                    timbrarBtn.disabled = false;
                }
                showModal();
            });

            if (cuiInput) {
                cuiInput.addEventListener('input', function() {
                    if (needsCfCui && cuiValidated) {
                        resetCuiGate();
                    }
                });
            }

            if (cuiValidateBtn && form) {
                cuiValidateBtn.addEventListener('click', function() {
                    if (!cuiInput) return;
                    var raw = String(cuiInput.value || '').replace(/\D/g, '');
                    if (raw === '') {
                        if (cuiMsg) {
                            cuiMsg.textContent = msgCuiRequired;
                            cuiMsg.className = 'small mt-2 text-danger';
                        }
                        cuiValidated = false;
                        timbrarBtn.disabled = true;
                        return;
                    }
                    if (cuiMsg) {
                        cuiMsg.textContent = '';
                        cuiMsg.className = 'small mt-2';
                    }
                    var prev = cuiValidateBtn.innerHTML;
                    cuiValidateBtn.disabled = true;
                    cuiValidateBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + msgValidateBusy;
                    var fd = new FormData(form);
                    fd.append('cui', raw);
                    fetch(verifyCuiUrl, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                        .then(readJsonResponse)
                        .then(function(res) {
                            cuiValidateBtn.disabled = false;
                            cuiValidateBtn.innerHTML = prev;
                            if (res.parseErr) {
                                cuiValidated = false;
                                timbrarBtn.disabled = true;
                                if (cuiMsg) {
                                    cuiMsg.textContent = msgNet + (res.text ? ' ' + res.text.substring(0, 160) : '');
                                    cuiMsg.className = 'small mt-2 text-danger';
                                }
                                return;
                            }
                            var j = res.data;
                            if (j && j.success) {
                                cuiValidated = true;
                                timbrarBtn.disabled = false;
                                if (buyerNameInput && j.data && j.data.name) {
                                    buyerNameInput.value = String(j.data.name).trim();
                                }
                                if (cuiMsg) {
                                    var m = (j.message) ? j.message : '';
                                    var n = (j.data && j.data.name) ? j.data.name : '';
                                    cuiMsg.textContent = (m && n) ? (m + ' — ' + n) : (m || n || 'OK');
                                    cuiMsg.className = 'small mt-2 text-success';
                                }
                            } else {
                                cuiValidated = false;
                                timbrarBtn.disabled = true;
                                if (cuiMsg) {
                                    cuiMsg.textContent = (j && j.message) ? j.message : 'Error';
                                    cuiMsg.className = 'small mt-2 text-danger';
                                }
                            }
                        })
                        .catch(function() {
                            cuiValidateBtn.disabled = false;
                            cuiValidateBtn.innerHTML = prev;
                            cuiValidated = false;
                            timbrarBtn.disabled = true;
                            if (cuiMsg) {
                                cuiMsg.textContent = msgNet;
                                cuiMsg.className = 'small mt-2 text-danger';
                            }
                        });
                });
            }

            if (needsCfCui) {
                timbrarBtn.disabled = true;
            }

            function collectLinesPayload() {
                var rows = [];
                var qtyInputs = modalEl.querySelectorAll('input.digifact-fel-line-qty[data-line-id]');
                qtyInputs.forEach(function(inp) {
                    var id = parseInt(inp.getAttribute('data-line-id') || '0', 10);
                    if (id < 1) return;
                    var ta = modalEl.querySelector('textarea.digifact-fel-line-desc[data-line-id="' + id + '"]');
                    if (!ta) return;
                    var q = parseFloat(String(inp.value).replace(',', '.'));
                    if (!isFinite(q) || q < 0.001) return;
                    rows.push({ id: id, cantidad: q, descripcion: String(ta.value || '').trim() });
                });
                return rows;
            }

            timbrarBtn.addEventListener('click', function() {
                if (timbrarBtn.dataset.issueInFlight === '1') {
                    return;
                }
                if (alertEl) {
                    alertEl.classList.add('d-none');
                    alertEl.textContent = '';
                }
                hideModalAlert();
                var buyerTrim = buyerNameInput ? String(buyerNameInput.value || '').trim() : '';
                if (!buyerTrim) {
                    showModalAlert(msgBuyerNameRequired);
                    return;
                }
                var lines = collectLinesPayload();
                lines.sort(function(a, b) { return a.id - b.id; });
                var qtyInputCount = modalEl.querySelectorAll('input.digifact-fel-line-qty[data-line-id]').length;
                if (lines.length !== qtyInputCount) {
                    showModalAlert(<?php echo json_encode($l('COM_ORDENPRODUCCION_DIGIFACT_LINES_INVALID_PAYLOAD', 'Each line must have a valid quantity (≥ 0.001).', 'Cada línea debe tener una cantidad válida (≥ 0,001).'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>);
                    return;
                }
                for (var i = 0; i < lines.length; i++) {
                    if (!lines[i].descripcion) {
                        showModalAlert(<?php echo json_encode($l('COM_ORDENPRODUCCION_DIGIFACT_LINES_DESC_REQUIRED', 'Description is required for every line.', 'La descripción es obligatoria en cada línea.'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>);
                        return;
                    }
                }
                if (needsCfCui) {
                    if (!cuiValidated) {
                        showModalAlert(msgCuiNotValidated);
                        return;
                    }
                    var cuiDig = cuiInput ? String(cuiInput.value || '').replace(/\D/g, '') : '';
                    if (!cuiDig) {
                        showModalAlert(msgCuiRequired);
                        return;
                    }
                }
                var fdSave = new FormData(form);
                fdSave.append('quotation_id', String(qid));
                fdSave.append('fel_lines_json', JSON.stringify(lines));
                timbrarBtn.dataset.issueInFlight = '1';
                timbrarBtn.disabled = true;
                openBtn.disabled = true;
                fetch(saveLinesUrl, { method: 'POST', body: fdSave, credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                    .then(readJsonResponse)
                    .then(function(res) {
                        if (res.parseErr) {
                            showModalAlert(msgNet + (res.text ? ' ' + res.text.substring(0, 220) : ''));
                            timbrarBtn.dataset.issueInFlight = '0';
                            timbrarBtn.disabled = false;
                            openBtn.disabled = false;
                            return Promise.resolve(null);
                        }
                        var data = res.data;
                        if (!res.ok || !data) {
                            showModalAlert((data && data.message) ? data.message : ('HTTP ' + res.status));
                            timbrarBtn.dataset.issueInFlight = '0';
                            timbrarBtn.disabled = false;
                            openBtn.disabled = false;
                            return Promise.resolve(null);
                        }
                        if (!data.success) {
                            showModalAlert((data && data.message) ? data.message : 'Error');
                            timbrarBtn.dataset.issueInFlight = '0';
                            timbrarBtn.disabled = false;
                            openBtn.disabled = false;
                            return Promise.resolve(null);
                        }
                        var fdIssue = new FormData(form);
                        fdIssue.append('quotation_id', String(qid));
                        fdIssue.append('digifact_buyer_name', buyerTrim);
                        if (needsCfCui && cuiInput) {
                            fdIssue.append('digifact_buyer_cui', String(cuiInput.value || '').replace(/\D/g, ''));
                        }
                        return fetch(issueUrl, { method: 'POST', body: fdIssue, credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
                    })
                    .then(function(respIssue) {
                        if (!respIssue) {
                            return Promise.resolve(null);
                        }
                        return readJsonResponse(respIssue);
                    })
                    .then(function(res2) {
                        if (!res2) {
                            return;
                        }
                        if (res2.parseErr) {
                            showModalAlert(msgNet + (res2.text ? ' ' + res2.text.substring(0, 220) : ''));
                            timbrarBtn.dataset.issueInFlight = '0';
                            timbrarBtn.disabled = false;
                            openBtn.disabled = false;
                            return;
                        }
                        var data2 = res2.data;
                        if (!res2.ok || !data2) {
                            showModalAlert((data2 && data2.message) ? data2.message : ('HTTP ' + res2.status));
                            timbrarBtn.dataset.issueInFlight = '0';
                            timbrarBtn.disabled = false;
                            openBtn.disabled = false;
                            return;
                        }
                        if (data2.success) {
                            hideModal();
                            window.location.reload();
                            return;
                        }
                        showModalAlert((data2 && data2.message) ? data2.message : 'Error');
                        timbrarBtn.dataset.issueInFlight = '0';
                        timbrarBtn.disabled = false;
                        openBtn.disabled = false;
                    })
                    .catch(function() {
                        showModalAlert(msgNet);
                        timbrarBtn.dataset.issueInFlight = '0';
                        timbrarBtn.disabled = false;
                        openBtn.disabled = false;
                    });
            });
        })();
        </script>
        <?php endif; ?>
        <button type="button" class="btn btn-outline-success" id="manual-fel-open-btn"<?php echo $digifactDirectBlockedByOcPdf ? ' disabled' : ''; ?>
            <?php if ($digifactDirectBlockedByOcPdf) : ?> title="<?php echo htmlspecialchars($l(
                'COM_ORDENPRODUCCION_DIGIFACT_DIRECT_BLOCKED_OC_PDF_REQUIRED',
                'Attach a purchase order PDF on this quotation before issuing FEL.',
                'Adjunte un PDF de orden de compra en esta cotización antes de emitir el FEL.'
            )); ?>"<?php endif; ?>>
            <i class="fas fa-file-invoice"></i> <?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_MANUAL_FEL_BTN', 'Manual invoice', 'Factura manual')); ?>
        </button>
        <?php include __DIR__ . '/manual_fel_modal.php'; ?>
        <?php if ($felStatus === 'completed') : ?>
        <p class="small text-muted mt-2 mb-0"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_MANUAL_FEL_AFTER_COMPLETED_HINT', 'You can issue additional manual invoices to complete the quotation total.', 'Puede emitir facturas manuales adicionales para completar el total de la cotización.')); ?></p>
        <?php endif; ?>
        <?php elseif (!$canDigifactEmitPermission) : ?>
        <p class="small text-muted mb-0"><i class="fas fa-user-lock"></i> <?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_FACTURA_RELACIONADA_EMIT_ADMIN_ONLY', 'Direct Digifact issue is available to the Administración group and super users.', 'La emisión directa por Digifact está disponible para el grupo Administración y superusuarios.')); ?></p>
        <?php elseif (!$digifactCfgOk) : ?>
        <p class="small text-warning mb-0"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_DIGIFACT_DIRECT_NEED_CONFIG', 'Configure «URL certificación / CF» and a valid bearer token in Administration → Settings → Certificador de facturación.', 'Configure «URL certificación / CF» y un token válido en Administración → Ajustes → Certificador de facturación.')); ?></p>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php
    // Wizard "Orden de Trabajo" (misma UX que Mis Clientes): entrega → contacto → enviar (stub = volver a esta cotización).
    if ($quotationConfirmed) {
        $wfOtAp = new ApprovalWorkflowService();
        $otTask = $wfOtAp->hasSchema() && $wfOtAp->isWorkflowPublishedForEntity(ApprovalWorkflowService::ENTITY_CREACION_ORDEN_TRABAJO)
            ? 'cotizacion.requestCreacionOrdenTrabajoApproval'
            : 'cotizacion.createOrdenFromQuotation';
        $createOrdenJsonUrl = Route::_('index.php?option=com_ordenproduccion&task=' . $otTask . '&format=json', false);
        $wizardParams = [
            'params'                            => ComponentHelper::getParams('com_ordenproduccion'),
            'user'                              => Factory::getUser(),
            'submit_mode_return'                => true,
            'return_url'                        => Route::_('index.php?option=com_ordenproduccion&view=cotizacion&id=' . $quotationId, false),
            /** Paso 3: mismos campos que #instruccionesOrdenModal (detalle por proceso) */
            'cotizacion_ot_step3_instructions'  => $instruccionesModalCanSave && $lineDetallesTableOk,
            'cot_ot_save_instrucciones_json_url'=> $instruccionesSaveJsonUrl,
            'cot_ot_create_orden_json_url'      => $createOrdenJsonUrl,
            'cot_ot_create_orden_task'          => $otTask,
        ];
        $otWizardPartial = JPATH_SITE . '/components/com_ordenproduccion/tmpl/partials/site_ot_modal_wizard.php';
        if (\is_file($otWizardPartial)) {
            // Must not use __DIR__ — if this view is copied to templates/.../html/..., __DIR__ is the template folder and the partial path breaks.
            include $otWizardPartial;
        }
    }
    ?>
<?php if ($quotationConfirmed) : ?>
<script>
(function() {
    var cotPreOtAlreadyMsg = <?php echo json_encode($l(
        'COM_ORDENPRODUCCION_COT_PRE_OT_ALREADY_EXISTS',
        'A work order already exists for this pre-quotation.',
        'Ya existe una orden de trabajo asociada a esta pre-cotización.'
    ), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;

    function onDocClick(ev) {
        var t = ev.target;
        var btn = t && t.closest ? t.closest('.cotizacion-ot-wizard-trigger') : null;
        if (!btn) {
            return;
        }
        ev.preventDefault();
        if (btn.getAttribute('data-ot-already-exists') === '1') {
            window.alert(cotPreOtAlreadyMsg || '');
            return;
        }
        var cid = parseInt(btn.getAttribute('data-client-id') || '0', 10);
        if (!cid) {
            return;
        }
        var name = btn.getAttribute('data-client-name') || '';
        var vat = btn.getAttribute('data-client-vat') || '';
        var fn = (typeof window.openOTModal === 'function') ? window.openOTModal : null;
        if (!fn) {
            alert('Orden de trabajo: el asistente no está disponible en esta página. Recargue (F5) e intente de nuevo.');
            return;
        }
        try {
            var preId = parseInt(btn.getAttribute('data-pre-cotizacion-id') || '0', 10);
            fn(cid, name, vat, preId);
        } catch (e) {
            if (typeof console !== 'undefined' && console.error) {
                console.error(e);
            }
            alert(e && e.message ? e.message : String(e));
        }
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            document.addEventListener('click', onDocClick, false);
        });
    } else {
        document.addEventListener('click', onDocClick, false);
    }
})();
</script>
<?php endif; ?>
</div>

<?php if (empty($this->confirmarCotizacionSkipModal) && !empty($this->quotationHasLinkedPreCotizacion) && !$quotationConfirmed) : ?>
<!-- Modal: archivos opcionales + Finalizar confirmación -->
<div class="modal fade" id="confirmarCotizacionModal" tabindex="-1" aria-labelledby="confirmarCotizacionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmarCotizacionModalLabel"><?php echo $l('COM_ORDENPRODUCCION_CONFIRMAR_COTIZACION', 'Confirm Quotation', 'Confirmar Cotización'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=cotizacion.finalizeConfirmacionCotizacion'); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo HTMLHelper::_('form.token'); ?>
                    <input type="hidden" name="id" value="<?php echo (int) $quotationId; ?>">
                    <div class="mb-3 border rounded p-3 bg-light" id="cotizacion-digifact-facturacion-preview">
                        <div class="fw-semibold small mb-2"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_CONFIRMAR_DIGIFACT_SECTION', 'Billing ID validation (NIT/CUI)', 'Validación de NIT a facturar')); ?></div>
                        <div id="cotizacion-digifact-facturacion-preview-body" class="small text-body"></div>
                        <div id="cotizacion-digifact-facturacion-preview-note" class="small text-warning mt-2 mb-0" style="display:none;"></div>
                    </div>
                    <script>
                    (function() {
                        var modal = document.getElementById('confirmarCotizacionModal');
                        if (!modal) {
                            return;
                        }
                        var bodyEl = document.getElementById('cotizacion-digifact-facturacion-preview-body');
                        var noteEl = document.getElementById('cotizacion-digifact-facturacion-preview-note');
                        var previewUrl = <?php echo json_encode(Route::_('index.php?option=com_ordenproduccion&task=cotizacion.digifactPreviewFacturacionCliente&format=json', false), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
                        var qid = <?php echo (int) $quotationId; ?>;
                        var tokenName = <?php echo json_encode(Session::getFormToken(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
                        var strLoading = <?php echo json_encode($l('COM_ORDENPRODUCCION_CONFIRMAR_DIGIFACT_LOADING', 'Verifying…', 'Verificando…'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
                        var strNit = <?php echo json_encode($l('COM_ORDENPRODUCCION_CONFIRMAR_DIGIFACT_ID_NIT', 'Tax ID (NIT)', 'NIT'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
                        var strCui = <?php echo json_encode($l('COM_ORDENPRODUCCION_CONFIRMAR_DIGIFACT_ID_CUI', 'Personal ID (CUI)', 'CUI'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
                        var strCliente = <?php echo json_encode($l('COM_ORDENPRODUCCION_CONFIRMAR_DIGIFACT_CLIENTE', 'Client', 'Cliente'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
                        var strDash = '—';
                        var strFetchErr = <?php echo json_encode($l('COM_ORDENPRODUCCION_CONFIRMAR_DIGIFACT_FETCH_ERROR', 'Could not load verification.', 'No se pudo cargar la verificación.'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
                        var finalizarBtn = modal.querySelector('#cotizacion-confirm-finalizar-btn');

                        function esc(s) {
                            return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
                        }
                        function getTokenValue() {
                            var inp = modal.querySelector('input[name="' + tokenName + '"]');
                            return inp ? inp.value : '';
                        }
                        function renderRow(idLabel, vat, name) {
                            var v = (vat === undefined || vat === null || String(vat) === '') ? strDash : String(vat);
                            var n = (name === undefined || name === null || String(name) === '') ? strDash : String(name);
                            return '<strong>' + esc(idLabel) + ':</strong> ' + esc(v) + ' <span class="text-muted">·</span> <strong>' + esc(strCliente) + ':</strong> ' + esc(n);
                        }
                        function setNote(text, show) {
                            if (!noteEl) {
                                return;
                            }
                            if (show && text) {
                                noteEl.textContent = text;
                                noteEl.style.display = '';
                            } else {
                                noteEl.textContent = '';
                                noteEl.style.display = 'none';
                            }
                        }
                        function syncDocPanels() {
                            var rCot = modal.querySelector('input[name="confirmar_adjunta_cotizacion_firmada"]:checked');
                            var wCot = document.getElementById('confirmar-wrap-cotizacion-aprobada');
                            var fCot = document.getElementById('cotizacion_aprobada_file');
                            if (wCot) {
                                wCot.style.display = (rCot && rCot.value === 'si') ? '' : 'none';
                                if (!rCot || rCot.value === 'no') {
                                    if (fCot) {
                                        fCot.value = '';
                                    }
                                }
                            }
                            applyFinalizarState();
                        }
                        function applyFinalizarState() {
                            if (!finalizarBtn) {
                                return;
                            }
                            finalizarBtn.disabled = false;
                            finalizarBtn.setAttribute('aria-disabled', 'false');
                            finalizarBtn.removeAttribute('title');
                        }
                        function resetDocumentChoices() {
                            var noCot = document.getElementById('confirmar_cot_firmada_no');
                            if (noCot) {
                                noCot.checked = true;
                            }
                            var noOc = document.getElementById('confirmar_orden_compra_no');
                            if (noOc) {
                                noOc.checked = true;
                            }
                            syncDocPanels();
                        }
                        function onConfirmarDocChoiceOrFile(ev) {
                            var t = ev.target;
                            if (!t) {
                                return;
                            }
                            if (t.name === 'confirmar_adjunta_cotizacion_firmada') {
                                syncDocPanels();
                                return;
                            }
                            if (t.type === 'file') {
                                applyFinalizarState();
                            }
                        }
                        modal.addEventListener('change', onConfirmarDocChoiceOrFile);
                        modal.addEventListener('shown.bs.modal', function() {
                            resetDocumentChoices();
                            applyFinalizarState();
                            if (!bodyEl) {
                                return;
                            }
                            bodyEl.textContent = strLoading;
                            setNote('', false);
                            var fd = new FormData();
                            fd.append('id', String(qid));
                            fd.append(tokenName, getTokenValue());
                            fetch(previewUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
                                .then(function(r) { return r.json(); })
                                .then(function(data) {
                                    if (!data || data.success === false) {
                                        bodyEl.textContent = (data && data.message) ? String(data.message) : strFetchErr;
                                        return;
                                    }
                                    var idLbl = (data.kind === 'cui') ? strCui : strNit;
                                    bodyEl.innerHTML = renderRow(idLbl, data.vat, data.name);
                                    if (data.verified) {
                                        setNote('', false);
                                    } else if (data.message) {
                                        setNote(String(data.message), true);
                                    }
                                })
                                .catch(function() {
                                    bodyEl.textContent = strFetchErr;
                                });
                        });
                    })();
                    </script>
                    <p class="text-muted small"><?php echo $l('COM_ORDENPRODUCCION_CONFIRMAR_MODAL_FILES_HELP', 'Optional: indicate if you will attach a signed confirmation quotation. Default is No. If you choose Yes, attach the file before finishing (the server requires it for that option).', 'Opcional: indique si adjuntará cotización firmada de confirmación. Por defecto es No. Si elige Sí, adjunte el archivo antes de finalizar (el servidor lo exige para esa opción).'); ?></p>
                    <fieldset class="mb-3 border-0 p-0">
                        <legend class="col-form-label small fw-semibold pt-0"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_CONFIRMAR_TIENE_COTIZACION_FIRMADA', 'Do you have a signed confirmation quotation?', '¿Tiene una cotización firmada de confirmación?')); ?></legend>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="confirmar_adjunta_cotizacion_firmada" id="confirmar_cot_firmada_no" value="no" checked>
                            <label class="form-check-label" for="confirmar_cot_firmada_no"><?php echo htmlspecialchars($l('JNO', 'No', 'No')); ?></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="confirmar_adjunta_cotizacion_firmada" id="confirmar_cot_firmada_si" value="si">
                            <label class="form-check-label" for="confirmar_cot_firmada_si"><?php echo htmlspecialchars($l('JYES', 'Yes', 'Sí')); ?></label>
                        </div>
                    </fieldset>
                    <div id="confirmar-wrap-cotizacion-aprobada" class="mb-3" style="display:none;">
                        <label for="cotizacion_aprobada_file" class="form-label"><?php echo $l('COM_ORDENPRODUCCION_COTIZACION_APROBADA_FILE', 'Approved quotation', 'Cotización aprobada'); ?></label>
                        <input type="file" name="cotizacion_aprobada" id="cotizacion_aprobada_file" class="form-control form-control-sm" accept=".pdf,.jpg,.jpeg,.png">
                        <?php if ($pathCotAprobada !== '') :
                            $uA = (strpos($pathCotAprobada, 'http') === 0) ? $pathCotAprobada : Uri::root() . ltrim($pathCotAprobada, '/');
                            ?>
                            <div class="small mt-1">
                                <i class="fas fa-paperclip text-success"></i> <?php echo htmlspecialchars(basename($pathCotAprobada)); ?>
                                <button type="button" class="btn btn-link btn-sm py-0 cotizacion-confirm-file-view" data-file-url="<?php echo htmlspecialchars($uA); ?>"><?php echo $l('COM_ORDENPRODUCCION_VIEW', 'View', 'Ver'); ?></button>
                            </div>
                        <?php endif; ?>
                    </div>
                    <fieldset class="mb-3 border-0 p-0">
                        <legend class="col-form-label small fw-semibold pt-0"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_CONFIRMAR_REQUIERE_OC_PARA_FACTURAR', 'Requires a purchase order to invoice?', '¿Requiere orden de compra para facturar?')); ?> <span class="text-danger">*</span></legend>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="confirmar_adjunta_orden_compra" id="confirmar_orden_compra_no" value="no" checked required>
                            <label class="form-check-label" for="confirmar_orden_compra_no"><?php echo htmlspecialchars($l('JNO', 'No', 'No')); ?></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="confirmar_adjunta_orden_compra" id="confirmar_orden_compra_si" value="si">
                            <label class="form-check-label" for="confirmar_orden_compra_si"><?php echo htmlspecialchars($l('JYES', 'Yes', 'Sí')); ?></label>
                        </div>
                    </fieldset>
                    <?php
                    $instruccionesBlocks = $this->confirmarInstruccionesFacturacionBlocks ?? [];
                    $facturacionUiAvailable = !empty($this->facturacionUiAvailable);
                    ?>
                    <?php if ($facturacionUiAvailable) : ?>
                    <div class="mb-3 border rounded p-3 bg-light">
                        <div class="fw-semibold small text-uppercase text-muted mb-2"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_FACTURACION_GROUP_LABEL', 'Billing', 'Facturación')); ?></div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="facturacion_modo" id="facturacion_modo_con_envio" value="con_envio"<?php echo $facturacionModoValue === 'fecha_especifica' ? '' : ' checked'; ?>>
                            <label class="form-check-label" for="facturacion_modo_con_envio"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_FACTURACION_MODO_CON_ENVIO', 'Bill with shipment', 'Facturar con el Envío')); ?></label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="facturacion_modo" id="facturacion_modo_fecha" value="fecha_especifica"<?php echo $facturacionModoValue === 'fecha_especifica' ? ' checked' : ''; ?>>
                            <label class="form-check-label" for="facturacion_modo_fecha"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_FACTURACION_MODO_FECHA_ESPECIFICA', 'Bill on a specific date', 'Facturar en fecha Específica')); ?></label>
                        </div>
                        <div class="mt-2" id="facturacion-fecha-wrapper"<?php echo $facturacionModoValue === 'fecha_especifica' ? '' : ' style="display:none;"'; ?>>
                            <label for="facturacion_fecha" class="form-label small mb-1"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_FACTURACION_FECHA_LABEL', 'Billing date', 'Fecha de facturación')); ?></label>
                            <input type="date" class="form-control form-control-sm" name="facturacion_fecha" id="facturacion_fecha" value="<?php echo htmlspecialchars($facturacionFechaValue); ?>">
                        </div>
                        <div class="form-check mt-3">
                            <input type="hidden" name="facturar_cotizacion_exacta" id="facturar_cotizacion_exacta_post" value="<?php echo $facturarCotizacionExacta === 1 ? '1' : '0'; ?>">
                            <input class="form-check-input" type="checkbox" id="facturar_cotizacion_exacta_cb"<?php echo $facturarCotizacionExacta === 1 ? ' checked' : ''; ?>>
                            <label class="form-check-label" for="facturar_cotizacion_exacta_cb"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_FACTURAR_COTIZACION_EXACTA', 'Bill exact quotation amount', 'Facturar cotización exacta')); ?></label>
                        </div>
                    </div>
                    <script>
                    (function() {
                        var rEnvio = document.getElementById('facturacion_modo_con_envio');
                        var rFecha = document.getElementById('facturacion_modo_fecha');
                        var wrap = document.getElementById('facturacion-fecha-wrapper');
                        function sync() {
                            if (!wrap) return;
                            wrap.style.display = (rFecha && rFecha.checked) ? '' : 'none';
                        }
                        if (rEnvio) rEnvio.addEventListener('change', sync);
                        if (rFecha) rFecha.addEventListener('change', sync);
                    })();
                    </script>
                    <?php endif; ?>
                    <?php if (!empty($instruccionesBlocks)) : ?>
                    <div id="confirmar-instrucciones-facturacion-wrapper" class="confirmar-instrucciones-facturacion-wrapper"<?php echo $facturarCotizacionExacta === 1 ? ' style="display:none;"' : ''; ?>>
                        <?php
                        $instruccionesMulti = \count($instruccionesBlocks) > 1;
                        $baseInstrLabel = $l('COM_ORDENPRODUCCION_CONFIRMAR_STEP2_TITLE', 'Billing Instructions', 'Instrucciones de Facturación');
                        foreach ($instruccionesBlocks as $instrBlock) :
                            $ibId = (int) ($instrBlock['id'] ?? 0);
                            $ibNum = trim((string) ($instrBlock['number'] ?? ''));
                            $ibShowSuffix = !empty($instrBlock['showSuffix']);
                            $ibLabel = $baseInstrLabel . ($ibShowSuffix && $ibNum !== '' ? (' - ' . $ibNum) : '');
                            $fieldId = 'instrucciones_facturacion_confirm' . ($instruccionesMulti ? '_' . $ibId : '');
                            $fieldName = $instruccionesMulti ? ('instrucciones_facturacion[' . $ibId . ']') : 'instrucciones_facturacion';
                            $fieldValue = (!$instruccionesMulti) ? $instruccionesFacturacionValue : '';
                            ?>
                    <div class="mb-3">
                        <label for="<?php echo htmlspecialchars($fieldId); ?>" class="form-label"><?php echo htmlspecialchars($ibLabel); ?></label>
                        <textarea name="<?php echo htmlspecialchars($fieldName); ?>" id="<?php echo htmlspecialchars($fieldId); ?>" class="form-control form-control-sm" rows="3" maxlength="65535" autocomplete="off" data-lpignore="true" data-1p-ignore="true"><?php echo htmlspecialchars($fieldValue, ENT_QUOTES, 'UTF-8'); ?></textarea>
                    </div>
                        <?php endforeach; ?>
                    </div>
                    <script>
                    (function() {
                        var hid = document.getElementById('facturar_cotizacion_exacta_post');
                        var cb = document.getElementById('facturar_cotizacion_exacta_cb');
                        var iWrap = document.getElementById('confirmar-instrucciones-facturacion-wrapper');
                        var modalForm = document.querySelector('#confirmarCotizacionModal form');
                        function syncExacta() {
                            if (hid && cb) {
                                hid.value = cb.checked ? '1' : '0';
                            }
                            if (iWrap) {
                                iWrap.style.display = (cb && cb.checked) ? 'none' : '';
                            }
                        }
                        if (cb) {
                            cb.addEventListener('change', syncExacta);
                            syncExacta();
                        }
                        if (modalForm) {
                            modalForm.addEventListener('submit', function() { syncExacta(); });
                        }
                    })();
                    </script>
                    <?php endif; ?>
                    <?php if ($facturacionUiAvailable && empty($instruccionesBlocks)) : ?>
                    <div id="confirmar-instrucciones-facturacion-wrapper" class="confirmar-instrucciones-facturacion-wrapper mb-3"<?php echo $facturarCotizacionExacta === 1 ? ' style="display:none;"' : ''; ?>>
                        <label for="instrucciones_facturacion_confirm" class="form-label"><?php echo htmlspecialchars($l('COM_ORDENPRODUCCION_CONFIRMAR_STEP2_TITLE', 'Billing instructions', 'Instrucciones de facturación')); ?></label>
                        <textarea name="instrucciones_facturacion" id="instrucciones_facturacion_confirm" class="form-control form-control-sm" rows="3" maxlength="65535" autocomplete="off" data-lpignore="true" data-1p-ignore="true"><?php echo htmlspecialchars($instruccionesFacturacionValue, ENT_QUOTES, 'UTF-8'); ?></textarea>
                    </div>
                    <script>
                    (function() {
                        var hid = document.getElementById('facturar_cotizacion_exacta_post');
                        var cb = document.getElementById('facturar_cotizacion_exacta_cb');
                        var iWrap = document.getElementById('confirmar-instrucciones-facturacion-wrapper');
                        var modalForm = document.querySelector('#confirmarCotizacionModal form');
                        function syncExacta() {
                            if (hid && cb) {
                                hid.value = cb.checked ? '1' : '0';
                            }
                            if (iWrap) {
                                iWrap.style.display = (cb && cb.checked) ? 'none' : '';
                            }
                        }
                        if (cb) {
                            cb.addEventListener('change', syncExacta);
                            syncExacta();
                        }
                        if (modalForm) {
                            modalForm.addEventListener('submit', function() { syncExacta(); });
                        }
                    })();
                    </script>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $l('JCANCEL', 'Cancel', 'Cancelar'); ?></button>
                    <button type="submit" class="btn btn-primary" id="cotizacion-confirm-finalizar-btn"><?php echo $l('COM_ORDENPRODUCCION_CONFIRMAR_FINALIZAR', 'Finish confirmation', 'Finalizar confirmación'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Modal: Instrucciones para orden de trabajo (pre-cotización) — saved via saveInstruccionesOrden + instrucciones_save_only -->
<div class="modal fade" id="instruccionesOrdenModal" tabindex="-1" aria-labelledby="instruccionesOrdenModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="instruccionesOrdenModalLabel">
                    <i class="fas fa-clipboard-list me-1"></i>
                    <?php echo $l('COM_ORDENPRODUCCION_INSTRUCCIONES_ORDEN_TITLE', 'Instructions for work order', 'Instrucciones para orden de trabajo'); ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo $l('JCLOSE', 'Close', 'Cerrar'); ?>"></button>
            </div>
            <div class="modal-body">
                <div id="instruccionesOrdenJsAlert" class="alert alert-danger py-2 small d-none" role="alert"></div>
                <?php if (!$lineDetallesTableOk) : ?>
                    <p class="text-warning mb-0"><?php echo $l('COM_ORDENPRODUCCION_INSTRUCCIONES_ORDEN_TABLE_MISSING', 'Detalles table is missing. Run migration 3.91.0.', 'Falta la tabla de detalles. Ejecute la migración 3.91.0.'); ?></p>
                <?php elseif (empty($itemsWithLineDetalles)) : ?>
                    <p class="text-muted mb-0"><?php echo $l('COM_ORDENPRODUCCION_INSTRUCCIONES_MODAL_EMPTY', 'No instruction fields are loaded for this quotation.', 'No hay campos de instrucción cargados para esta cotización.'); ?></p>
                <?php else : ?>
                    <?php foreach ($itemsWithLineDetalles as $blockIo) :
                        $preIdBlock = (int) $blockIo->pre_cotizacion_id;
                        $linesWithConceptsIo = $blockIo->linesWithConcepts ?? [];
                        ?>
                    <div class="instrucciones-orden-block d-none" data-pre-cotizacion-id="<?php echo $preIdBlock; ?>">
                        <form method="post" class="instrucciones-orden-form-inner" id="instrucciones-orden-form-<?php echo $preIdBlock; ?>" action="#">
                            <?php echo HTMLHelper::_('form.token'); ?>
                            <input type="hidden" name="quotation_id" value="<?php echo (int) $quotationId; ?>">
                            <input type="hidden" name="pre_cotizacion_id" value="<?php echo $preIdBlock; ?>">
                            <input type="hidden" name="instrucciones_save_only" value="1">
                            <?php
                            $preNumBlock = trim((string) ($blockIo->pre_cotizacion_number ?? ''));
                            if ($preNumBlock === '') {
                                $preNumBlock = 'PRE-' . $preIdBlock;
                            }
                            $preDescBlock = trim((string) ($blockIo->descripcion ?? ''));
                            $preMedidasBlock = trim((string) ($blockIo->medidas ?? ''));
                            ?>
                            <div class="border rounded bg-light p-3 mb-3">
                                <div class="d-flex flex-wrap justify-content-between align-items-baseline gap-2 mb-2">
                                    <span class="badge bg-secondary"><?php echo htmlspecialchars($preNumBlock); ?></span>
                                </div>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <div class="fw-semibold small text-uppercase text-muted mb-1"><?php echo $l('COM_ORDENPRODUCCION_PRE_COTIZACION_DESCRIPCION', 'Description', 'Descripción'); ?></div>
                                        <div class="small mb-0 instrucciones-pre-descripcion"><?php echo $preDescBlock !== '' ? nl2br(htmlspecialchars($preDescBlock, ENT_QUOTES, 'UTF-8')) : '<span class="text-muted">—</span>'; ?></div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="fw-semibold small text-uppercase text-muted mb-1"><?php echo $l('COM_ORDENPRODUCCION_PRE_COTIZACION_MEDIDAS', 'Dimensions', 'Medidas'); ?></div>
                                        <div class="small mb-0 instrucciones-pre-medidas"><?php echo $preMedidasBlock !== '' ? nl2br(htmlspecialchars($preMedidasBlock, ENT_QUOTES, 'UTF-8')) : '<span class="text-muted">—</span>'; ?></div>
                                    </div>
                                </div>
                            </div>
                            <?php foreach ($linesWithConceptsIo as $rowIo) :
                                $lineIo = $rowIo->line;
                                $conceptsIo = $rowIo->concepts;
                                $detallesIo = $rowIo->detalles;
                                $lineIdIo = (int) $lineIo->id;
                                $lineTypeIo = isset($lineIo->line_type) ? (string) $lineIo->line_type : 'pliego';
                                $lineLabelIo = '—';
                                if ($lineTypeIo === 'envio') {
                                    $lineLabelIo = isset($lineIo->envio_name) ? 'Envío: ' . $lineIo->envio_name : 'Envío';
                                } elseif ($lineTypeIo === 'tercerizado') {
                                    $prodIo = isset($lineIo->tercerizado_producto) ? trim((string) $lineIo->tercerizado_producto) : '';
                                    $lineLabelIo = $prodIo !== '' ? $prodIo : $l('COM_ORDENPRODUCCION_PRE_COT_TERCERIZADO_BTN', 'Outsourced service', 'Servicio tercerizado');
                                } elseif ($lineTypeIo === 'elementos' && !empty($lineIo->elemento_id) && isset($elementosByIdIo[(int) $lineIo->elemento_id])) {
                                    $lineLabelIo = $elementosByIdIo[(int) $lineIo->elemento_id]->name ?? ('ID ' . $lineIo->elemento_id);
                                } else {
                                    $paperNameIo = $paperNamesIo[$lineIo->paper_type_id ?? 0] ?? ('ID ' . (int) ($lineIo->paper_type_id ?? 0));
                                    $sizeNameIo = $sizeNamesIo[$lineIo->size_id ?? 0] ?? ('ID ' . (int) ($lineIo->size_id ?? 0));
                                    $lineLabelIo = $paperNameIo . ' · ' . $sizeNameIo . ' · ' . (int) $lineIo->quantity;
                                }
                                $tipoElementoIo = isset($lineIo->tipo_elemento) && trim((string) $lineIo->tipo_elemento) !== '' ? trim((string) $lineIo->tipo_elemento) : $lineLabelIo;
                                ?>
                            <?php $lineTypeAttrIo = htmlspecialchars(strtolower((string) $lineTypeIo), ENT_QUOTES, 'UTF-8'); ?>
                            <div class="card mb-3" data-line-type="<?php echo $lineTypeAttrIo; ?>">
                                <div class="card-header bg-light py-2">
                                    <strong><?php echo htmlspecialchars($tipoElementoIo); ?></strong>
                                    <span class="text-muted small ms-2"><?php echo $lineLabelIo !== $tipoElementoIo ? htmlspecialchars($lineLabelIo) : ''; ?></span>
                                </div>
                                <div class="card-body py-2">
                                    <?php foreach ($conceptsIo as $conceptoKeyIo => $conceptoLabelIo) :
                                        $valueIo = isset($detallesIo[$conceptoKeyIo]) ? htmlspecialchars((string) $detallesIo[$conceptoKeyIo], ENT_QUOTES, 'UTF-8') : '';
                                        $nameIo = 'detalle[' . $lineIdIo . '][' . $conceptoKeyIo . ']';
                                        $idIo = 'detalle_pre' . $preIdBlock . '_' . $lineIdIo . '_' . preg_replace('/[^a-z0-9_]/', '_', (string) $conceptoKeyIo);
                                        ?>
                                    <div class="mb-2">
                                        <label for="<?php echo htmlspecialchars($idIo, ENT_QUOTES, 'UTF-8'); ?>" class="form-label small mb-1"><?php echo htmlspecialchars($conceptoLabelIo); ?></label>
                                        <textarea name="<?php echo htmlspecialchars($nameIo, ENT_QUOTES, 'UTF-8'); ?>" id="<?php echo htmlspecialchars($idIo, ENT_QUOTES, 'UTF-8'); ?>" class="form-control form-control-sm instrucciones-orden-detalle" rows="2" autocomplete="off" data-lpignore="true" data-1p-ignore="true"><?php echo $valueIo; ?></textarea>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </form>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $l('JCANCEL', 'Cancel', 'Cancelar'); ?></button>
                <button type="button" class="btn btn-primary" id="instruccionesOrdenNextBtn"<?php echo $instruccionesModalCanSave ? '' : ' disabled'; ?>><?php echo $l('COM_ORDENPRODUCCION_CONFIRMAR_NEXT', 'Next', 'Siguiente'); ?></button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="cotizacionConfirmFileModal" tabindex="-1" aria-labelledby="cotizacionConfirmFileModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cotizacionConfirmFileModalLabel"><?php echo $l('COM_ORDENPRODUCCION_VIEW', 'View', 'Ver'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo $l('JCLOSE', 'Close', 'Cerrar'); ?>"></button>
            </div>
            <div class="modal-body p-0 bg-light position-relative" style="min-height: 70vh;">
                <iframe id="cotizacionConfirmFileIframe" class="w-100 border-0" style="min-height: 70vh;" title=""></iframe>
                <img id="cotizacionConfirmFileImg" class="d-none w-100" alt="" style="max-height: 70vh; object-fit: contain;">
            </div>
        </div>
    </div>
</div>
<script>
(function() {
    function stripInputPlaceholders(container) {
        if (!container) {
            return;
        }
        container.querySelectorAll('textarea, input').forEach(function(el) {
            el.removeAttribute('placeholder');
        });
    }
    var confirmModalEl = document.getElementById('confirmarCotizacionModal');
    if (confirmModalEl) {
        stripInputPlaceholders(confirmModalEl);
        confirmModalEl.addEventListener('show.bs.modal', function() {
            stripInputPlaceholders(confirmModalEl);
        });
    }
    var instrModal = document.getElementById('instruccionesOrdenModal');
    var instrNext = document.getElementById('instruccionesOrdenNextBtn');
    var saveUrl = <?php echo json_encode($instruccionesSaveJsonUrl, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    var savedMsg = <?php echo $instruccionesSavedMsgJs; ?>;
    if (!instrModal || !instrNext) {
        return;
    }
    stripInputPlaceholders(instrModal);
    function syncInstruccionesBlocksVisible() {
        var preId = String(instrModal.dataset.preCotizacionId || '');
        document.querySelectorAll('.instrucciones-orden-block').forEach(function(el) {
            var pid = String(el.getAttribute('data-pre-cotizacion-id') || '');
            el.classList.toggle('d-none', pid !== preId);
        });
    }
    document.querySelectorAll('[data-bs-target="#instruccionesOrdenModal"]').forEach(function(btn) {
        btn.addEventListener('click', function() {
            instrModal.dataset.preCotizacionId = this.getAttribute('data-pre-cotizacion-id') || '';
            instrModal.dataset.quotationId = this.getAttribute('data-quotation-id') || '';
        });
    });
    instrModal.addEventListener('show.bs.modal', function(e) {
        stripInputPlaceholders(instrModal);
        var ja = document.getElementById('instruccionesOrdenJsAlert');
        if (ja) {
            ja.classList.add('d-none');
            ja.textContent = '';
        }
        var t = e.relatedTarget;
        if (t && typeof t.closest === 'function') {
            var opener = t.closest('[data-pre-cotizacion-id]');
            if (opener) {
                instrModal.dataset.preCotizacionId = opener.getAttribute('data-pre-cotizacion-id') || '';
                instrModal.dataset.quotationId = opener.getAttribute('data-quotation-id') || '';
            }
        } else if (t && typeof t.getAttribute === 'function' && t.getAttribute('data-pre-cotizacion-id')) {
            instrModal.dataset.preCotizacionId = t.getAttribute('data-pre-cotizacion-id') || '';
            instrModal.dataset.quotationId = t.getAttribute('data-quotation-id') || '';
        }
        syncInstruccionesBlocksVisible();
    });
    instrModal.addEventListener('shown.bs.modal', function() {
        syncInstruccionesBlocksVisible();
    });
    instrNext.addEventListener('click', function() {
        if (instrNext.disabled) {
            return;
        }
        var preId = instrModal.dataset.preCotizacionId || '';
        var form = document.getElementById('instrucciones-orden-form-' + preId);
        var ja = document.getElementById('instruccionesOrdenJsAlert');
        if (!form) {
            if (ja) {
                ja.textContent = <?php echo $instruccionesJsErrNoForm; ?>;
                ja.classList.remove('d-none');
            }
            return;
        }
        instrNext.disabled = true;
        var fd = new FormData(form);
        fetch(saveUrl, {
            method: 'POST',
            body: fd,
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
            .then(function(r) {
                return r.text().then(function(text) {
                    try {
                        return JSON.parse(text);
                    } catch (err) {
                        return { success: false, message: text ? text.substring(0, 200) : 'Error' };
                    }
                });
            })
            .then(function(data) {
                if (data && data.success) {
                    var bs = typeof bootstrap !== 'undefined' && bootstrap.Modal ? bootstrap.Modal.getInstance(instrModal) : null;
                    if (bs) {
                        bs.hide();
                    }
                    var el = document.createElement('div');
                    el.className = 'alert alert-success alert-dismissible fade show';
                    el.setAttribute('role', 'alert');
                    el.innerHTML = '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>'
                        + (data.message || savedMsg);
                    var container = document.querySelector('.cotizacion-container');
                    if (container) {
                        container.insertBefore(el, container.firstChild);
                    }
                    window.setTimeout(function() {
                        if (el && el.parentNode) {
                            el.remove();
                        }
                    }, 8000);
                } else if (ja) {
                    ja.textContent = (data && data.message) ? data.message : <?php echo $instruccionesJsErrSave; ?>;
                    ja.classList.remove('d-none');
                }
            })
            .catch(function() {
                if (ja) {
                    ja.textContent = <?php echo $instruccionesJsErrNet; ?>;
                    ja.classList.remove('d-none');
                }
            })
            .finally(function() {
                instrNext.disabled = false;
            });
    });
})();
</script>
<script>
(function() {
    var modalFile = document.getElementById('cotizacionConfirmFileModal');
    var iframeFile = document.getElementById('cotizacionConfirmFileIframe');
    var imgFile = document.getElementById('cotizacionConfirmFileImg');
    if (!modalFile || !iframeFile) {
        return;
    }
    function urlLooksLikeImage(url) {
        if (!url) {
            return false;
        }
        var path = String(url).split('?')[0].toLowerCase();
        return /\.(jpe?g|png|gif|webp)$/.test(path);
    }
    function showFileInModal(url, kindAttr) {
        var kind = kindAttr || '';
        var asImage = (kind === 'image') || (kind !== 'pdf' && urlLooksLikeImage(url));
        if (imgFile) {
            if (asImage) {
                iframeFile.classList.add('d-none');
                imgFile.classList.remove('d-none');
                imgFile.src = url;
            } else {
                imgFile.classList.add('d-none');
                imgFile.removeAttribute('src');
                iframeFile.classList.remove('d-none');
                iframeFile.src = url;
            }
        } else {
            iframeFile.src = url;
        }
    }
    document.querySelectorAll('.cotizacion-confirm-file-view').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var url = this.getAttribute('data-file-url');
            if (url) {
                showFileInModal(url, this.getAttribute('data-file-kind') || '');
                if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                    bootstrap.Modal.getOrCreateInstance(modalFile).show();
                }
            }
        });
    });
    modalFile.addEventListener('hidden.bs.modal', function() {
        iframeFile.src = 'about:blank';
        iframeFile.classList.remove('d-none');
        if (imgFile) {
            imgFile.removeAttribute('src');
            imgFile.classList.add('d-none');
        }
    });
})();
</script>

<?php if (!empty($items)) : ?>
<!-- Modal: Pre-Cotización details (same as edit view) -->
<div class="modal fade" id="precotizacionDetailModal" tabindex="-1" aria-labelledby="precotizacionDetailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="precotizacionDetailModalLabel"><?php echo $l('COM_ORDENPRODUCCION_PRE_COTIZACION', 'Pre-Quotation', 'Pre-Cotización'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div id="precotizacionDetailContent" class="overflow-auto" style="max-height: 70vh;"></div>
            </div>
        </div>
    </div>
</div>
<script>
(function() {
    var precotizacionDetailBase = <?php echo json_encode(Uri::root()); ?>;
    var precotizacionDetailToken = <?php echo json_encode(Session::getFormToken() . '=1'); ?>;
    document.addEventListener('click', function(e) {
        var link = e.target && e.target.closest && e.target.closest('.precotizacion-detail-link');
        if (!link) return;
        e.preventDefault();
        var preId = link.getAttribute('data-pre-id');
        var preNumber = link.getAttribute('data-pre-number') || ('PRE-' + preId);
        if (!preId) return;
        var modal = document.getElementById('precotizacionDetailModal');
        var contentEl = document.getElementById('precotizacionDetailContent');
        var titleEl = document.getElementById('precotizacionDetailModalLabel');
        if (!modal || !contentEl) return;
        if (titleEl) titleEl.textContent = preNumber;
        contentEl.innerHTML = '<div class="p-3 text-muted text-center"><span class="spinner-border spinner-border-sm me-2"></span><?php echo addslashes($l('COM_ORDENPRODUCCION_LOADING', 'Loading...', 'Cargando...')); ?></div>';
        if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            var bsModal = bootstrap.Modal.getOrCreateInstance(modal);
            bsModal.show();
        } else {
            modal.classList.add('show');
            modal.style.display = 'block';
        }
        var url = precotizacionDetailBase + 'index.php?option=com_ordenproduccion&task=ajax.getPrecotizacionDetails&format=raw&id=' + encodeURIComponent(preId) + '&' + precotizacionDetailToken;
        fetch(url).then(function(r) { return r.text(); }).then(function(html) {
            contentEl.innerHTML = html || '<p class="p-3 text-muted"><?php echo addslashes($l('COM_ORDENPRODUCCION_PRE_COTIZACION_ERROR_NOT_FOUND', 'Pre-quotation not found.', 'Pre-cotización no encontrada.')); ?></p>';
        }).catch(function() {
            contentEl.innerHTML = '<p class="p-3 text-danger"><?php echo addslashes($l('COM_ORDENPRODUCCION_ERROR_LOADING', 'Error loading.', 'Error al cargar.')); ?></p>';
        });
    });
})();
</script>
<?php endif; ?>
