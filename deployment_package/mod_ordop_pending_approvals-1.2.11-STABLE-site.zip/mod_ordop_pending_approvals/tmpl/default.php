<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_ordop_pending_approvals
 *
 * @copyright   (C) 2026 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Grimpsa\Component\Ordenproduccion\Site\Service\ApprovalWorkflowService;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/** @var array $rows */
/** @var bool $schemaOk */
/** @var bool $showFullLink */
/** @var int $pendingTotal */

$entityLabel = static function (string $entityType): string {
    $entityType = ApprovalWorkflowService::normalizeEntityType($entityType);
    $map        = [
        'cotizacion_confirmation' => 'COM_ORDENPRODUCCION_APPROVAL_ENTITY_COTIZACION_CONFIRMATION',
        'orden_status'            => 'COM_ORDENPRODUCCION_APPROVAL_ENTITY_ORDEN_STATUS',
        'orden_compra'            => 'COM_ORDENPRODUCCION_APPROVAL_ENTITY_ORDEN_COMPRA',
        'timesheet'               => 'COM_ORDENPRODUCCION_APPROVAL_ENTITY_TIMESHEET',
        'payment_proof'           => 'COM_ORDENPRODUCCION_APPROVAL_ENTITY_PAYMENT_PROOF',
        'solicitud_descuento'     => 'COM_ORDENPRODUCCION_APPROVAL_ENTITY_SOLICITUD_DESCUENTO',
        'solicitud_cotizacion'    => 'COM_ORDENPRODUCCION_APPROVAL_ENTITY_SOLICITUD_COTIZACION',
        'creacion_orden_trabajo'   => 'COM_ORDENPRODUCCION_APPROVAL_ENTITY_CREACION_ORDEN_TRABAJO',
    ];
    $key = $map[$entityType] ?? 'COM_ORDENPRODUCCION_APPROVAL_ENTITY_GENERIC';

    return Text::_($key);
};

$adminAprobUrl = Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=aprobaciones', false);

$modId = 'mod-ordop-pending-approvals-' . (int) $module->id;
?>
<div id="<?php echo $modId; ?>" class="mod-ordop-pending-approvals <?php echo htmlspecialchars($params->get('moduleclass_sfx', ''), ENT_QUOTES, 'UTF-8'); ?>">
    <style>
    #<?php echo $modId; ?> {
        font-size: 0.8125rem;
        line-height: 1.35;
    }
    #<?php echo $modId; ?> .table { font-size: inherit; }
    #<?php echo $modId; ?> .mod-ordop-row-link:hover { background-color: rgba(13, 110, 253, 0.08); }
    </style>
    <?php if ($showFullLink) : ?>
    <p class="mb-2">
        <a href="<?php echo htmlspecialchars($adminAprobUrl, ENT_QUOTES, 'UTF-8'); ?>" class="small">
            <?php echo Text::_('MOD_ORDOP_PENDING_APPROVALS_LINK_FULL'); ?>
        </a>
    </p>
    <?php endif; ?>

    <?php if (!$schemaOk) : ?>
        <div class="alert alert-warning mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_APPROVAL_SCHEMA_MISSING'); ?></div>
    <?php elseif ($rows === []) : ?>
        <p class="mb-2"><strong><?php echo Text::sprintf('MOD_ORDOP_PENDING_APPROVALS_TOTAL', 0); ?></strong></p>
        <div class="alert alert-info mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_APPROVAL_EMPTY'); ?></div>
    <?php else : ?>
        <p class="mb-2"><strong><?php echo Text::sprintf('MOD_ORDOP_PENDING_APPROVALS_TOTAL', (int) $pendingTotal); ?></strong></p>
        <div class="table-responsive">
            <table class="table table-sm table-striped table-bordered align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th scope="col"><?php echo Text::_('MOD_ORDOP_PENDING_APPROVALS_COL_TYPE'); ?></th>
                        <th scope="col"><?php echo Text::_('MOD_ORDOP_PENDING_APPROVALS_COL_REQUESTER'); ?></th>
                        <th scope="col"><?php echo Text::_('MOD_ORDOP_PENDING_APPROVALS_COL_ID'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rows as $row) : ?>
                        <?php
                        $etype = ApprovalWorkflowService::normalizeEntityType((string) ($row->entity_type ?? ''));
                        $wfTypeLabel = isset($row->workflow_pending_type_label) ? trim((string) $row->workflow_pending_type_label) : '';
                        $isDiscount     = $etype === 'solicitud_descuento';
                        $isPreCotVendor = $etype === 'solicitud_cotizacion';
                        $isCreacionOt   = $etype === 'creacion_orden_trabajo';
                        $isPaymentProof = $etype === 'payment_proof';
                        $isOrdenCompra  = $etype === 'orden_compra';
                        if ($wfTypeLabel !== '') {
                            $tipoLabel = $wfTypeLabel;
                        } else {
                            $tipoLabel      = $isDiscount
                                ? Text::_('MOD_ORDOP_PENDING_APPROVALS_TYPE_DESCUENTO')
                                : ($isPreCotVendor
                                    ? Text::_('MOD_ORDOP_PENDING_APPROVALS_TYPE_VENDOR_QUOTE')
                                    : ($isPaymentProof
                                        ? Text::_('MOD_ORDOP_PENDING_APPROVALS_TYPE_PAGO')
                                        : ($isOrdenCompra
                                            ? Text::_('MOD_ORDOP_PENDING_APPROVALS_TYPE_ORDEN_COMPRA')
                                            : $entityLabel($etype))));
                        }
                        $eid = isset($row->entity_id) ? (int) $row->entity_id : 0;
                        if ($isDiscount || $isPreCotVendor || $isCreacionOt) {
                            $idLabel = isset($row->precotizacion_number) && (string) $row->precotizacion_number !== ''
                                ? (string) $row->precotizacion_number
                                : ($eid > 0 ? 'PRE-' . str_pad((string) $eid, 5, '0', STR_PAD_LEFT) : '');
                        } elseif ($isOrdenCompra) {
                            $idLabel = isset($row->orden_compra_number) && (string) $row->orden_compra_number !== ''
                                ? (string) $row->orden_compra_number
                                : ($eid > 0 ? '#' . $eid : '');
                        } else {
                            $idLabel = (string) $eid;
                        }
                        $href = isset($row->record_link) && is_string($row->record_link) && $row->record_link !== ''
                            ? Route::_($row->record_link, false)
                            : '';
                        $reqName = isset($row->submitter_name) ? trim((string) $row->submitter_name) : '';
                        $reqUser = isset($row->submitter_username) ? trim((string) $row->submitter_username) : '';
                        if ($reqUser !== '') {
                            $requesterLabel = $reqUser;
                        } elseif ($reqName !== '') {
                            $requesterLabel = $reqName;
                        } else {
                            $requesterLabel = '—';
                        }
                        ?>
                        <?php if ($href !== '') : ?>
                        <tr>
                            <td colspan="3" class="p-0">
                                <a href="<?php echo htmlspecialchars($href, ENT_QUOTES, 'UTF-8'); ?>" class="mod-ordop-row-link d-flex align-items-center w-100 px-2 py-2 text-decoration-none text-body gap-2">
                                    <span class="flex-shrink-0" style="min-width:4.5rem"><?php echo htmlspecialchars($tipoLabel, ENT_QUOTES, 'UTF-8'); ?></span>
                                    <span class="flex-grow-1 text-muted text-truncate" title="<?php echo htmlspecialchars($requesterLabel, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($requesterLabel, ENT_QUOTES, 'UTF-8'); ?></span>
                                    <span class="text-end text-nowrap flex-shrink-0 border-start ps-2"><?php echo htmlspecialchars($idLabel, ENT_QUOTES, 'UTF-8'); ?></span>
                                </a>
                            </td>
                        </tr>
                        <?php else : ?>
                        <tr>
                            <td><?php echo htmlspecialchars($tipoLabel, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($requesterLabel, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td class="text-end"><?php echo htmlspecialchars($idLabel, ENT_QUOTES, 'UTF-8'); ?></td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
