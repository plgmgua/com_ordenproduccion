<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_ordenproduccion
 *
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use InvalidArgumentException;
use Exception;

// Access check
$user = Factory::getApplication()->getIdentity();
if (!$user->authorise('core.manage', 'com_ordenproduccion')) {
    throw new InvalidArgumentException(Text::_('JERROR_ALERTNOAUTHOR'), 404);
}

// Boot the component and dispatch
try {
    $component = Factory::getApplication()->bootComponent('com_ordenproduccion');
    $component->dispatch();
} catch (Exception $e) {
    echo 'Component Error: ' . $e->getMessage();
}
