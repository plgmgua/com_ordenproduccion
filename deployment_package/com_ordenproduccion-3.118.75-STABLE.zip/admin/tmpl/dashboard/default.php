<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_ordenproduccion
 *
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

$siteAdminAprobacionesUrl = htmlspecialchars(
    Uri::root() . 'index.php?option=com_ordenproduccion&view=administracion&tab=aprobaciones',
    ENT_QUOTES,
    'UTF-8'
);

?>

<div class="com-ordenproduccion-dashboard">
    <!-- Dashboard Header (compact) -->
    <div class="dashboard-header mb-2">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="dashboard-title">
                    <i class="icon-dashboard"></i>
                    <?php echo Text::_('COM_ORDENPRODUCCION_DASHBOARD'); ?>
                </h1>
                <p class="dashboard-subtitle">
                    <?php echo Text::_('COM_ORDENPRODUCCION_DASHBOARD_SUBTITLE'); ?>
                </p>
            </div>
            <div class="col-md-6 text-md-end mt-2 mt-md-0">
                <div class="version-info">
                    <small class="text-muted">
                        <?php echo Text::_('COM_ORDENPRODUCCION_VERSION'); ?>: 
                        <strong><?php echo $this->versionInfo['version']; ?></strong>
                    </small>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions (top bar) -->
    <div class="dashboard-quick-actions mb-3">
        <div class="quick-actions-inner">
            <?php if ($this->hasPermission('core.create')): ?>
                <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=orden&layout=edit'); ?>" class="btn btn-sm btn-primary">
                    <i class="icon-plus"></i>
                    <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_NEW_ORDER', 'New Order'); ?>
                </a>
            <?php endif; ?>
            <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=ordenes'); ?>" class="btn btn-sm btn-outline-primary">
                <i class="icon-list"></i>
                <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_VIEW_ORDERS', 'View Orders'); ?>
            </a>
            <a href="<?php echo $siteAdminAprobacionesUrl; ?>" class="btn btn-sm btn-outline-success" title="<?php echo htmlspecialchars($this->getButtonLabel('COM_ORDENPRODUCCION_DASHBOARD_APROBACIONES_TITLE', 'Open the site Administración view (Aprobaciones tab)'), ENT_QUOTES, 'UTF-8'); ?>">
                <i class="icon-ok"></i>
                <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_DASHBOARD_APROBACIONES', 'Approvals'); ?>
            </a>
            <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=technicians'); ?>" class="btn btn-sm btn-outline-primary">
                <i class="icon-users"></i>
                <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_VIEW_TECHNICIANS', 'View Technicians'); ?>
            </a>
            <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=webhook'); ?>" class="btn btn-sm btn-outline-primary">
                <i class="icon-link"></i>
                <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_WEBHOOK_CONFIG', 'Webhook Config'); ?>
            </a>
            <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=webhook#webhook-logs'); ?>" class="btn btn-sm btn-outline-primary">
                <i class="icon-list"></i>
                <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_MENU_WEBHOOK_LOG', 'Webhook Log'); ?>
            </a>
            <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=settings'); ?>" class="btn btn-sm btn-outline-primary">
                <i class="icon-options"></i>
                <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_MENU_SETTINGS', 'Settings'); ?>
            </a>
            <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=settings#solicitud-orden-url'); ?>" class="btn btn-sm btn-outline-primary">
                <i class="icon-link"></i>
                <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_SOLICITUD_ORDEN_URL_BTN', 'Order Request URL'); ?>
            </a>
            <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=settings#ordenes-actions-access'); ?>" class="btn btn-sm btn-outline-primary">
                <i class="icon-shield"></i>
                <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_ORDENES_ACTIONS_ACCESS_BTN', 'Order list action buttons'); ?>
            </a>
            <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=testing'); ?>" class="btn btn-sm btn-outline-secondary">
                <i class="icon-puzzle"></i>
                <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_MENU_TESTING', 'Testing'); ?>
            </a>
            <?php if ($this->hasPermission('core.admin')): ?>
                <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=debug'); ?>" class="btn btn-sm btn-outline-secondary">
                    <i class="icon-bug"></i>
                    <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_DEBUG_CONSOLE', 'Debug Console'); ?>
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-3">
        <div class="col-lg-3 col-md-6 mb-2">
            <div class="card stat-card stat-card-primary">
                <div class="card-body">
                    <div class="stat-icon">
                        <i class="icon-list"></i>
                    </div>
                    <div class="stat-content">
                        <h3 class="stat-number"><?php echo $this->formatNumber($this->statistics['total_orders']); ?></h3>
                        <p class="stat-label"><?php echo Text::_('COM_ORDENPRODUCCION_TOTAL_ORDERS'); ?></p>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=ordenes'); ?>" class="btn btn-sm btn-primary">
                        <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_VIEW_ALL', 'View All'); ?>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-2">
            <div class="card stat-card stat-card-warning">
                <div class="card-body">
                    <div class="stat-icon">
                        <i class="icon-clock"></i>
                    </div>
                    <div class="stat-content">
                        <h3 class="stat-number"><?php echo $this->formatNumber($this->statistics['pending_orders']); ?></h3>
                        <p class="stat-label"><?php echo Text::_('COM_ORDENPRODUCCION_PENDING_ORDERS'); ?></p>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=ordenes&filter_status=nueva'); ?>" class="btn btn-sm btn-warning">
                        <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_VIEW_PENDING', 'View Pending'); ?>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-2">
            <div class="card stat-card stat-card-info">
                <div class="card-body">
                    <div class="stat-icon">
                        <i class="icon-checkmark"></i>
                    </div>
                    <div class="stat-content">
                        <h3 class="stat-number"><?php echo $this->formatNumber($this->statistics['completed_orders']); ?></h3>
                        <p class="stat-label"><?php echo Text::_('COM_ORDENPRODUCCION_COMPLETED_ORDERS'); ?></p>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=ordenes&filter_status=terminada'); ?>" class="btn btn-sm btn-info">
                        <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_VIEW_COMPLETED', 'View Completed'); ?>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-2">
            <div class="card stat-card stat-card-success">
                <div class="card-body">
                    <div class="stat-icon">
                        <i class="icon-users"></i>
                    </div>
                    <div class="stat-content">
                        <h3 class="stat-number"><?php echo $this->formatNumber($this->statistics['active_technicians']); ?></h3>
                        <p class="stat-label"><?php echo Text::_('COM_ORDENPRODUCCION_ACTIVE_TECHNICIANS'); ?></p>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=technicians'); ?>" class="btn btn-sm btn-success">
                        <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_VIEW_TECHNICIANS', 'View Technicians'); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Additional Statistics -->
    <div class="row mb-4">
        <div class="col-lg-4 col-md-6 mb-2">
            <div class="card stat-card stat-card-danger">
                <div class="card-body">
                    <div class="stat-icon">
                        <i class="icon-warning"></i>
                    </div>
                    <div class="stat-content">
                        <h3 class="stat-number"><?php echo $this->formatNumber($this->statistics['overdue_orders']); ?></h3>
                        <p class="stat-label"><?php echo Text::_('COM_ORDENPRODUCCION_OVERDUE_ORDERS'); ?></p>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=ordenes&filter_due=overdue'); ?>" class="btn btn-sm btn-danger">
                        <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_VIEW_OVERDUE', 'View Overdue'); ?>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-md-6 mb-2">
            <div class="card stat-card stat-card-secondary">
                <div class="card-body">
                    <div class="stat-icon">
                        <i class="icon-calendar"></i>
                    </div>
                    <div class="stat-content">
                        <h3 class="stat-number"><?php echo $this->formatNumber($this->statistics['orders_due_today']); ?></h3>
                        <p class="stat-label"><?php echo Text::_('COM_ORDENPRODUCCION_ORDERS_DUE_TODAY'); ?></p>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=ordenes&filter_due=due_today'); ?>" class="btn btn-sm btn-secondary">
                        <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_VIEW_DUE_TODAY', 'View Due Today'); ?>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-md-6 mb-2">
            <div class="card stat-card stat-card-dark">
                <div class="card-body">
                    <div class="stat-icon">
                        <i class="icon-cog"></i>
                    </div>
                    <div class="stat-content">
                        <h3 class="stat-number"><?php echo $this->formatNumber($this->statistics['in_process_orders']); ?></h3>
                        <p class="stat-label"><?php echo Text::_('COM_ORDENPRODUCCION_IN_PROCESS_ORDERS'); ?></p>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=ordenes&filter_status=en_proceso'); ?>" class="btn btn-sm btn-dark">
                        <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_VIEW_IN_PROCESS', 'View In Process'); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- All backend views (quick links) -->
    <div class="row mb-3">
        <div class="col-12">
            <div class="card">
                <div class="card-header py-2">
                    <h5 class="card-title mb-0">
                        <i class="icon-folder-open"></i>
                        <?php echo Text::_('COM_ORDENPRODUCCION_ALL_VIEWS'); ?>
                    </h5>
                </div>
                <div class="card-body py-2">
                    <div class="d-flex flex-wrap gap-2 align-items-center">
                        <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=dashboard'); ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="icon-dashboard"></i>
                            <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_MENU_DASHBOARD', 'Dashboard'); ?>
                        </a>
                        <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=ordenes'); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="icon-list"></i>
                            <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_MENU_ORDERS', 'Orders'); ?>
                        </a>
                        <a href="<?php echo $siteAdminAprobacionesUrl; ?>" class="btn btn-sm btn-outline-success" title="<?php echo htmlspecialchars($this->getButtonLabel('COM_ORDENPRODUCCION_DASHBOARD_APROBACIONES_TITLE', 'Open the site Administración view (Aprobaciones tab)'), ENT_QUOTES, 'UTF-8'); ?>">
                            <i class="icon-ok"></i>
                            <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_DASHBOARD_APROBACIONES', 'Approvals'); ?>
                        </a>
                        <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=technicians'); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="icon-users"></i>
                            <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_VIEW_TECHNICIANS', 'Technicians'); ?>
                        </a>
                        <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=webhook'); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="icon-link"></i>
                            <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_MENU_WEBHOOK', 'Webhook'); ?>
                        </a>
                        <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=webhook#webhook-logs'); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="icon-list"></i>
                            <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_MENU_WEBHOOK_LOG', 'Webhook Log'); ?>
                        </a>
                        <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=settings'); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="icon-options"></i>
                            <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_MENU_SETTINGS', 'Settings'); ?>
                        </a>
                        <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=settings#ordenes-actions-access'); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="icon-shield"></i>
                            <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_ORDENES_ACTIONS_ACCESS_BTN', 'Order list action buttons'); ?>
                        </a>
                        <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=testing'); ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="icon-puzzle"></i>
                            <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_MENU_TESTING', 'Testing'); ?>
                        </a>
                        <?php if ($this->hasPermission('core.admin')): ?>
                            <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=debug'); ?>" class="btn btn-sm btn-outline-secondary">
                                <i class="icon-bug"></i>
                                <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_DEBUG_CONSOLE', 'Debug'); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content Row -->
    <div class="row">
        <!-- Recent Orders -->
        <div class="col-lg-8 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">
                        <i class="icon-list"></i>
                        <?php echo Text::_('COM_ORDENPRODUCCION_RECENT_ORDERS'); ?>
                    </h5>
                    <div class="card-tools">
                        <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=ordenes'); ?>" class="btn btn-sm btn-primary">
                            <?php echo $this->getButtonLabel('COM_ORDENPRODUCCION_VIEW_ALL', 'View All'); ?>
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (!empty($this->recentOrders)): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th><?php echo Text::_('COM_ORDENPRODUCCION_ORDER_NUMBER'); ?></th>
                                        <th><?php echo Text::_('COM_ORDENPRODUCCION_CLIENT'); ?></th>
                                        <th><?php echo Text::_('COM_ORDENPRODUCCION_STATUS'); ?></th>
                                        <th><?php echo Text::_('COM_ORDENPRODUCCION_DELIVERY_DATE'); ?></th>
                                        <th><?php echo Text::_('COM_ORDENPRODUCCION_CREATED'); ?></th>
                                        <th><?php echo Text::_('COM_ORDENPRODUCCION_ACTIONS'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($this->recentOrders as $order): ?>
                                        <?php
                                        $orderNumber = $order->orden_de_trabajo ?? $order->order_number ?? '';
                                        $clientName = $order->nombre_del_cliente ?? $order->client_name ?? '';
                                        $deliveryDate = $order->fecha_de_entrega ?? $order->delivery_date ?? null;
                                        $status = $order->status ?? $order->valor ?? '';
                                        ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo htmlspecialchars($orderNumber); ?></strong>
                                            </td>
                                            <td><?php echo htmlspecialchars($clientName); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $this->getStatusColor($status); ?>">
                                                    <?php echo $this->getStatusText($status); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($deliveryDate): ?>
                                                    <?php echo Factory::getDate($deliveryDate)->format('d/m/Y'); ?>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <small class="text-muted">
                                                    <?php echo Factory::getDate($order->created)->format('d/m/Y H:i'); ?>
                                                </small>
                                            </td>
                                            <td>
                                                <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=orden&layout=edit&id=' . $order->id); ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="icon-edit"></i>
                                                    <?php echo Text::_('COM_ORDENPRODUCCION_EDIT'); ?>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="icon-list icon-3x text-muted"></i>
                            <p class="text-muted mt-2"><?php echo Text::_('COM_ORDENPRODUCCION_NO_RECENT_ORDERS'); ?></p>
                            <?php if ($this->hasPermission('core.create')): ?>
                                <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=orden&layout=edit'); ?>" class="btn btn-primary">
                                    <i class="icon-plus"></i>
                                    <?php echo Text::_('COM_ORDENPRODUCCION_CREATE_FIRST_ORDER'); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Calendar -->
        <div class="col-lg-4">
            <!-- Calendar Widget -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title">
                        <i class="icon-calendar"></i>
                        <?php echo Text::_('COM_ORDENPRODUCCION_ORDERS_CALENDAR'); ?>
                    </h5>
                    <div class="card-tools">
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="prevMonth">
                                <i class="icon-chevron-left"></i>
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="nextMonth">
                                <i class="icon-chevron-right"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="calendar-widget">
                        <div class="calendar-header">
                            <h6 id="calendarTitle">
                                <?php echo $this->getMonthName($this->currentMonth) . ' ' . $this->currentYear; ?>
                            </h6>
                        </div>
                        <div class="calendar-grid" id="calendarGrid">
                            <!-- Calendar will be populated by JavaScript -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Hidden form for AJAX requests -->
<form id="dashboardForm" style="display: none;">
    <input type="hidden" name="option" value="com_ordenproduccion">
    <input type="hidden" name="task" value="">
    <input type="hidden" name="format" value="json">
    <input type="hidden" name="<?php echo Factory::getSession()->getFormToken(); ?>" value="1">
</form>
