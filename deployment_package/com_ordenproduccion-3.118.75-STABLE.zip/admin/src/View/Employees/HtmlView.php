<?php
/**
 * @package     Grimpsa.Component
 * @subpackage  com_ordenproduccion
 *
 * @copyright   Copyright (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later
 */

namespace Grimpsa\Component\Ordenproduccion\Administrator\View\Employees;

use Joomla\CMS\Helper\ContentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\Toolbar;
use Joomla\CMS\Toolbar\ToolbarHelper;

defined('_JEXEC') or die;

/**
 * Employees List View
 *
 * @since  3.3.0
 */
class HtmlView extends BaseHtmlView
{
    protected $items;
    protected $pagination;
    protected $state;
    protected $groups;

    /**
     * Display the view
     *
     * @param   string  $tpl  The name of the template file to parse
     *
     * @return  void
     *
     * @since   3.3.0
     */
    public function display($tpl = null)
    {
        $this->items = $this->get('Items');
        $this->pagination = $this->get('Pagination');
        $this->state = $this->get('State');
        $this->filterForm = $this->get('FilterForm');
        $this->activeFilters = $this->get('ActiveFilters');
        
        $model = $this->getModel();
        $this->groups = $model->getGroups();

        // Check for errors
        if (count($errors = $this->get('Errors'))) {
            throw new \Exception(implode("\n", $errors), 500);
        }

        $this->addToolbar();

        parent::display($tpl);
    }

    /**
     * Add the page toolbar.
     *
     * @return  void
     *
     * @since   3.3.0
     */
    protected function addToolbar()
    {
        $canDo = ContentHelper::getActions('com_ordenproduccion');

        ToolbarHelper::title(Text::_('COM_ORDENPRODUCCION_EMPLOYEES_TITLE'), 'users');

        if ($canDo->get('core.create')) {
            ToolbarHelper::addNew('employee.add');
        }

        if ($canDo->get('core.edit')) {
            ToolbarHelper::editList('employee.edit');
        }

        if ($canDo->get('core.edit.state')) {
            // Custom Activate/Deactivate buttons
            $toolbar = Toolbar::getInstance();
            
            $activateButton = $toolbar->standardButton('check-circle')
                ->text('COM_ORDENPRODUCCION_ACTIVATE')
                ->task('employees.activate')
                ->icon('fa fa-check-circle')
                ->listCheck(true);
            
            $deactivateButton = $toolbar->standardButton('times-circle')
                ->text('COM_ORDENPRODUCCION_DEACTIVATE')
                ->task('employees.deactivate')
                ->icon('fa fa-times-circle')
                ->listCheck(true);

            ToolbarHelper::divider();
            
            // Change Group button
            $changeGroupButton = $toolbar->standardButton('users')
                ->text('COM_ORDENPRODUCCION_CHANGE_GROUP')
                ->onclick('document.getElementById(\'changeGroupModal\').style.display=\'block\';')
                ->icon('fa fa-users')
                ->listCheck(true);

            ToolbarHelper::divider();
            ToolbarHelper::publish('employees.publish', 'JTOOLBAR_PUBLISH', true);
            ToolbarHelper::unpublish('employees.unpublish', 'JTOOLBAR_UNPUBLISH', true);
        }

        if ($canDo->get('core.delete')) {
            ToolbarHelper::deleteList('JGLOBAL_CONFIRM_DELETE', 'employees.delete');
        }

        ToolbarHelper::divider();
        ToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_ordenproduccion');
    }
}

