/**
 * Payment Info Popup for Com Orden Produccion
 * Fetches and displays payment information for work orders
 * @since 3.54.0
 */
(function() {
    'use strict';

    const paymentTypeLabels = {
        efectivo: 'Efectivo',
        cheque: 'Cheque',
        transferencia: 'Transferencia',
        deposito: 'Depósito'
    };

    window.showPaymentInfoPopup = function(orderId, baseUrl, token) {
        const modal = document.getElementById('paymentInfoModal');
        const body = document.getElementById('paymentInfoBody');
        const loader = document.getElementById('paymentInfoLoader');
        const content = document.getElementById('paymentInfoContent');
        const errorDiv = document.getElementById('paymentInfoError');

        if (!modal || !body || !loader || !content) return;

        // Do not clear body.innerHTML - that removes loader/content/error divs and leaves modal empty
        loader.style.display = 'block';
        content.style.display = 'none';
        content.innerHTML = '';
        if (errorDiv) {
            errorDiv.style.display = 'none';
            errorDiv.textContent = '';
        }

        const url = (baseUrl || '') + '&order_id=' + orderId + '&' + (token || '') + '=1';
        fetch(url)
            .then(r => r.json())
            .then(data => {
                loader.style.display = 'none';
                if (data && data.success) {
                    content.innerHTML = renderPaymentInfo(data, orderId);
                    content.style.display = 'block';
                } else {
                    if (errorDiv) {
                        errorDiv.textContent = (data && data.message) ? data.message : 'Error loading payment info';
                        errorDiv.style.display = 'block';
                    }
                }
            })
            .catch(err => {
                loader.style.display = 'none';
                if (errorDiv) {
                    errorDiv.textContent = 'Error loading payment info';
                    errorDiv.style.display = 'block';
                }
            });

        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
    };

    function renderPaymentInfo(data, orderId) {
        let html = '<div class="payment-info-summary mb-4">';
        html += '<table class="table table-sm"><tbody>';
        html += '<tr><th>Valor a facturar:</th><td>Q ' + formatNum(data.invoice_value) + '</td></tr>';
        html += '<tr><th>Total pagado:</th><td>Q ' + formatNum(data.total_paid) + '</td></tr>';
        html += '<tr><th>Saldo pendiente:</th><td>Q ' + formatNum(-(parseFloat(data.remaining_balance) || 0)) + '</td></tr>';
        html += '</tbody></table></div>';

        if (data.payment_proofs && data.payment_proofs.length > 0) {
            const proofBaseUrl = (typeof window.paymentProofBaseUrl !== 'undefined') ? window.paymentProofBaseUrl : (window.location.pathname.replace(/\/[^/]*$/, '') + '/index.php?option=com_ordenproduccion&view=paymentproof&order_id=');
            html += '<h6>Comprobantes de pago</h6>';
            html += '<table class="table table-sm table-bordered"><thead><tr>';
            html += '<th>ID</th><th>Documento</th><th>Tipo</th><th>Monto doc.</th><th>Aplicado</th><th>Archivo</th></tr></thead><tbody>';
            data.payment_proofs.forEach(function(p) {
                const typeLabel = paymentTypeLabels[p.payment_type] || p.payment_type;
                const fileUrl = p.file_path ? (p.file_path.startsWith('http') ? p.file_path : (window.location.origin + '/' + p.file_path.replace(/^\//, ''))) : '';
                const fileLink = fileUrl ? '<a href="' + escapeHtml(fileUrl) + '" target="_blank"><i class="fas fa-file-pdf"></i></a>' : '-';
                const proofId = (p.id != null && p.id !== '') ? parseInt(p.id, 10) : 0;
                const proofUrl = (proofId > 0 && orderId) ? (proofBaseUrl + orderId + '#proof-' + proofId) : (proofBaseUrl + (orderId || ''));
                const proofLink = proofId > 0 && orderId
                    ? '<a href="' + escapeHtml(proofUrl) + '">#' + proofId + '</a>'
                    : ('#' + (proofId || ''));
                html += '<tr>';
                html += '<td>' + proofLink + '</td>';
                html += '<td>' + escapeHtml(p.document_number || '') + '</td>';
                html += '<td>' + escapeHtml(typeLabel) + '</td>';
                html += '<td>Q ' + formatNum(p.payment_amount) + '</td>';
                html += '<td>Q ' + formatNum(p.amount_applied) + '</td>';
                html += '<td>' + fileLink + '</td>';
                html += '</tr>';
            });
            html += '</tbody></table>';
        } else {
            html += '<p class="text-muted">No hay comprobantes de pago registrados.</p>';
        }
        return html;
    }

    function formatNum(n) {
        return parseFloat(n || 0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }
    function escapeHtml(s) {
        const div = document.createElement('div');
        div.textContent = s || '';
        return div.innerHTML;
    }
})();
