<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_ordenproduccion
 *
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Grimpsa\Component\Ordenproduccion\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Session\Session;
use Grimpsa\Component\Ordenproduccion\Site\Helper\HistorialHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\AccessHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\QuotationLineImagesHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\TelegramNotificationHelper;

/**
 * Ajax controller for com_ordenproduccion
 *
 * @since  1.0.0
 */
class AjaxController extends BaseController
{
    /**
     * Method to change work order status via AJAX
     *
     * @return  void
     *
     * @since   1.0.0
     */
    public function changeStatus()
    {
        try {
            // Set proper headers for JSON response
            header('Content-Type: application/json');
            
            $app = Factory::getApplication();
            $user = Factory::getUser();
        
        // Check CSRF token
        if (!Session::checkToken()) {
            echo json_encode(['success' => false, 'message' => 'Invalid token']);
            exit;
        }
        
        // Check if user is in produccion group
        $userGroups = $user->getAuthorisedGroups();
        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->select('id')
            ->from($db->quoteName('#__usergroups'))
            ->where($db->quoteName('title') . ' = ' . $db->quote('produccion'));

        $db->setQuery($query);
        $produccionGroupId = $db->loadResult();

        $hasProductionAccess = false;
        if ($produccionGroupId && in_array($produccionGroupId, $userGroups)) {
            $hasProductionAccess = true;
        }

        if (!$hasProductionAccess) {
            echo json_encode(['success' => false, 'message' => 'Acceso denegado']);
            exit;
        }
        
        $orderId = $app->input->getInt('order_id', 0);
        $newStatus = $app->input->getString('new_status', '');
        
        if ($orderId > 0 && !empty($newStatus)) {
            try {
                $db = Factory::getDbo();
                
                // Get current status before updating
                $query = $db->getQuery(true)
                    ->select($db->quoteName('status'))
                    ->from($db->quoteName('#__ordenproduccion_ordenes'))
                    ->where($db->quoteName('id') . ' = ' . (int)$orderId);
                
                $db->setQuery($query);
                $oldStatus = $db->loadResult();
                
                // Update status
                $query = $db->getQuery(true)
                    ->update($db->quoteName('#__ordenproduccion_ordenes'))
                    ->set($db->quoteName('status') . ' = ' . $db->quote($newStatus))
                    ->set($db->quoteName('modified') . ' = NOW()')
                    ->set($db->quoteName('modified_by') . ' = ' . (int)$user->id)
                    ->where($db->quoteName('id') . ' = ' . (int)$orderId);

                $db->setQuery($query);
                $result = $db->execute();
                
                if ($result) {
                    // Save historial entry for status change
                    $statusDescription = 'Estado cambiado de "' . ($oldStatus ?: 'N/A') . '" a "' . $newStatus . '"';
                    $historialSaved = HistorialHelper::saveEntry(
                        $orderId,
                        'status_change',
                        'Cambio de Estado',
                        $statusDescription,
                        $user->id,
                        ['old_status' => $oldStatus, 'new_status' => $newStatus]
                    );
                    
                    $message = 'Estado actualizado correctamente';
                    if (!$historialSaved) {
                        // Log warning but don't fail the status update
                        \Joomla\CMS\Log\Log::add('Failed to save historial entry for status change on order ' . $orderId . ' (from "' . ($oldStatus ?: 'N/A') . '" to "' . $newStatus . '")', \Joomla\CMS\Log\Log::WARNING, 'com_ordenproduccion');
                    }
                    
                    echo json_encode(['success' => true, 'message' => $message]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Error al actualizar el estado']);
                }
            } catch (Exception $e) {
                echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Datos inválidos']);
        }
        
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
        }
        
        exit;
    }

    /**
     * Method to create invoice via AJAX
     *
     * @return  void
     *
     * @since   3.50.0
     */
    public function createInvoice()
    {
        try {
            // Set proper headers for JSON response
            header('Content-Type: application/json');
            
            $app = Factory::getApplication();
            $user = Factory::getUser();
        
            // Check CSRF token
            if (!Session::checkToken()) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            $input = $app->input;
            
            // Get form data
            $orderId = $input->getInt('order_id', 0);
            $orderNumber = $input->getString('order_number', '');
            $cliente = $input->getString('cliente', '');
            $nit = $input->getString('nit', '');
            $direccion = $input->getString('direccion', '');
            $items = $input->get('items', [], 'array');
            
            // Validate required fields
            if (empty($orderId) || empty($orderNumber) || empty($cliente) || empty($nit)) {
                echo json_encode(['success' => false, 'message' => 'Missing required fields']);
                exit;
            }

            // Get work order data directly from database
            $db = Factory::getDbo();
            $query = $db->getQuery(true)
                ->select('*')
                ->from($db->quoteName('#__ordenproduccion_ordenes'))
                ->where($db->quoteName('id') . ' = ' . (int) $orderId);
            
            $db->setQuery($query);
            $workOrder = $db->loadObject();
            
            if (!$workOrder) {
                echo json_encode(['success' => false, 'message' => 'Order not found']);
                exit;
            }

            // Generate autonumeric invoice number
            $query = $db->getQuery(true)
                ->select('MAX(id) + 1')
                ->from($db->quoteName('#__ordenproduccion_invoices'));
            $db->setQuery($query);
            $nextId = $db->loadResult() ?: 1;
            $invoiceNumber = 'FAC-' . str_pad($nextId, 6, '0', STR_PAD_LEFT);
            
            // Calculate total amount from items
            $totalAmount = 0;
            $lineItems = [];
            
            foreach ($items as $item) {
                if (!empty($item['cantidad']) && !empty($item['precio_unitario'])) {
                    $cantidad = floatval($item['cantidad']);
                    $precioUnitario = floatval($item['precio_unitario']);
                    $subtotal = $cantidad * $precioUnitario;
                    
                    $lineItems[] = [
                        'cantidad' => $cantidad,
                        'descripcion' => $item['descripcion'] ?? '',
                        'precio_unitario' => $precioUnitario,
                        'subtotal' => $subtotal
                    ];
                    
                    $totalAmount += $subtotal;
                }
            }

            // Prepare invoice data
            $invoiceData = (object) [
                'invoice_number' => $invoiceNumber,
                'orden_id' => $orderId,
                'orden_de_trabajo' => $orderNumber,
                'client_name' => $cliente,
                'client_nit' => $nit,
                'sales_agent' => $workOrder->sales_agent ?? '',
                'request_date' => $workOrder->request_date ? Factory::getDate($workOrder->request_date)->format('Y-m-d') : null,
                'delivery_date' => $workOrder->delivery_date ?? null,
                'invoice_date' => Factory::getDate()->format('Y-m-d'),
                'invoice_amount' => $totalAmount,
                'currency' => 'Q',
                'work_description' => $workOrder->work_description ?? '',
                'material' => $workOrder->material ?? '',
                'dimensions' => $workOrder->dimensions ?? '',
                'print_color' => $workOrder->print_color ?? '',
                'line_items' => json_encode($lineItems),
                'quotation_file' => $workOrder->quotation_files ?? '',
                'extraction_status' => 'manual',
                'status' => 'created',
                'notes' => 'Created from quotation form',
                'state' => 1,
                'created' => Factory::getDate()->toSql(),
                'created_by' => $user->id
            ];

            // Save invoice directly to database
            $result = $db->insertObject('#__ordenproduccion_invoices', $invoiceData, 'id');

            if ($result) {
                $newInvId = (int) ($invoiceData->id ?? 0);
                if ($newInvId < 1) {
                    $newInvId = (int) $db->insertid();
                }
                if ($newInvId > 0) {
                    try {
                        TelegramNotificationHelper::notifyInvoiceCreated($newInvId);
                    } catch (\Throwable $e) {
                    }
                }
                // Update work order with invoice number
                $query = $db->getQuery(true)
                    ->update($db->quoteName('#__ordenproduccion_ordenes'))
                    ->set($db->quoteName('invoice_number') . ' = ' . $db->quote($invoiceNumber))
                    ->where($db->quoteName('id') . ' = ' . (int) $orderId);
                $db->setQuery($query);
                $db->execute();
                
                echo json_encode([
                    'success' => true, 
                    'message' => 'Invoice created successfully: ' . $invoiceNumber,
                    'invoice_number' => $invoiceNumber,
                    'invoice_id' => $invoiceData->id
                ]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error creating invoice']);
            }
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
        }
        
        exit;
    }

    /**
     * Method to create quotation via AJAX
     *
     * @return  void
     *
     * @since   3.52.0
     */
    public function createQuotation()
    {
        try {
            // Set proper headers for JSON response
            header('Content-Type: application/json');
            
            $app = Factory::getApplication();
            $user = Factory::getUser();
        
            // Check CSRF token
            if (!Session::checkToken()) {
                echo json_encode(['success' => false, 'message' => 'Invalid token']);
                exit;
            }
            
            // Check if user is in ventas group
            $userGroups = $user->getAuthorisedGroups();
            $db = Factory::getDbo();
            $query = $db->getQuery(true)
                ->select('id')
                ->from($db->quoteName('#__usergroups'))
                ->where($db->quoteName('title') . ' = ' . $db->quote('ventas'));

            $db->setQuery($query);
            $ventasGroupId = $db->loadResult();

            $hasVentasAccess = false;
            if ($ventasGroupId && in_array($ventasGroupId, $userGroups)) {
                $hasVentasAccess = true;
            }

            if (!$hasVentasAccess) {
                echo json_encode(['success' => false, 'message' => 'Acceso denegado - Solo usuarios del grupo ventas']);
                exit;
            }
            
            $input = $app->input;
            
            // Get form data (contact_name → client_name, contact_vat → client_nit, x_studio_agente_de_ventas → sales_agent)
            $clientName = $input->getString('client_name', '');
            $clientNit = $input->getString('client_nit', '');
            $clientAddress = $input->getString('client_address', '');
            $contactName = $input->getString('contact_name', '');
            $contactPhone = $input->getString('contact_phone', '');
            $quoteDate = $input->getString('quote_date', '');
            $clientId = $input->getString('client_id', '');
            $salesAgent = $input->getString('sales_agent', '');
            $lines = $input->get('lines', [], 'array');
            $lines = QuotationLineImagesHelper::mergeLineImagesJsonFromRequest($lines);
            $items = $input->get('items', [], 'array');
            
            // Validate required fields
            if (empty($clientName) || empty($clientNit) || empty($quoteDate)) {
                echo json_encode(['success' => false, 'message' => 'Missing required fields']);
                exit;
            }
            // When using lines (pre-cotización), at least one line required
            if (!empty($lines)) {
                $validLines = 0;
                foreach ($lines as $line) {
                    if (!empty($line['pre_cotizacion_id']) && isset($line['value'])) {
                        $validLines++;
                    }
                }
                if ($validLines === 0) {
                    echo json_encode(['success' => false, 'message' => 'Add at least one Pre-Cotización line']);
                    exit;
                }
                $preIdsForQuote = [];
                foreach ($lines as $line) {
                    if (!empty($line['pre_cotizacion_id'])) {
                        $preIdsForQuote[] = (int) $line['pre_cotizacion_id'];
                    }
                }
                $precotModel = $app->bootComponent('com_ordenproduccion')->getMVCFactory()
                    ->createModel('Precotizacion', 'Site', ['ignore_request' => true]);
                $precotErr = $precotModel->validatePreCotizacionIdsForQuotationLine($preIdsForQuote);
                if ($precotErr !== null) {
                    $app->getLanguage()->load('com_ordenproduccion', JPATH_SITE);
                    echo json_encode(['success' => false, 'message' => Text::_($precotErr)]);
                    exit;
                }
            }

            // Generate autonumeric quotation number
            $query = $db->getQuery(true)
                ->select('MAX(id) + 1')
                ->from($db->quoteName('#__ordenproduccion_quotations'));
            $db->setQuery($query);
            $nextId = $db->loadResult() ?: 1;
            $quotationNumber = 'COT-' . str_pad($nextId, 6, '0', STR_PAD_LEFT);
            
            $totalAmount = 0;
            $lineItems = [];
            
            // New format: lines[] with pre_cotizacion_id, cantidad, descripcion, value (valor final)
            $precotModel = $app->bootComponent('com_ordenproduccion')->getMVCFactory()->createModel('Precotizacion', 'Site', ['ignore_request' => true]);
            if (!empty($lines)) {
                foreach ($lines as $lineOrder => $line) {
                    $preId = isset($line['pre_cotizacion_id']) ? (int) $line['pre_cotizacion_id'] : 0;
                    $value = isset($line['value']) ? (float) $line['value'] : 0;
                    $cantidad = isset($line['cantidad']) ? (float) $line['cantidad'] : 0;
                    $desc = isset($line['descripcion']) ? trim((string) $line['descripcion']) : '';
                    if ($preId > 0 && $value >= 0) {
                        if ($cantidad < 0.001) {
                            $app->getLanguage()->load('com_ordenproduccion', JPATH_SITE);
                            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_QUOTATION_LINE_CANTIDAD_REQUIRED')]);
                            exit;
                        }
                        $baseTotal = $precotModel ? (float) $precotModel->getTotalForPreCotizacion($preId) : 0;
                        $minTotal = $precotModel ? (float) $precotModel->getMinimumValorFinalForPreCotizacion($preId) : $baseTotal;
                        if ($value < $minTotal) {
                            $app->getLanguage()->load('com_ordenproduccion', JPATH_SITE);
                            echo json_encode(['success' => false, 'message' => Text::sprintf('COM_ORDENPRODUCCION_VALOR_FINAL_MIN_ERROR', number_format($minTotal, 2))]);
                            exit;
                        }
                        $valorUnitario = $cantidad > 0 ? round($value / $cantidad, 4) : (float) $value;
                        $lineItems[] = [
                            'line_order' => $lineOrder,
                            'cantidad' => $cantidad,
                            'descripcion' => $desc !== '' ? $desc : 'PRE-' . $preId,
                            'valor_unitario' => $valorUnitario,
                            'subtotal' => $value,
                            'valor_final' => $value,
                            'pre_cotizacion_id' => $preId,
                            'pre_cotizacion_total' => $baseTotal,
                            'line_images_json' => QuotationLineImagesHelper::normalizeJsonFromInput(isset($line['line_images_json']) ? (string) $line['line_images_json'] : ''),
                        ];
                        $totalAmount += $value;
                    }
                }
            } else {
                // Legacy format: items[] with cantidad, descripcion, valor_unitario, subtotal
                foreach ($items as $lineOrder => $item) {
                    if (!empty($item['cantidad']) && !empty($item['valor_unitario'])) {
                        $cantidad = (float) $item['cantidad'];
                        $valorUnitario = round((float) $item['valor_unitario'], 4);
                        $subtotal = $cantidad * $valorUnitario;
                        $lineItems[] = [
                            'line_order' => $lineOrder,
                            'cantidad' => $cantidad,
                            'descripcion' => $item['descripcion'] ?? '',
                            'valor_unitario' => $valorUnitario,
                            'subtotal' => $subtotal,
                            'pre_cotizacion_id' => null,
                            'line_images_json' => '[]',
                        ];
                        $totalAmount += $subtotal;
                    }
                }
            }

            if (empty($lineItems)) {
                echo json_encode(['success' => false, 'message' => 'Add at least one quotation line']);
                exit;
            }

            $cols = $db->getTableColumns('#__ordenproduccion_quotations', false);
            $cols = is_array($cols) ? array_change_key_case($cols, CASE_LOWER) : [];
            $hasClientId = isset($cols['client_id']);
            $hasSalesAgent = isset($cols['sales_agent']);
            $quotationData = (object) [
                'quotation_number' => $quotationNumber,
                'client_name' => $clientName,
                'client_nit' => $clientNit,
                'client_address' => $clientAddress,
                'contact_name' => $contactName,
                'contact_phone' => $contactPhone,
                'creation_date' => Factory::getDate()->toSql(),
                'quote_date' => $quoteDate,
                'total_amount' => $totalAmount,
                'currency' => 'Q',
                'status' => 'draft',
                'notes' => 'Created from quotation form',
                'state' => 1,
                'created' => Factory::getDate()->toSql(),
                'created_by' => $user->id,
                'version' => '3.52.0'
            ];
            if ($hasClientId) {
                $quotationData->client_id = $clientId !== '' ? $clientId : null;
            }
            if ($hasSalesAgent) {
                $quotationData->sales_agent = $salesAgent !== '' ? $salesAgent : null;
            }

            $result = $db->insertObject('#__ordenproduccion_quotations', $quotationData, 'id');

            $itemCols = $db->getTableColumns('#__ordenproduccion_quotation_items', false);
            $itemCols = is_array($itemCols) ? array_change_key_case($itemCols, CASE_LOWER) : [];
            $hasPreCotizacionId = isset($itemCols['pre_cotizacion_id']);
            $hasValorFinal = isset($itemCols['valor_final']);
            $hasLineImages = isset($itemCols['line_images_json']);
            if ($result) {
                $quotationId = $quotationData->id;
                
                foreach ($lineItems as $item) {
                    $itemData = (object) [
                        'quotation_id' => $quotationId,
                        'cantidad' => $item['cantidad'],
                        'descripcion' => $item['descripcion'],
                        'valor_unitario' => $item['valor_unitario'],
                        'subtotal' => $item['subtotal'],
                        'line_order' => $item['line_order'],
                        'created' => Factory::getDate()->toSql()
                    ];
                    if ($hasPreCotizacionId && isset($item['pre_cotizacion_id']) && $item['pre_cotizacion_id'] > 0) {
                        $itemData->pre_cotizacion_id = $item['pre_cotizacion_id'];
                    }
                    if ($hasValorFinal && isset($item['valor_final'])) {
                        $itemData->valor_final = $item['valor_final'];
                    }
                    $db->insertObject('#__ordenproduccion_quotation_items', $itemData, 'id');
                    if (isset($item['pre_cotizacion_id']) && (int) $item['pre_cotizacion_id'] > 0) {
                        $preTotal = isset($item['pre_cotizacion_total']) ? (float) $item['pre_cotizacion_total'] : 0;
                        $valorFinal = isset($item['valor_final']) ? (float) $item['valor_final'] : (float) $item['subtotal'];
                        if ($valorFinal > $preTotal) {
                            $margenAdicional = round($valorFinal - $preTotal, 2);
                            $paramPct = (float) ComponentHelper::getParams('com_ordenproduccion')->get('comision_margen_adicional', 0);
                            $comisionMargenAdicional = round($margenAdicional * $paramPct / 100, 2);
                            $pcCols = $db->getTableColumns('#__ordenproduccion_pre_cotizacion', false);
                            $pcCols = is_array($pcCols) ? array_change_key_case($pcCols, CASE_LOWER) : [];
                            $hasComisionCol = isset($pcCols['comision_margen_adicional']);
                            try {
                                $q = $db->getQuery(true)
                                    ->update($db->quoteName('#__ordenproduccion_pre_cotizacion'))
                                    ->set($db->quoteName('margen_adicional') . ' = ' . (float) $margenAdicional)
                                    ->where($db->quoteName('id') . ' = ' . (int) $item['pre_cotizacion_id']);
                                if ($hasComisionCol) {
                                    $q->set($db->quoteName('comision_margen_adicional') . ' = ' . (float) $comisionMargenAdicional);
                                }
                                $db->setQuery($q)->execute();
                            } catch (\Exception $e) {
                                // Column may not exist yet; run migration 3.88.0 / 3.94.0
                            }
                        } else {
                            $pcCols = $db->getTableColumns('#__ordenproduccion_pre_cotizacion', false);
                            $pcCols = is_array($pcCols) ? array_change_key_case($pcCols, CASE_LOWER) : [];
                            $hasComisionCol = isset($pcCols['comision_margen_adicional']);
                            try {
                                $q = $db->getQuery(true)
                                    ->update($db->quoteName('#__ordenproduccion_pre_cotizacion'))
                                    ->set($db->quoteName('margen_adicional') . ' = NULL')
                                    ->where($db->quoteName('id') . ' = ' . (int) $item['pre_cotizacion_id']);
                                if ($hasComisionCol) {
                                    $q->set($db->quoteName('comision_margen_adicional') . ' = NULL');
                                }
                                $db->setQuery($q)->execute();
                            } catch (\Exception $e) {
                            }
                        }
                    }
                    if ($hasLineImages && !empty($itemData->id)) {
                        $norm = isset($item['line_images_json']) ? (string) $item['line_images_json'] : '[]';
                        if ($norm === '' || $norm === '[]') {
                            $db->setQuery(
                                $db->getQuery(true)
                                    ->update($db->quoteName('#__ordenproduccion_quotation_items'))
                                    ->set($db->quoteName('line_images_json') . ' = NULL')
                                    ->where($db->quoteName('id') . ' = ' . (int) $itemData->id)
                            )->execute();
                        } else {
                            $final = QuotationLineImagesHelper::finalizeJsonForQuotation((int) $quotationId, (int) $user->id, $norm);
                            $uq = $db->getQuery(true)
                                ->update($db->quoteName('#__ordenproduccion_quotation_items'))
                                ->where($db->quoteName('id') . ' = ' . (int) $itemData->id);
                            if ($final === '[]') {
                                $uq->set($db->quoteName('line_images_json') . ' = NULL');
                            } else {
                                $uq->set($db->quoteName('line_images_json') . ' = ' . $db->quote($final));
                            }
                            $db->setQuery($uq)->execute();
                        }
                    }
                }
                
                echo json_encode([
                    'success' => true, 
                    'message' => 'Quotation created successfully: ' . $quotationNumber,
                    'quotation_number' => $quotationNumber,
                    'quotation_id' => $quotationId
                ]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error creating quotation']);
            }
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
        }
        
        exit;
    }

    /**
     * Update an existing quotation (header + replace all lines). Access: ventas group or quotation owner.
     *
     * @return  void
     * @since   3.74.0
     */
    public function updateQuotation()
    {
        header('Content-Type: application/json');
        $app = Factory::getApplication();
        $user = Factory::getUser();
        if ($user->guest) {
            echo json_encode(['success' => false, 'message' => 'Login required']);
            exit;
        }
        if (!Session::checkToken()) {
            echo json_encode(['success' => false, 'message' => 'Invalid token']);
            exit;
        }
        $db = Factory::getDbo();
        $quotationId = $app->input->getInt('quotation_id', 0);
        if ($quotationId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid quotation']);
            exit;
        }
        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__ordenproduccion_quotations'))
            ->where($db->quoteName('id') . ' = ' . (int) $quotationId)
            ->where($db->quoteName('state') . ' = 1');
        $db->setQuery($query);
        $quotation = $db->loadObject();
        if (!$quotation) {
            echo json_encode(['success' => false, 'message' => 'Quotation not found']);
            exit;
        }
        if (!AccessHelper::userCanAccessQuotationRow($quotation)) {
            echo json_encode(['success' => false, 'message' => 'Access denied']);
            exit;
        }
        $qCols = $db->getTableColumns('#__ordenproduccion_quotations', false);
        $qCols = is_array($qCols) ? array_change_key_case($qCols, CASE_LOWER) : [];
        if (isset($qCols['cotizacion_confirmada']) && (int) ($quotation->cotizacion_confirmada ?? 0) === 1) {
            $app->getLanguage()->load('com_ordenproduccion', JPATH_SITE);
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_QUOTATION_LOCKED_EDIT')]);
            exit;
        }
        $precotOt = $app->bootComponent('com_ordenproduccion')->getMVCFactory()
            ->createModel('Precotizacion', 'Site', ['ignore_request' => true]);
        if ($precotOt && $precotOt->quotationHasActiveOrdenTrabajo($quotationId)) {
            $app->getLanguage()->load('com_ordenproduccion', JPATH_SITE);
            echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_QUOTATION_LOCKED_ORDEN_TRABAJO')]);
            exit;
        }
        $input = $app->input;
        $clientName = $input->getString('client_name', '');
        $clientNit = $input->getString('client_nit', '');
        $clientAddress = $input->getString('client_address', '');
        $contactName = $input->getString('contact_name', '');
        $contactPhone = $input->getString('contact_phone', '');
        // Edited quotations: always store today's date as the cotización date (site timezone).
        $quoteDate = Factory::getDate()->format('Y-m-d');
        $clientId = $input->getString('client_id', '');
        $salesAgent = $input->getString('sales_agent', '');
        $lines = $input->get('lines', [], 'array');
        $lines = QuotationLineImagesHelper::mergeLineImagesJsonFromRequest($lines);
        if (empty($clientName) || empty($clientNit)) {
            echo json_encode(['success' => false, 'message' => 'Missing required fields']);
            exit;
        }

        try {
        $precotModel = $app->bootComponent('com_ordenproduccion')->getMVCFactory()->createModel('Precotizacion', 'Site', ['ignore_request' => true]);
        $preIdsForQuote = [];
        foreach ($lines as $line) {
            if (!empty($line['pre_cotizacion_id'])) {
                $preIdsForQuote[] = (int) $line['pre_cotizacion_id'];
            }
        }
        $precotErr = $precotModel->validatePreCotizacionIdsForQuotationLine($preIdsForQuote);
        if ($precotErr !== null) {
            $app->getLanguage()->load('com_ordenproduccion', JPATH_SITE);
            echo json_encode(['success' => false, 'message' => Text::_($precotErr)]);
            exit;
        }
        $lineItems = [];
        $totalAmount = 0;
        foreach ($lines as $lineOrder => $line) {
            $preId = isset($line['pre_cotizacion_id']) ? (int) $line['pre_cotizacion_id'] : 0;
            $value = isset($line['value']) ? (float) $line['value'] : 0;
            $cantidad = isset($line['cantidad']) ? (float) $line['cantidad'] : 0;
            $desc = isset($line['descripcion']) ? trim((string) $line['descripcion']) : '';
            if ($value >= 0 && ($preId > 0 || $desc !== '')) {
                if ($cantidad < 0.001) {
                    $app->getLanguage()->load('com_ordenproduccion', JPATH_SITE);
                    echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_QUOTATION_LINE_CANTIDAD_REQUIRED')]);
                    exit;
                }
                $baseTotal = null;
                if ($preId > 0 && $precotModel) {
                    $baseTotal = (float) $precotModel->getTotalForPreCotizacion($preId);
                    $minTotal = (float) $precotModel->getMinimumValorFinalForPreCotizacion($preId);
                    if ($value < $minTotal) {
                        $app->getLanguage()->load('com_ordenproduccion', JPATH_SITE);
                        echo json_encode(['success' => false, 'message' => Text::sprintf('COM_ORDENPRODUCCION_VALOR_FINAL_MIN_ERROR', number_format($minTotal, 2))]);
                        exit;
                    }
                }
                $valorUnitario = $cantidad > 0 ? round($value / $cantidad, 4) : (float) $value;
                $lineItems[] = [
                    'line_order' => $lineOrder,
                    'cantidad' => $cantidad,
                    'descripcion' => $desc !== '' ? $desc : ('PRE-' . $preId),
                    'valor_unitario' => $valorUnitario,
                    'subtotal' => $value,
                    'valor_final' => $value,
                    'pre_cotizacion_id' => $preId > 0 ? $preId : null,
                    'pre_cotizacion_total' => $baseTotal,
                    'line_images_json' => QuotationLineImagesHelper::normalizeJsonFromInput(isset($line['line_images_json']) ? (string) $line['line_images_json'] : ''),
                ];
                $totalAmount += $value;
            }
        }
        if (empty($lineItems)) {
            echo json_encode(['success' => false, 'message' => 'Add at least one quotation line']);
            exit;
        }
        $cols = $db->getTableColumns('#__ordenproduccion_quotations', false);
        $cols = is_array($cols) ? array_change_key_case($cols, CASE_LOWER) : [];
        $updateData = (object) [
            'id' => $quotationId,
            'client_name' => $clientName,
            'client_nit' => $clientNit,
            'client_address' => $clientAddress,
            'contact_name' => $contactName,
            'contact_phone' => $contactPhone,
            'quote_date' => $quoteDate,
            'total_amount' => $totalAmount,
            'modified' => Factory::getDate()->toSql(),
            'modified_by' => $user->id,
        ];
        if (isset($cols['client_id'])) $updateData->client_id = $clientId !== '' ? $clientId : null;
        if (isset($cols['sales_agent'])) $updateData->sales_agent = $salesAgent !== '' ? $salesAgent : null;
            $db->updateObject('#__ordenproduccion_quotations', $updateData, 'id');
            $db->setQuery(
                $db->getQuery(true)
                    ->delete($db->quoteName('#__ordenproduccion_quotation_items'))
                    ->where($db->quoteName('quotation_id') . ' = ' . (int) $quotationId)
            )->execute();
            $itemCols = $db->getTableColumns('#__ordenproduccion_quotation_items', false);
            $itemCols = is_array($itemCols) ? array_change_key_case($itemCols, CASE_LOWER) : [];
            $hasPreCotizacionId = isset($itemCols['pre_cotizacion_id']);
            $hasValorFinal = isset($itemCols['valor_final']);
            $hasLineImages = isset($itemCols['line_images_json']);
            foreach ($lineItems as $item) {
                $itemData = (object) [
                    'quotation_id' => $quotationId,
                    'cantidad' => $item['cantidad'],
                    'descripcion' => $item['descripcion'],
                    'valor_unitario' => $item['valor_unitario'],
                    'subtotal' => $item['subtotal'],
                    'line_order' => $item['line_order'],
                    'created' => Factory::getDate()->toSql(),
                ];
                if ($hasPreCotizacionId && isset($item['pre_cotizacion_id']) && $item['pre_cotizacion_id'] > 0) {
                    $itemData->pre_cotizacion_id = $item['pre_cotizacion_id'];
                }
                if ($hasValorFinal && isset($item['valor_final'])) {
                    $itemData->valor_final = $item['valor_final'];
                }
                $db->insertObject('#__ordenproduccion_quotation_items', $itemData, 'id');
                if (isset($item['pre_cotizacion_id']) && (int) $item['pre_cotizacion_id'] > 0) {
                    $preTotal = isset($item['pre_cotizacion_total']) ? (float) $item['pre_cotizacion_total'] : 0;
                    $valorFinal = isset($item['valor_final']) ? (float) $item['valor_final'] : (float) $item['subtotal'];
                    if ($valorFinal > $preTotal) {
                        $margenAdicional = round($valorFinal - $preTotal, 2);
                        $paramPct = (float) ComponentHelper::getParams('com_ordenproduccion')->get('comision_margen_adicional', 0);
                        $comisionMargenAdicional = round($margenAdicional * $paramPct / 100, 2);
                        $pcCols = $db->getTableColumns('#__ordenproduccion_pre_cotizacion', false);
                        $pcCols = is_array($pcCols) ? array_change_key_case($pcCols, CASE_LOWER) : [];
                        $hasComisionCol = isset($pcCols['comision_margen_adicional']);
                        try {
                            $q = $db->getQuery(true)
                                ->update($db->quoteName('#__ordenproduccion_pre_cotizacion'))
                                ->set($db->quoteName('margen_adicional') . ' = ' . (float) $margenAdicional)
                                ->where($db->quoteName('id') . ' = ' . (int) $item['pre_cotizacion_id']);
                            if ($hasComisionCol) {
                                $q->set($db->quoteName('comision_margen_adicional') . ' = ' . (float) $comisionMargenAdicional);
                            }
                            $db->setQuery($q)->execute();
                        } catch (\Exception $e) {
                            // Column may not exist; run migration 3.88.0 / 3.94.0
                        }
                    } else {
                        $pcCols = $db->getTableColumns('#__ordenproduccion_pre_cotizacion', false);
                        $pcCols = is_array($pcCols) ? array_change_key_case($pcCols, CASE_LOWER) : [];
                        $hasComisionCol = isset($pcCols['comision_margen_adicional']);
                        try {
                            $q = $db->getQuery(true)
                                ->update($db->quoteName('#__ordenproduccion_pre_cotizacion'))
                                ->set($db->quoteName('margen_adicional') . ' = NULL')
                                ->where($db->quoteName('id') . ' = ' . (int) $item['pre_cotizacion_id']);
                            if ($hasComisionCol) {
                                $q->set($db->quoteName('comision_margen_adicional') . ' = NULL');
                            }
                            $db->setQuery($q)->execute();
                        } catch (\Exception $e) {
                        }
                    }
                }
                if ($hasLineImages && !empty($itemData->id)) {
                    $norm = isset($item['line_images_json']) ? (string) $item['line_images_json'] : '[]';
                    if ($norm === '' || $norm === '[]') {
                        $db->setQuery(
                            $db->getQuery(true)
                                ->update($db->quoteName('#__ordenproduccion_quotation_items'))
                                ->set($db->quoteName('line_images_json') . ' = NULL')
                                ->where($db->quoteName('id') . ' = ' . (int) $itemData->id)
                        )->execute();
                    } else {
                        $final = QuotationLineImagesHelper::finalizeJsonForQuotation((int) $quotationId, (int) $user->id, $norm);
                        $uq = $db->getQuery(true)
                            ->update($db->quoteName('#__ordenproduccion_quotation_items'))
                            ->where($db->quoteName('id') . ' = ' . (int) $itemData->id);
                        if ($final === '[]') {
                            $uq->set($db->quoteName('line_images_json') . ' = NULL');
                        } else {
                            $uq->set($db->quoteName('line_images_json') . ' = ' . $db->quote($final));
                        }
                        $db->setQuery($uq)->execute();
                    }
                }
            }
            echo json_encode([
                'success' => true,
                'message' => 'Quotation updated: ' . $quotation->quotation_number,
                'quotation_number' => $quotation->quotation_number,
                'quotation_id' => $quotationId,
            ]);
        } catch (\Throwable $e) {
            echo json_encode(['success' => false, 'message' => 'Error updating quotation: ' . $e->getMessage()]);
        }
        exit;
    }

    /**
     * Upload one image for a quotation line (staging or q{id}/). JSON task for edit form.
     *
     * @return  void
     *
     * @since   3.113.85
     */
    public function uploadQuotationLineImage()
    {
        header('Content-Type: application/json; charset=utf-8');
        $app  = Factory::getApplication();
        $user = Factory::getUser();
        if ($user->guest) {
            echo json_encode(['success' => false, 'message' => 'Login required']);
            exit;
        }
        if (!Session::checkToken()) {
            echo json_encode(['success' => false, 'message' => 'Invalid token']);
            exit;
        }
        $userGroups = $user->getAuthorisedGroups();
        $db         = Factory::getDbo();
        $query      = $db->getQuery(true)
            ->select('id')
            ->from($db->quoteName('#__usergroups'))
            ->where($db->quoteName('title') . ' = ' . $db->quote('ventas'));
        $db->setQuery($query);
        $ventasGroupId = (int) $db->loadResult();
        if (!$ventasGroupId || !in_array($ventasGroupId, $userGroups, true)) {
            echo json_encode(['success' => false, 'message' => 'Access denied']);
            exit;
        }

        $lang = $app->getLanguage();
        $lang->load('com_ordenproduccion', JPATH_SITE);
        $lang->load('com_ordenproduccion', JPATH_SITE . '/components/com_ordenproduccion');

        $quotationId = $app->input->getInt('quotation_id', 0);
        if ($quotationId > 0) {
            $query = $db->getQuery(true)
                ->select('*')
                ->from($db->quoteName('#__ordenproduccion_quotations'))
                ->where($db->quoteName('id') . ' = ' . $quotationId)
                ->where($db->quoteName('state') . ' = 1');
            $db->setQuery($query);
            $qRow = $db->loadObject();
            if (!$qRow || !AccessHelper::userCanAccessQuotationRow($qRow)) {
                echo json_encode(['success' => false, 'message' => 'Quotation not found']);
                exit;
            }
            $qCols = $db->getTableColumns('#__ordenproduccion_quotations', false);
            $qCols = is_array($qCols) ? array_change_key_case($qCols, CASE_LOWER) : [];
            if (isset($qCols['cotizacion_confirmada']) && (int) ($qRow->cotizacion_confirmada ?? 0) === 1) {
                echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_QUOTATION_LOCKED_EDIT')]);
                exit;
            }
            $precotOt = $app->bootComponent('com_ordenproduccion')->getMVCFactory()
                ->createModel('Precotizacion', 'Site', ['ignore_request' => true]);
            if ($precotOt && $precotOt->quotationHasActiveOrdenTrabajo($quotationId)) {
                echo json_encode(['success' => false, 'message' => Text::_('COM_ORDENPRODUCCION_QUOTATION_LOCKED_ORDEN_TRABAJO')]);
                exit;
            }
        }

        $file = $app->input->files->get('image', [], 'array');
        $res  = QuotationLineImagesHelper::processUploadedFile(is_array($file) ? $file : null, (int) $user->id, $quotationId);
        echo json_encode($res);
        exit;
    }

    /**
     * Get pre-cotización details HTML for popup (no document chrome / no debug bar).
     *
     * @return  void
     * @since   3.76.0
     */
    public function getPrecotizacionDetails()
    {
        header('Content-Type: text/html; charset=utf-8');

        $app = Factory::getApplication();
        $user = Factory::getUser();

        if ($user->guest) {
            echo '<p class="text-muted p-3">' . htmlspecialchars(\Joomla\CMS\Language\Text::_('COM_ORDENPRODUCCION_ERROR_LOGIN_REQUIRED')) . '</p>';
            exit;
        }

        if (!Session::checkToken('request')) {
            echo '<p class="text-danger p-3">' . htmlspecialchars(\Joomla\CMS\Language\Text::_('JINVALID_TOKEN')) . '</p>';
            exit;
        }

        $id = (int) $app->input->get('id', 0);
        if ($id < 1) {
            echo '<p class="text-muted p-3">' . htmlspecialchars(\Joomla\CMS\Language\Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ERROR_INVALID_ID')) . '</p>';
            exit;
        }

        $app->input->set('id', $id);
        $app->input->set('layout', 'details');

        ob_start();
        try {
            $view = $this->getView('Cotizador', 'html');
            $view->display();
        } catch (\Throwable $e) {
            ob_end_clean();
            echo '<p class="text-danger p-3">' . htmlspecialchars($e->getMessage()) . '</p>';
            exit;
        }
        $html = ob_get_clean();
        echo $html;
        exit;
    }

    /**
     * Get payment info for a work order (AJAX)
     * Access: owner (sales agent) or Administracion group - same as valor a facturar
     *
     * @return  void
     *
     * @since   3.54.0
     */
    public function getOrderPayments()
    {
        header('Content-Type: application/json');
        
        $app = Factory::getApplication();
        $user = Factory::getUser();
        
        if ($user->guest) {
            echo json_encode(['success' => false, 'message' => 'Login required']);
            exit;
        }
        
        if (!Session::checkToken('get')) {
            echo json_encode(['success' => false, 'message' => 'Invalid token']);
            exit;
        }
        
        $orderId = $app->input->getInt('order_id', 0);
        if ($orderId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid order']);
            exit;
        }
        
        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__ordenproduccion_ordenes'))
            ->where($db->quoteName('id') . ' = ' . (int) $orderId);
        $db->setQuery($query);
        $order = $db->loadObject();
        
        if (!$order) {
            echo json_encode(['success' => false, 'message' => 'Order not found']);
            exit;
        }
        
        $salesAgent = $order->sales_agent ?? $order->agente_ventas ?? '';
        if (!AccessHelper::canSeeValorFactura($salesAgent)) {
            echo json_encode(['success' => false, 'message' => 'Access denied']);
            exit;
        }
        
        $paymentModel = $app->bootComponent('com_ordenproduccion')->getMVCFactory()->createModel('Paymentproof', 'Site');
        $paymentProofs = $paymentModel->getPaymentProofsByOrderId($orderId);
        $totalPaid = $paymentModel->getTotalPaidByOrderId($orderId);
        $invoiceValue = (float) ($order->invoice_value ?? $order->valor_a_facturar ?? 0);
        $remainingBalance = $invoiceValue - $totalPaid;
        
        echo json_encode([
            'success' => true,
            'order_number' => $order->order_number ?? $order->orden_de_trabajo ?? '',
            'invoice_value' => $invoiceValue,
            'total_paid' => $totalPaid,
            'remaining_balance' => $remainingBalance,
            'payment_proofs' => $paymentProofs
        ]);
        exit;
    }

    /**
     * Suggest client names for report filter (by date range and search query)
     *
     * @return  void
     *
     * @since   3.6.0
     */
    public function suggestReportClients()
    {
        header('Content-Type: application/json; charset=utf-8');

        $app = Factory::getApplication();
        $user = Factory::getUser();

        if ($user->guest) {
            echo json_encode(['success' => false, 'clients' => []]);
            exit;
        }

        if (!Session::checkToken('get')) {
            echo json_encode(['success' => false, 'clients' => []]);
            exit;
        }

        $dateFrom = $app->input->getString('date_from', '');
        $dateTo = $app->input->getString('date_to', '');
        $q = $app->input->getString('q', '');

        if (empty($dateFrom) || empty($dateTo)) {
            echo json_encode(['success' => true, 'clients' => [], 'message' => 'Select date range first']);
            exit;
        }

        try {
            $model = $app->bootComponent('com_ordenproduccion')->getMVCFactory()->createModel('Administracion', 'Site');
            $clients = $model->getReportClientsInDateRange($dateFrom, $dateTo, $q);
            echo json_encode(['success' => true, 'clients' => $clients]);
        } catch (\Exception $e) {
            echo json_encode(['success' => false, 'clients' => []]);
        }
        exit;
    }

    /**
     * Suggest NITs for report filter (by date range and search query)
     *
     * @return  void
     *
     * @since   3.6.0
     */
    public function suggestReportNits()
    {
        header('Content-Type: application/json; charset=utf-8');

        $app = Factory::getApplication();
        $user = Factory::getUser();

        if ($user->guest) {
            echo json_encode(['success' => false, 'nits' => []]);
            exit;
        }

        if (!Session::checkToken('get')) {
            echo json_encode(['success' => false, 'nits' => []]);
            exit;
        }

        $dateFrom = $app->input->getString('date_from', '');
        $dateTo = $app->input->getString('date_to', '');
        $q = $app->input->getString('q', '');

        if (empty($dateFrom) || empty($dateTo)) {
            echo json_encode(['success' => true, 'nits' => [], 'message' => 'Select date range first']);
            exit;
        }

        try {
            $model = $app->bootComponent('com_ordenproduccion')->getMVCFactory()->createModel('Administracion', 'Site');
            $nits = $model->getReportNitsInDateRange($dateFrom, $dateTo, $q);
            echo json_encode(['success' => true, 'nits' => $nits]);
        } catch (\Exception $e) {
            echo json_encode(['success' => false, 'nits' => []]);
        }
        exit;
    }
}
