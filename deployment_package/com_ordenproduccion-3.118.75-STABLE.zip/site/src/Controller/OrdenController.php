<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_ordenproduccion
 *
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Grimpsa\Component\Ordenproduccion\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Grimpsa\Component\Ordenproduccion\Site\Helper\FpdfHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\HistorialHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\OrdenTrabajoPdfPrecotSectionsHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\QuotationEnvioFelHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\TelegramNotificationHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\Utf8DisplayHelper;
use Grimpsa\Component\Ordenproduccion\Site\Model\OrdenModel;

/**
 * Orden controller for com_ordenproduccion
 *
 * @since  1.0.0
 */
class OrdenController extends BaseController
{
    /**
     * The default view for the display method.
     *
     * @var    string
     * @since  1.0.0
     */
    protected $default_view = 'orden';

    /**
     * Method to display a view.
     *
     * @param   boolean  $cachable   If true, the view output will be cached
     * @param   array    $urlparams  An array of safe URL parameters and their variable types, for valid values see {@link \JFilterInput::clean()}.
     *
     * @return  \Joomla\CMS\MVC\Controller\BaseController|boolean  This object to support chaining.
     *
     * @since   1.0.0
     */
    public function display($cachable = false, $urlparams = [])
    {
        $view = $this->input->get('view', $this->default_view);
        $this->input->set('view', $view);

        return parent::display($cachable, $urlparams);
    }

    /**
     * Method to generate PDF for a work order.
     *
     * @return  void
     *
     * @since   1.0.0
     */
    public function generatePdf()
    {
        $app = Factory::getApplication();
        $app->getLanguage()->load('com_ordenproduccion', JPATH_SITE . '/components/com_ordenproduccion');

        $user = Factory::getUser();
        
        // Check if user is in produccion group
        $userGroups = $user->getAuthorisedGroups();
        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->select('id')
            ->from($db->quoteName('#__usergroups'))
            ->where($db->quoteName('title') . ' = ' . $db->quote('produccion'));

        $db->setQuery($query);
        $produccionGroupId = $db->loadResult();

        $hasProductionAccess = false;
        if ($produccionGroupId && in_array($produccionGroupId, $userGroups)) {
            $hasProductionAccess = true;
        }

        if (!$hasProductionAccess) {
            $app->enqueueMessage('Acceso denegado. Solo usuarios del grupo Producción pueden generar PDFs.', 'error');
            $app->redirect('index.php?option=com_ordenproduccion&view=ordenes');
            return;
        }

        $orderId = $this->input->getInt('id', 0);
        
        if (!$orderId) {
            $app->enqueueMessage('ID de orden no válido.', 'error');
            $app->redirect('index.php?option=com_ordenproduccion&view=ordenes');
            return;
        }

        try {
            // Get work order data
            $workOrderData = $this->getWorkOrderData($orderId);
            
            if (!$workOrderData) {
                $app->enqueueMessage('Orden de trabajo no encontrada.', 'error');
                $app->redirect('index.php?option=com_ordenproduccion&view=ordenes');
                return;
            }

            // Guard: block PDF for Anulada orders
            if (strtolower((string) ($workOrderData->status ?? '')) === 'anulada') {
                $app->enqueueMessage('No se puede imprimir una orden de trabajo Anulada.', 'error');
                $app->redirect('index.php?option=com_ordenproduccion&view=orden&id=' . $orderId);

                return;
            }

            // Guard: completed (Terminada) — OT PDF reprint is disabled; show clear message (not a raw FPDF error).
            $statusNorm = strtolower(trim((string) ($workOrderData->status ?? '')));
            if ($statusNorm === 'terminada') {
                $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_ORDEN_PDF_BLOCKED_TERMINADA'), 'warning');
                $app->redirect('index.php?option=com_ordenproduccion&view=orden&id=' . $orderId);

                return;
            }

            // Generate PDF using FPDF
            $this->generateWorkOrderPDF($orderId, $workOrderData);
            
        } catch (\Throwable $e) {
            $app->enqueueMessage('Error: ' . $e->getMessage(), 'error');
            $app->redirect('index.php?option=com_ordenproduccion&view=orden&id=' . $orderId);
        }
    }

    /**
     * Method to generate shipping slip PDF.
     *
     * @return  void
     *
     * @since   1.0.0
     */
    public function generateShippingSlip()
    {
        $app = Factory::getApplication();
        $user = Factory::getUser();
        
        // Check if user is in produccion group
        $userGroups = $user->getAuthorisedGroups();
        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->select('id')
            ->from($db->quoteName('#__usergroups'))
            ->where($db->quoteName('title') . ' = ' . $db->quote('produccion'));

        $db->setQuery($query);
        $produccionGroupId = $db->loadResult();

        $hasProductionAccess = false;
        if ($produccionGroupId && in_array($produccionGroupId, $userGroups)) {
            $hasProductionAccess = true;
        }

        if (!$hasProductionAccess) {
            $app->enqueueMessage('Acceso denegado. Solo usuarios del grupo Producción pueden generar envios.', 'error');
            $app->redirect('index.php?option=com_ordenproduccion&view=ordenes');
            return;
        }

                $orderId = $this->input->getInt('id', 0);
                $tipoEnvio = $this->input->getString('tipo_envio', 'completo');
                $tipoMensajeria = $this->input->getString('tipo_mensajeria', 'propio');
                $descripcionEnvio = $this->input->getString('descripcion_envio', '');
        
        if (!$orderId) {
            $app->enqueueMessage('ID de orden no válido.', 'error');
            $app->redirect('index.php?option=com_ordenproduccion&view=ordenes');
            return;
        }

        try {
            // Get work order data
            $workOrderData = $this->getWorkOrderData($orderId);
            
            if (!$workOrderData) {
                $app->enqueueMessage('Orden de trabajo no encontrada.', 'error');
                $app->redirect('index.php?option=com_ordenproduccion&view=ordenes');
                return;
            }

            // Guard: block for Anulada orders
            if (strtolower((string) ($workOrderData->status ?? '')) === 'anulada') {
                $app->enqueueMessage('No se puede generar un envío para una orden Anulada.', 'error');
                $app->redirect('index.php?option=com_ordenproduccion&view=orden&id=' . $orderId);
                return;
            }

            // Always save historial entries regardless of request method
            // This ensures history is logged even when opening PDF directly
            try {
                // Log the shipping event
                error_log('SHIPPING HISTORY DEBUG - Order ID: ' . $orderId . ', Tipo: ' . $tipoEnvio . ', Mensajeria: ' . $tipoMensajeria . ', Descripcion: ' . $descripcionEnvio);
                
                if ($tipoEnvio === 'completo') {
                    // For "completo", save print event with fixed description
                    $result = HistorialHelper::saveEntry(
                        $orderId,
                        'shipping_print',
                        'Impresion de Envio',
                        'Envio completo impreso via ' . $tipoMensajeria,
                        $user->id,
                        ['tipo_envio' => $tipoEnvio, 'tipo_mensajeria' => $tipoMensajeria]
                    );
                    error_log('SHIPPING HISTORY DEBUG - Completo save result: ' . var_export($result, true));
                    try {
                        QuotationEnvioFelHelper::maybeIssueFelAfterEnvioCompleto((int) $orderId, (int) $user->id);
                    } catch (\Throwable $e) {
                        error_log('QUOTATION_ENVIO_FEL_AFTER_COMPLETO: ' . $e->getMessage());
                    }
                } else {
                    // For "parcial", save shipping description if provided
                    if (!empty($descripcionEnvio)) {
                        $result1 = HistorialHelper::saveEntry(
                            $orderId,
                            'shipping_description',
                            'Descripcion de Envio',
                            $descripcionEnvio,
                            $user->id,
                            ['tipo_envio' => $tipoEnvio, 'tipo_mensajeria' => $tipoMensajeria]
                        );
                        error_log('SHIPPING HISTORY DEBUG - Descripcion save result: ' . var_export($result1, true));
                    }
                    
                    // Also save print event for parcial
                    $result2 = HistorialHelper::saveEntry(
                        $orderId,
                        'shipping_print',
                        'Impresion de Envio',
                        'Envio parcial impreso via ' . $tipoMensajeria,
                        $user->id,
                        ['tipo_envio' => $tipoEnvio, 'tipo_mensajeria' => $tipoMensajeria, 'descripcion' => $descripcionEnvio]
                    );
                    error_log('SHIPPING HISTORY DEBUG - Parcial save result: ' . var_export($result2, true));
                }
            } catch (\Exception $e) {
                // Log error but don't break PDF generation
                error_log('SHIPPING HISTORY ERROR: ' . $e->getMessage());
                $app->enqueueMessage('Advertencia: El envio se genero pero no se registro en el historial.', 'warning');
            }

            try {
                TelegramNotificationHelper::notifyEnvioIssued((int) $orderId, $tipoEnvio, $tipoMensajeria);
            } catch (\Throwable $e) {
            }

            // When "envio completo" is printed, set orden status to Terminada
            if ($tipoEnvio === 'completo') {
                try {
                    $db = Factory::getDbo();
                    $query = $db->getQuery(true)
                        ->select($db->quoteName('status'))
                        ->from($db->quoteName('#__ordenproduccion_ordenes'))
                        ->where($db->quoteName('id') . ' = ' . (int) $orderId);
                    $db->setQuery($query);
                    $oldStatus = $db->loadResult();
                    $newStatus = 'Terminada';
                    if ($oldStatus !== $newStatus) {
                        $db->setQuery($db->getQuery(true)
                            ->update($db->quoteName('#__ordenproduccion_ordenes'))
                            ->set($db->quoteName('status') . ' = ' . $db->quote($newStatus))
                            ->set($db->quoteName('modified') . ' = ' . $db->quote(Factory::getDate()->toSql()))
                            ->set($db->quoteName('modified_by') . ' = ' . (int) $user->id)
                            ->where($db->quoteName('id') . ' = ' . (int) $orderId));
                        $db->execute();
                        HistorialHelper::saveEntry(
                            $orderId,
                            'status_change',
                            'Cambio de Estado',
                            'Estado cambiado de "' . ($oldStatus ?: 'N/A') . '" a "' . $newStatus . '" (envio completo impreso)',
                            $user->id,
                            ['old_status' => $oldStatus, 'new_status' => $newStatus, 'trigger' => 'envio_completo']
                        );
                    }
                } catch (\Exception $e) {
                    error_log('ENVIO COMPLETO STATUS UPDATE ERROR: ' . $e->getMessage());
                }
            }

            // Generate shipping slip PDF using FPDF
            $this->generateShippingSlipPDF($orderId, $workOrderData, $tipoEnvio, $tipoMensajeria, $descripcionEnvio);
            
        } catch (\Throwable $e) {
            $app->enqueueMessage('Error: ' . $e->getMessage(), 'error');
            $app->redirect('index.php?option=com_ordenproduccion&view=orden&id=' . $orderId);
        }
    }

    /**
     * Method to get work order data from database.
     *
     * @param   int  $orderId  Work order ID
     *
     * @return  object|null  Work order data or null if not found
     *
     * @since   1.0.0
     */
    private function getWorkOrderData($orderId)
    {
        $db = Factory::getDbo();
        
        // Get main work order data
        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__ordenproduccion_ordenes'))
            ->where($db->quoteName('id') . ' = ' . (int)$orderId)
            ->where($db->quoteName('state') . ' = 1');

        $db->setQuery($query);
        $workOrder = $db->loadObject();

        if (!$workOrder) {
            return null;
        }

        OrdenModel::copySpanishFinishFieldsToEnglishAliases($workOrder);

        // Get additional EAV data (tecnico, detalles, etc.) - using correct table structure
        try {
            $eavQuery = $db->getQuery(true)
                ->select('attribute_name, attribute_value, created, created_by')
                ->from($db->quoteName('#__ordenproduccion_info'))
                ->where($db->quoteName('order_id') . ' = ' . (int)$orderId)
                ->where($db->quoteName('state') . ' = 1');

            $db->setQuery($eavQuery);
            $eavData = $db->loadObjectList();

            // Organize EAV data by attribute name
            $workOrder->eav_data = [];
            foreach ($eavData as $item) {
                $workOrder->eav_data[$item->attribute_name] = $item;
            }
        } catch (\Throwable $e) {
            // EAV table doesn't exist or other error - continue without EAV data
            $workOrder->eav_data = [];
        }

        try {
            $ordenModel = $this->app->bootComponent('com_ordenproduccion')
                ->getMVCFactory()
                ->createModel('Orden', 'Site', ['ignore_request' => true]);
            if ($ordenModel instanceof OrdenModel) {
                $ordenModel->attachPrecotHeaderFieldsForPdf($workOrder);
            }
        } catch (\Throwable $e) {
            // PDF can still render without PRE header enrichment
        }

        return $workOrder;
    }

    /**
     * Final dimensions text for orden PDF: orden_view_pre_medidas if present, otherwise dimensions,
     * with fallbacks mirroring orden vista (PRE medidas tabla / orden_source_json).
     */
    private function resolveMedidasFinalesForWorkOrderPdf(object $wd): string
    {
        if (isset($wd->orden_view_pre_medidas) && trim((string) $wd->orden_view_pre_medidas) !== '') {
            return trim((string) $wd->orden_view_pre_medidas);
        }

        if (isset($wd->dimensions) && trim((string) $wd->dimensions) !== '') {
            return trim((string) $wd->dimensions);
        }

        $preId = isset($wd->pre_cotizacion_id) ? (int) $wd->pre_cotizacion_id : 0;
        if ($preId >= 1) {
            try {
                $db = Factory::getDbo();
                $q = $db->getQuery(true)
                    ->select($db->quoteName('medidas'))
                    ->from($db->quoteName('#__ordenproduccion_pre_cotizacion'))
                    ->where($db->quoteName('id') . ' = ' . $preId);

                $db->setQuery($q);
                $raw = $db->loadResult();
                if ($raw !== null && trim((string) $raw) !== '') {
                    return trim((string) $raw);
                }
            } catch (\Throwable $e) {
            }
        }

        if (!empty($wd->orden_source_json)) {
            $decoded = json_decode((string) $wd->orden_source_json, true);
            if (\is_array($decoded) && isset($decoded['pre_medidas'])) {
                $m = trim((string) $decoded['pre_medidas']);
                if ($m !== '') {
                    return $m;
                }
            }
        }

        return '';
    }

    /**
     * PRE cabecera cantidad total for OT PDF (mirrors orden vista / snapshot JSON).
     */
    private function resolveCantidadTotalForWorkOrderPdf(object $wd): string
    {
        if (isset($wd->orden_view_pre_cantidad_total) && trim((string) $wd->orden_view_pre_cantidad_total) !== '') {
            return trim((string) $wd->orden_view_pre_cantidad_total);
        }

        $preId = isset($wd->pre_cotizacion_id) ? (int) $wd->pre_cotizacion_id : 0;
        if ($preId >= 1) {
            try {
                $db = Factory::getDbo();
                $q = $db->getQuery(true)
                    ->select($db->quoteName('cantidad_total'))
                    ->from($db->quoteName('#__ordenproduccion_pre_cotizacion'))
                    ->where($db->quoteName('id') . ' = ' . $preId);

                $db->setQuery($q);
                $raw = $db->loadResult();
                if ($raw !== null && trim((string) $raw) !== '') {
                    return trim((string) $raw);
                }
            } catch (\Throwable $e) {
            }
        }

        if (!empty($wd->orden_source_json)) {
            $decoded = json_decode((string) $wd->orden_source_json, true);
            if (\is_array($decoded) && isset($decoded['pre_cantidad_total'])) {
                $m = trim((string) $decoded['pre_cantidad_total']);
                if ($m !== '') {
                    return $m;
                }
            }
        }

        return '';
    }

    /**
     * Method to generate PDF file for work order using FPDF.
     *
     * @param   int     $orderId        Work order ID
     * @param   object  $workOrderData Work order data
     *
     * @return  void
     *
     * @since   1.0.0
     */
    private function generateWorkOrderPDF($orderId, $workOrderData)
    {
        if (!FpdfHelper::register()) {
            Factory::getApplication()->enqueueMessage('No se encontro la libreria FPDF para generar el PDF.', 'error');
            Factory::getApplication()->redirect('index.php?option=com_ordenproduccion&view=orden&id=' . (int) $orderId);

            return;
        }

                // Create PDF instance with UTF-8 support for 8.5" x 11" paper
                $pdf = new \FPDF('P', 'mm', array(215.9, 279.4)); // 8.5" x 11" in mm
                $pdf->AddPage();
                
                // Set margins for letter size
                $pdf->SetMargins(15, 15, 15);
                $pdfSideMarginMm = 15.0;

        // Set UTF-8 encoding for proper Spanish character support
        $pdf->SetAutoPageBreak(true, 15);
        
        // Function to fix Spanish characters for FPDF
        $fixSpanishChars = function ($text) {
            $text = Utf8DisplayHelper::normalizeUserFacing((string) $text);
            if ($text === '') {
                return $text;
            }

            // Convert common Spanish characters that FPDF doesn't handle well
            $replacements = [
                'Á' => 'A', 'É' => 'E', 'Í' => 'I', 'Ó' => 'O', 'Ú' => 'U', 'Ñ' => 'N',
                'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ñ' => 'n',
                'Ü' => 'U', 'ü' => 'u', 'Ç' => 'C', 'ç' => 'c'
            ];
            
            return strtr($text, $replacements);
        };

        Factory::getLanguage()->load('com_ordenproduccion', JPATH_SITE . '/components/com_ordenproduccion');

        $ordenLayoutPdf  = OrdenModel::ORDEN_VIEW_LAYOUT_STANDARD;
        $ordenPiecesPdf = [];

        try {
            $mOrdenPdf = Factory::getApplication()->bootComponent('com_ordenproduccion')
                ->getMVCFactory()->createModel('Orden', 'Site', ['ignore_request' => true]);

            $rowPdf = ($mOrdenPdf !== null) ? $mOrdenPdf->getItem((int) $orderId) : null;

            if ($rowPdf && \is_object($rowPdf)) {
                $ordenLayoutPdf = (int) ($rowPdf->orden_view_layout_type ?? OrdenModel::ORDEN_VIEW_LAYOUT_STANDARD);
                $secPdf         = $rowPdf->orden_view_precot_line_sections ?? [];
                if (\is_array($secPdf) && $secPdf !== []) {
                    $ordenPiecesPdf = OrdenTrabajoPdfPrecotSectionsHelper::buildRenderPieces($secPdf);
                }
            }
        } catch (\Throwable $e) {
            $ordenPiecesPdf = [];
        }

        $usePrecMixedPdfLayout = ($ordenLayoutPdf === OrdenModel::ORDEN_VIEW_LAYOUT_PLIEGO_ELEMENTOS)
            && ($ordenPiecesPdf !== []);

        
                // Header with logo and work order info - 3 rows layout with borders
                // Store current Y position for alignment
                $startY = $pdf->GetY();

                // ROW 1: Logo + ORDEN DE TRABAJO # and number
                // Add GRIMPSA logo (left side) - correct path, maintain aspect ratio, 100% larger
                $logoPath = JPATH_ROOT . '/images/grimpsa_logo.gif';
                if (file_exists($logoPath)) {
                    // Add logo image (50mm width, auto height to maintain aspect ratio - 100% larger)
                    $pdf->Image($logoPath, 15, $startY, 50, 0, 'GIF');
                } else {
                    // Fallback if logo not found
                    $pdf->SetXY(15, $startY);
                    $pdf->SetFont('Arial', 'B', 12);
                    $pdf->Cell(50, 15, 'GRIMPSA', 1, 0, 'C');
                }

                // Right side: ORDEN DE TRABAJO and number on same line (no borders)
                $pdf->SetXY(100, $startY);
                $pdf->SetFont('Arial', 'B', 14);
                
                // Get orden_de_trabajo from main table (as shown in screenshot)
                $numeroOrden = 'N/A';
                
                // Check main table field first (orden_de_trabajo from joomla_ordenproduccion_ordenes)
                if (isset($workOrderData->orden_de_trabajo)) {
                    $numeroOrden = $workOrderData->orden_de_trabajo;
                } elseif (isset($workOrderData->numero_de_orden)) {
                    $numeroOrden = $workOrderData->numero_de_orden;
                }
                
                // Try EAV data as fallback
                if ($numeroOrden === 'N/A') {
                    $possibleFields = ['orden_de_trabajo', 'numero_de_orden', 'orden_trabajo', 'numero_orden'];
                    foreach ($possibleFields as $field) {
                        if (isset($workOrderData->eav_data[$field])) {
                            $numeroOrden = $workOrderData->eav_data[$field]->attribute_value;
                            break;
                        }
                    }
                }
                
                // Format as ORD-000000 if numeric
                if (is_numeric($numeroOrden)) {
                    $numeroOrden = 'ORD-' . str_pad($numeroOrden, 6, '0', STR_PAD_LEFT);
                }
                
                // Display label and number on same line, right-aligned
                $fullText = 'ORDEN DE TRABAJO ' . $numeroOrden;
                $pdf->Cell(0, 8, $fullText, 0, 1, 'R');

                // ROW 2: FECHA SOLICITUD + FECHA ENTREGA with proper spacing
                $wOrdenPdfFechaLabelColMm = 40;
                $pdf->SetXY(15, $startY + 20); // Position below logo
                $pdf->SetFont('Arial', 'B', 10);
                $pdf->Cell($wOrdenPdfFechaLabelColMm, 6, 'FECHA SOLICITUD:', 1, 0, 'L');
                $pdf->SetFont('Arial', '', 10);
                $pdf->Cell(50, 6, $fixSpanishChars($this->formatOrdenPdfDisplayDate($workOrderData->request_date ?? null)), 1, 0, 'L');
                
                $pdf->SetFont('Arial', 'B', 10);
                $pdf->Cell($wOrdenPdfFechaLabelColMm, 6, 'FECHA ENTREGA:', 1, 0, 'L');
                $pdf->SetFont('Arial', '', 10);
                $pdf->Cell(0, 6, $fixSpanishChars($this->formatOrdenPdfDisplayDate($workOrderData->delivery_date ?? null)), 1, 1, 'L');

                // ROW 3: AGENTE DE VENTAS (label | value, same label width as FECHA / CLIENTE columns)
                $pdf->SetXY(15, $startY + 26); // Position below dates
                $pdf->SetFont('Arial', 'B', 10);

                // Get sales agent from correct field name
                $salesAgent = 'N/A';
                if (isset($workOrderData->sales_agent)) {
                    $salesAgent = $workOrderData->sales_agent;
                } elseif (isset($workOrderData->agente_de_ventas)) {
                    $salesAgent = $workOrderData->agente_de_ventas;
                }

                // Try EAV data as fallback
                if ($salesAgent === 'N/A' && isset($workOrderData->eav_data['sales_agent'])) {
                    $salesAgent = $workOrderData->eav_data['sales_agent']->attribute_value;
                }

                $hAgenteRowMm = 6.5;
                $pdf->Cell($wOrdenPdfFechaLabelColMm, $hAgenteRowMm, 'AGENTE DE VENTAS:', 1, 0, 'L');
                $pdf->SetFont('Arial', '', 9);
                $pdf->Cell(0, $hAgenteRowMm, $fixSpanishChars($salesAgent), 1, 1, 'L');

                
        // Client/job label column aligns with fecha row labels (same variable).
        $labelColWpdf = $wOrdenPdfFechaLabelColMm;
        $hClienteRowMm = 6.5; // 8 mm − 1.5 mm
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell($labelColWpdf, $hClienteRowMm, 'CLIENTE:', 1, 0, 'L');
        $pdf->SetFont('Arial', '', 9);
        $clientName = $workOrderData->client_name ?? 'N/A';
        $clientName = $fixSpanishChars($clientName); // Fix Spanish characters
        if (strlen($clientName) > 50) {
            $clientName = substr($clientName, 0, 47) . '...';
        }
        $pdf->Cell(0, $hClienteRowMm, $clientName, 1, 1, 'L');

        // Get job description from correct field name
        $jobDesc = 'N/A';

        // Debug: Check what fields are available
        $debugInfo = [];
        if (isset($workOrderData->work_description)) {
            $jobDesc = $workOrderData->work_description;
            $debugInfo[] = 'work_description: ' . $workOrderData->work_description;
        } elseif (isset($workOrderData->description)) {
            $jobDesc = $workOrderData->description;
            $debugInfo[] = 'description: ' . $workOrderData->description;
        }
        
        // Try EAV data as fallback
        if ($jobDesc === 'N/A') {
            if (isset($workOrderData->eav_data['work_description'])) {
                $jobDesc = $workOrderData->eav_data['work_description']->attribute_value;
                $debugInfo[] = 'EAV work_description: ' . $jobDesc;
            } elseif (isset($workOrderData->eav_data['descripcion_de_trabajo'])) {
                $jobDesc = $workOrderData->eav_data['descripcion_de_trabajo']->attribute_value;
                $debugInfo[] = 'EAV descripcion_de_trabajo: ' . $jobDesc;
            }
        }
        
        // If still N/A, try to get from EAV data directly
        if ($jobDesc === 'N/A' && isset($workOrderData->eav_data)) {
            foreach ($workOrderData->eav_data as $key => $data) {
                if (strpos($key, 'work') !== false || strpos($key, 'description') !== false || strpos($key, 'trabajo') !== false) {
                    $jobDesc = $data->attribute_value;
                    $debugInfo[] = 'EAV ' . $key . ': ' . $jobDesc;
                    break;
                }
            }
        }
        
        $jobDesc = $fixSpanishChars($jobDesc); // Fix Spanish characters

        // Medidas finales: prefer PRE cabecera medidas, then orden dimensions (same as orden vista).
        $medidasPdf = trim($this->resolveMedidasFinalesForWorkOrderPdf($workOrderData));
        if ($medidasPdf === '') {
            $medidasPdf = 'N/A';
        }
        $medidasPdf = $fixSpanishChars($medidasPdf);

        $cantidadPdf = trim($this->resolveCantidadTotalForWorkOrderPdf($workOrderData));
        $cantidadPdf = $cantidadPdf !== '' ? $fixSpanishChars($cantidadPdf) : '';

        // TRABAJO: aligned label/value row (avoid overlap); MEDIDAS same fixed height as CLIENTE (Cell rows).
        $innerPdfW    = (float) $pdf->GetPageWidth() - 30.0;
        $valueColWpdf = max(80.0, $innerPdfW - $labelColWpdf);
        $jobDescPdf   = ($jobDesc !== 'N/A' && $jobDesc !== '')
            ? (rtrim((string) $jobDesc) . "\n")
            : $jobDesc;

        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell($labelColWpdf, $hClienteRowMm, Text::_('COM_ORDENPRODUCCION_ORDEN_PDF_MEDIDAS_FINALES') . ':', 1, 0, 'L');
        $pdf->SetFont('Arial', '', 9);
        $valAreaMm     = max(10.0, $innerPdfW - $labelColWpdf);
        $cantLabelMm   = 36.0;
        $cantValMinMm  = 22.0;
        $medidasValMm  = max(30.0, $valAreaMm - $cantLabelMm - $cantValMinMm);
        $cantidadValMm = max($cantValMinMm, $valAreaMm - $medidasValMm - $cantLabelMm);
        $cantidadCellPdf = $cantidadPdf !== '' ? $cantidadPdf : '-';
        $pdf->Cell($medidasValMm, $hClienteRowMm, $medidasPdf, 1, 0, 'L');
        $pdf->SetFont('Arial', 'B', 9);
        $pdf->Cell($cantLabelMm, $hClienteRowMm, $fixSpanishChars(Text::_('COM_ORDENPRODUCCION_ORDEN_PDF_CANTIDAD_TOTAL')) . ':', 1, 0, 'L');
        $pdf->SetFont('Arial', '', 9);
        $pdf->Cell($cantidadValMm, $hClienteRowMm, $cantidadCellPdf, 1, 1, 'L');

        OrdenTrabajoPdfPrecotSectionsHelper::drawLabelValueRowTwoColumn(
            $pdf,
            $labelColWpdf,
            $valueColWpdf,
            'TRABAJO',
            (string) $jobDescPdf,
            $fixSpanishChars,
            6.0,
            10.0,
            'B',
            9.0,
            ''
        );

        $pdf->Ln(5);
        
        if (!$usePrecMixedPdfLayout) {
        // Production specifications table - 2 columns × 4 rows layout
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(80, 8, 'COLOR:', 1, 0, 'L');
        // Get color from main table (print_color)
        $color = $workOrderData->print_color ?? 'N/A';
        $color = $fixSpanishChars($color);
        $pdf->SetFont('Arial', '', 9);
        $pdf->Cell(0, 8, $color, 1, 1, 'L');
        
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(80, 8, 'TIRO / RETIRO:', 1, 0, 'L');
        // Get tiro/retiro from main table
        $tiroRetiro = $workOrderData->tiro_retiro ?? 'N/A';
        $tiroRetiro = $fixSpanishChars($tiroRetiro);
        $pdf->SetFont('Arial', '', 9);
        $pdf->Cell(0, 8, $tiroRetiro, 1, 1, 'L');
        
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(80, 8, 'MATERIAL:', 1, 0, 'L');
        $material = $workOrderData->material ?? 'N/A';
        $material = $fixSpanishChars($material);
        $pdf->SetFont('Arial', '', 9);
        $pdf->Cell(0, 8, $material, 1, 1, 'L');
        
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(80, 8, 'MEDIDAS:', 1, 0, 'L');
        $medidasSpec = trim($this->resolveMedidasFinalesForWorkOrderPdf($workOrderData));
        if ($medidasSpec === '') {
            $medidasSpec = $workOrderData->dimensions ?? 'N/A';
        }
        $medidasSpec = $fixSpanishChars($medidasSpec);
        $cantidadSpec = trim($this->resolveCantidadTotalForWorkOrderPdf($workOrderData));
        $cantidadSpec = $cantidadSpec !== '' ? $fixSpanishChars($cantidadSpec) : '';
        $cantidadSpecCell = $cantidadSpec !== '' ? $cantidadSpec : '-';
        $pdf->SetFont('Arial', '', 9);
        $wRestSpec   = (float) $pdf->GetPageWidth() - 30.0 - 80.0;
        $cantLblSpec = 36.0;
        $medWSpec    = max(25.0, $wRestSpec - $cantLblSpec - 22.0);
        $cantWSpec   = max(22.0, $wRestSpec - $medWSpec - $cantLblSpec);
        $pdf->Cell($medWSpec, 8, $medidasSpec, 1, 0, 'L');
        $pdf->SetFont('Arial', 'B', 9);
        $pdf->Cell($cantLblSpec, 8, $fixSpanishChars(Text::_('COM_ORDENPRODUCCION_ORDEN_PDF_CANTIDAD_TOTAL')) . ':', 1, 0, 'L');
        $pdf->SetFont('Arial', '', 9);
        $pdf->Cell($cantWSpec, 8, $cantidadSpecCell, 1, 1, 'L');
        
        $pdf->Ln(5);
        
        // Finishing options table with real data from main table
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(60, 8, 'ACABADOS', 1, 0, 'C');
        $pdf->Cell(30, 8, 'SELECCION', 1, 0, 'C');
        $pdf->Cell(0, 8, 'DETALLES', 1, 1, 'C');
        
        // Map display names to database field names (main table)
        $finishingFieldMap = [
            'BLOCADO' => ['field' => 'blocking', 'details' => 'blocking_details'],
            'CORTE' => ['field' => 'cutting', 'details' => 'cutting_details'],
            'DOBLADO' => ['field' => 'folding', 'details' => 'folding_details'],
            'LAMINADO' => ['field' => 'laminating', 'details' => 'laminating_details'],
            'LOMO' => ['field' => 'spine', 'details' => 'spine_details'],
            'NUMERADO' => ['field' => 'numbering', 'details' => 'numbering_details'],
            'PEGADO' => ['field' => 'gluing', 'details' => 'gluing_details'],
            'SIZADO' => ['field' => 'sizing', 'details' => 'sizing_details'],
            'ENGRAPADO' => ['field' => 'stapling', 'details' => 'stapling_details'],
            'TROQUEL' => ['field' => 'die_cutting', 'details' => 'die_cutting_details'],
            'BARNIZ' => ['field' => 'varnish', 'details' => 'varnish_details'],
            'IMP. EN BLANCO' => ['field' => 'white_print', 'details' => 'white_print_details'],
            'DESPUNTADO' => ['field' => 'trimming', 'details' => 'trimming_details'],
            'OJETES' => ['field' => 'eyelets', 'details' => 'eyelets_details'],
            'PERFORADO' => ['field' => 'perforation', 'details' => 'perforation_details']
        ];
        
        $pdf->SetFont('Arial', '', 9);
        $hasSelectedAcabados = false; // Track if any acabados are selected
        
        foreach ($finishingFieldMap as $displayName => $fields) {
            // Get selection value (SI/NO) from main table
            $fieldName = $fields['field'];
            $detailsFieldName = $fields['details'];
            
            $isSelected = $workOrderData->$fieldName ?? 'NO';
            $isSelected = strtoupper($isSelected); // Ensure uppercase
            if (empty($isSelected) || $isSelected === 'NULL') {
                $isSelected = 'NO';
            }
            
            // Only display rows where selection is "SI"
            if ($isSelected === 'SI') {
                $hasSelectedAcabados = true;
                
                // Get details from main table
                $details = $workOrderData->$detailsFieldName ?? '';
                $details = $fixSpanishChars($details);
                
                // No truncation - let MultiCell handle text wrapping
                $pdf->Cell(60, 6, $displayName, 1, 0, 'L');
                $pdf->Cell(30, 6, $isSelected, 1, 0, 'C');
                // Use MultiCell like INSTRUCCIONES GENERALES to allow text wrapping
                $pdf->MultiCell(0, 6, $details, 1, 'L');
            }
        }
        
        // If no acabados are selected, show a message
        if (!$hasSelectedAcabados) {
            $pdf->Cell(60, 6, 'NINGUNO SELECCIONADO', 1, 0, 'L');
            $pdf->Cell(30, 6, '', 1, 0, 'C');
            $pdf->Cell(0, 6, '', 1, 1, 'L');
        }
        
        $pdf->Ln(5);

        } else {
            OrdenTrabajoPdfPrecotSectionsHelper::renderPiecesOnPdf($pdf, $ordenPiecesPdf, $fixSpanishChars);
            $pdf->Ln(1);
        }

        // Footers stacked at bottom margin (no gap between IG and envío); estimate height before drawing.
        $instructionsStr = (string) ($fixSpanishChars($workOrderData->instructions ?? 'N/A'));
        $instructionsPdf = ($instructionsStr !== 'N/A' && $instructionsStr !== '')
            ? rtrim($instructionsStr) . "\n\n"
            : $instructionsStr;
        $shippingType       = $fixSpanishChars($this->resolveShippingTypeDisplayForPdf($workOrderData));
        $footerH            = $this->ordenPdfEstimatedFooterIgEnvioHeightMm(
            $pdf,
            $workOrderData,
            $fixSpanishChars,
            (string) $instructionsPdf,
            $shippingType
        );
        $pageHFull          = 279.4;
        // Same as generateWorkOrderPDF SetMargins / SetAutoPageBreak (FPDF exposes no getters)
        $bottomMargMm       = 15.0;
        $leftMm             = 15.0;
        $yAfterContent      = (float) $pdf->GetY();
        $yFloor             = $pageHFull - $bottomMargMm - $footerH;
        $pdf->SetXY($leftMm, max($yAfterContent + 0.5, $yFloor));

        // INSTRUCCIONES GENERALES section with 3-row height
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->SetFillColor(220, 220, 220); // Light gray background
        $pdf->Cell(0, 8, 'INSTRUCCIONES GENERALES', 1, 1, 'L', true);
        $pdf->SetFont('Arial', '', 9);
        $pdf->MultiCell(0, 6, $instructionsPdf, 1, 'L');

        // INFORMACION DE ENVIO section (immediately follows IG row; no intervening blank line)
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->SetFillColor(220, 220, 220); // Light gray background
        $pdf->Cell(0, 8, 'INFORMACION DE ENVIO', 1, 1, 'L', true);
        
        // Tipo de Entrega
        $pdf->SetFont('Arial', 'B', 10);
        if ($shippingType === 'Recoge en oficina') {
            $pdf->Cell(50, 7, 'TIPO DE ENTREGA:', 1, 0, 'L');
            $pdf->SetFont('Arial', '', 9);
            $pdf->Cell(0, 7, $shippingType, 1, 1, 'L');
        } else {
            // No bottom on this row: the address block below draws the shared horizontal line (avoids double stroke with MultiCell).
            $pdf->Cell(50, 7, 'TIPO DE ENTREGA:', 'LRT', 0, 'L');
            $pdf->SetFont('Arial', '', 9);
            $pdf->Cell(0, 7, $shippingType, 'LRT', 1, 'L');
        }

        // Check if "Recoge en oficina"
        if ($shippingType === 'Recoge en oficina') {
            // Only show "Recoge en oficina" message
            $pdf->SetFont('Arial', 'I', 9);
            $pdf->SetTextColor(0, 102, 153); // Blue color
            $pdf->Cell(0, 7, 'El cliente recogera el pedido en la oficina de GRIMPSA', 1, 1, 'L');
            $pdf->SetTextColor(0, 0, 0); // Reset to black
        } else {
            // Show full shipping information
            $shippingAddress = $workOrderData->shipping_address ?? 'N/A';
            $shippingAddress = $fixSpanishChars($shippingAddress);
            $xStart   = (float) $pdf->GetX();
            $labelW   = 50.0;
            $valueW   = (float) $pdf->GetPageWidth() - $xStart - $pdfSideMarginMm - $labelW;
            $valueW   = max(30.0, $valueW);
            // Single bordered row (label + wrapped value) — avoids stacked Cell/MultiCell double borders.
            OrdenTrabajoPdfPrecotSectionsHelper::drawLabelValueRowTwoColumn(
                $pdf,
                $labelW,
                $valueW,
                'DIRECCION DE ENTREGA',
                $shippingAddress,
                $fixSpanishChars,
                6.0,
                10.0,
                'B',
                9.0,
                ''
            );

            // Nombre de Contacto (omit top edge: continues the address rectangle’s bottom stroke)
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Cell(50, 7, 'NOMBRE DE CONTACTO:', 'LRB', 0, 'L');
            $pdf->SetFont('Arial', '', 9);
            $shippingContact = $workOrderData->shipping_contact ?? 'N/A';
            $shippingContact = $fixSpanishChars($shippingContact);
            $pdf->Cell(0, 7, $shippingContact, 'LRB', 1, 'L');

            // Telefono de Contacto
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Cell(50, 7, 'TELEFONO DE CONTACTO:', 'LRB', 0, 'L');
            $pdf->SetFont('Arial', '', 9);
            $shippingPhone = $workOrderData->shipping_phone ?? 'N/A';
            $shippingPhone = $fixSpanishChars($shippingPhone);
            $pdf->Cell(0, 7, $shippingPhone, 'LRB', 1, 'L');
        }

        // Instrucciones de Entrega - Label row (spans both columns)
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(0, 7, 'INSTRUCCIONES DE ENTREGA:', 'LRB', 1, 'L');

        // Instrucciones de Entrega - Value row with 3-row height
        $pdf->SetFont('Arial', '', 9);
        $shippingInstructions = $workOrderData->instrucciones_entrega ?? 'N/A';
        $shippingInstructions = $fixSpanishChars($shippingInstructions);
        // LRB: omit top border (shared with label row) — avoids double horizontal line.
        $pdf->MultiCell(0, 6, $shippingInstructions, 'LRB', 'L');
        
        // Set headers for inline PDF viewing in new tab
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="orden_trabajo_' . $orderId . '.pdf"');
        header('Cache-Control: private, max-age=0, must-revalidate');
        header('Pragma: public');
        
        // Output PDF inline (opens in new tab)
        $pdf->Output('I', 'orden_trabajo_' . $orderId . '.pdf');
        exit;
    }


            /**
             * Method to generate shipping slip PDF using FPDF.
             *
             * @param   int     $orderId        Work order ID
             * @param   object  $workOrderData  Work order data
             * @param   string  $tipoEnvio      Tipo de envio (completo/parcial)
             * @param   string  $tipoMensajeria Tipo de mensajería (propio/terceros)
             * @param   string  $descripcionEnvio Shipping description text
             *
             * @return  void
             *
             * @since   1.0.0
             */
            private function generateShippingSlipPDF($orderId, $workOrderData, $tipoEnvio = 'completo', $tipoMensajeria = 'propio', $descripcionEnvio = '')
    {
        // Include FPDF library (same path as working PDF generation)
        require_once JPATH_ROOT . '/fpdf/fpdf.php';

        // Create PDF for 8.5" x 11" paper
        $pdf = new \FPDF('P', 'mm', array(215.9, 279.4)); // 8.5" x 11" in mm
        $pdf->AddPage();
        
        // Function to fix Spanish characters for FPDF
        $fixSpanishChars = function ($text) {
            $text = Utf8DisplayHelper::normalizeUserFacing((string) $text);
            if ($text === '') {
                return $text;
            }

            // Convert common Spanish characters that FPDF doesn't handle well
            $replacements = [
                'Á' => 'A', 'É' => 'E', 'Í' => 'I', 'Ó' => 'O', 'Ú' => 'U', 'Ñ' => 'N',
                'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ñ' => 'n',
                'Ü' => 'U', 'ü' => 'u', 'Ç' => 'C', 'ç' => 'c'
            ];
            
            return strtr($text, $replacements);
        };
        
        // Get shipping number (convert ORD-000000 to ENV-000000)
        $ordenNumber = $workOrderData->orden_de_trabajo ?? $workOrderData->numero_de_orden ?? 'ORD-' . str_pad($orderId, 6, '0', STR_PAD_LEFT);
        $envioNumber = str_replace('ORD-', 'ENV-', $ordenNumber);
        
        // Get current date
        $currentDate = date('d/m/Y');
        
        // Get client data from main table
        $clientName = $fixSpanishChars($workOrderData->client_name ?? 'N/A');
        $salesAgent = $fixSpanishChars($workOrderData->sales_agent ?? 'N/A');
        $workDescription = $fixSpanishChars($workOrderData->work_description ?? 'N/A');
        
        // Get shipping type and information from main table
        $shippingType = $workOrderData->shipping_type ?? 'Entrega a domicilio';
        
        // Handle "Recoge en oficina" vs "Entrega a domicilio"
        if ($shippingType === 'Recoge en oficina') {
            $shippingContact = 'N/A';
            $shippingPhone = 'N/A';
            $shippingAddress = 'Recoge en oficina';
            $shippingInstructions = 'El cliente recogera el pedido en la oficina de GRIMPSA';
        } else {
            $shippingContact = $fixSpanishChars($workOrderData->shipping_contact ?? 'N/A');
            $shippingPhone = $workOrderData->shipping_phone ?? 'N/A';
            $shippingAddress = $fixSpanishChars($workOrderData->shipping_address ?? 'N/A');
            $shippingInstructions = $fixSpanishChars($workOrderData->instrucciones_entrega ?? '');
        }
        
        // Generate two identical shipping slips on one page
        // Page height: 279.4mm
        // Balance between readability (larger cells) and fitting on single page
        $pageHeight = 279.4;
        $topMargin = 2; // Minimal top margin
        $eachSlipHeight = 133; // Slightly increased from 130 to account for larger cells
        // Calculate spacing to center both slips with minimal margins
        // Total needed: 130 * 2 = 260mm
        // Remaining: 279.4 - 260 = 19.4mm
        // Divide into 3 equal parts: top margin + spacing + bottom margin
        $totalSlipsHeight = $eachSlipHeight * 2;
        $remainingSpace = $pageHeight - $totalSlipsHeight;
        $spacingBetween = $remainingSpace / 3; // Equal spacing sections (top, between, bottom)
        
        for ($slip = 0; $slip < 2; $slip++) {
            // Calculate Y position for each slip with equal spacing
            // First slip starts after minimal top margin + first spacing section
            // Second slip starts after first slip + spacing between
            if ($slip === 0) {
                $startY = $topMargin + $spacingBetween;
            } else {
                $startY = $topMargin + $spacingBetween + $eachSlipHeight + $spacingBetween;
            }
            
            // Header with logo and title - clean layout, reduced spacing
            // Logo (top left) - only show for "Propio" mensajería
            if ($tipoMensajeria === 'propio') {
                $logoPath = 'https://grimpsa_webserver.grantsolutions.cc/images/grimpsa_logo.gif';
                $pdf->Image($logoPath, 10, $startY + 5, 55, 0); // Reduced Y offset from 20 to 5
            }
            
            // Envio number only (center) - no "Envio #" label
            $pdf->SetFont('Arial', 'B', 24); // Reduced from 26 to 24
            $pdf->SetXY(0, $startY + 15); // Reduced from 30 to 15
            $pdf->Cell(0, 8, $envioNumber, 0, 1, 'C'); // Reduced height from 10 to 8
            
            $pdf->SetFont('Arial', 'B', 9); // Reduced from 10 to 9
            $pdf->SetXY(0, $startY + 23); // Reduced from 40 to 23
            $pdf->Cell(0, 5, 'GUATEMALA, ' . $currentDate, 0, 1, 'C'); // Reduced height from 6 to 5
            
            // QR Code (top right) - no square border, no label
            $pdf->SetXY(159, $startY + 5); // Reduced from 20 to 5
            $pdf->Cell(40, 40, '', 0, 0, 'C'); // No border
            
            // Client and delivery information table - using exact dimensions from working code
            $cellHeight = 5; // Increased from 4 to 5 for better readability
            
            // Start table below header area - slightly adjusted
            $pdf->SetY($startY + 30); // Adjusted from 28 to 30 to account for slightly larger cells
            
            // Row 1: Cliente
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Cell(37, $cellHeight, 'Cliente', 1, 0, 'L');
            $pdf->SetFont('Arial', '', 10); // Increased from 9 to 10 for better readability
            $pdf->Cell(153, $cellHeight, $clientName, 1, 0, 'L');
            $pdf->Ln();
            
            // Row 2: Agente de Ventas (only show if mensajeria is NOT "terceros")
            if ($tipoMensajeria !== 'terceros') {
                $pdf->SetFont('Arial', 'B', 10);
                $pdf->Cell(37, $cellHeight, 'Agente de Ventas', 1, 0, 'L');
                $pdf->SetFont('Arial', '', 10); // Increased from 9 to 10
                $pdf->Cell(153, $cellHeight, $salesAgent, 1, 0, 'L');
                $pdf->Ln();
            }
            
            // Row 3: Contacto and Telefono (split row) - matching original layout
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Cell(37, $cellHeight, 'Contacto', 1, 0, 'L');
            $pdf->SetFont('Arial', '', 10); // Increased from 9 to 10
            $pdf->Cell(81, $cellHeight, $shippingContact, 1, 0, 'L');
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Cell(32, $cellHeight, 'Telefono', 1, 0, 'L');
            $pdf->SetFont('Arial', '', 10); // Increased from 9 to 10
            $pdf->Cell(40, $cellHeight, $shippingPhone, 1, 0, 'L');
            $pdf->Ln();
            
            // Row 4: Direccion de entrega - using MultiCell for text wrapping
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Cell(37, $cellHeight, 'Direccion de entrega', 1, 0, 'L');
            $pdf->SetFont('Arial', '', 10); // Increased from 9 to 10
            // Use MultiCell to allow text wrapping like TRABAJO row
            $pdf->MultiCell(153, $cellHeight, $shippingAddress, 1, 'L');
            
            // Row 5: Instrucciones de entrega (full width)
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Cell(190, $cellHeight, 'Instrucciones de entrega', 1, 1, 'C');
            $pdf->SetFont('Arial', '', 10); // Increased from 9 to 10
            $pdf->MultiCell(190, $cellHeight, $shippingInstructions, 1, 'L');
            $pdf->Ln(0.5); // Reduced spacing slightly
            
            // Row 6: Tipo de Entrega
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Cell(37, $cellHeight, 'Tipo de Entrega', 1, 0, 'L');
            $pdf->SetFont('Arial', '', 10); // Increased from 9 to 10
            $pdf->Cell(153, $cellHeight, $tipoEnvio, 1, 0, 'L');
            $pdf->Ln();
            
            // Row 7: Trabajo - using MultiCell for text wrapping
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Cell(37, $cellHeight, 'Trabajo', 1, 0, 'L');
            $pdf->SetFont('Arial', '', 10); // Increased from 9 to 10
            // Use MultiCell to allow text wrapping like work order PDF
            $pdf->MultiCell(153, $cellHeight, $workDescription, 1, 'L');
            
            // Row 8: Descripcion de Envio - fixed row, show or hide text
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Cell(37, $cellHeight, 'Descripcion de Envio', 1, 0, 'L');
            $pdf->SetFont('Arial', '', 10); // Increased from 9 to 10
            if (!empty($descripcionEnvio)) {
                $descripcionEnvioFixed = $fixSpanishChars($descripcionEnvio);
                // Use MultiCell to allow text wrapping
                $pdf->MultiCell(153, $cellHeight, $descripcionEnvioFixed, 1, 'L');
            } else {
                // Empty cell if no description
                $pdf->Cell(153, $cellHeight, '', 1, 0, 'L');
                $pdf->Ln();
            }
            
            // Light gray separator - minimal spacing
            $pdf->SetFillColor(211, 211, 211);
            $pdf->Cell(190, 1.5, '', 0, 0, '', true); // Slightly increased from 1 to 1.5
            $pdf->Ln(0.5); // Minimal spacing
            
            // Footer with signature box and labels - for EACH slip
            $footerX = 10; // Starting X position (matches content start)
            $footerWidth = 190; // Width matching content cells above
            $signatureBoxHeight = 15; // Slightly increased from 14 to 15
            $labelHeight = 3.5; // Slightly increased from 3 to 3.5
            
            // Get current Y position after content
            $footerY = $pdf->GetY();
            
            // Draw signature box spanning full width
            $pdf->Rect($footerX, $footerY, $footerWidth, $signatureBoxHeight);
            
            // Labels below box (centered in three equal sections)
            $pdf->SetY($footerY + $signatureBoxHeight + 0.5); // Minimal spacing
            $pdf->SetFont('Arial', 'B', 8); // Increased from 7 to 8 for better readability
            $labelWidth = $footerWidth / 3; // Divide width equally among three labels
            $pdf->Cell($labelWidth, $labelHeight, 'FECHA', 0, 0, 'C');
            $pdf->Cell($labelWidth, $labelHeight, 'NOMBRE Y FIRMA', 0, 0, 'C');
            $pdf->Cell($labelWidth, $labelHeight, 'Sello', 0, 0, 'C');
            $pdf->Ln(0.5); // Reduced from 2 to 0.5
        }
        
        // Output PDF
        $pdf->Output('I', 'envio_' . $envioNumber . '.pdf');
        exit;
    }

    /**
     * Formato de fecha corto para el PDF OT (ISO/SQL datetime → DD/MM/AAAA).
     *
     * @param   mixed   $raw
     *
     * @return  string
     *
     * @since   3.115.33
     */
    private function formatOrdenPdfDisplayDate($raw): string
    {
        $s = trim((string) ($raw ?? ''));
        if ($s === '') {
            return 'N/A';
        }
        $ts = strtotime($s);

        return $ts ? date('d/m/Y', $ts) : $s;
    }

    /**
     * Approximate rendered height for a MultiCell block (explicit newlines + word wrap).
     *
     * Must run with font/size matching the actual PDF output (caller sets font).
     */
    private function ordenPdfApproxMultilineBlockMm(\FPDF $pdf, string $text, float $usableWmm, float $lineHm): float
    {
        $text = str_replace(["\r\n", "\r"], "\n", $text);

        $linesTotal = 0;
        foreach (explode("\n", $text) as $paragraph) {
            if ($paragraph === '') {
                $linesTotal++;

                continue;
            }
            $linesTotal += $this->ordenPdfApproxWrapParagraphLines($pdf, $paragraph, $usableWmm);
        }

        return max($lineHm, ($linesTotal > 0 ? $linesTotal : 1) * $lineHm);
    }

    private function ordenPdfApproxWrapParagraphLines(\FPDF $pdf, string $paragraph, float $usableWmm): int
    {
        $words = preg_split('/\s+/u', $paragraph, -1, PREG_SPLIT_NO_EMPTY);
        if ($words === []) {
            return 1;
        }

        $line       = '';
        $lineBlocks = 0;

        foreach ($words as $word) {
            $trial = ($line === '') ? $word : $line . ' ' . $word;

            if ($pdf->GetStringWidth($trial) <= $usableWmm) {
                $line = $trial;

                continue;
            }

            if ($line !== '') {
                $lineBlocks++;
                $line = '';
            }

            if ($pdf->GetStringWidth($word) <= $usableWmm) {
                $line = $word;

                continue;
            }

            $lineBlocks++;
            $line = '';
        }

        if ($line !== '') {
            $lineBlocks++;
        }

        return max(1, $lineBlocks);
    }

    /**
     * Conservative height (mm) for INSTRUCCIONES GENERALES + INFORMACION DE ENVIO stacked at page bottom.
     */
    private function ordenPdfEstimatedFooterIgEnvioHeightMm(
        \FPDF $pdf,
        object $wd,
        callable $fix,
        string $instructionsPdf,
        string $shippingType
    ): float {
        $pageW   = 215.9;
        $lMargin = 15.0;
        $rEdge   = $pageW - $lMargin;
        $fullW   = $rEdge - $lMargin;
        $addrW   = $rEdge - ($lMargin + 50.0);

        $h = 0.0;

        $h += 8.0;
        $pdf->SetFont('Arial', '', 9);
        $h += $this->ordenPdfApproxMultilineBlockMm($pdf, $instructionsPdf, $fullW, 6.0);

        $h += 8.0;
        $h += 7.0;

        if ($shippingType === 'Recoge en oficina') {
            $h += 7.0;
        } else {
            $addr = (string) $fix($wd->shipping_address ?? 'N/A');
            $h    += max(7.0, $this->ordenPdfApproxMultilineBlockMm($pdf, $addr, $addrW, 6.0));
            $h    += 7.0 + 7.0;
        }

        $h += 7.0;
        $instr = (string) $fix($wd->instrucciones_entrega ?? 'N/A');
        $h     += $this->ordenPdfApproxMultilineBlockMm($pdf, $instr, $fullW, 6.0);

        return $h + 10.0;
    }

    /**
     * Tipo de entrega legible cuando `shipping_type` quedó vacío pero existe snapshot en orden_source_json.
     *
     * @param   object  $data
     *
     * @return  string
     *
     * @since   3.115.33
     */
    private function resolveShippingTypeDisplayForPdf(object $data): string
    {
        $t = trim((string) ($data->shipping_type ?? ''));
        if ($t !== '') {
            return $t;
        }

        $j = isset($data->orden_source_json) ? json_decode((string) $data->orden_source_json, true) : null;
        if (\is_array($j) && !empty($j['wizard_tipo_entrega'])) {
            $w = strtolower(trim((string) $j['wizard_tipo_entrega']));
            if ($w === 'recoger') {
                return 'Recoge en oficina';
            }
            if ($w === 'domicilio') {
                return 'Entrega a domicilio';
            }
        }

        return 'Entrega a domicilio';
    }

}