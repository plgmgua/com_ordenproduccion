<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_ordenproduccion
 *
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Grimpsa\Component\Ordenproduccion\Site\View\Orden;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Router\Route;
use Grimpsa\Component\Ordenproduccion\Site\Helper\AccessHelper;

/**
 * Orden view class for com_ordenproduccion
 *
 * @since  1.0.0
 */
class HtmlView extends BaseHtmlView
{
    /**
     * The model state
     *
     * @var    \Joomla\Registry\Registry
     * @since  1.0.0
     */
    protected $state;

    /**
     * The item object
     *
     * @var    object
     * @since  1.0.0
     */
    protected $item;

    /**
     * The component parameters
     *
     * @var    \Joomla\Registry\Registry
     * @since  1.0.0
     */
    protected $params;

    /**
     * The user object
     *
     * @var    \Joomla\CMS\User\User
     * @since  1.0.0
     */
    protected $user;

    /**
     * Historial entries for the work order
     *
     * @var    array
     * @since  3.8.0
     */
    protected $historialEntries;

    /**
     * Display the view
     *
     * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
     *
     * @return  void
     *
     * @since   1.0.0
     */
    public function display($tpl = null)
    {
        // Suppress deprecation warnings in production
        error_reporting(E_ALL & ~E_DEPRECATED & ~E_USER_DEPRECATED);
        
        try {
            $app = Factory::getApplication();
            $user = Factory::getUser();

            // Load component language (site + admin for full string coverage)
            $lang = $app->getLanguage();
            $lang->load('com_ordenproduccion', JPATH_SITE . '/components/com_ordenproduccion');
            $lang->load('com_ordenproduccion', JPATH_ADMINISTRATOR . '/components/com_ordenproduccion');

            // Check if user is logged in
            if ($user->guest) {
                $app->redirect(Route::_('index.php?option=com_users&view=login'));
                return;
            }

            // Check if user has access to ordenes using custom AccessHelper
            if (!AccessHelper::hasOrderAccess()) {
                $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_ERROR_ACCESS_DENIED'), 'error');
                $app->redirect(Route::_('index.php'));
                return;
            }

            $this->state = $this->get('State');
            $this->item = $this->get('Item');
            $this->params = $app->getParams('com_ordenproduccion');
            $this->user = $user;
            
            // Get historial entries for this work order
            $model = $this->getModel();
            $this->historialEntries = $model->getHistorialEntries($this->item->id ?? null);

            // Payment proofs for this order (only when user can see payment info)
            $this->paymentProofs = [];
            $this->paymentProofViewUrl = '';
            if (AccessHelper::canSeeValorFactura($this->item->sales_agent ?? '')) {
                try {
                    $proofModel = $app->bootComponent('com_ordenproduccion')->getMVCFactory()->createModel('Paymentproof', 'Site');
                    if ($proofModel && method_exists($proofModel, 'getPaymentProofsByOrderId')) {
                        $this->paymentProofs = $proofModel->getPaymentProofsByOrderId((int) ($this->item->id ?? 0));
                    }
                    $this->paymentProofViewUrl = Route::_('index.php?option=com_ordenproduccion&view=paymentproof&order_id=' . (int) ($this->item->id ?? 0));
                } catch (\Throwable $e) {
                    $this->paymentProofs = [];
                }
            }

            // Check for errors.
            if (count($errors = $this->get('Errors'))) {
                $app->enqueueMessage(implode("\n", $errors), 'error');
                return;
            }
        } catch (\Exception $e) {
            // Display error in a visible way
            echo '<div style="margin: 20px; padding: 20px; background: #ffebee; border: 2px solid #c62828; font-family: monospace;">';
            echo '<h2 style="color: #c62828;">❌ VIEW ERROR (HtmlView.php)</h2>';
            echo '<p><strong>Error Message:</strong></p>';
            echo '<pre style="background: white; padding: 10px; overflow: auto;">' . htmlspecialchars($e->getMessage()) . '</pre>';
            echo '<p><strong>File:</strong> ' . htmlspecialchars($e->getFile()) . '</p>';
            echo '<p><strong>Line:</strong> ' . $e->getLine() . '</p>';
            echo '<p><strong>Stack Trace:</strong></p>';
            echo '<pre style="background: white; padding: 10px; overflow: auto; max-height: 400px;">' . htmlspecialchars($e->getTraceAsString()) . '</pre>';
            echo '</div>';
            return;
        }

        try {
            $this->_prepareDocument();
            parent::display($tpl);
        } catch (\Exception $e) {
            // Display error in a visible way
            echo '<div style="margin: 20px; padding: 20px; background: #ffebee; border: 2px solid #c62828; font-family: monospace;">';
            echo '<h2 style="color: #c62828;">❌ TEMPLATE RENDERING ERROR</h2>';
            echo '<p><strong>Error Message:</strong></p>';
            echo '<pre style="background: white; padding: 10px; overflow: auto;">' . htmlspecialchars($e->getMessage()) . '</pre>';
            echo '<p><strong>File:</strong> ' . htmlspecialchars($e->getFile()) . '</p>';
            echo '<p><strong>Line:</strong> ' . $e->getLine() . '</p>';
            echo '<p><strong>Stack Trace:</strong></p>';
            echo '<pre style="background: white; padding: 10px; overflow: auto; max-height: 400px;">' . htmlspecialchars($e->getTraceAsString()) . '</pre>';
            echo '</div>';
        }
    }

    /**
     * Prepares the document
     *
     * @return  void
     *
     * @since   1.0.0
     */
    protected function _prepareDocument()
    {
        $app = Factory::getApplication();
        $menus = $app->getMenu();
        $title = null;

        // Because the application sets a default page title,
        // we need to get it from the menu item itself
        $menu = $menus->getActive();

        if ($menu) {
            $this->params->def('page_heading', $this->params->get('page_title', $menu->title));
        } else {
            $this->params->def('page_heading', Text::_('COM_ORDENPRODUCCION_ORDEN_DEFAULT_PAGE_TITLE'));
        }

        $title = $this->params->get('page_title', '');

        if (empty($title)) {
            $title = $app->get('sitename');
        } elseif ($app->get('sitename_pagetitles', 0) == 1) {
            $title = Text::sprintf('JPAGETITLE', $app->get('sitename'), $title);
        } elseif ($app->get('sitename_pagetitles', 0) == 2) {
            $title = Text::sprintf('JPAGETITLE', $title, $app->get('sitename'));
        }

        $this->document->setTitle($title);

        if ($this->params->get('menu-meta_description')) {
            $this->document->setDescription($this->params->get('menu-meta_description'));
        }

        if ($this->params->get('menu-meta_keywords')) {
            $this->document->setMetadata('keywords', $this->params->get('menu-meta_keywords'));
        }

        if ($this->params->get('robots')) {
            $this->document->setMetadata('robots', $this->params->get('robots'));
        }

        // Load assets
        HTMLHelper::_('bootstrap.framework');
        
        // Use timestamp for cache busting to ensure latest template changes are loaded
        $version = time();
        
        $wa = $this->document->getWebAssetManager();
        $wa->registerAndUseStyle('com_ordenproduccion.orden', 'media/com_ordenproduccion/css/orden.css', [], ['version' => $version]);
        $wa->registerAndUseScript('com_ordenproduccion.orden', 'media/com_ordenproduccion/js/orden.js', [], ['version' => $version]);
    }

    /**
     * Format date for display
     *
     * @param   string  $date  The date string
     *
     * @return  string  Formatted date
     *
     * @since   1.0.0
     */
    public function formatDate($date)
    {
        if (empty($date) || $date === '0000-00-00' || $date === '0000-00-00 00:00:00') {
            return '-';
        }

        // For DATE fields (YYYY-MM-DD), use direct PHP date formatting to avoid timezone conversion issues
        // Joomla's HTMLHelper::_('date') applies timezone conversion which can shift dates by one day
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            // This is a DATE field (no time component), format directly without timezone conversion
            $timestamp = strtotime($date);
            return date('d F Y', $timestamp); // e.g., "14 October 2025"
        }

        // For DATETIME fields, use Joomla's date helper with timezone conversion
        return HTMLHelper::_('date', $date, Text::_('DATE_FORMAT_LC3'));
    }

    /**
     * Get status badge class
     *
     * @param   string  $status  The status
     *
     * @return  string  Badge class
     *
     * @since   1.0.0
     */
    public function getStatusBadgeClass($status)
    {
        switch (strtolower($status)) {
            case 'new':
            case 'nuevo':
                return 'badge-primary';
            case 'in process':
            case 'en proceso':
                return 'badge-warning';
            case 'completed':
            case 'terminada':
            case 'completada':
                return 'badge-success';
            case 'closed':
            case 'cerrada':
                return 'badge-secondary';
            default:
                return 'badge-light';
        }
    }

    /**
     * Get order type badge class
     *
     * @param   string  $type  The order type
     *
     * @return  string  Badge class
     *
     * @since   1.0.0
     */
    public function getOrderTypeBadgeClass($type)
    {
        switch (strtolower($type)) {
            case 'internal':
            case 'interna':
                return 'badge-info';
            case 'external':
            case 'externa':
                return 'badge-success';
            default:
                return 'badge-light';
        }
    }

    /**
     * Get shipping status badge class
     *
     * @param   string  $status  The shipping status
     *
     * @return  string  Badge class
     *
     * @since   1.0.0
     */
    public function getShippingStatusBadgeClass($status)
    {
        switch (strtolower($status)) {
            case 'pending':
                return 'badge-warning';
            case 'shipped':
                return 'badge-info';
            case 'delivered':
                return 'badge-success';
            default:
                return 'badge-light';
        }
    }

    /**
     * Get user groups for access control
     *
     * @return  array  User group IDs
     *
     * @since   1.0.0
     */
    public function getUserGroups()
    {
        return $this->user->getAuthorisedGroups();
    }

    /**
     * Check if user can see invoice value (and payment info)
     *
     * @return  boolean  True if user can see invoice value
     *
     * @since   1.0.0
     */
    public function canSeeInvoiceValue()
    {
        return AccessHelper::canSeeValorFactura($this->item->sales_agent ?? '');
    }

    /**
     * Get back to list route
     *
     * @return  string  The route URL
     *
     * @since   1.0.0
     */
    public function getBackToListRoute()
    {
        return Route::_('index.php?option=com_ordenproduccion&view=ordenes');
    }

    /**
     * Format currency value
     *
     * @param   float  $value  The currency value
     *
     * @return  string  Formatted currency
     *
     * @since   1.0.0
     */
    public function formatCurrency($value)
    {
        if (empty($value) || $value == 0) {
            return '-';
        }

        return 'Q.' . number_format($value, 2);
    }

    /**
     * Get EAV attribute value
     *
     * @param   string  $attribute  The attribute name
     *
     * @return  string  The attribute value
     *
     * @since   1.0.0
     */
    public function getEAVValue($attribute)
    {
        if (isset($this->item->eav_data[$attribute])) {
            return $this->item->eav_data[$attribute];
        }

        return '-';
    }

    /**
     * Translate status value to human-readable text
     *
     * @param   string  $status  The status value
     *
     * @return  string  Translated status text
     *
     * @since   1.0.0
     */
    public function translateStatus($status)
    {
        // Debug: Log the status value
        error_log("DEBUG: translateStatus called with status: " . var_export($status, true));
        
        // Handle empty or null status - default to "Nueva" for new orders
        if (empty($status) || $status === null || $status === '') {
            error_log("DEBUG: Status is empty, returning Nueva");
            return Text::_('COM_ORDENPRODUCCION_STATUS_NEW');
        }

        // Map status values to language keys
        $statusMap = [
            // Spanish values (current)
            'Nueva' => 'COM_ORDENPRODUCCION_STATUS_NEW',
            'En Proceso' => 'COM_ORDENPRODUCCION_STATUS_IN_PROCESS',
            'Terminada' => 'COM_ORDENPRODUCCION_STATUS_COMPLETED',
            'Cerrada' => 'COM_ORDENPRODUCCION_STATUS_CLOSED',
            'Entregada' => 'COM_ORDENPRODUCCION_STATUS_DELIVERED',
            // English values (legacy)
            'New' => 'COM_ORDENPRODUCCION_STATUS_NEW',
            'In Process' => 'COM_ORDENPRODUCCION_STATUS_IN_PROCESS',
            'Completed' => 'COM_ORDENPRODUCCION_STATUS_COMPLETED',
            'Closed' => 'COM_ORDENPRODUCCION_STATUS_CLOSED',
            'Delivered' => 'COM_ORDENPRODUCCION_STATUS_DELIVERED',
            // Lowercase variants
            'nueva' => 'COM_ORDENPRODUCCION_STATUS_NEW',
            'en proceso' => 'COM_ORDENPRODUCCION_STATUS_IN_PROCESS',
            'terminada' => 'COM_ORDENPRODUCCION_STATUS_COMPLETED',
            'cerrada' => 'COM_ORDENPRODUCCION_STATUS_CLOSED',
            'entregada' => 'COM_ORDENPRODUCCION_STATUS_DELIVERED',
            'new' => 'COM_ORDENPRODUCCION_STATUS_NEW',
            'in process' => 'COM_ORDENPRODUCCION_STATUS_IN_PROCESS',
            'completed' => 'COM_ORDENPRODUCCION_STATUS_COMPLETED',
            'closed' => 'COM_ORDENPRODUCCION_STATUS_CLOSED',
            'delivered' => 'COM_ORDENPRODUCCION_STATUS_DELIVERED'
        ];

        if (isset($statusMap[$status])) {
            $translated = Text::_($statusMap[$status]);
            error_log("DEBUG: Status mapped to: " . $statusMap[$status] . " -> " . $translated);
            return $translated;
        }

        // If status is already a language key, try to translate it directly
        if (strpos($status, 'COM_ORDENPRODUCCION_STATUS_') === 0) {
            $translated = Text::_($status);
            error_log("DEBUG: Status is language key: " . $status . " -> " . $translated);
            return $translated;
        }

        // Fallback: return the status as-is
        error_log("DEBUG: Status fallback: " . $status);
        return $status;
    }

    /**
     * Get component version
     *
     * @return  string  Component version
     *
     * @since   1.0.0
     */
    public function getComponentVersion()
    {
        // Hardcoded version - update this with each release
        return '3.1.1-STABLE';
    }
}
