<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_ordenproduccion
 *
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Grimpsa\Component\Ordenproduccion\Site\View\Cotizador;

defined('_JEXEC') or die;

use Grimpsa\Component\Ordenproduccion\Site\Helper\AccessHelper;
use Grimpsa\Component\Ordenproduccion\Site\Service\ApprovalWorkflowService;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Router\Route;

/**
 * View for Pre-Cotización CRUD and pliego quote (cotizador).
 * Menu link: index.php?option=com_ordenproduccion&view=cotizador
 * - default layout: list of Pre-Cotizaciones (current user).
 * - document layout: one Pre-Cotización with lines; Totals row sums all line amounts (including Envío) for subtotal snapshot.
 *
 * @since  3.67.0
 */
class HtmlView extends BaseHtmlView
{
    /**
     * Tarjeta de crédito rates for pre-cotización dropdown (document layout).
     *
     * @var    \stdClass[]
     * @since  3.101.0
     */
    protected $tarjetaCreditoRates = [];

    /**
     * Whether tarjeta de crédito table is installed.
     *
     * @var    bool
     * @since  3.101.0
     */
    protected $tarjetaCreditoTableExists = false;

    /**
     * Whether pre_cotizacion has facturar column (list column Facturar Sí/No).
     *
     * @var    bool
     * @since  3.101.37
     */
    protected $hasFacturarColumn = false;

    /**
     * Whether pre_cotizacion has oferta column (list column Oferta Sí/No).
     *
     * @var    bool
     * @since  3.101.38
     */
    protected $hasOfertaColumn = false;

    /**
     * Sales agent id => name for list filter dropdown (admin list only).
     *
     * @var    array<int, string>
     * @since  3.101.39
     */
    protected $salesAgentFilterOptions = [];

    /**
     * Default list layout: active work orders (state = 1) keyed by pre-cotización id.
     *
     * @var    array<int, array<int, array{id: int, label: string, url: string}>>
     * @since   3.115.69
     */
    protected $associatedOrdenesByPreId = [];

    /**
     * Document layout: whether the user may change lines, description, facturar, etc. (offer templates: owner only).
     *
     * @var    bool
     * @since  3.104.2
     */
    protected $precotizacionDocumentEditable = true;

    /**
     * Document layout: locked because an active orden de trabajo exists for this pre-cotización (UI copy).
     *
     * @var    bool
     * @since  3.115.70
     */
    protected $precotizacionLockedByOrdenTrabajo = false;

    /**
     * Document layout: Aprobaciones Ventas may edit Impresión subtotal override (schema + permission).
     *
     * @var    bool
     * @since  3.109.19
     */
    protected $canSaveImpresionOverride = false;

    /**
     * Document: user may enter Importe (Q) on líneas servicio tercerizado (Aprobaciones Ventas / super user).
     *
     * @var    bool
     * @since  3.117.0
     */
    protected $canSetTercerizadoImporte = false;

    /**
     * Document: solicitud de descuento workflow is installed and published.
     *
     * @var    bool
     * @since  3.109.59
     */
    protected $discountWorkflowAvailable = false;

    /**
     * Document: open solicitud de descuento approval for this pre-cotización.
     *
     * @var    bool
     * @since  3.109.59
     */
    protected $pendingSolicitudDescuento = false;

    /**
     * Document: user may submit a new solicitud de descuento.
     *
     * @var    bool
     * @since  3.109.59
     */
    protected $canRequestSolicitudDescuento = false;

    /**
     * Document: note text from the latest solicitud de descuento request metadata (if any).
     *
     * @var    string
     * @since  3.114.2
     */
    protected $solicitudDescuentoLatestNote = '';

    /**
     * Document (proveedor_externo): solicitud de cotización workflow is installed and published.
     *
     * @var    bool
     * @since  3.113.26
     */
    protected $solicitudCotizacionWorkflowAvailable = false;

    /**
     * Document: open solicitud de cotización al proveedor for this pre-cotización.
     *
     * @var    bool
     * @since  3.113.26
     */
    protected $pendingSolicitudCotizacion = false;

    /**
     * Open solicitud de cotización request id (proveedor externo), or 0.
     *
     * @var    int
     *
     * @since   3.117.4
     */
    protected $pendingSolicitudCotizacionRequestId = 0;

    /**
     * Current user is assignee for the pending solicitud de cotización step (may approve/reject on document).
     *
     * @var    bool
     *
     * @since   3.117.4
     */
    protected $canCompleteSolicitudCotizacionApprovalHere = false;

    /**
     * Document: user may submit a new solicitud de cotización (proveedor externo).
     *
     * @var    bool
     * @since  3.113.26
     */
    protected $canRequestSolicitudCotizacion = false;

    /**
     * Document: at least one solicitud de cotización was approved for this pre-cotización.
     *
     * @var    bool
     * @since  3.113.26
     */
    protected $vendorQuoteSolicitudApproved = false;

    /**
     * Document: orden de compra workflow published.
     *
     * @var    bool
     * @since  3.113.47
     */
    protected $ordenCompraWorkflowAvailable = false;

    /**
     * Document: orden de compra DB tables exist (draft editor / PDF without requiring workflow).
     *
     * @var    bool
     * @since  3.113.52
     */
    protected $ordenCompraTablesAvailable = false;

    /**
     * Document: count of órdenes de compra for this pre-cot (any vendor / status); for confirm-before-submit UI.
     *
     * @var    int
     * @since  3.113.48
     */
    protected $ordenCompraExistingCountForPrecot = 0;

    /**
     * Document: all proveedor_externo lines have qty and P.Unit Proveedor ready for OC.
     *
     * @var    bool
     * @since  3.113.47
     */
    protected $ordenCompraLinesReady = false;

    /**
     * Document: open «creación orden de trabajo» approval for this pre-cotización (entity_id = precot PK).
     *
     * @var    bool
     * @since  3.115.57
     */
    protected $creacionOtWorkflowAvailable = false;

    /**
     * Request id for pending creacion_orden_trabajo workflow, or 0.
     *
     * @var    int
     * @since  3.115.57
     */
    protected $pendingCreacionOtRequestId = 0;

    /**
     * Current user may approve/reject that request (pending step assignee).
     *
     * @var    bool
     * @since  3.115.57
     */
    protected $canCompleteCreacionOtApprovalHere = false;

    /**
     * Default delivery date Y-m-d from pending creación OT request metadata (approval modal).
     *
     * @var    string
     * @since  3.115.57
     */
    protected $pendingCreacionOtDefaultFechaYmd = '';

    /**
     * Precotizacion model (document/details layout) for breakdown adjustment helpers in layout.
     *
     * @var    \Grimpsa\Component\Ordenproduccion\Site\Model\PrecotizacionModel|null
     * @since  3.109.54
     */
    protected $precotizacionModel = null;

    /**
     * Proveedor externo: vendor quote request audit log (newest first).
     *
     * @var    array<int, \stdClass>
     * @since  3.113.6
     */
    protected $precotVendorQuoteEvents = [];

    /**
     * proveedor_id => latest orden_compra row summary (id, workflow_status), excluding deleted.
     *
     * @var    array<int, object>
     * @since  3.113.65
     */
    protected $ordenCompraLatestByProveedor = [];

    /**
     * Proveedor externo: user may see the vendor request log block (Administración, Aprobaciones Ventas).
     *
     * @var    bool
     * @since  3.113.30
     */
    protected $canViewVendorQuoteRequestLog = false;

    /**
     * Display the view
     *
     * @param   string  $tpl  The name of the template file to parse
     *
     * @return  void
     *
     * @since   3.67.0
     */
    public function display($tpl = null)
    {
        $app   = Factory::getApplication();
        $user  = Factory::getUser();
        $input = $app->input;

        $lang = $app->getLanguage();
        $lang->load('com_ordenproduccion', JPATH_SITE);
        $lang->load('com_ordenproduccion', JPATH_SITE . '/components/com_ordenproduccion');

        if ($user->guest) {
            $app->redirect(Route::_('index.php?option=com_users&view=login', false));
            return;
        }

        $layout = $input->get('layout', 'default', 'cmd');
        $id     = (int) $input->get('id', 0);

        // Pliego data for modal (paper types, sizes, lamination, processes)
        $productosModel = $app->bootComponent('com_ordenproduccion')->getMVCFactory()
            ->createModel('Productos', 'Site', ['ignore_request' => true]);
        $this->pliegoPaperTypes = $productosModel->getPaperTypesWithNonZeroPrintPrice();
        $this->pliegoSizes = $productosModel->getSizesWithNonZeroPrintPrice();
        $sizeIdsByPaperType = [];
        foreach ($this->pliegoPaperTypes as $pt) {
            $sizeIdsByPaperType[(int) $pt->id] = $productosModel->getSizeIdsWithNonZeroPrintPriceForPaperType((int) $pt->id);
        }
        $this->pliegoSizeIdsByPaperType = $sizeIdsByPaperType;
        $this->pliegoLaminationTypes = $productosModel->getLaminationTypes();
        $laminationTypeIdsBySizeTiro = [];
        $laminationTypeIdsBySizeRetiro = [];
        foreach ($this->pliegoSizes as $sz) {
            $sid = (int) $sz->id;
            $laminationTypeIdsBySizeTiro[$sid] = $productosModel->getLaminationTypeIdsWithNonZeroPriceForSize($sid, 'tiro');
            $laminationTypeIdsBySizeRetiro[$sid] = $productosModel->getLaminationTypeIdsWithNonZeroPriceForSize($sid, 'retiro');
        }
        $this->pliegoLaminationTypeIdsBySizeTiro = $laminationTypeIdsBySizeTiro;
        $this->pliegoLaminationTypeIdsBySizeRetiro = $laminationTypeIdsBySizeRetiro;
        $this->pliegoProcesses = $productosModel->getProcesses();
        $this->pliegoTablesExist = $productosModel->tablesExist();

        $mvcFactory = $app->bootComponent('com_ordenproduccion')->getMVCFactory();

        if (($layout === 'document' || $layout === 'details') && $id > 0) {
            if ($layout === 'document') {
                HTMLHelper::_('bootstrap.framework');
                HTMLHelper::_('form.csrf');
                $wa = $this->document->getWebAssetManager();
                if ($wa->assetExists('script', 'bootstrap.modal')) {
                    $wa->useScript('bootstrap.modal');
                }
            }
            $precotModel = $mvcFactory->createModel('Precotizacion', 'Site', ['ignore_request' => true]);
            $this->precotizacionModel = $precotModel;
            $this->item               = $precotModel->getItem($id);
            if (!$this->item) {
                if ($layout === 'document') {
                    $app->enqueueMessage(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_ERROR_NOT_FOUND'), 'error');
                    $app->redirect(Route::_('index.php?option=com_ordenproduccion&view=cotizador', false));
                    return;
                }
                $this->item = null;
                $this->lines = [];
                $this->elementos = [];
                $this->envios = [];
                $this->tarjetaCreditoTableExists = $productosModel->tarjetaCreditoTableExists();
                $this->tarjetaCreditoRates = $this->tarjetaCreditoTableExists ? $productosModel->getTarjetaCreditoRates() : [];
            } else {
                $this->lines = $precotModel->getLines($id);
                $this->elementos = [];
                if ($productosModel->elementosTableExists()) {
                    $this->elementos = $productosModel->getElementos();
                }
                $this->envios = [];
                if ($productosModel->enviosTableExists()) {
                    $this->envios = $productosModel->getEnvios();
                }
                $this->tarjetaCreditoTableExists = $productosModel->tarjetaCreditoTableExists();
                $this->tarjetaCreditoRates = $this->tarjetaCreditoTableExists ? $productosModel->getTarjetaCreditoRates() : [];
                // Backfill / repair totals snapshot (lines_subtotal includes all line totals, e.g. Envío — 3.115.27+)
                if (($layout === 'document' || $layout === 'details') && !empty($this->lines)) {
                    $sumLines = 0.0;
                    foreach ($this->lines as $ln) {
                        $sumLines += (float) ($ln->total ?? 0);
                    }
                    $hasSnapshot = isset($this->item->lines_subtotal) && $this->item->lines_subtotal !== null && $this->item->lines_subtotal !== '';
                    $stored = $hasSnapshot ? (float) $this->item->lines_subtotal : null;
                    if ($stored === null || abs($stored - $sumLines) > 0.02) {
                        $precotModel->refreshPreCotizacionTotalsSnapshot($id);
                        $this->item = $precotModel->getItem($id);
                    }
                }
                if ($layout === 'document') {
                    $this->associatedQuotations = $this->getQuotationsForPreCotizacion($id);
                    $this->precotizacionLockedByOrdenTrabajo = $precotModel->hasActiveOrdenTrabajoForPrecotizacion((int) $id);
                    $this->precotizacionLocked = $this->precotizacionLockedByOrdenTrabajo
                        || $precotModel->isAssociatedWithConfirmedQuotation((int) $id);
                    $this->precotizacionDocumentEditable = $precotModel->canUserEditPreCotizacionDocument((int) $id)
                        && !$this->precotizacionLocked;
                    $this->canSaveImpresionOverride = $precotModel->canUserSaveImpresionOverrideOnPreCotizacion((int) $id);
                    $this->canSetTercerizadoImporte  = AccessHelper::canSetTercerizadoImporte();
                    $this->discountWorkflowAvailable   = false;
                    $this->pendingSolicitudDescuento     = false;
                    $this->canRequestSolicitudDescuento  = false;
                    $this->solicitudDescuentoLatestNote  = '';
                    $this->solicitudCotizacionWorkflowAvailable = false;
                    $this->pendingSolicitudCotizacion           = false;
                    $this->pendingSolicitudCotizacionRequestId  = 0;
                    $this->canCompleteSolicitudCotizacionApprovalHere = false;
                    $this->canRequestSolicitudCotizacion        = false;
                    $this->vendorQuoteSolicitudApproved         = false;
                    $this->ordenCompraWorkflowAvailable         = false;
                    $this->ordenCompraTablesAvailable           = false;
                    $this->ordenCompraExistingCountForPrecot   = 0;
                    $this->ordenCompraLinesReady                = false;
                    $this->ordenCompraLatestByProveedor         = [];
                    $docMode = isset($this->item->document_mode) ? (string) $this->item->document_mode : 'pliego';
                    $this->creacionOtWorkflowAvailable = false;
                    $this->pendingCreacionOtRequestId = 0;
                    $this->canCompleteCreacionOtApprovalHere = false;
                    try {
                        $wf = new ApprovalWorkflowService();
                        if ($wf->hasSchema()) {
                            $this->discountWorkflowAvailable = $wf->isWorkflowPublishedForEntity(
                                ApprovalWorkflowService::ENTITY_SOLICITUD_DESCUENTO
                            );
                            $this->pendingSolicitudDescuento = $wf->getOpenPendingRequest(
                                ApprovalWorkflowService::ENTITY_SOLICITUD_DESCUENTO,
                                (int) $id
                            ) !== null;
                            $this->pendingCreacionOtDefaultFechaYmd = '';
                            $this->creacionOtWorkflowAvailable      = $wf->isWorkflowPublishedForEntity(
                                ApprovalWorkflowService::ENTITY_CREACION_ORDEN_TRABAJO
                            );
                            if ($this->creacionOtWorkflowAvailable) {
                                $pendingCre = $wf->getOpenPendingRequest(
                                    ApprovalWorkflowService::ENTITY_CREACION_ORDEN_TRABAJO,
                                    (int) $id
                                );
                                if ($pendingCre !== null) {
                                    $this->pendingCreacionOtRequestId = (int) ($pendingCre->id ?? 0);
                                    $this->canCompleteCreacionOtApprovalHere = $this->pendingCreacionOtRequestId > 0
                                        && $wf->canUserActOnPendingStep(
                                            $this->pendingCreacionOtRequestId,
                                            (int) $user->id
                                        );
                                    $mr = isset($pendingCre->metadata) ? trim((string) $pendingCre->metadata) : '';
                                    if ($mr !== '') {
                                        $decodedMeta = json_decode($mr, true);
                                        if (is_array($decodedMeta) && isset($decodedMeta['wizard']['ot_fecha_entrega'])) {
                                            $fe0 = trim((string) $decodedMeta['wizard']['ot_fecha_entrega']);
                                            if ($fe0 !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $fe0)) {
                                                $this->pendingCreacionOtDefaultFechaYmd = $fe0;
                                            }
                                        }
                                    }
                                }
                            }
                            if ($this->discountWorkflowAvailable) {
                                $latestDisc = $wf->getLatestRequestForEntity(
                                    ApprovalWorkflowService::ENTITY_SOLICITUD_DESCUENTO,
                                    (int) $id
                                );
                                if ($latestDisc !== null && isset($latestDisc->metadata) && $latestDisc->metadata !== null && $latestDisc->metadata !== '') {
                                    $meta = json_decode((string) $latestDisc->metadata, true);
                                    if (is_array($meta) && isset($meta['request_note'])) {
                                        $this->solicitudDescuentoLatestNote = trim((string) $meta['request_note']);
                                    }
                                }
                            }
                            if ($docMode === 'proveedor_externo') {
                                $this->solicitudCotizacionWorkflowAvailable = $wf->isWorkflowPublishedForEntity(
                                    ApprovalWorkflowService::ENTITY_SOLICITUD_COTIZACION
                                );
                                $this->pendingSolicitudCotizacionRequestId = 0;
                                $this->canCompleteSolicitudCotizacionApprovalHere = false;
                                $pendingSc = $wf->getOpenPendingRequest(
                                    ApprovalWorkflowService::ENTITY_SOLICITUD_COTIZACION,
                                    (int) $id
                                );
                                $this->pendingSolicitudCotizacion = $pendingSc !== null;
                                if ($pendingSc !== null) {
                                    $this->pendingSolicitudCotizacionRequestId = (int) ($pendingSc->id ?? 0);
                                    $this->canCompleteSolicitudCotizacionApprovalHere = $this->pendingSolicitudCotizacionRequestId > 0
                                        && $wf->canUserActOnPendingStep(
                                            $this->pendingSolicitudCotizacionRequestId,
                                            (int) $user->id
                                        );
                                }
                                $this->vendorQuoteSolicitudApproved = $wf->hasApprovedRequestForEntity(
                                    ApprovalWorkflowService::ENTITY_SOLICITUD_COTIZACION,
                                    (int) $id
                                );
                                $this->ordenCompraWorkflowAvailable = $wf->isWorkflowPublishedForEntity(
                                    ApprovalWorkflowService::ENTITY_ORDEN_COMPRA
                                );
                                $ocModel = $mvcFactory->createModel('Ordencompra', 'Site', ['ignore_request' => true]);
                                if ($ocModel && method_exists($ocModel, 'hasSchema') && $ocModel->hasSchema()) {
                                    $this->ordenCompraTablesAvailable = true;
                                }
                                if ($ocModel && method_exists($ocModel, 'countForPrecotizacion')) {
                                    $this->ordenCompraExistingCountForPrecot = $ocModel->countForPrecotizacion((int) $id);
                                }
                                $this->ordenCompraLinesReady = $precotModel->allProveedorExternoLinesReadyForOrdenCompra((int) $id);
                            }
                        }
                    } catch (\Throwable $e) {
                        $this->discountWorkflowAvailable  = false;
                        $this->pendingSolicitudDescuento    = false;
                        $this->solicitudCotizacionWorkflowAvailable = false;
                        $this->pendingSolicitudCotizacion           = false;
                        $this->pendingSolicitudCotizacionRequestId  = 0;
                        $this->canCompleteSolicitudCotizacionApprovalHere = false;
                        $this->vendorQuoteSolicitudApproved           = false;
                        $this->ordenCompraWorkflowAvailable           = false;
                        $this->ordenCompraTablesAvailable             = false;
                        $this->ordenCompraExistingCountForPrecot      = 0;
                        $this->ordenCompraLinesReady                  = false;
                        $this->ordenCompraLatestByProveedor           = [];
                        $this->solicitudDescuentoLatestNote           = '';
                        $this->creacionOtWorkflowAvailable            = false;
                        $this->pendingCreacionOtRequestId           = 0;
                        $this->canCompleteCreacionOtApprovalHere    = false;
                        $this->pendingCreacionOtDefaultFechaYmd       = '';
                        $this->canSetTercerizadoImporte               = false;
                    }
                    $this->canRequestSolicitudDescuento = $this->discountWorkflowAvailable
                        && $precotModel->canUserSubmitPreCotizacionWorkflowRequests((int) $id)
                        && !$this->pendingSolicitudDescuento;
                    $this->canRequestSolicitudCotizacion = $docMode === 'proveedor_externo'
                        && $this->solicitudCotizacionWorkflowAvailable
                        && $precotModel->canUserSubmitPreCotizacionWorkflowRequests((int) $id)
                        && !$this->precotizacionLocked
                        && !$this->pendingSolicitudCotizacion;
                    $this->canViewVendorQuoteRequestLog = AccessHelper::canViewVendorQuoteRequestLog();
                    $this->precotVendorQuoteEvents      = [];
                    if (
                        $docMode === 'proveedor_externo'
                        && $this->canViewVendorQuoteRequestLog
                        && method_exists($precotModel, 'getVendorQuoteEvents')
                    ) {
                        $this->precotVendorQuoteEvents = $precotModel->getVendorQuoteEvents((int) $id);
                    }
                    if (
                        $docMode === 'proveedor_externo'
                        && $this->ordenCompraTablesAvailable
                        && $this->precotVendorQuoteEvents !== []
                    ) {
                        $ocLatestModel = $mvcFactory->createModel('Ordencompra', 'Site', ['ignore_request' => true]);
                        if ($ocLatestModel && method_exists($ocLatestModel, 'getLatestOrdenCompraSummaryForPrecotProveedor')) {
                            $seenProv = [];
                            foreach ($this->precotVendorQuoteEvents as $evRow) {
                                $ppid = (int) ($evRow->proveedor_id ?? 0);
                                if ($ppid < 1 || isset($seenProv[$ppid])) {
                                    continue;
                                }
                                $seenProv[$ppid] = true;
                                $summary = $ocLatestModel->getLatestOrdenCompraSummaryForPrecotProveedor((int) $id, $ppid);
                                if ($summary !== null) {
                                    $this->ordenCompraLatestByProveedor[$ppid] = $summary;
                                }
                            }
                        }
                    }
                }
            }
            $params = ComponentHelper::getParams('com_ordenproduccion');
            $this->paramMargen   = (float) $params->get('margen_ganancia', 0);
            $this->paramIva      = (float) $params->get('iva', 0);
            $this->paramIsr      = (float) $params->get('isr', 0);
            $this->paramComision = (float) $params->get('comision_venta', 0);
            $this->paramComisionMargenAdicional = (float) $params->get('comision_margen_adicional', 0);
            $this->clickAncho    = (float) $params->get('click_ancho', 0);
            $this->clickAlto     = (float) $params->get('click_alto', 0);
            $this->clickPrecio   = (float) $params->get('click_precio', 0);
            if ($layout === 'details') {
                $this->setLayout('details');
            } else {
                $this->setLayout('document');
                $this->document->setTitle(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_TITLE') . ' ' . $this->item->number);
                // Show "Oferta" (template) checkbox only for users selected in Administración > Ofertas tab
                $params = ComponentHelper::getParams('com_ordenproduccion');
                $ofertasUserIds = (array) $params->get('ofertas_user_ids', []);
                if (!empty($ofertasUserIds) && !is_array($ofertasUserIds)) {
                    $ofertasUserIds = array_map('intval', array_filter(explode(',', (string) $ofertasUserIds)));
                } else {
                    $ofertasUserIds = array_values(array_filter(array_map('intval', $ofertasUserIds)));
                }
                $this->showOfertaCheckbox = in_array((int) $user->id, $ofertasUserIds, true);
            }
        } else {
            $precotModel = $mvcFactory->createModel('Precotizacion', 'Site');
            $this->items = $precotModel->getItems();
            $this->pagination = $precotModel->getPagination();
            $this->state = $precotModel->getState();
            $pcCols = Factory::getDbo()->getTableColumns('#__ordenproduccion_pre_cotizacion', false);
            $pcColsLc = is_array($pcCols) ? array_change_key_case($pcCols, CASE_LOWER) : [];
            $this->hasFacturarColumn = isset($pcColsLc['facturar']);
            $this->hasOfertaColumn   = isset($pcColsLc['oferta']);
            $this->showSalesAgentColumn = AccessHelper::canViewAllPrecotizaciones();
            $this->templates = $precotModel->getTemplates();
            $ids = [];
            foreach ($this->items as $it) {
                $ids[] = (int) $it->id;
            }
            $this->associatedQuotationNumbersByPreId = $this->getAssociatedQuotationNumbersByPreCotizacionIds($ids);
            $this->associatedOrdenesByPreId = $this->getAssociatedOrdenTrabajoLinksByPreCotizacionIds($ids);
            $this->salesAgentFilterOptions = [];
            if ($this->showSalesAgentColumn) {
                $db = Factory::getDbo();
                $q = $db->getQuery(true)
                    ->select('DISTINCT ' . $db->quoteName('a.created_by') . ', ' . $db->quoteName('u.name'))
                    ->from($db->quoteName('#__ordenproduccion_pre_cotizacion', 'a'))
                    ->innerJoin(
                        $db->quoteName('#__users', 'u'),
                        $db->quoteName('u.id') . ' = ' . $db->quoteName('a.created_by')
                    )
                    ->where($db->quoteName('a.state') . ' = 1')
                    ->order($db->quoteName('u.name') . ' ASC');
                $db->setQuery($q);
                $agentRows = $db->loadObjectList() ?: [];
                foreach ($agentRows as $ar) {
                    $this->salesAgentFilterOptions[(int) $ar->created_by] = (string) ($ar->name ?? '');
                }
            }
            $this->setLayout('default');
            $this->document->setTitle(Text::_('COM_ORDENPRODUCCION_PRE_COTIZACION_LIST_TITLE'));
            HTMLHelper::_('bootstrap.framework');
        }

        parent::display($tpl);
    }

    /**
     * Get quotations that reference this pre-cotización (via quotation_items.pre_cotizacion_id).
     *
     * @param   int  $preCotizacionId  Pre-cotización id
     *
     * @return  \stdClass[]  List of objects with id, quotation_number
     *
     * @since   3.74.0
     */
    protected function getQuotationsForPreCotizacion($preCotizacionId)
    {
        $db = Factory::getDbo();
        $itemCols = $db->getTableColumns('#__ordenproduccion_quotation_items', false);
        $itemCols = is_array($itemCols) ? array_change_key_case($itemCols, CASE_LOWER) : [];
        if (!isset($itemCols['pre_cotizacion_id'])) {
            return [];
        }
        $query = $db->getQuery(true)
            ->select('DISTINCT ' . $db->quoteName('q.id') . ', ' . $db->quoteName('q.quotation_number'))
            ->from($db->quoteName('#__ordenproduccion_quotation_items', 'qi'))
            ->innerJoin(
                $db->quoteName('#__ordenproduccion_quotations', 'q'),
                $db->quoteName('q.id') . ' = ' . $db->quoteName('qi.quotation_id')
                . ' AND ' . $db->quoteName('q.state') . ' = 1'
            )
            ->where($db->quoteName('qi.pre_cotizacion_id') . ' = ' . (int) $preCotizacionId)
            ->order($db->quoteName('q.quotation_number'));
        $db->setQuery($query);
        $list = $db->loadObjectList();
        return is_array($list) ? $list : [];
    }

    /**
     * Get associated quotations per pre-cotización id (for list view).
     *
     * @param   int[]  $preCotizacionIds  Pre-cotización ids
     *
     * @return  array  [ pre_cotizacion_id => [ [ 'id' => int, 'quotation_number' => string ], ... ], ... ]
     *
     * @since   3.75.0
     */
    protected function getAssociatedQuotationNumbersByPreCotizacionIds(array $preCotizacionIds)
    {
        $db = Factory::getDbo();
        $itemCols = $db->getTableColumns('#__ordenproduccion_quotation_items', false);
        $itemCols = is_array($itemCols) ? array_change_key_case($itemCols, CASE_LOWER) : [];
        if (!isset($itemCols['pre_cotizacion_id']) || empty($preCotizacionIds)) {
            return [];
        }
        $ids = array_map('intval', $preCotizacionIds);
        $ids = array_filter($ids, function ($id) {
            return $id > 0;
        });
        if (empty($ids)) {
            return [];
        }
        $qCols = $db->getTableColumns('#__ordenproduccion_quotations', false);
        $qCols = is_array($qCols) ? array_change_key_case($qCols, CASE_LOWER) : [];
        $selectClientName = isset($qCols['client_name']);
        $select = $db->quoteName('qi.pre_cotizacion_id') . ', ' . $db->quoteName('q.id', 'quotation_id') . ', ' . $db->quoteName('q.quotation_number');
        if ($selectClientName) {
            $select .= ', ' . $db->quoteName('q.client_name');
        }
        $query = $db->getQuery(true)
            ->select($select)
            ->from($db->quoteName('#__ordenproduccion_quotation_items', 'qi'))
            ->innerJoin(
                $db->quoteName('#__ordenproduccion_quotations', 'q'),
                $db->quoteName('q.id') . ' = ' . $db->quoteName('qi.quotation_id')
                . ' AND ' . $db->quoteName('q.state') . ' = 1'
            )
            ->whereIn($db->quoteName('qi.pre_cotizacion_id'), $ids)
            ->order($db->quoteName('qi.pre_cotizacion_id') . ', ' . $db->quoteName('q.quotation_number'));
        $db->setQuery($query);
        $rows = $db->loadObjectList();
        $map = [];
        foreach ($ids as $id) {
            $map[$id] = [];
        }
        foreach (is_array($rows) ? $rows : [] as $row) {
            $pid = (int) $row->pre_cotizacion_id;
            $qid = (int) $row->quotation_id;
            $num = $row->quotation_number ?? ('COT-' . $qid);
            $seen = false;
            foreach ($map[$pid] as $existing) {
                if ($existing['id'] === $qid) {
                    $seen = true;
                    break;
                }
            }
            if (!$seen) {
                $entry = ['id' => $qid, 'quotation_number' => $num];
                if ($selectClientName && isset($row->client_name)) {
                    $entry['client_name'] = trim((string) $row->client_name);
                }
                $map[$pid][] = $entry;
            }
        }
        return $map;
    }

    /**
     * Active work orders per pre-cotización id (for list view). Mirrors
     * {@see \Grimpsa\Component\Ordenproduccion\Site\View\Cotizacion\HtmlView::buildOrdenesLinksByPreCotizacionIds}.
     *
     * @param   int[]  $preCotizacionIds  Pre-cotización primary keys
     *
     * @return  array<int, array<int, array{id: int, label: string, url: string}>>
     *
     * @since   3.115.69
     */
    protected function getAssociatedOrdenTrabajoLinksByPreCotizacionIds(array $preCotizacionIds): array
    {
        $db = Factory::getDbo();
        $ids = array_map('intval', $preCotizacionIds);
        $ids = array_filter($ids, static function ($id) {
            return $id > 0;
        });
        if ($ids === []) {
            return [];
        }
        $cols = $db->getTableColumns('#__ordenproduccion_ordenes', false);
        $cols = \is_array($cols) ? array_change_key_case($cols, CASE_LOWER) : [];
        if (!isset($cols['pre_cotizacion_id'])) {
            return [];
        }
        $map = [];
        foreach ($ids as $id) {
            $map[$id] = [];
        }
        $q = $db->getQuery(true)
            ->select($db->quoteName('id'))
            ->select($db->quoteName('pre_cotizacion_id'))
            ->from($db->quoteName('#__ordenproduccion_ordenes'))
            ->whereIn($db->quoteName('pre_cotizacion_id'), $ids)
            ->where($db->quoteName('state') . ' = 1');
        if (isset($cols['order_number'])) {
            $q->select($db->quoteName('order_number'));
        }
        if (isset($cols['orden_de_trabajo'])) {
            $q->select($db->quoteName('orden_de_trabajo'));
        }
        $q->order($db->quoteName('pre_cotizacion_id') . ' ASC')
            ->order($db->quoteName('id') . ' ASC');

        try {
            $db->setQuery($q);
            $rows = $db->loadObjectList();
        } catch (\Throwable $e) {
            return $map;
        }
        foreach ($rows ?: [] as $row) {
            $preId = isset($row->pre_cotizacion_id) ? (int) $row->pre_cotizacion_id : 0;
            if ($preId < 1 || !isset($map[$preId])) {
                continue;
            }
            $label = '';
            if (isset($row->order_number)) {
                $label = trim((string) $row->order_number);
            }
            if ($label === '' && isset($row->orden_de_trabajo)) {
                $label = trim((string) $row->orden_de_trabajo);
            }
            $oid = (int) $row->id;
            if ($label === '') {
                $label = '#' . $oid;
            }
            $map[$preId][] = [
                'id'    => $oid,
                'label' => $label,
                'url'   => Route::_('index.php?option=com_ordenproduccion&view=orden&id=' . $oid, false),
            ];
        }

        return $map;
    }

}
