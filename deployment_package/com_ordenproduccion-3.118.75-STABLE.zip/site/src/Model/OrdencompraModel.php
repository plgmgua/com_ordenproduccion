<?php
/**
 * Orden de compra (purchase order) — ORC numbering, lines from pre-cot P.Unit Proveedor.
 *
 * @package     Grimpsa\Component\Ordenproduccion\Site\Model
 * @since       3.113.47
 */

namespace Grimpsa\Component\Ordenproduccion\Site\Model;

defined('_JEXEC') or die;

use Grimpsa\Component\Ordenproduccion\Site\Service\ApprovalWorkflowService;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;

class OrdencompraModel extends BaseDatabaseModel
{
    /** Saved locally until user requests approval. */
    public const WORKFLOW_STATUS_DRAFT = 'draft';

    public function hasSchema(): bool
    {
        $db     = $this->getDatabase();
        $prefix = $db->getPrefix();
        $name   = $prefix . 'ordenproduccion_orden_compra';

        try {
            $db->setQuery('SHOW TABLES LIKE ' . $db->quote($name));
            $db->execute();

            return (string) $db->loadResult() !== '';
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function getNextNumber(): string
    {
        try {
            $settingsModel = new \Grimpsa\Component\Ordenproduccion\Administrator\Model\SettingsModel();

            return $settingsModel->getNextOrdenCompraNumber();
        } catch (\Throwable $e) {
            $db = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select('MAX(CAST(SUBSTRING(' . $db->quoteName('number') . ', 5) AS UNSIGNED))')
                ->from($db->quoteName('#__ordenproduccion_orden_compra'))
                ->where($db->quoteName('number') . ' LIKE ' . $db->quote('ORC-%'));
            $db->setQuery($query);
            $max  = (int) $db->loadResult();
            $next = $max + 1;

            return 'ORC-' . str_pad((string) $next, 5, '0', STR_PAD_LEFT);
        }
    }

    /**
     * Pending approval row for same pre-cot + vendor (blocks duplicate submit).
     */
    public function getPendingIdForPrecotProveedor(int $precotId, int $proveedorId): int
    {
        if (!$this->hasSchema() || $precotId < 1 || $proveedorId < 1) {
            return 0;
        }

        $db = $this->getDatabase();
        $q  = $db->getQuery(true)
            ->select($db->quoteName('id'))
            ->from($db->quoteName('#__ordenproduccion_orden_compra'))
            ->where($db->quoteName('precotizacion_id') . ' = ' . $precotId)
            ->where($db->quoteName('proveedor_id') . ' = ' . $proveedorId)
            ->where($db->quoteName('workflow_status') . ' = ' . $db->quote('pending_approval'))
            ->setLimit(1);
        $db->setQuery($q);

        return (int) $db->loadResult();
    }

    /**
     * How many órdenes de compra exist for this pre-cotización (any vendor, any workflow status).
     *
     * @since  3.113.48
     */
    public function countForPrecotizacion(int $precotId): int
    {
        if (!$this->hasSchema() || $precotId < 1) {
            return 0;
        }

        $db = $this->getDatabase();
        $q  = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from($db->quoteName('#__ordenproduccion_orden_compra'))
            ->where($db->quoteName('precotizacion_id') . ' = ' . $precotId)
            ->where($db->quoteName('workflow_status') . ' != ' . $db->quote('deleted'));
        $db->setQuery($q);

        return (int) $db->loadResult();
    }

    /**
     * Rows in the list view (excludes soft-deleted).
     *
     * @since  3.113.92
     */
    public function getListTotal(): int
    {
        if (!$this->hasSchema()) {
            return 0;
        }

        $db = $this->getDatabase();
        $q  = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from($db->quoteName('#__ordenproduccion_orden_compra', 'o'))
            ->where($db->quoteName('o.workflow_status') . ' != ' . $db->quote('deleted'));
        $db->setQuery($q);

        return (int) $db->loadResult();
    }

    /**
     * @param   int  $limitStart  Offset for pagination
     * @param   int  $limit       Page size (max 500)
     *
     * @return  array<int, object>
     */
    public function getListItems(int $limitStart = 0, int $limit = 20): array
    {
        if (!$this->hasSchema()) {
            return [];
        }

        if ($limit < 1) {
            $limit = 20;
        }

        $limit = min($limit, 500);

        $db = $this->getDatabase();
        $q  = $db->getQuery(true)
            ->select('o.*, p.number AS precot_number')
            ->from($db->quoteName('#__ordenproduccion_orden_compra', 'o'))
            ->leftJoin(
                $db->quoteName('#__ordenproduccion_pre_cotizacion', 'p') . ' ON ' . $db->quoteName('p.id') . ' = ' . $db->quoteName('o.precotizacion_id')
            )
            ->where($db->quoteName('o.workflow_status') . ' != ' . $db->quote('deleted'))
            ->order($db->quoteName('o.id') . ' DESC');

        $db->setQuery($q, $limitStart, $limit);

        return $db->loadObjectList() ?: [];
    }

    public function getItemById(int $id): ?object
    {
        if (!$this->hasSchema() || $id < 1) {
            return null;
        }

        $db = $this->getDatabase();
        $q  = $db->getQuery(true)
            ->select('o.*, p.number AS precot_number')
            ->from($db->quoteName('#__ordenproduccion_orden_compra', 'o'))
            ->leftJoin(
                $db->quoteName('#__ordenproduccion_pre_cotizacion', 'p') . ' ON ' . $db->quoteName('p.id') . ' = ' . $db->quoteName('o.precotizacion_id')
            )
            ->where($db->quoteName('o.id') . ' = ' . $id)
            ->setLimit(1);
        $db->setQuery($q);
        $row = $db->loadObject();

        return $row ?: null;
    }

    /**
     * @return array<int, object>
     */
    public function getLines(int $ordenCompraId): array
    {
        if (!$this->hasSchema() || $ordenCompraId < 1) {
            return [];
        }

        $db = $this->getDatabase();
        $q  = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__ordenproduccion_orden_compra_line'))
            ->where($db->quoteName('orden_compra_id') . ' = ' . $ordenCompraId)
            ->order($db->quoteName('id') . ' ASC');
        $db->setQuery($q);

        return $db->loadObjectList() ?: [];
    }

    public function deleteOrden(int $id): bool
    {
        if (!$this->hasSchema() || $id < 1) {
            return false;
        }

        $row = $this->getItemById($id);
        $st  = strtolower((string) ($row->workflow_status ?? ''));
        if (!$row || !in_array($st, ['pending_approval', self::WORKFLOW_STATUS_DRAFT, 'rejected', 'approved'], true)) {
            return false;
        }

        $reqId  = (int) ($row->approval_request_id ?? 0);
        $userId = (int) Factory::getUser()->id;
        // Approved/rejected requests are not `pending`; cancel only applies while workflow is open.
        if ($st === 'pending_approval' && $reqId > 0 && $userId > 0) {
            $wf = new ApprovalWorkflowService($this->getDatabase());
            if (!$wf->cancelRequest($reqId, $userId, 'orden_compra_deleted')) {
                return false;
            }
        }

        $db = $this->getDatabase();
        $now = Factory::getDate()->toSql();
        try {
            $db->setQuery(
                $db->getQuery(true)
                    ->update($db->quoteName('#__ordenproduccion_orden_compra'))
                    ->set($db->quoteName('workflow_status') . ' = ' . $db->quote('deleted'))
                    ->set($db->quoteName('state') . ' = 0')
                    ->set($db->quoteName('approval_request_id') . ' = NULL')
                    ->set($db->quoteName('modified') . ' = ' . $db->quote($now))
                    ->set($db->quoteName('modified_by') . ' = ' . $userId)
                    ->where($db->quoteName('id') . ' = ' . $id)
            );
            $db->execute();
        } catch (\Throwable $e) {
            return false;
        }

        return true;
    }

    public function setApprovalRequestId(int $ordenCompraId, int $requestId): void
    {
        if (!$this->hasSchema() || $ordenCompraId < 1 || $requestId < 1) {
            return;
        }

        $db = $this->getDatabase();
        $db->setQuery(
            $db->getQuery(true)
                ->update($db->quoteName('#__ordenproduccion_orden_compra'))
                ->set($db->quoteName('approval_request_id') . ' = ' . $requestId)
                ->set($db->quoteName('modified') . ' = ' . $db->quote(Factory::getDate()->toSql()))
                ->set($db->quoteName('modified_by') . ' = ' . (int) Factory::getUser()->id)
                ->where($db->quoteName('id') . ' = ' . $ordenCompraId)
        );
        $db->execute();
    }

    public function updateWorkflowStatus(int $ordenCompraId, string $status): void
    {
        if (!$this->hasSchema() || $ordenCompraId < 1) {
            return;
        }

        $status = strtolower(trim($status));
        if (!in_array($status, ['pending_approval', 'approved', 'rejected', 'deleted', self::WORKFLOW_STATUS_DRAFT], true)) {
            return;
        }

        $db = $this->getDatabase();
        $db->setQuery(
            $db->getQuery(true)
                ->update($db->quoteName('#__ordenproduccion_orden_compra'))
                ->set($db->quoteName('workflow_status') . ' = ' . $db->quote($status))
                ->set($db->quoteName('modified') . ' = ' . $db->quote(Factory::getDate()->toSql()))
                ->set($db->quoteName('modified_by') . ' = ' . (int) Factory::getUser()->id)
                ->where($db->quoteName('id') . ' = ' . $ordenCompraId)
        );
        $db->execute();
    }

    /**
     * Relative path (from site root) to the final combined PDF after approval.
     */
    public function setApprovedPdfPath(int $ordenCompraId, string $relativePath): void
    {
        if (!$this->hasSchema() || $ordenCompraId < 1 || $relativePath === '') {
            return;
        }
        if (strpos($relativePath, '..') !== false) {
            return;
        }

        $db = $this->getDatabase();
        $db->setQuery(
            $db->getQuery(true)
                ->update($db->quoteName('#__ordenproduccion_orden_compra'))
                ->set($db->quoteName('approved_pdf_path') . ' = ' . $db->quote($relativePath))
                ->set($db->quoteName('modified') . ' = ' . $db->quote(Factory::getDate()->toSql()))
                ->set($db->quoteName('modified_by') . ' = ' . (int) Factory::getUser()->id)
                ->where($db->quoteName('id') . ' = ' . $ordenCompraId)
        );
        $db->execute();
    }

    /**
     * Proveedor ids that already have a pending-approval orden de compra for this pre-cotización.
     *
     * @return array<int, true>
     */
    public function getPendingProveedorIdsForPrecot(int $precotId): array
    {
        if (!$this->hasSchema() || $precotId < 1) {
            return [];
        }

        $db = $this->getDatabase();
        $q  = $db->getQuery(true)
            ->select($db->quoteName('proveedor_id'))
            ->from($db->quoteName('#__ordenproduccion_orden_compra'))
            ->where($db->quoteName('precotizacion_id') . ' = ' . $precotId)
            ->where($db->quoteName('workflow_status') . ' = ' . $db->quote('pending_approval'));
        $db->setQuery($q);
        $ids = $db->loadColumn() ?: [];
        $out = [];
        foreach ($ids as $pid) {
            $pid = (int) $pid;
            if ($pid > 0) {
                $out[$pid] = true;
            }
        }

        return $out;
    }

    /**
     * Latest draft orden de compra for this pre-cotización and proveedor (if any).
     */
    public function getDraftIdForPrecotProveedor(int $precotId, int $proveedorId): int
    {
        if (!$this->hasSchema() || $precotId < 1 || $proveedorId < 1) {
            return 0;
        }

        $db = $this->getDatabase();
        $q  = $db->getQuery(true)
            ->select($db->quoteName('id'))
            ->from($db->quoteName('#__ordenproduccion_orden_compra'))
            ->where($db->quoteName('precotizacion_id') . ' = ' . $precotId)
            ->where($db->quoteName('proveedor_id') . ' = ' . $proveedorId)
            ->where($db->quoteName('workflow_status') . ' = ' . $db->quote(self::WORKFLOW_STATUS_DRAFT))
            ->order($db->quoteName('id') . ' DESC')
            ->setLimit(1);
        $db->setQuery($q);

        return (int) $db->loadResult();
    }

    /**
     * Latest orden de compra for pre-cot + vendor (any status except deleted).
     *
     * @return  object|null  { id, workflow_status }
     *
     * @since   3.113.65
     */
    public function getLatestOrdenCompraSummaryForPrecotProveedor(int $precotId, int $proveedorId): ?object
    {
        if (!$this->hasSchema() || $precotId < 1 || $proveedorId < 1) {
            return null;
        }

        $db = $this->getDatabase();
        $q  = $db->getQuery(true)
            ->select([
                $db->quoteName('id'),
                $db->quoteName('workflow_status'),
            ])
            ->from($db->quoteName('#__ordenproduccion_orden_compra'))
            ->where($db->quoteName('precotizacion_id') . ' = ' . $precotId)
            ->where($db->quoteName('proveedor_id') . ' = ' . $proveedorId)
            ->where($db->quoteName('workflow_status') . ' != ' . $db->quote('deleted'))
            ->order($db->quoteName('id') . ' DESC')
            ->setLimit(1);
        $db->setQuery($q);
        $row = $db->loadObject();
        if (!$row || (int) ($row->id ?? 0) < 1) {
            return null;
        }

        return $row;
    }

    /**
     * Update orden de compra lines (draft only). Rows: id = orden_compra_line.id, quantity, descripcion, vendor_unit_price.
     *
     * @param   array<int, array<string, mixed>>  $rows
     */
    public function saveOrdenCompraDraftLines(int $ordenCompraId, array $rows): bool
    {
        $ordenCompraId = (int) $ordenCompraId;
        if (!$this->hasSchema() || $ordenCompraId < 1) {
            return false;
        }

        $header = $this->getItemById($ordenCompraId);
        if (!$header || strtolower((string) ($header->workflow_status ?? '')) !== self::WORKFLOW_STATUS_DRAFT) {
            return false;
        }

        $db = $this->getDatabase();
        $db->transactionStart();

        try {
            $sum = 0.0;

            foreach ($rows as $row) {
                if (!is_array($row)) {
                    continue;
                }

                $lineId = (int) ($row['id'] ?? 0);
                if ($lineId < 1) {
                    continue;
                }

                $q0 = $db->getQuery(true)
                    ->select($db->quoteName('id'))
                    ->from($db->quoteName('#__ordenproduccion_orden_compra_line'))
                    ->where($db->quoteName('id') . ' = ' . $lineId)
                    ->where($db->quoteName('orden_compra_id') . ' = ' . $ordenCompraId)
                    ->setLimit(1);
                $db->setQuery($q0);
                if ((int) $db->loadResult() !== $lineId) {
                    throw new \RuntimeException('line mismatch');
                }

                $qty  = max(1, (int) ($row['quantity'] ?? 1));
                $desc = trim((string) ($row['descripcion'] ?? ''));
                $pup  = round((float) ($row['vendor_unit_price'] ?? 0), 2);
                $lt   = round($qty * $pup, 2);
                $sum += $lt;

                $db->setQuery(
                    $db->getQuery(true)
                        ->update($db->quoteName('#__ordenproduccion_orden_compra_line'))
                        ->set($db->quoteName('quantity') . ' = ' . $qty)
                        ->set($db->quoteName('descripcion') . ' = ' . $db->quote($desc))
                        ->set($db->quoteName('vendor_unit_price') . ' = ' . $db->quote(number_format($pup, 2, '.', '')))
                        ->set($db->quoteName('line_total') . ' = ' . $db->quote(number_format($lt, 2, '.', '')))
                        ->where($db->quoteName('id') . ' = ' . $lineId)
                );
                $db->execute();
            }

            $sum = round($sum, 2);
            $now = Factory::getDate()->toSql();
            $db->setQuery(
                $db->getQuery(true)
                    ->update($db->quoteName('#__ordenproduccion_orden_compra'))
                    ->set($db->quoteName('total_amount') . ' = ' . $db->quote(number_format($sum, 2, '.', '')))
                    ->set($db->quoteName('modified') . ' = ' . $db->quote($now))
                    ->set($db->quoteName('modified_by') . ' = ' . (int) Factory::getUser()->id)
                    ->where($db->quoteName('id') . ' = ' . $ordenCompraId)
            );
            $db->execute();

            $db->transactionCommit();
        } catch (\Throwable $e) {
            $db->transactionRollback();

            return false;
        }

        return true;
    }

    /**
     * Insert header + lines in one transaction. Returns new orden_compra id or 0.
     *
     * @param array<int, array{precotizacion_line_id:int, quantity:int, descripcion:string, vendor_unit_price:float, line_total:float}> $lines
     * @param string $workflowStatus draft | pending_approval
     */
    public function createPendingOrdenCompra(
        int $precotizacionId,
        int $proveedorId,
        ?int $vendorQuoteEventId,
        string $condicionesEntrega,
        string $proveedorSnapshotJson,
        string $currency,
        array $lines,
        int $userId,
        string $workflowStatus = 'pending_approval'
    ): int {
        if (!$this->hasSchema() || $precotizacionId < 1 || $proveedorId < 1 || $userId < 1 || $lines === []) {
            return 0;
        }

        $workflowStatus = strtolower(trim($workflowStatus));
        if (!in_array($workflowStatus, ['pending_approval', self::WORKFLOW_STATUS_DRAFT], true)) {
            return 0;
        }

        $currency = trim($currency) !== '' ? strtoupper(substr(trim($currency), 0, 8)) : 'Q';
        $number   = $this->getNextNumber();
        $now      = Factory::getDate()->toSql();
        $total    = 0.0;
        foreach ($lines as $L) {
            $total += (float) ($L['line_total'] ?? 0);
        }
        $total = round($total, 2);

        $db = $this->getDatabase();
        $db->transactionStart();

        try {
            $evtVal = $vendorQuoteEventId !== null && $vendorQuoteEventId > 0
                ? (string) (int) $vendorQuoteEventId
                : 'NULL';

            $ins = $db->getQuery(true)
                ->insert($db->quoteName('#__ordenproduccion_orden_compra'))
                ->columns([
                    $db->quoteName('number'),
                    $db->quoteName('precotizacion_id'),
                    $db->quoteName('proveedor_id'),
                    $db->quoteName('vendor_quote_event_id'),
                    $db->quoteName('condiciones_entrega'),
                    $db->quoteName('proveedor_snapshot'),
                    $db->quoteName('currency'),
                    $db->quoteName('total_amount'),
                    $db->quoteName('workflow_status'),
                    $db->quoteName('approval_request_id'),
                    $db->quoteName('state'),
                    $db->quoteName('created'),
                    $db->quoteName('created_by'),
                    $db->quoteName('modified_by'),
                    $db->quoteName('approve_email_cc_vendor'),
                ])
                ->values(implode(',', [
                    $db->quote($number),
                    (string) (int) $precotizacionId,
                    (string) (int) $proveedorId,
                    $evtVal === 'NULL' ? 'NULL' : $evtVal,
                    $db->quote($condicionesEntrega),
                    $db->quote($proveedorSnapshotJson),
                    $db->quote($currency),
                    $db->quote(number_format($total, 2, '.', '')),
                    $db->quote($workflowStatus),
                    'NULL',
                    '1',
                    $db->quote($now),
                    (string) (int) $userId,
                    '0',
                    '0',
                ]));
            $db->setQuery($ins);
            $db->execute();
            $ocId = (int) $db->insertid();
            if ($ocId < 1) {
                throw new \RuntimeException('insert oc');
            }

            foreach ($lines as $L) {
                $lid = (int) ($L['precotizacion_line_id'] ?? 0);
                $qty = (int) ($L['quantity'] ?? 0);
                if ($lid < 1 || $qty < 1) {
                    throw new \RuntimeException('line');
                }
                $desc = (string) ($L['descripcion'] ?? '');
                $pup  = round((float) ($L['vendor_unit_price'] ?? 0), 2);
                $lt   = round((float) ($L['line_total'] ?? 0), 2);
                $insL = $db->getQuery(true)
                    ->insert($db->quoteName('#__ordenproduccion_orden_compra_line'))
                    ->columns([
                        $db->quoteName('orden_compra_id'),
                        $db->quoteName('precotizacion_line_id'),
                        $db->quoteName('quantity'),
                        $db->quoteName('descripcion'),
                        $db->quoteName('vendor_unit_price'),
                        $db->quoteName('line_total'),
                    ])
                    ->values(implode(',', [
                        (string) $ocId,
                        (string) $lid,
                        (string) $qty,
                        $db->quote($desc),
                        $db->quote(number_format($pup, 2, '.', '')),
                        $db->quote(number_format($lt, 2, '.', '')),
                    ]));
                $db->setQuery($insL);
                $db->execute();
            }

            $db->transactionCommit();
        } catch (\Throwable $e) {
            $db->transactionRollback();

            return 0;
        }

        return $ocId;
    }

    /**
     * Persist whether the approved-PO notification should CC the vendor contact email.
     *
     * @since  3.113.63
     */
    public function setApproveEmailCcVendor(int $ordenCompraId, bool $ccVendor): bool
    {
        if (!$this->hasSchema() || $ordenCompraId < 1) {
            return false;
        }

        $db = $this->getDatabase();
        $db->setQuery(
            $db->getQuery(true)
                ->update($db->quoteName('#__ordenproduccion_orden_compra'))
                ->set($db->quoteName('approve_email_cc_vendor') . ' = ' . ($ccVendor ? '1' : '0'))
                ->set($db->quoteName('modified') . ' = ' . $db->quote(Factory::getDate()->toSql()))
                ->set($db->quoteName('modified_by') . ' = ' . (int) Factory::getUser()->id)
                ->where($db->quoteName('id') . ' = ' . $ordenCompraId)
        );

        try {
            $db->execute();
        } catch (\Throwable $e) {
            return false;
        }

        return true;
    }
}
