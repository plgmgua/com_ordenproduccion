<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_ordenproduccion
 *
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Grimpsa\Component\Ordenproduccion\Site\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\CMS\User\UserFactoryInterface;
use Grimpsa\Component\Ordenproduccion\Site\Helper\AccessHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\TelegramNotificationHelper;

/**
 * Payments model for com_ordenproduccion - lists payment proofs with filters
 *
 * @since  1.0.0
 */
class PaymentsModel extends ListModel
{
    /**
     * The prefix to use with controller messages.
     *
     * @var    string
     * @since  1.0.0
     */
    protected $text_prefix = 'COM_ORDENPRODUCCION_PAYMENTS';

    /**
     * Constructor.
     *
     * @param   array  $config  An optional associative array of configuration settings.
     *
     * @since   1.0.0
     */
    public function __construct($config = [])
    {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = [
                'id', 'pp.created', 'payment_amount', 'client_name', 'sales_agent'
            ];
        }

        parent::__construct($config);
    }

    /**
     * Method to get a store id based on model configuration state.
     *
     * @param   string  $id  A prefix for the store id.
     *
     * @return  string  A store id.
     *
     * @since   1.0.0
     */
    protected function getStoreId($id = '')
    {
        $id .= ':' . $this->getState('filter.client');
        $id .= ':' . $this->getState('filter.date_from');
        $id .= ':' . $this->getState('filter.date_to');
        $id .= ':' . $this->getState('filter.sales_agent');
        $id .= ':' . $this->getState('filter.state');
        $id .= ':' . $this->getState('filter.estado');

        return parent::getStoreId($id);
    }

    /**
     * Method to auto-populate the model state.
     *
     * @param   string  $ordering   An optional ordering field.
     * @param   string  $direction  An optional direction (asc|desc).
     *
     * @return  void
     *
     * @since   1.0.0
     */
    protected function populateState($ordering = 'pp.created', $direction = 'desc')
    {
        $app = Factory::getApplication();

        $params = $app->getParams();
        $this->setState('params', $params);

        $limit = $app->getUserStateFromRequest('global.list.limit', 'limit', $app->get('list_limit'), 'uint');
        $this->setState('list.limit', $limit);

        $limitstart = $app->input->get('limitstart', 0, 'uint');
        $this->setState('list.start', $limitstart);

        $orderCol = $app->input->get('filter_order', $ordering);
        if (!in_array($orderCol, $this->filter_fields)) {
            $orderCol = $ordering;
        }
        $this->setState('list.ordering', $orderCol);

        $listOrder = $app->input->get('filter_order_Dir', $direction);
        if (!in_array(strtoupper($listOrder), ['ASC', 'DESC', ''])) {
            $listOrder = $direction;
        }
        $this->setState('list.direction', $listOrder);

        $client = $app->getUserStateFromRequest($this->context . '.filter.client', 'filter_client', '', 'string');
        $this->setState('filter.client', $client);

        $dateFrom = $app->getUserStateFromRequest($this->context . '.filter.date_from', 'filter_date_from', '', 'string');
        $this->setState('filter.date_from', $dateFrom);

        $dateTo = $app->getUserStateFromRequest($this->context . '.filter.date_to', 'filter_date_to', '', 'string');
        $this->setState('filter.date_to', $dateTo);

        $salesAgent = $app->getUserStateFromRequest($this->context . '.filter.sales_agent', 'filter_sales_agent', '', 'string');
        $this->setState('filter.sales_agent', $salesAgent);

        $docNumber = $app->getUserStateFromRequest($this->context . '.filter.doc_number', 'filter_doc_number', '', 'string');
        $this->setState('filter.doc_number', $docNumber);

        $state = $app->input->get('filter_state', null, 'string');
        if ($state !== null && $state !== '') {
            $state = (int) $state;
            $this->setState('filter.state', $state);
        } else {
            $state = $app->getUserStateFromRequest($this->context . '.filter.state', 'filter_state', 1, 'int');
            $this->setState('filter.state', $state);
        }

        $estado = $app->getUserStateFromRequest($this->context . '.filter.estado', 'filter_estado', '', 'string');
        $this->setState('filter.estado', $estado);
    }

    /**
     * Build an SQL query to load the list data.
     *
     * @return  \Joomla\Database\DatabaseQuery
     *
     * @since   1.0.0
     */
    protected function getListQuery()
    {
        $db = $this->getDatabase();
        $query = $db->getQuery(true);

        $clientCol = 'o.' . $this->getOrdenesClientColumn();

        $selectCols = [
            'pp.id',
            'pp.order_id',
            'pp.payment_type',
            'pp.bank',
            'pp.document_number',
            'pp.payment_amount',
            'pp.created',
            'pp.created_by',
            'pp.file_path',
            $clientCol . ' AS client_name',
            'o.sales_agent',
            'o.orden_de_trabajo',
            'o.order_number',
            'creator.name AS created_by_name',
            'pp.modified',
            'pp.modified_by',
            'deleter.name AS modified_by_name'
        ];
        $ppCols = $db->getTableColumns('#__ordenproduccion_payment_proofs', false);
        $ppCols = is_array($ppCols) ? array_change_key_case($ppCols, CASE_LOWER) : [];
        if (isset($ppCols['verification_status'])) {
            $selectCols[] = 'pp.verification_status';
        }
        $query->select($selectCols)
            ->from($db->quoteName('#__ordenproduccion_payment_proofs', 'pp'))
            ->leftJoin(
                $db->quoteName('#__users', 'creator') . ' ON creator.id = pp.created_by'
            )
            ->leftJoin(
                $db->quoteName('#__users', 'deleter') . ' ON deleter.id = pp.modified_by'
            );

        if ($this->hasPaymentOrdersTable()) {
            $subQuery = $db->getQuery(true)
                ->select('po.payment_proof_id, MIN(po.order_id) AS first_order_id')
                ->from($db->quoteName('#__ordenproduccion_payment_orders', 'po'))
                ->group('po.payment_proof_id');

            $query->leftJoin(
                '(' . (string) $subQuery . ') AS first_po ON first_po.payment_proof_id = pp.id'
            )
                ->leftJoin(
                    $db->quoteName('#__ordenproduccion_ordenes', 'o') .
                    ' ON o.id = COALESCE(pp.order_id, first_po.first_order_id)'
                );
        } else {
            $query->leftJoin(
                $db->quoteName('#__ordenproduccion_ordenes', 'o') .
                ' ON o.id = pp.order_id'
            );
        }

        $stateFilter = (int) $this->getState('filter.state', 1);
        $query->where($db->quoteName('pp.state') . ' = ' . $stateFilter);

        // Administracion: all comprobantes. Ventas / Produccion: only orders where sales_agent matches user
        $salesAgentFilter = AccessHelper::getSalesAgentFilterForPaymentProofs();
        if ($salesAgentFilter !== null) {
            $query->where($db->quoteName('o.sales_agent') . ' = ' . $db->quote($salesAgentFilter));
        }

        // Filter by client name
        $client = $this->getState('filter.client');
        if (!empty($client)) {
            $search = $db->quote('%' . $db->escape($client, true) . '%');
            $query->where('(' . $clientCol . ' LIKE ' . $search . ')');
        }

        // Filter by date range (payment created date)
        $dateFrom = $this->getState('filter.date_from');
        if (!empty($dateFrom)) {
            $query->where($db->quoteName('pp.created') . ' >= ' . $db->quote($dateFrom . ' 00:00:00'));
        }

        $dateTo = $this->getState('filter.date_to');
        if (!empty($dateTo)) {
            $query->where($db->quoteName('pp.created') . ' <= ' . $db->quote($dateTo . ' 23:59:59'));
        }

        // Filter by sales agent
        $salesAgent = $this->getState('filter.sales_agent');
        if (!empty($salesAgent)) {
            $query->where($db->quoteName('o.sales_agent') . ' = ' . $db->quote($salesAgent));
        }

        // Filter by verification status (Estado: Ingresado / Verificado) when column exists
        $estado = $this->getState('filter.estado');
        if (isset($ppCols['verification_status']) && $estado !== '') {
            if ($estado === 'verificado') {
                $query->where($db->quoteName('pp.verification_status') . ' = ' . $db->quote('verificado'));
            } elseif ($estado === 'ingresado') {
                $query->where(
                    '(' . $db->quoteName('pp.verification_status') . ' IS NULL OR ' .
                    $db->quoteName('pp.verification_status') . ' = ' . $db->quote('') . ' OR ' .
                    $db->quoteName('pp.verification_status') . ' = ' . $db->quote('ingresado') . ')'
                );
            }
        }

        // Filter by document number — searches both the proof header and any line
        $docNumber = $this->getState('filter.doc_number');
        if (!empty($docNumber)) {
            $docSearch = $db->quote('%' . $db->escape(trim($docNumber), true) . '%');
            if ($this->hasPaymentProofLinesTable()) {
                // LEFT JOIN lines so we can match on any line's document_number
                $query->leftJoin(
                    $db->quoteName('#__ordenproduccion_payment_proof_lines', 'ppl') .
                    ' ON ppl.' . $db->quoteName('payment_proof_id') . ' = pp.' . $db->quoteName('id')
                );
                $query->where(
                    '(pp.' . $db->quoteName('document_number') . ' LIKE ' . $docSearch .
                    ' OR ppl.' . $db->quoteName('document_number') . ' LIKE ' . $docSearch . ')'
                );
                // Avoid duplicate rows when multiple lines match
                $query->group('pp.id');
            } else {
                $query->where('pp.' . $db->quoteName('document_number') . ' LIKE ' . $docSearch);
            }
        }

        $orderCol = $this->state->get('list.ordering', 'pp.created');
        $orderDirn = $this->state->get('list.direction', 'desc');

        if ($orderCol && $orderDirn) {
            $query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));
        }

        return $query;
    }

    /**
     * Get distinct sales agents for filter dropdown
     *
     * @return  array
     *
     * @since   1.0.0
     */
    public function getSalesAgentOptions()
    {
        $db = $this->getDatabase();
        $query = $db->getQuery(true)
            ->select('DISTINCT o.' . $db->quoteName('sales_agent'))
            ->from($db->quoteName('#__ordenproduccion_payment_proofs', 'pp'))
            ->leftJoin(
                $db->quoteName('#__ordenproduccion_ordenes', 'o') .
                ' ON o.id = pp.order_id'
            )
            ->where('pp.' . $db->quoteName('state') . ' = ' . (int) $this->getState('filter.state', 1))
            ->where('o.' . $db->quoteName('sales_agent') . ' IS NOT NULL')
            ->where('o.' . $db->quoteName('sales_agent') . ' != ' . $db->quote(''))
            ->where('o.' . $db->quoteName('sales_agent') . ' != ' . $db->quote(' '))
            ->order('o.' . $db->quoteName('sales_agent') . ' ASC');

        $salesAgentFilter = AccessHelper::getSalesAgentFilterForPaymentProofs();
        if ($salesAgentFilter !== null) {
            $query->where('o.' . $db->quoteName('sales_agent') . ' = ' . $db->quote($salesAgentFilter));
        }

        $db->setQuery($query);
        $agents = $db->loadColumn() ?: [];

        $key = 'COM_ORDENPRODUCCION_PAYMENTS_SELECT_SALES_AGENT';
        $label = \Joomla\CMS\Language\Text::_($key);
        $options = ['' => ($label !== $key ? $label : 'Todos los agentes')];
        foreach ($agents as $agent) {
            $options[$agent] = $agent;
        }

        return $options;
    }

    /**
     * Get the client name column for ordenes (supports both client_name and nombre_del_cliente)
     *
     * @return  string  Column name: 'client_name' or 'nombre_del_cliente'
     *
     * @since   1.0.0
     */
    protected function getOrdenesClientColumn()
    {
        try {
            $db = $this->getDatabase();
            $prefix = $db->getPrefix();
            $tableName = $prefix . 'ordenproduccion_ordenes';
            $db->setQuery(
                "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS " .
                "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = " . $db->quote($tableName) . " " .
                "AND COLUMN_NAME IN ('client_name', 'nombre_del_cliente')"
            );
            $cols = $db->loadColumn() ?: [];
            if (in_array('client_name', $cols)) {
                return 'client_name';
            }
            if (in_array('nombre_del_cliente', $cols)) {
                return 'nombre_del_cliente';
            }
        } catch (\Throwable $e) {
            // Fallback
        }
        return 'client_name';
    }

    /**
     * Get full payment details for delete preview and PDF (proof, lines, orders).
     *
     * @param   int  $paymentId  Payment proof ID
     *
     * @return  object|null  { proof, lines, orders } or null if not found/access denied
     *
     * @since   1.0.0
     */
    public function getPaymentDetailsForDelete($paymentId)
    {
        $paymentId = (int) $paymentId;
        if ($paymentId <= 0) {
            return null;
        }

        $db = $this->getDatabase();

        $clientCol = 'o.' . $this->getOrdenesClientColumn();
        $query = $db->getQuery(true)
            ->select([
                'pp.id', 'pp.order_id', 'pp.payment_type', 'pp.bank', 'pp.document_number',
                'pp.payment_amount', 'pp.created', 'pp.created_by', 'pp.file_path',
                $clientCol . ' AS client_name',
                'o.sales_agent', 'o.orden_de_trabajo', 'o.order_number',
                'creator.name AS created_by_name'
            ])
            ->from($db->quoteName('#__ordenproduccion_payment_proofs', 'pp'))
            ->leftJoin(
                $db->quoteName('#__users', 'creator') . ' ON creator.id = pp.created_by'
            );

        if ($this->hasPaymentOrdersTable()) {
            $subQuery = $db->getQuery(true)
                ->select('po.payment_proof_id, MIN(po.order_id) AS first_order_id')
                ->from($db->quoteName('#__ordenproduccion_payment_orders', 'po'))
                ->group('po.payment_proof_id');
            $query->leftJoin('(' . (string) $subQuery . ') AS first_po ON first_po.payment_proof_id = pp.id')
                ->leftJoin(
                    $db->quoteName('#__ordenproduccion_ordenes', 'o') .
                    ' ON o.id = COALESCE(pp.order_id, first_po.first_order_id)'
                );
        } else {
            $query->leftJoin(
                $db->quoteName('#__ordenproduccion_ordenes', 'o') . ' ON o.id = pp.order_id'
            );
        }

        $query->where('pp.id = ' . $paymentId)->where('pp.state = 1');

        $salesAgentFilter = AccessHelper::getSalesAgentFilterForPaymentProofs();
        if ($salesAgentFilter !== null) {
            $query->where($db->quoteName('o.sales_agent') . ' = ' . $db->quote($salesAgentFilter));
        }

        $db->setQuery($query);
        $proof = $db->loadObject();
        if (!$proof) {
            return null;
        }

        $lines = $this->getPaymentLinesForProof($paymentId);
        $orders = $this->getOrdersForProof($paymentId);

        return (object) ['proof' => $proof, 'lines' => $lines, 'orders' => $orders];
    }

    /**
     * Get payment lines (from payment_proof_lines or legacy single from proof)
     */
    protected function getPaymentLinesForProof($paymentId)
    {
        $db = $this->getDatabase();
        if ($this->hasPaymentProofLinesTable()) {
            $db->setQuery(
                $db->getQuery(true)
                    ->select('*')
                    ->from($db->quoteName('#__ordenproduccion_payment_proof_lines'))
                    ->where($db->quoteName('payment_proof_id') . ' = ' . (int) $paymentId)
                    ->order($db->quoteName('ordering') . ' ASC, id ASC')
            );
            return $db->loadObjectList() ?: [];
        }
        $db->setQuery(
            $db->getQuery(true)
                ->select('id, payment_type, bank, document_number, payment_amount AS amount')
                ->from($db->quoteName('#__ordenproduccion_payment_proofs'))
                ->where($db->quoteName('id') . ' = ' . (int) $paymentId)
        );
        $row = $db->loadObject();
        return $row ? [$row] : [];
    }

    /**
     * Get orders linked to this payment proof
     */
    protected function getOrdersForProof($paymentId)
    {
        if (!$this->hasPaymentOrdersTable()) {
            return [];
        }
        $db = $this->getDatabase();
        $clientCol = 'o.' . $this->getOrdenesClientColumn();
        $query = $db->getQuery(true)
            ->select([
                'po.order_id', 'po.amount_applied',
                'COALESCE(o.order_number, o.orden_de_trabajo) AS order_number',
                $clientCol . ' AS client_name'
            ])
            ->from($db->quoteName('#__ordenproduccion_payment_orders', 'po'))
            ->innerJoin(
                $db->quoteName('#__ordenproduccion_ordenes', 'o') . ' ON o.id = po.order_id'
            )
            ->where('po.payment_proof_id = ' . (int) $paymentId)
            ->where('o.state = 1');
        $db->setQuery($query);
        return $db->loadObjectList() ?: [];
    }

    protected function hasPaymentProofLinesTable()
    {
        try {
            $db = $this->getDatabase();
            $tables = $db->getTableList();
            $prefix = $db->getPrefix();
            $name = $prefix . 'ordenproduccion_payment_proof_lines';
            foreach ($tables as $t) {
                if (strcasecmp($t, $name) === 0) {
                    return true;
                }
            }
        } catch (\Throwable $e) {
        }
        return false;
    }

    /**
     * Delete a payment proof and its associated data, then refresh client balances.
     *
     * @param   int  $paymentId  Payment proof ID
     *
     * @return  bool  True on success
     *
     * @since   1.0.0
     */
    public function deletePayment($paymentId)
    {
        $paymentId = (int) $paymentId;
        if ($paymentId <= 0) {
            $this->setError('Invalid payment ID');
            return false;
        }

        $db = $this->getDatabase();

        // Verify payment exists and user has access (sales agent filter)
        $salesAgentFilter = AccessHelper::getSalesAgentFilterForPaymentProofs();
        if ($salesAgentFilter !== null) {
            $checkQuery = $db->getQuery(true)
                ->select('1')
                ->from($db->quoteName('#__ordenproduccion_payment_proofs', 'pp'));
            if ($this->hasPaymentOrdersTable()) {
                $subQuery = $db->getQuery(true)
                    ->select('po.payment_proof_id, MIN(po.order_id) AS first_order_id')
                    ->from($db->quoteName('#__ordenproduccion_payment_orders', 'po'))
                    ->group('po.payment_proof_id');
                $checkQuery->leftJoin('(' . (string) $subQuery . ') AS first_po ON first_po.payment_proof_id = pp.id')
                    ->leftJoin(
                        $db->quoteName('#__ordenproduccion_ordenes', 'o') .
                        ' ON o.id = COALESCE(pp.order_id, first_po.first_order_id)'
                    );
            } else {
                $checkQuery->leftJoin(
                    $db->quoteName('#__ordenproduccion_ordenes', 'o') . ' ON o.id = pp.order_id'
                );
            }
            $checkQuery->where('pp.id = ' . $paymentId)
                ->where('pp.state = 1')
                ->where('o.sales_agent = ' . $db->quote($salesAgentFilter));
            $db->setQuery($checkQuery);
            if (!$db->loadResult()) {
                $this->setError('Payment not found or access denied');
                return false;
            }
        }

        try {
            $db->transactionStart();

            // Collect ALL file paths to delete from disk (legacy column + payment_proof_files rows)
            $filesToDelete = [];

            $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('file_path'))
                    ->from($db->quoteName('#__ordenproduccion_payment_proofs'))
                    ->where($db->quoteName('id') . ' = ' . $paymentId)
            );
            $legacyFilePath = $db->loadResult();
            if (!empty($legacyFilePath)) {
                $filesToDelete[] = $legacyFilePath;
            }

            // Collect and clean up additional files (3.65.0+)
            if ($this->hasPaymentProofFilesTable()) {
                $db->setQuery(
                    $db->getQuery(true)
                        ->select($db->quoteName('file_path'))
                        ->from($db->quoteName('#__ordenproduccion_payment_proof_files'))
                        ->where($db->quoteName('payment_proof_id') . ' = ' . $paymentId)
                        ->where($db->quoteName('state') . ' = 1')
                );
                $extraPaths = $db->loadColumn();
                foreach ($extraPaths as $ep) {
                    if (!empty($ep)) {
                        $filesToDelete[] = $ep;
                    }
                }
                $db->setQuery(
                    $db->getQuery(true)
                        ->delete($db->quoteName('#__ordenproduccion_payment_proof_files'))
                        ->where($db->quoteName('payment_proof_id') . ' = ' . $paymentId)
                );
                $db->execute();
            }

            // Clean up payment lines (3.64.0+)
            if ($this->hasPaymentProofLinesTable()) {
                $db->setQuery(
                    $db->getQuery(true)
                        ->delete($db->quoteName('#__ordenproduccion_payment_proof_lines'))
                        ->where($db->quoteName('payment_proof_id') . ' = ' . $paymentId)
                );
                $db->execute();
            }

            // Clean up order junction rows (3.54.0+)
            if ($this->hasPaymentOrdersTable()) {
                $db->setQuery(
                    $db->getQuery(true)
                        ->delete($db->quoteName('#__ordenproduccion_payment_orders'))
                        ->where($db->quoteName('payment_proof_id') . ' = ' . $paymentId)
                );
                $db->execute();
            }

            // Soft-delete the proof record itself
            $db->setQuery(
                $db->getQuery(true)
                    ->update($db->quoteName('#__ordenproduccion_payment_proofs'))
                    ->set($db->quoteName('state') . ' = 0')
                    ->set($db->quoteName('modified') . ' = ' . $db->quote(Factory::getDate()->toSql()))
                    ->set($db->quoteName('modified_by') . ' = ' . (int) Factory::getUser()->id)
                    ->where($db->quoteName('id') . ' = ' . $paymentId)
            );
            $db->execute();

            $db->transactionCommit();

            // Delete physical files from disk after the transaction commits
            foreach ($filesToDelete as $fp) {
                if (strpos($fp, '..') !== false) {
                    continue;
                }
                $fullPath = JPATH_ROOT . '/' . ltrim($fp, '/');
                if (is_file($fullPath)) {
                    @unlink($fullPath);
                }
            }

            $adminModel = Factory::getApplication()->bootComponent('com_ordenproduccion')
                ->getMVCFactory()->createModel('Administracion', 'Site', ['ignore_request' => true]);
            if ($adminModel && method_exists($adminModel, 'refreshClientBalances')) {
                $adminModel->refreshClientBalances();
            }

            return true;
        } catch (\Exception $e) {
            if ($db->transactionDepth()) {
                $db->transactionRollback();
            }
            $this->setError($e->getMessage());
            return false;
        }
    }

    /**
     * Check if payment_orders junction table exists (3.54.0+ schema)
     *
     * @return  boolean
     *
     * @since   1.0.0
     */
    protected function hasPaymentOrdersTable()
    {
        try {
            $db = $this->getDatabase();
            $tables = $db->getTableList();
            $prefix = $db->getPrefix();
            $tableName = $prefix . 'ordenproduccion_payment_orders';
            foreach ($tables as $t) {
                if (strcasecmp($t, $tableName) === 0) {
                    return true;
                }
            }
            return false;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Check if payment_proof_files table exists (3.65.0+ schema)
     *
     * @return  boolean
     */
    protected function hasPaymentProofFilesTable(): bool
    {
        try {
            $db     = $this->getDatabase();
            $tables = $db->getTableList();
            $target = $db->getPrefix() . 'ordenproduccion_payment_proof_files';
            foreach ($tables as $t) {
                if (strcasecmp($t, $target) === 0) {
                    return true;
                }
            }
            return false;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Whether mismatch note tracking columns exist (3.82.0+).
     *
     * @return  bool
     */
    public function hasMismatchTrackingSchema(): bool
    {
        return $this->hasMismatchNoteColumns();
    }

    /**
     * Payment proofs table has mismatch note columns (3.82.0+).
     *
     * @return  bool
     */
    protected function hasMismatchNoteColumns(): bool
    {
        try {
            $db   = $this->getDatabase();
            $cols = $db->getTableColumns('#__ordenproduccion_payment_proofs', false);
            $cols = \is_array($cols) ? array_change_key_case($cols, CASE_LOWER) : [];
            $hasNote = isset($cols['mismatch_note']);
            $hasDiff = isset($cols['mismatch_difference']);

            return $hasNote || $hasDiff;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Allowed values for mismatch ticket status (helpdesk-style workflow).
     *
     * @return  string[]
     */
    public static function getMismatchTicketStatusAllowlist(): array
    {
        return ['nuevo', 'esperando_respuesta', 'resuelto'];
    }

    /**
     * Build base query for payment proofs that have a mismatch note or stored difference.
     *
     * @param   int|null  $restrictProofId           When set, restrict to this payment proof id (access rules still apply).
     * @param   bool      $applySalesAgentFilter     When false, omit sales-agent scoping (for permission checks without a logged-in user).
     *
     * @return  \Joomla\Database\DatabaseQuery|null
     */
    protected function buildMismatchNotesBaseQuery(?int $restrictProofId = null, bool $applySalesAgentFilter = true)
    {
        if (!$this->hasMismatchNoteColumns()) {
            return null;
        }

        $db        = $this->getDatabase();
        $clientCol = 'o.' . $this->getOrdenesClientColumn();
        $ppCols    = $db->getTableColumns('#__ordenproduccion_payment_proofs', false);
        $ppCols    = \is_array($ppCols) ? array_change_key_case($ppCols, CASE_LOWER) : [];

        $parts = [];
        if (isset($ppCols['mismatch_note'])) {
            $parts[] = '(' . $db->quoteName('pp.mismatch_note') . ' IS NOT NULL AND LENGTH(TRIM(' .
                $db->quoteName('pp.mismatch_note') . ')) > 0)';
        }
        if (isset($ppCols['mismatch_difference'])) {
            $parts[] = '(' . $db->quoteName('pp.mismatch_difference') . ' IS NOT NULL AND LENGTH(TRIM(' .
                $db->quoteName('pp.mismatch_difference') . ')) > 0)';
        }
        if ($parts === []) {
            return null;
        }

        $selectCols = [
            'pp.id',
            'pp.payment_type',
            'pp.document_number',
            'pp.payment_amount',
            'pp.created',
            'pp.created_by',
            $clientCol . ' AS client_name',
            'o.sales_agent',
            'o.orden_de_trabajo',
            'o.order_number',
            'creator.name AS created_by_name',
        ];
        if (isset($ppCols['mismatch_note'])) {
            $selectCols[] = 'pp.mismatch_note';
        } else {
            $selectCols[] = $db->quote('') . ' AS mismatch_note';
        }
        if (isset($ppCols['mismatch_difference'])) {
            $selectCols[] = 'pp.mismatch_difference';
        } else {
            $selectCols[] = $db->quote('') . ' AS mismatch_difference';
        }
        if (isset($ppCols['mismatch_ticket_status'])) {
            $selectCols[] = 'COALESCE(NULLIF(TRIM(' . $db->quoteName('pp.mismatch_ticket_status') . '), ' .
                $db->quote('') . '), ' . $db->quote('nuevo') . ') AS mismatch_ticket_status';
        } else {
            $selectCols[] = $db->quote('nuevo') . ' AS mismatch_ticket_status';
        }

        if ($this->hasPaymentOrdersTable()) {
            $selectCols = array_merge(
                ['COALESCE(pp.order_id, first_po.first_order_id) AS order_id'],
                $selectCols
            );
        } else {
            $selectCols = array_merge(['pp.order_id'], $selectCols);
        }

        $query = $db->getQuery(true)
            ->select($selectCols)
            ->from($db->quoteName('#__ordenproduccion_payment_proofs', 'pp'))
            ->leftJoin(
                $db->quoteName('#__users', 'creator') . ' ON creator.id = pp.created_by'
            );

        if ($this->hasPaymentOrdersTable()) {
            $subQuery = $db->getQuery(true)
                ->select('po.payment_proof_id, MIN(po.order_id) AS first_order_id')
                ->from($db->quoteName('#__ordenproduccion_payment_orders', 'po'))
                ->group('po.payment_proof_id');

            $query->leftJoin(
                '(' . (string) $subQuery . ') AS first_po ON first_po.payment_proof_id = pp.id'
            )
                ->leftJoin(
                    $db->quoteName('#__ordenproduccion_ordenes', 'o') .
                    ' ON o.id = COALESCE(pp.order_id, first_po.first_order_id)'
                );
        } else {
            $query->leftJoin(
                $db->quoteName('#__ordenproduccion_ordenes', 'o') .
                ' ON o.id = pp.order_id'
            );
        }

        $stateFilter = (int) $this->getState('filter.state', 1);
        $query->where($db->quoteName('pp.state') . ' = ' . $stateFilter)
            ->where('(' . implode(' OR ', $parts) . ')');

        if ($applySalesAgentFilter) {
            $salesAgentFilter = AccessHelper::getSalesAgentFilterForPaymentProofs();
            if ($salesAgentFilter !== null) {
                $query->where($db->quoteName('o.sales_agent') . ' = ' . $db->quote($salesAgentFilter));
            }
        }

        if ($restrictProofId !== null && $restrictProofId > 0) {
            $query->where($db->quoteName('pp.id') . ' = ' . (int) $restrictProofId);
        }

        return $query;
    }

    /**
     * Single mismatch ticket row if current user may see it (same rules as list).
     *
     * @param   int  $proofId  Payment proof id
     *
     * @return  object|null
     */
    public function loadMismatchTicketContext(int $proofId): ?object
    {
        $query = $this->buildMismatchNotesBaseQuery($proofId);
        if ($query === null) {
            return null;
        }

        $db = $this->getDatabase();
        $db->setQuery($query, 0, 1);

        $row = $db->loadObject();

        return $row ?: null;
    }

    /**
     * Whether the current user may view or update this mismatch ticket.
     */
    public function userCanAccessMismatchTicket(int $proofId): bool
    {
        return $this->loadMismatchTicketContext($proofId) !== null;
    }

    /**
     * Mismatch ticket row without sales-agent scoping (for permission checks when no user session).
     *
     * @param   int  $proofId  Payment proof id
     *
     * @return  object|null
     *
     * @since   3.109.22
     */
    public function loadMismatchTicketContextUnscoped(int $proofId): ?object
    {
        $query = $this->buildMismatchNotesBaseQuery($proofId, false);
        if ($query === null) {
            return null;
        }

        $db = $this->getDatabase();
        $db->setQuery($query, 0, 1);

        $row = $db->loadObject();

        return $row ?: null;
    }

    /**
     * Whether this Joomla user may post mismatch ticket comments (Administración / Admon / super user, or sales_agent on linked order).
     *
     * @param   int  $proofId  Payment proof id
     * @param   int  $userId   Joomla user id
     *
     * @return  bool
     *
     * @since   3.109.22
     */
    public function canUserCommentOnMismatchTicket(int $proofId, int $userId): bool
    {
        $proofId = (int) $proofId;
        $userId  = (int) $userId;
        if ($proofId < 1 || $userId < 1 || !$this->hasMismatchTicketCommentsTable()) {
            return false;
        }

        $ctx = $this->loadMismatchTicketContextUnscoped($proofId);
        if ($ctx === null) {
            return false;
        }

        try {
            $user = Factory::getContainer()->get(UserFactoryInterface::class)->loadUserById($userId);
        } catch (\Throwable $e) {
            return false;
        }

        if ($user->guest || (int) $user->id !== $userId) {
            return false;
        }

        if ($user->authorise('core.admin')) {
            return true;
        }

        if (AccessHelper::isUserInAdministracionOrAdmonGroupById($userId)) {
            return true;
        }

        $agent = trim((string) ($ctx->sales_agent ?? ''));

        return $agent !== '' && $agent === trim($user->name);
    }

    /**
     * Append a comment as a specific Joomla user (e.g. Telegram webhook). Validates with canUserCommentOnMismatchTicket.
     *
     * @param   int     $proofId                        Payment proof id
     * @param   string  $body                           Comment text
     * @param   int     $createdByUserId                Joomla user id stored as created_by
     * @param   bool    $notifyMismatchCommentTelegram  When true, queue Telegram DMs to other stakeholders (site UI). Set false for comments ingested from the Telegram webhook so the same text is not pushed back to chats.
     * @param   string  $commentSource                  `site` (browser) or `telegram` (webhook); stored when `source` column exists (3.109.46+).
     *
     * @return  bool
     *
     * @since   3.109.22
     */
    public function addMismatchTicketCommentAsUser(int $proofId, string $body, int $createdByUserId, bool $notifyMismatchCommentTelegram = true, string $commentSource = 'site'): bool
    {
        if (!$this->hasMismatchTicketCommentsTable() || !$this->canUserCommentOnMismatchTicket($proofId, $createdByUserId)) {
            $this->setError('Access denied or comments table missing');

            return false;
        }

        $body = trim(strip_tags($body));
        if ($body === '') {
            $this->setError('Comment is empty');

            return false;
        }
        if (strlen($body) > 8000) {
            $this->setError('Comment too long');

            return false;
        }

        $commentSource = \in_array($commentSource, ['site', 'telegram'], true) ? $commentSource : 'site';

        $db   = $this->getDatabase();
        $date = Factory::getDate()->toSql();

        $columns = ['payment_proof_id', 'body', 'created', 'created_by'];
        $values  = [
            (int) $proofId,
            $db->quote($body),
            $db->quote($date),
            (int) $createdByUserId,
        ];
        if ($this->hasMismatchTicketCommentSourceColumn()) {
            $columns[] = 'source';
            $values[]  = $db->quote($commentSource);
        }

        $query = $db->getQuery(true)
            ->insert($db->quoteName('#__ordenproduccion_payment_mismatch_ticket_comments'))
            ->columns(array_map([$db, 'quoteName'], $columns))
            ->values(implode(',', $values));

        $db->setQuery($query);

        try {
            $db->execute();
        } catch (\Throwable $e) {
            $this->setError($e->getMessage());

            return false;
        }

        if ($notifyMismatchCommentTelegram) {
            try {
                TelegramNotificationHelper::notifyMismatchTicketCommentAdded($proofId, $body, $createdByUserId);
            } catch (\Throwable $e) {
            }
        }

        return true;
    }

    /**
     * Comments table for mismatch ticket thread (3.101.15+).
     */
    public function hasMismatchTicketCommentsTable(): bool
    {
        try {
            $db     = $this->getDatabase();
            $tables = $db->getTableList();
            $target = $db->getPrefix() . 'ordenproduccion_payment_mismatch_ticket_comments';
            foreach ($tables as $t) {
                if (strcasecmp($t, $target) === 0) {
                    return true;
                }
            }
        } catch (\Throwable $e) {
        }

        return false;
    }

    /**
     * Whether mismatch comment rows have a `source` column (site|telegram). Version 3.109.46+.
     *
     * @return  bool
     *
     * @since   3.109.46
     */
    protected function hasMismatchTicketCommentSourceColumn(): bool
    {
        static $cached;

        if ($cached !== null) {
            return $cached;
        }

        $cached = false;
        if (!$this->hasMismatchTicketCommentsTable()) {
            return $cached;
        }

        try {
            $db   = $this->getDatabase();
            $cols = $db->getTableColumns('#__ordenproduccion_payment_mismatch_ticket_comments', false);
            $cols = \is_array($cols) ? array_change_key_case($cols, CASE_LOWER) : [];
            $cached = isset($cols['source']);
        } catch (\Throwable $e) {
        }

        return $cached;
    }

    /**
     * Whether payment_proofs has mismatch_ticket_status column.
     */
    public function hasMismatchTicketStatusColumn(): bool
    {
        try {
            $db   = $this->getDatabase();
            $cols = $db->getTableColumns('#__ordenproduccion_payment_proofs', false);
            $cols = \is_array($cols) ? array_change_key_case($cols, CASE_LOWER) : [];

            return isset($cols['mismatch_ticket_status']);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * @return  array<int, object>
     */
    public function getMismatchTicketComments(int $proofId): array
    {
        if (!$this->hasMismatchTicketCommentsTable() || $proofId <= 0) {
            return [];
        }

        $db    = $this->getDatabase();
        $sel   = [
            $db->quoteName('c.id'),
            $db->quoteName('c.body'),
            $db->quoteName('c.created'),
            $db->quoteName('c.created_by'),
            $db->quoteName('u.name', 'user_name'),
        ];
        if ($this->hasMismatchTicketCommentSourceColumn()) {
            $sel[] = $db->quoteName('c.source');
        }

        $query = $db->getQuery(true)
            ->select($sel)
            ->from($db->quoteName('#__ordenproduccion_payment_mismatch_ticket_comments', 'c'))
            ->leftJoin($db->quoteName('#__users', 'u') . ' ON u.id = c.created_by')
            ->where($db->quoteName('c.payment_proof_id') . ' = ' . (int) $proofId)
            ->order($db->quoteName('c.created') . ' ASC,' . $db->quoteName('c.id') . ' ASC');

        $db->setQuery($query);

        $rows = $db->loadObjectList() ?: [];
        foreach ($rows as $row) {
            if (!$this->hasMismatchTicketCommentSourceColumn()) {
                $row->source = 'site';
            } else {
                $s = strtolower(trim((string) ($row->source ?? '')));
                $row->source = ($s === 'telegram') ? 'telegram' : 'site';
            }
        }

        return $rows;
    }

    /**
     * Append a comment to the ticket thread.
     */
    public function addMismatchTicketComment(int $proofId, string $body): bool
    {
        if (!$this->hasMismatchTicketCommentsTable() || !$this->userCanAccessMismatchTicket($proofId)) {
            $this->setError('Access denied or comments table missing');

            return false;
        }

        $body = trim(strip_tags($body));
        if ($body === '') {
            $this->setError('Comment is empty');

            return false;
        }
        if (strlen($body) > 8000) {
            $this->setError('Comment too long');

            return false;
        }

        $db   = $this->getDatabase();
        $date = Factory::getDate()->toSql();
        $uid  = (int) Factory::getUser()->id;

        $columns = ['payment_proof_id', 'body', 'created', 'created_by'];
        $values  = [
            (int) $proofId,
            $db->quote($body),
            $db->quote($date),
            (int) $uid,
        ];
        if ($this->hasMismatchTicketCommentSourceColumn()) {
            $columns[] = 'source';
            $values[]  = $db->quote('site');
        }

        $query = $db->getQuery(true)
            ->insert($db->quoteName('#__ordenproduccion_payment_mismatch_ticket_comments'))
            ->columns(array_map([$db, 'quoteName'], $columns))
            ->values(implode(',', $values));

        $db->setQuery($query);

        try {
            $db->execute();
        } catch (\Throwable $e) {
            $this->setError($e->getMessage());

            return false;
        }

        try {
            TelegramNotificationHelper::notifyMismatchTicketCommentAdded($proofId, $body, $uid);
        } catch (\Throwable $e) {
        }

        return true;
    }

    /**
     * Set ticket status (nuevo | esperando_respuesta | resuelto).
     */
    public function setMismatchTicketStatus(int $proofId, string $status): bool
    {
        $status = strtolower(trim($status));
        if (!\in_array($status, self::getMismatchTicketStatusAllowlist(), true)) {
            $this->setError('Invalid status');

            return false;
        }

        if (!$this->hasMismatchTicketStatusColumn() || !$this->userCanAccessMismatchTicket($proofId)) {
            $this->setError('Access denied or status column missing');

            return false;
        }

        if (!AccessHelper::isInAdministracionOrAdmonGroup() && !AccessHelper::isSuperUser()) {
            $this->setError(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_STATUS_FORBIDDEN'));

            return false;
        }

        $db  = $this->getDatabase();
        $ppC = $db->getTableColumns('#__ordenproduccion_payment_proofs', false);
        $ppC = \is_array($ppC) ? array_change_key_case($ppC, CASE_LOWER) : [];

        $query = $db->getQuery(true)
            ->update($db->quoteName('#__ordenproduccion_payment_proofs'))
            ->set($db->quoteName('mismatch_ticket_status') . ' = ' . $db->quote($status));
        if (isset($ppC['modified'])) {
            $query->set($db->quoteName('modified') . ' = ' . $db->quote(Factory::getDate()->toSql()));
        }
        if (isset($ppC['modified_by'])) {
            $query->set($db->quoteName('modified_by') . ' = ' . (int) Factory::getUser()->id);
        }
        $query->where($db->quoteName('id') . ' = ' . (int) $proofId);

        $db->setQuery($query);

        try {
            $db->execute();
        } catch (\Throwable $e) {
            $this->setError($e->getMessage());

            return false;
        }

        return true;
    }

    /**
     * Count payment proofs with mismatch note / difference (same access rules as list).
     *
     * @return  int
     */
    public function getMismatchNotesTotal(): int
    {
        $query = $this->buildMismatchNotesBaseQuery();
        if ($query === null) {
            return 0;
        }

        $db = $this->getDatabase();
        $query->clear('select')->clear('order')
            ->select('COUNT(' . $db->quoteName('pp.id') . ')');

        $db->setQuery($query);

        return (int) $db->loadResult();
    }

    /**
     * List rows for mismatch notes tracking (newest first).
     *
     * @param   int  $start  Offset
     * @param   int  $limit  Page size
     *
     * @return  array<int, object>
     */
    public function getMismatchNotesItems(int $start, int $limit): array
    {
        $query = $this->buildMismatchNotesBaseQuery();
        if ($query === null) {
            return [];
        }

        $db = $this->getDatabase();
        $query->order($db->quoteName('pp.created') . ' DESC');

        $db->setQuery($query, $start, $limit);

        return $db->loadObjectList() ?: [];
    }
}
