<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_ordenproduccion
 *
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Grimpsa\Component\Ordenproduccion\Site\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ItemModel;
use Joomla\CMS\Language\Text;
use Grimpsa\Component\Ordenproduccion\Site\Helper\AccessHelper;
use Grimpsa\Component\Ordenproduccion\Site\Helper\OrdenPrecotSectionsHelper;

/**
 * Orden model for com_ordenproduccion
 *
 * @since  1.0.0
 */
class OrdenModel extends ItemModel
{
    /**
     * Single-orden presentation layout: standard OT (production fields + acabados).
     *
     * @since  3.116.3
     */
    public const ORDEN_VIEW_LAYOUT_STANDARD = 1;

    /**
     * PRE cotización document_mode proveedor_externo: compact view (strip color/material rows + acabados).
     *
     * @since  3.116.3
     */
    public const ORDEN_VIEW_LAYOUT_VENDOR_PRE = 2;

    /**
     * Internal PRE cotización path (wizard / quotation + PRE): línea-accurate orden + PDF slices.
     * Used when the orden row carries a quotation wizard snapshot and PRE document_mode is not proveedor externo.
     *
     * @since  3.115.18
     */
    public const ORDEN_VIEW_LAYOUT_PLIEGO_ELEMENTOS = 3;

    /**
     * The prefix to use with controller messages.
     *
     * @var    string
     * @since  1.0.0
     */
    protected $text_prefix = 'COM_ORDENPRODUCCION_ORDEN';

    /**
     * The type alias for this content type.
     *
     * @var    string
     * @since  1.0.0
     */
    public $typeAlias = 'com_ordenproduccion.orden';

    /**
     * Method to get the record form.
     *
     * @param   array    $data      Data for the form.
     * @param   boolean  $loadData  True if the form should load its own data (default case), false if not.
     *
     * @return  \Joomla\CMS\Form\Form|boolean  A Form object on success, false on failure
     *
     * @since   1.0.0
     */
    public function getForm($data = [], $loadData = true)
    {
        // Get the form.
        $form = $this->loadForm('com_ordenproduccion.orden', 'orden', ['control' => 'jform', 'load_data' => $loadData]);

        if (empty($form)) {
            return false;
        }

        return $form;
    }

    /**
     * Method to populate the state.
     *
     * @param   string  $ordering   An optional ordering field.
     * @param   string  $direction  An optional direction (asc|desc).
     *
     * @return  void
     *
     * @since   1.0.0
     */
    protected function populateState($ordering = null, $direction = null)
    {
        $app = Factory::getApplication();
        
        // Get the ID from the input
        $id = $app->input->getInt('id', 0);
        $this->setState($this->getName() . '.id', $id);
        
        // Load the parameters
        $params = $app->getParams('com_ordenproduccion');
        $this->setState('params', $params);
    }

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return  mixed  The data for the form.
     *
     * @since   1.0.0
     */
    protected function loadFormData()
    {
        // Check the session for previously entered form data.
        $app = Factory::getApplication();
        $data = $app->getUserState('com_ordenproduccion.edit.orden.data', []);

        if (empty($data)) {
            $data = $this->getItem();
        }

        $this->preprocessData('com_ordenproduccion.orden', $data);

        return $data;
    }

    /**
     * Method to get a single record.
     *
     * @param   integer  $pk  The id of the primary key.
     *
     * @return  mixed  Object on success, false on failure.
     *
     * @since   1.0.0
     */
    public function getItem($pk = null)
    {
        // Try to get ID from parameter first, then from state, then from input
        if (!empty($pk)) {
            $pk = (int) $pk;
        } else {
            $pk = (int) $this->getState($this->getName() . '.id');
            if (empty($pk)) {
                // Try to get from input as fallback
                $app = Factory::getApplication();
                $pk = (int) $app->input->get('id', 0);
            }
        }

        if ($this->_item === null) {
            $this->_item = [];
        }

        if (!isset($this->_item[$pk])) {
            try {
                $db = $this->getDatabase();
                
                // Simple query - just get the work order data
                $query = $db->getQuery(true)
                    ->select('a.*')
                    ->from($db->quoteName('#__ordenproduccion_ordenes', 'a'))
                    ->where($db->quoteName('a.id') . ' = ' . (int) $pk)
                    ->where($db->quoteName('a.state') . ' = 1');

                $db->setQuery($query);
                $data = $db->loadObject();

                if (empty($data)) {
                    // Record not found or not published
                    throw new \Exception(Text::sprintf('COM_ORDENPRODUCCION_ERROR_ORDEN_NOT_FOUND', $pk), 404);
                }

                $this->normalizeOrdenRecordForView($data);
                $this->normalizeLegacyQuotationWorkDescriptionBlob($data);
                $this->enrichOrdenViewPresentationType($data);
                $this->enrichOrdenPrecotHeaderMedidasForView($data);
                $this->enrichOrdenPrecotHeaderCantidadTotalForView($data);

                // Check user access to this order
                $this->checkUserAccess($data);

                // Apply field visibility based on user groups
                $this->applyFieldVisibility($data);

                $this->_item[$pk] = $data;

            } catch (\Exception $e) {
                if ($e->getCode() == 404) {
                    // Need to go through the error handler to allow Redirect to work.
                    throw $e;
                } else {
                    $this->setError($e->getMessage());
                    $this->_item[$pk] = false;
                }
            }
        }

        return $this->_item[$pk];
    }

    /**
     * Map legacy Spanish column names onto the English properties the site templates expect.
     * Webhook-created rows typically already use English names (invoice_value, client_name, …).
     *
     * @param   object  $data  Row from #__ordenproduccion_ordenes
     *
     * @return  void
     *
     * @since   3.101.2
     */
    protected function normalizeOrdenRecordForView($data): void
    {
        if (!\is_object($data)) {
            return;
        }

        $pick = static function ($obj, string $primary, string $fallback): void {
            $p = $obj->$primary ?? null;
            if ($p !== null && $p !== '') {
                return;
            }
            if (property_exists($obj, $fallback)) {
                $f = $obj->$fallback;
                if ($f !== null && $f !== '') {
                    $obj->$primary = $f;
                }
            }
        };

        $pick($data, 'invoice_value', 'valor_a_facturar');
        $pick($data, 'sales_agent', 'agente_de_ventas');
        $pick($data, 'client_name', 'nombre_del_cliente');
        $pick($data, 'work_description', 'descripcion_de_trabajo');
        $pick($data, 'print_color', 'color_de_impresion');
        $pick($data, 'dimensions', 'medidas_en_pulgadas');
        $pick($data, 'delivery_date', 'fecha_de_entrega');
        $pick($data, 'request_date', 'fecha_de_solicitud');
        $pick($data, 'order_number', 'orden_de_trabajo');

        $qf = property_exists($data, 'quotation_files') ? $data->quotation_files : null;
        $adj = property_exists($data, 'adjuntar_cotizacion') ? $data->adjuntar_cotizacion : null;
        if (($qf === null || $qf === '') && $adj !== null && $adj !== '') {
            $data->quotation_files = $adj;
        }

        self::copySpanishFinishFieldsToEnglishAliases($data);
    }

    /**
     * Spanish-only orden rows use corte/laminado/detalles_de_* columns; vistas y PDF esperan cutting/laminating/*_details.
     *
     * @since   3.115.63
     */
    public static function copySpanishFinishFieldsToEnglishAliases(object $data): void
    {
        $pairs = [
            ['cutting', 'corte'],
            ['cutting_details', 'detalles_de_corte'],
            ['blocking', 'bloqueado'],
            ['blocking_details', 'detalles_de_bloqueado'],
            ['folding', 'doblado'],
            ['folding_details', 'detalles_de_doblado'],
            ['laminating', 'laminado'],
            ['laminating_details', 'detalles_de_laminado'],
            ['spine', 'lomo'],
            ['spine_details', 'detalles_de_lomo'],
            ['gluing', 'pegado'],
            ['gluing_details', 'detalles_de_pegado'],
            ['numbering', 'numerado'],
            ['numbering_details', 'detalles_de_numerado'],
            ['sizing', 'sizado'],
            ['sizing_details', 'detalles_de_sizado'],
            ['stapling', 'engrapado'],
            ['stapling_details', 'detalles_de_engrapado'],
            ['die_cutting', 'troquel'],
            ['die_cutting_details', 'detalles_de_troquel'],
            ['varnish', 'barniz'],
            ['varnish_details', 'descripcion_de_barniz'],
            ['white_print', 'impresion_en_blanco'],
            ['white_print_details', 'descripcion_de_acabado_en_blanco'],
            ['trimming', 'despuntados'],
            ['trimming_details', 'descripcion_de_despuntados'],
            ['eyelets', 'ojetes'],
            ['perforation', 'perforado'],
            ['perforation_details', 'descripcion_de_perforado'],
        ];

        foreach ($pairs as [$en, $es]) {
            if (!property_exists($data, $es)) {
                continue;
            }

            $esValTrim = trim((string) ($data->$es ?? ''));
            $enBlank   = !property_exists($data, $en)
                || $data->$en === null
                || trim((string) ($data->$en ?? '')) === '';

            if ($enBlank && $esValTrim !== '') {
                $data->$en = $data->$es;
            }
        }
    }

    /**
     * Sets orden_view_layout_type on the row: {@see ORDEN_VIEW_LAYOUT_STANDARD},
     * {@see ORDEN_VIEW_LAYOUT_VENDOR_PRE}, or {@see ORDEN_VIEW_LAYOUT_PLIEGO_ELEMENTOS}.
     * Populates orden_view_precot_line_sections for layout 3 when applicable.
     *
     * @param   object  $data  Row reference
     *
     * @return  void
     *
     * @since   3.116.3
     */
    protected function enrichOrdenViewPresentationType(object $data): void
    {
        $layout = self::ORDEN_VIEW_LAYOUT_STANDARD;
        $preId  = isset($data->pre_cotizacion_id) ? (int) $data->pre_cotizacion_id : 0;

        $data->orden_view_precot_line_sections = [];

        if (!empty($data->orden_source_json)) {
            $decoded = json_decode((string) $data->orden_source_json, true);
            if (\is_array($decoded) && isset($decoded['document_mode'])
                && (string) $decoded['document_mode'] === 'proveedor_externo') {
                $layout = self::ORDEN_VIEW_LAYOUT_VENDOR_PRE;
            }
        }

        $preDm = null;

        if ($layout === self::ORDEN_VIEW_LAYOUT_STANDARD && $preId > 0) {
            try {
                $db = $this->getDatabase();
                $q  = $db->getQuery(true)
                    ->select($db->quoteName('document_mode'))
                    ->from($db->quoteName('#__ordenproduccion_pre_cotizacion'))
                    ->where($db->quoteName('id') . ' = ' . $preId);

                $db->setQuery($q);
                $preDm = $db->loadResult();

                if ($preDm !== null && (string) $preDm === 'proveedor_externo') {
                    $layout = self::ORDEN_VIEW_LAYOUT_VENDOR_PRE;
                }
            } catch (\Throwable $e) {
                $preDm = null;
            }
        }

        if ($layout === self::ORDEN_VIEW_LAYOUT_STANDARD && !empty($data->work_description)) {
            if (preg_match('/Modo\s+documento\s*:\s*proveedor_externo/ui', (string) $data->work_description)) {
                $layout = self::ORDEN_VIEW_LAYOUT_VENDOR_PRE;
            }
        }

        if ($layout === self::ORDEN_VIEW_LAYOUT_STANDARD
            && $preId > 0
            && $this->ordenRowHasCotizacionPreWizardLinkage($data)
            && $preDm !== null
            && strtolower(trim((string) $preDm)) !== 'proveedor_externo') {
            $layout = self::ORDEN_VIEW_LAYOUT_PLIEGO_ELEMENTOS;
        }

        $data->orden_view_layout_type = $layout;

        if ($layout === self::ORDEN_VIEW_LAYOUT_PLIEGO_ELEMENTOS && $preId > 0) {
            try {
                $data->orden_view_precot_line_sections = OrdenPrecotSectionsHelper::buildSections($preId);
            } catch (\Throwable $e) {
                $data->orden_view_precot_line_sections = [];
            }
        }
    }

    /**
     * True when OT was produced from cotización wizard (PRE line on confirmed quote): orden_source_json has
     * source quotation_pre_cotizacion plus quotation/PRE ids. Legacy webhook/manual OT without this blob
     * keeps layout 1.
     *
     * @since  3.115.64
     */
    protected function ordenRowHasCotizacionPreWizardLinkage(object $data): bool
    {
        if (empty($data->orden_source_json)) {
            return false;
        }

        $d = json_decode((string) $data->orden_source_json, true);
        if (!\is_array($d)) {
            return false;
        }

        if (($d['source'] ?? '') !== 'quotation_pre_cotizacion') {
            return false;
        }

        if ((int) ($d['quotation_id'] ?? 0) < 1) {
            return false;
        }

        $jsonPre = (int) ($d['pre_cotizacion_id'] ?? 0);
        $rowPre  = isset($data->pre_cotizacion_id) ? (int) $data->pre_cotizacion_id : 0;

        if ($jsonPre > 0 && $rowPre > 0 && $jsonPre !== $rowPre) {
            return false;
        }

        return $jsonPre > 0 || $rowPre > 0;
    }

    /**
     * Cabecera PRE "Medidas" for display in orden Información del trabajo (prefer over empty dimensions).
     *
     * @param   object  $data  Row from #__ordenproduccion_ordenes (mutated)
     *
     * @return  void
     *
     * @since   3.115.20
     */
    protected function enrichOrdenPrecotHeaderMedidasForView(object $data): void
    {
        $data->orden_view_pre_medidas = '';

        $preId = isset($data->pre_cotizacion_id) ? (int) $data->pre_cotizacion_id : 0;
        if ($preId < 1) {
            return;
        }

        try {
            $db = $this->getDatabase();
            $q  = $db->getQuery(true)
                ->select($db->quoteName('medidas'))
                ->from($db->quoteName('#__ordenproduccion_pre_cotizacion'))
                ->where($db->quoteName('id') . ' = ' . $preId);

            $db->setQuery($q);
            $raw = $db->loadResult();
            if ($raw !== null && trim((string) $raw) !== '') {
                $data->orden_view_pre_medidas = trim((string) $raw);

                return;
            }
        } catch (\Throwable $e) {
            // Column/table missing or other DB failure: fallback below.
        }

        if (!empty($data->orden_source_json)) {
            $decoded = json_decode((string) $data->orden_source_json, true);
            if (\is_array($decoded) && isset($decoded['pre_medidas'])) {
                $m = trim((string) $decoded['pre_medidas']);
                if ($m !== '') {
                    $data->orden_view_pre_medidas = $m;
                }
            }
        }
    }

    /**
     * Cabecera PRE "Cantidad total" for display in orden Información del trabajo (alongside medidas).
     *
     * @param   object  $data  Row from #__ordenproduccion_ordenes (mutated)
     *
     * @return  void
     *
     * @since   3.117.5
     */
    protected function enrichOrdenPrecotHeaderCantidadTotalForView(object $data): void
    {
        $data->orden_view_pre_cantidad_total = '';

        $preId = isset($data->pre_cotizacion_id) ? (int) $data->pre_cotizacion_id : 0;
        if ($preId < 1) {
            return;
        }

        try {
            $db = $this->getDatabase();
            $q  = $db->getQuery(true)
                ->select($db->quoteName('cantidad_total'))
                ->from($db->quoteName('#__ordenproduccion_pre_cotizacion'))
                ->where($db->quoteName('id') . ' = ' . $preId);

            $db->setQuery($q);
            $raw = $db->loadResult();
            if ($raw !== null && trim((string) $raw) !== '') {
                $data->orden_view_pre_cantidad_total = trim((string) $raw);

                return;
            }
        } catch (\Throwable $e) {
        }

        if (!empty($data->orden_source_json)) {
            $decoded = json_decode((string) $data->orden_source_json, true);
            if (\is_array($decoded) && isset($decoded['pre_cantidad_total'])) {
                $m = trim((string) $decoded['pre_cantidad_total']);
                if ($m !== '') {
                    $data->orden_view_pre_cantidad_total = $m;
                }
            }
        }
    }

    /**
     * Populate PRE snapshot header fields (medidas, cantidad total) on a loaded orden row (e.g. PDF data load).
     *
     * @param   object  $data  Row from #__ordenproduccion_ordenes
     *
     * @return  void
     *
     * @since   3.117.5
     */
    public function attachPrecotHeaderFieldsForPdf(object $data): void
    {
        if (!\is_object($data)) {
            return;
        }

        $this->enrichOrdenPrecotHeaderMedidasForView($data);
        $this->enrichOrdenPrecotHeaderCantidadTotalForView($data);
    }

    /**
     * Whether the PRE contains at least one pliego línea and at least one elementos or envío línea (diagnostics / callers).
     *
     * @param   int  $preCotizacionId  Pre-cotización id on the orden
     *
     * @return  bool
     *
     * @since   3.115.18
     */
    protected function precotMixedPliegoWithElementOrEnvio(int $preCotizacionId): bool
    {
        if ($preCotizacionId < 1) {
            return false;
        }

        try {
            $db = $this->getDatabase();
            $q  = $db->getQuery(true)
                ->select($db->quoteName('line_type'))
                ->from($db->quoteName('#__ordenproduccion_pre_cotizacion_line'))
                ->where($db->quoteName('pre_cotizacion_id') . ' = ' . $preCotizacionId);
            $db->setQuery($q);
            $types = $db->loadColumn() ?: [];
        } catch (\Throwable $e) {
            return false;
        }

        $hasPliego = false;
        $hasOther  = false;

        foreach ($types as $t) {
            $lt = strtolower(trim((string) $t));
            if ($lt === '' || $lt === 'pliego') {
                $hasPliego = true;

                continue;
            }

            if ($lt === 'elementos' || $lt === 'envio' || $lt === 'tercerizado') {
                $hasOther = true;
            }
        }

        return $hasPliego && $hasOther;
    }

    /**
     * Older OT rows stored a multi-line work_description (Cotización/PRE metadata + Descripción línea / PRE).
     * For display, reduce to the cotización-line text when that pattern is detected.
     *
     * @param   object  $data  Mutable row from #__ordenproduccion_ordenes
     *
     * @return  void
     *
     * @since   3.116.5
     */
    protected function normalizeLegacyQuotationWorkDescriptionBlob(object $data): void
    {
        $tryExtract = static function (string $blob): ?string {
            $blob = trim($blob);
            if ($blob === '' || strpos($blob, 'Cotización / PRE — línea vendida') !== 0) {
                return null;
            }
            if (preg_match('/^Descripción línea:\s*(.+)$/m', $blob, $m)) {
                return trim($m[1]);
            }

            return null;
        };

        $wd = isset($data->work_description) ? trim((string) $data->work_description) : '';
        $dde = property_exists($data, 'descripcion_de_trabajo')
            ? trim((string) ($data->descripcion_de_trabajo ?? ''))
            : '';

        $clean = $tryExtract($wd);
        if ($clean === null) {
            $clean = $tryExtract($dde);
        }

        if ($clean === null || $clean === '') {
            return;
        }

        $data->work_description = $clean;
        if (property_exists($data, 'descripcion_de_trabajo')
            && ($dde === '' || strpos($dde, 'Cotización / PRE — línea vendida') === 0)) {
            $data->descripcion_de_trabajo = $clean;
        }
    }

    /**
     * Check if user has access to this order
     *
     * @param   object  $data  The order data
     *
     * @return  void
     *
     * @since   1.0.0
     * @throws  \Exception
     */
    protected function checkUserAccess($data)
    {
        // Check if user has any access to orders
        if (!AccessHelper::hasOrderAccess()) {
            throw new \Exception(Text::_('COM_ORDENPRODUCCION_ERROR_ACCESS_DENIED'), 403);
        }

        // Check if user can see all orders or only their own
        if (!AccessHelper::canSeeAllOrders()) {
            // User can only see their own orders
            $user = Factory::getUser();
            $userName = $user->get('name');
            $salesAgent = $data->sales_agent ?? '';
            
            if ($salesAgent !== $userName) {
                throw new \Exception(Text::_('COM_ORDENPRODUCCION_ERROR_ACCESS_DENIED'), 403);
            }
        }
        // Users who can see all orders don't need additional checks
    }

    /**
     * Apply field visibility based on user groups
     *
     * @param   object  $data  The order data
     *
     * @return  void
     *
     * @since   1.0.0
     */
    protected function applyFieldVisibility($data)
    {
        // Check if user can see valor_factura for this specific order
        $canSeeValorFactura = AccessHelper::canSeeValorFactura($data->sales_agent ?? '');
        
        if (!$canSeeValorFactura) {
            unset($data->invoice_value, $data->valor_a_facturar);

            return;
        }

        if ((!isset($data->invoice_value) || $data->invoice_value === null || $data->invoice_value === '')
            && isset($data->valor_a_facturar) && $data->valor_a_facturar !== null && $data->valor_a_facturar !== '') {
            $data->invoice_value = $data->valor_a_facturar;
        }
    }

    /**
     * Map Spanish database fields to English field names for template
     *
     * @param   object  $data  The order data
     *
     * @return  object  Mapped order data
     *
     * @since   1.0.0
     */
    protected function mapDatabaseFields($data)
    {
        // The database already has English field names, so we just need to ensure
        // the template has access to the fields it expects
        
        // Create new object with all original fields
        $mappedData = new \stdClass();
        
        // Copy all original fields first
        foreach ($data as $key => $value) {
            $mappedData->$key = $value;
        }
        
        // The database already has the correct English field names:
        // - order_number, client_name, sales_agent, work_description, etc.
        // So we don't need to map anything, just return the data as-is
        
        return $mappedData;
    }

    /**
     * Get EAV data for the order
     *
     * @param   integer  $orderId  The order ID
     *
     * @return  array  Array of EAV data
     *
     * @since   1.0.0
     */
    protected function getEAVData($orderId)
    {
        try {
            $db = $this->getDatabase();
            
            // First get the order number from the order ID
            $orderQuery = $db->getQuery(true)
                ->select('orden_de_trabajo')
                ->from($db->quoteName('#__ordenproduccion_ordenes'))
                ->where($db->quoteName('id') . ' = ' . (int) $orderId);
            
            $db->setQuery($orderQuery);
            $orderNumber = $db->loadResult();
            
            if (empty($orderNumber)) {
                return [];
            }
            
            // Now get EAV data using the order number
            $query = $db->getQuery(true)
                ->select('tipo_de_campo, valor')
                ->from($db->quoteName('#__ordenproduccion_info'))
                ->where($db->quoteName('numero_de_orden') . ' = ' . $db->quote($orderNumber));

            $db->setQuery($query);
            $results = $db->loadObjectList();

            $eavData = [];
            foreach ($results as $result) {
                $eavData[$result->tipo_de_campo] = $result->valor;
            }

            return $eavData;

        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Get status options
     *
     * @return  array  Array of status options
     *
     * @since   1.0.0
     */
    public function getStatusOptions()
    {
        return [
            'Nueva' => \Joomla\CMS\Language\Text::_('COM_ORDENPRODUCCION_STATUS_NEW'),
            'En Proceso' => \Joomla\CMS\Language\Text::_('COM_ORDENPRODUCCION_STATUS_IN_PROCESS'),
            'Terminada' => \Joomla\CMS\Language\Text::_('COM_ORDENPRODUCCION_STATUS_COMPLETED'),
            'Cerrada' => \Joomla\CMS\Language\Text::_('COM_ORDENPRODUCCION_STATUS_CLOSED')
        ];
    }

    /**
     * Get order type options
     *
     * @return  array  Array of order type options
     *
     * @since   1.0.0
     */
    public function getOrderTypeOptions()
    {
        return [
            'Internal' => 'COM_ORDENPRODUCCION_ORDER_TYPE_INTERNAL',
            'External' => 'COM_ORDENPRODUCCION_ORDER_TYPE_EXTERNAL'
        ];
    }

    /**
     * Get shipping status options
     *
     * @return  array  Array of shipping status options
     *
     * @since   1.0.0
     */
    public function getShippingStatusOptions()
    {
        return [
            'Pending' => 'COM_ORDENPRODUCCION_SHIPPING_STATUS_PENDING',
            'Shipped' => 'COM_ORDENPRODUCCION_SHIPPING_STATUS_SHIPPED',
            'Delivered' => 'COM_ORDENPRODUCCION_SHIPPING_STATUS_DELIVERED'
        ];
    }

    /**
     * Get historial (log) entries for a work order
     *
     * @param   integer  $orderId  The work order ID
     *
     * @return  array  Array of historial entries
     *
     * @since   3.8.0
     */
    public function getHistorialEntries($orderId = null)
    {
        if (empty($orderId)) {
            $orderId = (int) $this->getState($this->getName() . '.id');
            if (empty($orderId)) {
                $app = Factory::getApplication();
                $orderId = (int) $app->input->get('id', 0);
            }
        }

        if (empty($orderId)) {
            return [];
        }

        try {
            $db = $this->getDatabase();
            
            // Check if historial table exists
            $columns = $db->getTableColumns('#__ordenproduccion_historial');
            if (empty($columns)) {
                // Table doesn't exist yet
                return [];
            }
            
            $query = $db->getQuery(true)
                ->select([
                    'h.id',
                    'h.order_id',
                    'h.event_type',
                    'h.event_title',
                    'h.event_description',
                    'h.metadata',
                    'h.created',
                    'h.created_by',
                    'u.name AS created_by_name',
                    'u.username AS created_by_username'
                ])
                ->from($db->quoteName('#__ordenproduccion_historial', 'h'))
                ->leftJoin(
                    $db->quoteName('#__users', 'u') . ' ON ' .
                    $db->quoteName('u.id') . ' = ' . $db->quoteName('h.created_by')
                )
                ->where($db->quoteName('h.order_id') . ' = ' . (int) $orderId)
                ->where($db->quoteName('h.state') . ' = 1')
                ->order($db->quoteName('h.created') . ' ASC');

            $db->setQuery($query);
            $entries = $db->loadObjectList();

            return $entries ?: [];

        } catch (\Exception $e) {
            // Table doesn't exist or other error - return empty array
            return [];
        }
    }

    /**
     * Set a work order's status to "Anulada".
     *
     * Called by the webhook endpoint. Validates the order exists and is not
     * already anulada, updates the status column and writes a historial entry.
     *
     * @param   string  $orderNumber  The ORD-XXXXXX identifier
     * @param   string  $requestedBy  Full name of the requester (for the log)
     * @param   int     $requesterId  User ID of the requester
     * @param   string  $description  Optional description / reason
     *
     * @return  array{success: bool, message: string, order_id: int|null}
     *
     * @since   3.71.0
     */
    public function anularOrden(string $orderNumber, string $requestedBy = '', int $requesterId = 0, string $description = ''): array
    {
        $db = $this->getDatabase();

        // --- 1. Find the order ---
        try {
            $query = $db->getQuery(true)
                ->select(['id', 'status', 'client_name', 'order_number'])
                ->from($db->quoteName('#__ordenproduccion_ordenes'))
                ->where($db->quoteName('order_number') . ' = ' . $db->quote(trim($orderNumber)))
                ->where($db->quoteName('state') . ' = 1');
            $db->setQuery($query);
            $order = $db->loadObject();
        } catch (\Exception $e) {
            return ['success' => false, 'message' => 'Error al buscar la orden: ' . $e->getMessage(), 'order_id' => null];
        }

        if (!$order) {
            return ['success' => false, 'message' => 'Orden no encontrada: ' . $orderNumber, 'order_id' => null];
        }

        // --- 2. Guard: already anulada ---
        if (strtolower((string) $order->status) === 'anulada') {
            return ['success' => false, 'message' => 'La orden ' . $orderNumber . ' ya fue anulada anteriormente.', 'order_id' => (int) $order->id];
        }

        // --- 3. Update status ---
        try {
            $updateQuery = $db->getQuery(true)
                ->update($db->quoteName('#__ordenproduccion_ordenes'))
                ->set($db->quoteName('status') . ' = ' . $db->quote('Anulada'))
                ->set($db->quoteName('modified') . ' = ' . $db->quote(Factory::getDate()->toSql()))
                ->set($db->quoteName('modified_by') . ' = ' . $requesterId)
                ->where($db->quoteName('id') . ' = ' . (int) $order->id);
            $db->setQuery($updateQuery);
            $db->execute();
        } catch (\Exception $e) {
            return ['success' => false, 'message' => 'Error al actualizar la orden: ' . $e->getMessage(), 'order_id' => (int) $order->id];
        }

        // --- 4. Historial entry ---
        try {
            $historialColumns = $db->getTableColumns('#__ordenproduccion_historial');
            if (!empty($historialColumns)) {
                $reason = $description ?: 'Anulación procesada vía sistema de aprobación.';
                $meta   = json_encode(['requester' => $requestedBy, 'requester_id' => $requesterId, 'reason' => $reason], JSON_UNESCAPED_UNICODE);
                $histQuery = $db->getQuery(true)
                    ->insert($db->quoteName('#__ordenproduccion_historial'))
                    ->set($db->quoteName('order_id') . ' = ' . (int) $order->id)
                    ->set($db->quoteName('event_type') . ' = ' . $db->quote('anulacion'))
                    ->set($db->quoteName('event_title') . ' = ' . $db->quote('Orden Anulada'))
                    ->set($db->quoteName('event_description') . ' = ' . $db->quote('La orden fue marcada como Anulada. Solicitante: ' . $requestedBy))
                    ->set($db->quoteName('metadata') . ' = ' . $db->quote($meta))
                    ->set($db->quoteName('created_by') . ' = ' . $requesterId)
                    ->set($db->quoteName('state') . ' = 1');
                $db->setQuery($histQuery);
                $db->execute();
            }
        } catch (\Exception $e) {
            // Historial failure is non-fatal
        }

        // --- 5. Refresh client balances asynchronously (best-effort) ---
        try {
            $adminModel = Factory::getApplication()->bootComponent('com_ordenproduccion')
                ->getMVCFactory()
                ->createModel('Administracion', 'Administrator');
            if ($adminModel && method_exists($adminModel, 'refreshClientBalances')) {
                $adminModel->refreshClientBalances();
            }
        } catch (\Exception $e) {
            // Non-fatal
        }

        return [
            'success'  => true,
            'message'  => 'La orden ' . $orderNumber . ' fue marcada como Anulada exitosamente.',
            'order_id' => (int) $order->id,
        ];
    }

}
