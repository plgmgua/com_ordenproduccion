<?php
/**
 * Payment Proof Template for Com Orden Produccion
 * 
 * @package     Grimpsa\Component\Ordenproduccion\Site\View\PaymentProof
 * @subpackage  PaymentProof
 * @since       3.1.3
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Grimpsa\Component\Ordenproduccion\Site\Helper\AsistenciaHelper;

/** @var \Grimpsa\Component\Ordenproduccion\Site\View\Paymentproof\HtmlView $this */

$order = $this->order;
$orderId = $this->orderId;
$existingPayments = $this->existingPayments ?? [];

$bankAccountOptionsForPayment = [];
$defaultBankAccountIdForPayment = 0;
$bankAccountNameByIdForLabel = [];
try {
    $baMdl = Factory::getApplication()->bootComponent('com_ordenproduccion')->getMVCFactory()->createModel('Bankaccount', 'Site', ['ignore_request' => true]);
    if ($baMdl !== null && method_exists($baMdl, 'getBankAccounts')) {
        foreach ($baMdl->getBankAccounts() as $acc) {
            $bid = (int) ($acc->id ?? 0);
            if ($bid < 1) {
                continue;
            }
            $bankAccountNameByIdForLabel[$bid] = trim((string) ($acc->name ?? ''));
            if ((int) ($acc->state ?? 0) !== 1) {
                continue;
            }
            $bankAccountOptionsForPayment[$bid] = $bankAccountNameByIdForLabel[$bid];
            if (!empty($acc->is_default)) {
                $defaultBankAccountIdForPayment = $bid;
            }
        }
    }
} catch (\Throwable $e) {
    // Optional until DB migration
}

$bankAccountColumnLabel = AsistenciaHelper::safeText(
    'COM_ORDENPRODUCCION_PAYMENT_LINE_BANK_ACCOUNT',
    'Destination account',
    'Cuenta Destino'
);

if (empty($order)) :
    $labelTitle = $this->labelPaymentProofTitle ?? 'Registro de Comprobante de Pago';
    $labelBack  = $this->labelBackToOrder ?? 'Volver a Control de Pagos';
    $labelNoOrder = Text::_('COM_ORDENPRODUCCION_PAYMENT_PROOF_NO_ORDER_SELECTED');
    if (strpos($labelNoOrder, 'COM_ORDENPRODUCCION_') === 0) {
        $labelNoOrder = 'Seleccione una o más órdenes de trabajo para registrar un comprobante de pago. Solo se muestran órdenes a las que tiene acceso (Agente de Ventas: sus órdenes; Administración: todas).';
    }
    $backUrl = Route::_('index.php?option=com_ordenproduccion&view=payments');
    // Bank and payment type options for the form
    $bankOptions = [];
    $defaultBankCode = null;
    try {
        $db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
        $q = $db->getQuery(true)->select('id, code, name, name_es, name_en, is_default')
            ->from($db->quoteName('#__ordenproduccion_banks'))->where($db->quoteName('state') . ' = 1')
            ->order($db->quoteName('ordering') . ' ASC, id ASC');
        $db->setQuery($q);
        $banks = $db->loadObjectList() ?: [];
        $lang = Factory::getLanguage();
        $isSpanish = (strpos($lang->getTag(), 'es') === 0);
        foreach ($banks as $b) {
            if (empty($b->code)) continue;
            $displayName = ($isSpanish && !empty($b->name_es)) ? trim($b->name_es) : (trim($b->name_en ?? $b->name ?? '') ?: $b->code);
            $bankOptions[$b->code] = $displayName;
            if (!empty($b->is_default)) $defaultBankCode = $b->code;
        }
    } catch (\Exception $e) { /* ignore */ }
    $paymentTypeOptions = $this->getPaymentTypeOptions();
    $availableOrders = json_decode($this->availableOrdersJson ?? '[]', true);
?>
<div class="com-ordenproduccion-paymentproof">
    <div class="container">
        <div class="row mb-2">
            <div class="col-12 d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h1 class="page-title h4 mb-0"><?php echo htmlspecialchars($labelTitle); ?></h1>
                <a href="<?php echo htmlspecialchars($backUrl); ?>" class="btn btn-secondary btn-sm">
                    <i class="fas fa-arrow-left"></i> <?php echo htmlspecialchars($labelBack); ?>
                </a>
            </div>
        </div>
        <p class="text-muted mb-3"><?php echo htmlspecialchars($labelNoOrder); ?></p>

        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><i class="fas fa-credit-card"></i> <?php echo htmlspecialchars(AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_PROOF_REGISTRATION', 'Registro de Comprobante de Pago', 'Registro de Comprobante de Pago')); ?></h5>
            </div>
            <div class="card-body">
                <form action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=paymentproof.register'); ?>" method="post" enctype="multipart/form-data" class="form-validate" id="payment-proof-form">
                    <input type="hidden" name="order_id" value="0">
                    <?php echo HTMLHelper::_('form.token'); ?>

                    <div class="row mb-3">
                        <div class="col-12">
                            <label><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_METHOD_LINES', 'Payment method lines', 'Métodos de pago'); ?></label>
                            <small class="form-text text-muted d-block mb-2"><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_METHOD_LINES_HELP', 'Add one or more lines.', 'Agregue una o más líneas.'); ?></small>
                            <div class="table-responsive">
                                <table class="table table-bordered" id="payment-lines-table">
                                    <thead>
                                        <tr>
                                            <th><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_TYPE', 'Payment Type', 'Tipo de pago'); ?></th>
                                            <th><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_LINE_BANK_ORIGIN', 'Origin bank', 'Banco Origen'); ?></th>
                                            <th><?php echo htmlspecialchars($bankAccountColumnLabel); ?></th>
                                            <th style="width: 140px;">Doc. No</th>
                                            <th style="width: 130px;"><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_DOCUMENT_DATE', 'Document Date', 'Fecha del Documento'); ?></th>
                                            <th style="width: 110px;"><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_AMOUNT', 'Amount', 'Monto'); ?></th>
                                            <th class="text-center" style="width: 52px;" title="<?php echo htmlspecialchars(AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_LINE_ATTACHMENTS', 'Attachments for this line', 'Archivos por línea')); ?>"><i class="fas fa-paperclip" aria-hidden="true"></i></th>
                                            <th style="width: 40px;"></th>
                                        </tr>
                                    </thead>
                                    <tbody id="payment-lines-body">
                                        <tr class="payment-line-row">
                                            <td>
                                                <select name="payment_lines[0][payment_type]" class="form-control form-control-sm payment-line-type" required>
                                                    <option value="">Seleccionar</option>
                                                    <?php foreach ($paymentTypeOptions as $val => $txt): ?>
                                                    <option value="<?php echo htmlspecialchars($val); ?>"><?php echo htmlspecialchars($txt); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </td>
                                            <td class="bank-cell">
                                                <select name="payment_lines[0][bank]" class="form-control form-control-sm payment-line-bank">
                                                    <option value=""><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_SELECT_BANK', 'Select bank', 'Seleccionar banco'); ?></option>
                                                    <?php foreach ($bankOptions as $code => $name): ?>
                                                    <option value="<?php echo htmlspecialchars($code); ?>"<?php echo ($defaultBankCode && $code === $defaultBankCode) ? ' selected' : ''; ?>><?php echo htmlspecialchars($name); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </td>
                                            <td class="bank-account-cell">
                                                <select name="payment_lines[0][bank_account_id]" class="form-control form-control-sm payment-line-bank-account" required>
                                                    <option value=""><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_SELECT_BANK_ACCOUNT', 'Select bank account', 'Seleccionar cuenta'); ?></option>
                                                    <?php foreach ($bankAccountOptionsForPayment as $accId => $accName) : ?>
                                                    <option value="<?php echo (int) $accId; ?>"<?php echo ((int) $defaultBankAccountIdForPayment === (int) $accId) ? ' selected' : ''; ?>><?php echo htmlspecialchars($accName); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </td>
                                            <td><input type="text" name="payment_lines[0][document_number]" class="form-control form-control-sm" placeholder="<?php echo htmlspecialchars($this->labelDocumentNumberPlaceholder ?? 'ej. Número de cheque'); ?>" maxlength="255" required></td>
                                            <td><input type="date" name="payment_lines[0][document_date]" class="form-control form-control-sm payment-line-document-date"></td>
                                            <td><input type="number" name="payment_lines[0][amount]" class="form-control form-control-sm payment-line-amount" min="0.01" step="0.01" max="999999.99" placeholder="0.00" required></td>
                                            <td class="text-center align-middle">
                                                <label class="btn btn-sm btn-outline-secondary mb-0 payment-line-clip-label" title="<?php echo htmlspecialchars(AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_LINE_ATTACH_HINT', 'One or more files for this line', 'Uno o más archivos para esta línea')); ?>">
                                                    <i class="fas fa-paperclip" aria-hidden="true"></i>
                                                    <input type="file" name="payment_line_files[0][]" class="d-none payment-line-file-input" accept=".jpg,.jpeg,.png,.pdf" multiple onchange="validateFiles(this)">
                                                </label>
                                            </td>
                                            <td class="text-center"></td>
                                        </tr>
                                    </tbody>
                                    <tfoot>
                                        <tr class="table-info">
                                            <td colspan="5" class="text-end"><strong><?php echo htmlspecialchars($this->labelTotal ?? 'Total'); ?>:</strong></td>
                                            <td><strong id="payment-lines-total">Q. 0.00</strong></td>
                                            <td></td>
                                            <td class="text-end">
                                                <button type="button" class="btn btn-sm btn-success add-payment-line-btn" style="min-width: 38px;" title="<?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_ADD_LINE', 'Add line', 'Agregar línea'); ?>">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="payment_amount" id="payment_amount" value="">
                    <input type="hidden" name="payment_mismatch_note" id="payment_mismatch_note" value="">
                    <input type="hidden" name="payment_mismatch_difference" id="payment_mismatch_difference" value="">

                    <div class="row mb-3">
                        <div class="col-12">
                            <?php if (empty($availableOrders)) : ?>
                            <div class="alert alert-warning"><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_NO_ORDERS_AVAILABLE_FOR_PAYMENT') ?: 'No tiene órdenes disponibles para registrar pago. Solo se muestran órdenes activas (no anuladas) a las que tiene acceso.'); ?></div>
                            <?php endif; ?>
                            <label><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_ORDERS_TO_APPLY_PAYMENT', 'Orders to apply payment', 'Órdenes a aplicar este pago'); ?></label>
                            <div class="table-responsive">
                                <table class="table table-bordered" id="payment-orders-table">
                                    <thead>
                                        <tr>
                                            <th style="width: 50%"><?php echo htmlspecialchars($this->labelOrderNumber ?? 'Orden #'); ?></th>
                                            <th style="width: 35%"><?php echo htmlspecialchars($this->labelValueToApply ?? 'Valor a Aplicar'); ?></th>
                                            <th style="width: 40px;"></th>
                                        </tr>
                                    </thead>
                                    <tbody id="payment-orders-body">
                                        <tr class="payment-order-row" data-row-index="0">
                                            <td>
                                                <input type="hidden" name="payment_orders[0][order_id]" class="order-id-input" value="">
                                                <div class="order-search-wrap position-relative">
                                                    <input type="text" class="form-control order-search-input" placeholder="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_SEARCH_ORDER_PLACEHOLDER') ?: 'Escriba número de orden para buscar...'); ?>" autocomplete="off" required>
                                                    <ul class="order-search-results list-group position-absolute" style="display:none; z-index: 1000; max-height: 200px; overflow-y: auto; min-width: 100%;"></ul>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="input-group">
                                                    <span class="input-group-text">Q.</span>
                                                    <input type="number" name="payment_orders[0][value]" class="form-control payment-value-input" min="0.01" step="0.01" placeholder="0.00" required>
                                                </div>
                                            </td>
                                            <td class="text-center"></td>
                                        </tr>
                                    </tbody>
                                    <tfoot>
                                        <tr class="table-info">
                                            <td class="text-end"><strong><?php echo htmlspecialchars($this->labelTotal ?? 'Total'); ?>:</strong></td>
                                            <td>
                                                <div class="input-group">
                                                    <span class="input-group-text">Q.</span>
                                                    <input type="text" id="payment-total" class="form-control font-weight-bold" value="0.00" readonly>
                                                </div>
                                            </td>
                                            <td class="text-end">
                                                <button type="button" class="btn btn-sm btn-success add-row-btn" title="<?php echo htmlspecialchars($this->labelAddOrder ?? 'Agregar orden'); ?>"><i class="fas fa-plus"></i></button>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <small class="form-text text-muted"><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_ORDERS_TO_APPLY_HELP', 'Add work orders and amount for each', 'Agregue las órdenes y el monto para cada una.'); ?></small>
                        </div>
                    </div>

                    <script type="application/json" id="unpaid-orders-data"><?php echo $this->availableOrdersJson ?? '[]'; ?></script>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?php echo htmlspecialchars($this->labelRegisterPaymentProof ?? 'Registrar Comprobante de Pago'); ?></button>
                        <a href="<?php echo htmlspecialchars($backUrl); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> <?php echo htmlspecialchars($this->labelCancel ?? 'Cancelar'); ?></a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php
    // Inline script: order select sync and totals (same behaviour as paymentproof.js)
    ?>
<style>
.order-search-results { list-style: none; margin: 0; padding: 0; }
.order-search-results .list-group-item { cursor: pointer; }
.order-search-results .list-group-item:hover { background-color: var(--bs-list-group-hover-bg, #e9ecef); }
/* Make action buttons column slim and right-aligned */
#payment-orders-table th:last-child,
#payment-orders-table td:last-child { text-align: right; }
</style>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var tbody = document.getElementById('payment-orders-body');
    if (tbody) {
        tbody.addEventListener('input', function(e) {
            if (e.target.classList.contains('payment-value-input')) {
                var total = 0;
                document.querySelectorAll('#payment-orders-body .payment-value-input').forEach(function(inp) { total += parseFloat(inp.value) || 0; });
                var el = document.getElementById('payment-total');
                if (el) el.value = total.toFixed(2);
            }
        });
    }
    var lineIndex = 1;
    var bankOpts = <?php echo json_encode($bankOptions); ?>;
    var defaultBank = <?php echo json_encode($defaultBankCode ?? ''); ?>;
    var defaultBankAccountId = <?php echo (int) $defaultBankAccountIdForPayment; ?>;
    var typeOpts = <?php echo json_encode(array_keys($paymentTypeOptions)); ?>;
    var typeLabels = <?php echo json_encode($paymentTypeOptions); ?>;
    function toggleBankCell(row) {
        var typeSel = row && row.querySelector('.payment-line-type');
        var bankCell = row && row.querySelector('.bank-cell');
        var accCell = row && row.querySelector('.bank-account-cell');
        var bankSel = row && row.querySelector('.payment-line-bank');
        var accSel = row && row.querySelector('.payment-line-bank-account');
        var isCash = typeSel && typeSel.value === 'efectivo';
        if (bankCell) bankCell.style.visibility = isCash ? 'hidden' : 'visible';
        if (accCell) accCell.style.visibility = isCash ? 'hidden' : 'visible';
        if (bankSel) {
            bankSel.disabled = !!isCash;
            if (isCash) {
                bankSel.value = '';
            } else if (!bankSel.value && defaultBank) {
                bankSel.value = defaultBank;
            }
        }
        if (accSel) {
            accSel.disabled = !!isCash;
            accSel.required = !isCash;
            if (isCash) {
                accSel.value = '';
            } else if (!accSel.value && defaultBankAccountId) {
                accSel.value = String(defaultBankAccountId);
            }
        }
    }
    function updateLinesTotal() {
        var sum = 0;
        document.querySelectorAll('.payment-line-amount').forEach(function(inp) { sum += parseFloat(inp.value) || 0; });
        var el = document.getElementById('payment-lines-total');
        if (el) el.textContent = 'Q. ' + sum.toFixed(2);
        var amt = document.getElementById('payment_amount');
        if (amt) amt.value = sum.toFixed(2);
    }
    document.querySelectorAll('.add-payment-line-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            var tbody = document.getElementById('payment-lines-body');
            var first = tbody && tbody.querySelector('.payment-line-row');
            if (!first) return;
            var clone = first.cloneNode(true);
            clone.classList.remove('payment-line-row');
            var lastTd = clone.querySelector('td:last-child');
            if (lastTd) lastTd.innerHTML = '<button type="button" class="btn btn-sm btn-danger remove-payment-line-btn"><i class="fas fa-minus"></i></button>';
            clone.querySelectorAll('select, input').forEach(function(el) {
                var m = el.name && el.name.match(/payment_lines\[\d+\]\[(\w+)\]/);
                if (m) {
                    el.name = 'payment_lines[' + lineIndex + '][' + m[1] + ']';
                    if (m[1] === 'amount' || m[1] === 'document_number' || m[1] === 'document_date' || m[1] === 'payment_type') el.value = '';
                    if (m[1] === 'bank') el.value = defaultBank || '';
                    if (m[1] === 'bank_account_id') el.value = defaultBankAccountId ? String(defaultBankAccountId) : '';
                }
                if (el.classList && el.classList.contains('payment-line-file-input')) {
                    el.name = 'payment_line_files[' + lineIndex + '][]';
                    el.value = '';
                }
            });
            tbody.appendChild(clone);
            lineIndex++;
            toggleBankCell(clone);
            clone.querySelector('.payment-line-type').addEventListener('change', function() { toggleBankCell(clone); });
            clone.querySelector('.payment-line-amount').addEventListener('input', updateLinesTotal);
            var rm = clone.querySelector('.remove-payment-line-btn');
            if (rm) rm.addEventListener('click', function() { clone.remove(); updateLinesTotal(); });
            updateLinesTotal();
        });
    });
    document.querySelectorAll('.payment-line-type').forEach(function(el) { el.addEventListener('change', function() { toggleBankCell(el.closest('tr')); }); });
    document.querySelectorAll('.payment-line-amount').forEach(function(el) { el.addEventListener('input', updateLinesTotal); });
    document.querySelectorAll('#payment-lines-body tr').forEach(function(r) { toggleBankCell(r); });
    updateLinesTotal();
});
window.validateFiles = function(input) {
    var allowed = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
    var max = 5 * 1024 * 1024;
    for (var i = 0; i < input.files.length; i++) {
        var file = input.files[i];
        if (allowed.indexOf(file.type) === -1) { alert('Tipo inválido: ' + file.name); input.value = ''; return false; }
        if (file.size > max) { alert('Archivo demasiado grande: ' + file.name); input.value = ''; return false; }
    }
    return true;
};
</script>
<?php
    return;
endif;

$invoiceValue = (float) ($order->invoice_value ?? 0);
$defaultAmount = $invoiceValue > 0 ? number_format($invoiceValue, 2, '.', '') : '';

// Bank options for payment lines (JS will clone from first row)
$bankOptions = [];
$defaultBankCode = null;
try {
    $db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
    $q = $db->getQuery(true)->select('id, code, name, name_es, name_en, is_default')
        ->from($db->quoteName('#__ordenproduccion_banks'))->where($db->quoteName('state') . ' = 1')
        ->order($db->quoteName('ordering') . ' ASC, id ASC');
    $db->setQuery($q);
    $banks = $db->loadObjectList() ?: [];
    $lang = Factory::getLanguage();
    $isSpanish = (strpos($lang->getTag(), 'es') === 0);
    foreach ($banks as $b) {
        if (empty($b->code)) continue;
        $displayName = ($isSpanish && !empty($b->name_es)) ? trim($b->name_es) : (trim($b->name_en ?? $b->name ?? '') ?: $b->code);
        $bankOptions[$b->code] = $displayName;
        if (!empty($b->is_default)) $defaultBankCode = $b->code;
    }
} catch (\Exception $e) { /* ignore */ }
$paymentTypeOptions = $this->getPaymentTypeOptions();
?>

<div class="com-ordenproduccion-paymentproof">
    <div class="container">
        <!-- Page Header -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h1 class="page-title">
                            <?php echo htmlspecialchars($this->labelPaymentProofTitle ?? 'Registro de Comprobante de Pago'); ?>
                        </h1>
                        <p class="text-muted">
                            <?php
                            // Collect all order numbers from all existing payment proofs, plus the current order
                            $allLinkedOrderNums   = [];
                            $allLinkedOrderNumIds = [];
                            if (!empty($existingPayments)) {
                                $proofModelHdr = $this->getModel();
                                foreach ($existingPayments as $ep) {
                                    $epOrders = method_exists($proofModelHdr, 'getOrdersByPaymentProofId') ? $proofModelHdr->getOrdersByPaymentProofId($ep->id ?? 0) : [];
                                    foreach ($epOrders as $epo) {
                                        $oid = (int) ($epo->order_id ?? 0);
                                        if ($oid > 0 && in_array($oid, $allLinkedOrderNumIds, true)) {
                                            continue;
                                        }
                                        $allLinkedOrderNumIds[] = $oid;
                                        $allLinkedOrderNums[]   = $epo->order_number ?? '#' . ($epo->order_id ?? '');
                                    }
                                }
                            }
                            $currentOrderNum = $order->order_number ?? $order->orden_de_trabajo ?? $orderId;
                            if (!in_array($currentOrderNum, $allLinkedOrderNums, true)) {
                                $allLinkedOrderNums[] = $currentOrderNum;
                            }
                            if (count($allLinkedOrderNums) === 1) {
                                $fmt = $this->labelPaymentProofForOrder ?? 'Comprobante de Pago para Orden %s';
                                echo htmlspecialchars(sprintf($fmt, $allLinkedOrderNums[0]));
                            } else {
                                echo htmlspecialchars('Comprobante de Pago — Órdenes: ' . implode(', ', $allLinkedOrderNums));
                            }
                            ?>
                        </p>
                    </div>
                    <div>
                        <a href="<?php echo $this->getBackToOrderRoute(); ?>" 
                           class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i>
                            <?php echo htmlspecialchars($this->labelBackToOrder ?? 'Volver a la Orden'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Existing Payments Info (can add more - many-to-many) -->
        <?php if (!empty($existingPayments)): ?>
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2 py-2">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-history"></i>
                            <?php echo htmlspecialchars($this->labelExistingPayments ?? 'Pagos Existentes para Esta Orden'); ?>
                        </h5>
                        <?php if (!empty($this->mismatchTicketHeaderProofId)) : ?>
                            <button type="button"
                                    class="btn btn-sm btn-primary py-1 px-2 btn-mismatch-ticket flex-shrink-0"
                                    data-proof-id="<?php echo (int) $this->mismatchTicketHeaderProofId; ?>"
                                    title="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_OPEN')); ?>"
                                    aria-label="<?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_OPEN')); ?>">
                                <i class="fas fa-comments" aria-hidden="true"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <p class="small text-muted mb-2"><?php echo htmlspecialchars($this->labelPaymentProofNoEdit ?? 'Los comprobantes guardados no se pueden modificar, solo eliminar (desde Control de Pagos).'); ?></p>
                        <table class="table table-sm payment-proof-list-table">
                            <thead>
                                <tr>
                                    <th><?php echo htmlspecialchars($this->labelPaymentProofId ?? 'ID'); ?></th>
                                    <th><?php echo htmlspecialchars($this->labelDocumentNumberShort ?? 'Doc. No'); ?></th>
                                    <th><?php echo htmlspecialchars($this->labelDocumentDate ?? 'Fecha Doc.'); ?></th>
                                    <th><?php echo htmlspecialchars($this->labelPaymentType ?? 'Tipo de Pago'); ?></th>
                                    <th><?php echo htmlspecialchars($bankAccountColumnLabel); ?></th>
                                    <th><?php echo htmlspecialchars($this->labelPaymentAmount ?? 'Monto del Pago'); ?></th>
                                    <th class="text-nowrap"><?php echo htmlspecialchars($this->labelEstado ?? 'Estado'); ?></th>
                                    <th style="width: 200px;"><?php echo htmlspecialchars(AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_PROOF_FILES_COLUMN', 'Attached files', 'Archivos adjuntos')); ?></th>
                                    <th class="text-center" style="width: 52px;" title="<?php echo htmlspecialchars(AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_LINE_ADD_FILE', 'Add file for this line', 'Adjuntar a esta línea')); ?>"><i class="fas fa-paperclip" aria-hidden="true"></i></th>
                                    <th style="width: 180px;"><?php echo htmlspecialchars($this->labelMismatchNoteActions ?? 'Nota / Acciones'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $proofModel = $this->getModel();
                                $totalMonto = 0.0;
                                foreach ($existingPayments as $proof):
                                    $isMerged = !empty($proof->_merged);
                                    $lines = !$isMerged && method_exists($proofModel, 'getPaymentProofLines') ? $proofModel->getPaymentProofLines($proof->id ?? 0) : [];
                                    if (!empty($lines)):
                                        $groupedLineFiles = method_exists($proofModel, 'groupFilesByPaymentLineForDisplay')
                                            ? $proofModel->groupFilesByPaymentLineForDisplay($proof, $lines)
                                            : [];
                                        $delConfirmMsg = Text::_('COM_ORDENPRODUCCION_PAYMENT_PROOF_DELETE_FILE_CONFIRM');
                                        if (strpos((string) $delConfirmMsg, 'COM_ORDENPRODUCCION') === 0) {
                                            $delConfirmMsg = '¿Eliminar este archivo adjunto?';
                                        }
                                        $proofMonto = 0.0;
                                        $isFirstLine = true;
                                        foreach ($lines as $line):
                                            $proofMonto += (float)($line->amount ?? 0);
                                            $lineId = (int) ($line->id ?? 0);
                                            $cellFiles = $groupedLineFiles[$lineId] ?? [];
                                ?>
                                <tr<?php if ($isFirstLine) { echo ' id="proof-' . (int)($proof->id ?? 0) . '"'; } ?>>
                                    <td><?php echo $isFirstLine ? ('PA-' . str_pad((string)(int)($proof->id ?? 0), 5, '0', STR_PAD_LEFT)) : ''; ?></td>
                                    <td><?php echo htmlspecialchars($line->document_number ?? ''); ?></td>
                                    <td class="text-nowrap"><?php
                                        $docDate = $line->document_date ?? null;
                                        if (!empty($docDate)) {
                                            try { echo htmlspecialchars(Factory::getDate($docDate)->format('d/m/Y')); } catch (\Exception $e) { echo htmlspecialchars($docDate); }
                                        } else { echo '—'; }
                                    ?></td>
                                    <td><?php echo $this->translatePaymentType($line->payment_type ?? ''); ?></td>
                                    <td><?php
                                        $lineBaId = (int) ($line->bank_account_id ?? 0);
                                        echo $lineBaId > 0
                                            ? htmlspecialchars($bankAccountNameByIdForLabel[$lineBaId] ?? '—')
                                            : '—';
                                    ?></td>
                                    <td>Q <?php echo number_format((float)($line->amount ?? 0), 2); ?></td>
                                    <td class="text-nowrap"><?php
                                        if ($isFirstLine) {
                                            $proofStatus = isset($proof->verification_status) ? trim((string)$proof->verification_status) : '';
                                            $isIngresado = ($proofStatus === '' || strtolower($proofStatus) === 'ingresado');
                                            echo $isIngresado ? htmlspecialchars($this->labelIngresado ?? 'Ingresado') : htmlspecialchars($this->labelVerificado ?? 'Verificado');
                                        }
                                    ?></td>
                                    <td><?php
                                        $fileShown = false;
                                        foreach ($cellFiles as $fObj) {
                                            $pf = $this->getPaymentProofFileInfo($fObj);
                                            if ($pf === null) {
                                                continue;
                                            }
                                            $fileShown = true;
                                            $url  = htmlspecialchars($pf['url'], ENT_QUOTES, 'UTF-8');
                                            $type = $pf['type'];
                                            $fid  = (int) ($fObj->id ?? 0);
                                            echo '<span class="payment-proof-attach-cell-item me-1 mb-1 d-inline-block position-relative align-top">';
                                            if ($type === 'image') {
                                                echo '<span class="view-payment-attachment payment-proof-thumb-wrap" role="button" tabindex="0" data-url="' . $url . '" data-type="' . $type . '" title="Ver comprobante"><img src="' . $url . '" alt="" class="payment-proof-thumb"></span>';
                                            } else {
                                                echo '<span class="view-payment-attachment payment-proof-thumb-wrap payment-proof-thumb-pdf" role="button" tabindex="0" data-url="' . $url . '" data-type="' . $type . '" title="Ver comprobante"><i class="fas fa-file-pdf"></i><span class="small d-block">PDF</span></span>';
                                            }
                                            if (!empty($this->canEditNoteOrAssociateOrder)) {
                                                echo '<form method="post" action="' . Route::_('index.php?option=com_ordenproduccion&task=paymentproof.deleteAttachment') . '" class="payment-proof-delete-file-form d-inline" onsubmit="return confirm(' . json_encode($delConfirmMsg) . ');">';
                                                echo HTMLHelper::_('form.token');
                                                echo '<input type="hidden" name="proof_id" value="' . (int)($proof->id ?? 0) . '">';
                                                echo '<input type="hidden" name="order_id" value="' . (int)$orderId . '">';
                                                echo '<input type="hidden" name="file_id" value="' . $fid . '">';
                                                echo '<button type="submit" class="btn btn-sm btn-danger payment-proof-attach-delete p-0" title="' . htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_PROOF_DELETE_FILE')) . '" aria-label="' . htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_PROOF_DELETE_FILE')) . '"><i class="fas fa-times"></i></button>';
                                                echo '</form>';
                                            }
                                            echo '</span>';
                                        }
                                        if (!$fileShown) {
                                            echo '<span class="text-muted">—</span>';
                                        }
                                    ?></td>
                                    <td class="text-center align-middle"><?php
                                        $proofStatusClip = isset($proof->verification_status) ? trim((string)$proof->verification_status) : '';
                                        $isIngresadoClip = ($proofStatusClip === '' || strtolower($proofStatusClip) === 'ingresado');
                                        if ($isIngresadoClip && $lineId > 0) {
                                            echo '<button type="button" class="btn btn-sm btn-outline-secondary payment-proof-action-btn toggle-add-file-form" data-proof-id="' . (int)($proof->id ?? 0) . '" data-line-id="' . $lineId . '" data-line-doc="' . htmlspecialchars((string) ($line->document_number ?? ''), ENT_QUOTES, 'UTF-8') . '" title="' . htmlspecialchars(AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_LINE_ADD_FILE', 'Add file for this line', 'Adjuntar archivo a esta línea')) . '"><i class="fas fa-paperclip"></i></button>';
                                        } else {
                                            echo '<span class="text-muted">—</span>';
                                        }
                                    ?></td>
                                    <td class="align-top"><?php
                                        if ($isFirstLine) {
                                            $pn = trim((string)($proof->mismatch_note ?? ''));
                                            if ($pn !== '') {
                                                echo '<span class="small text-muted d-block" title="' . htmlspecialchars($pn) . '">' . htmlspecialchars(mb_strlen($pn) > 40 ? mb_substr($pn, 0, 37) . '…' : $pn) . '</span>';
                                            }
                                            $proofStatus = isset($proof->verification_status) ? trim((string)$proof->verification_status) : '';
                                            $isIngresado = ($proofStatus === '' || strtolower($proofStatus) === 'ingresado');
                                            echo '<div class="payment-proof-actions-row mt-1">';
                                            if ($isIngresado && !empty($this->canEditNoteOrAssociateOrder)) {
                                                echo '<form action="' . Route::_('index.php?option=com_ordenproduccion&task=paymentproof.markAsVerificado') . '" method="post" class="d-inline">';
                                                echo HTMLHelper::_('form.token');
                                                echo '<input type="hidden" name="proof_id" value="' . (int)($proof->id ?? 0) . '"><input type="hidden" name="order_id" value="' . (int)$orderId . '">';
                                                echo '<button type="submit" class="btn btn-sm btn-success payment-proof-action-btn" title="' . htmlspecialchars($this->labelMarkVerificado ?? 'Marcar como Verificado') . '"><i class="fas fa-check"></i></button>';
                                                echo '</form>';
                                            }
                                            if (!empty($this->canEditNoteOrAssociateOrder)) {
                                                echo '<button type="button" class="btn btn-sm btn-outline-secondary payment-proof-action-btn toggle-edit-note-form" data-proof-id="' . (int)($proof->id ?? 0) . '" title="' . htmlspecialchars($this->labelEditMismatchNote ?? 'Editar nota') . '"><i class="fas fa-edit"></i></button>';
                                                echo '<button type="button" class="btn btn-sm btn-outline-secondary payment-proof-action-btn toggle-add-order-form" data-proof-id="' . (int)($proof->id ?? 0) . '" title="' . htmlspecialchars($this->labelAssociateAnotherOrder ?? 'Asociar otra orden') . '"><i class="fas fa-link"></i></button>';
                                            }
                                            echo '</div>';
                                        }
                                    ?></td>
                                </tr>
                                <?php
                                        $isFirstLine = false;
                                        endforeach;
                                        $totalMonto += $proofMonto;
                                        $proofOrders = method_exists($proofModel, 'getOrdersByPaymentProofId') ? $proofModel->getOrdersByPaymentProofId($proof->id ?? 0) : [];
                                ?>
                                <?php /* Removed duplicate simple "Orden #" list; keep detailed "Información de la Orden" table below. */ ?>
                                <?php
                                    else:
                                        $totalMonto += (float)($proof->payment_amount ?? 0);
                                        $proofOrders = method_exists($proofModel, 'getOrdersByPaymentProofId') ? $proofModel->getOrdersByPaymentProofId($proof->id ?? 0) : [];
                                        $delConfirmMsgLegacy = Text::_('COM_ORDENPRODUCCION_PAYMENT_PROOF_DELETE_FILE_CONFIRM');
                                        if (strpos((string) $delConfirmMsgLegacy, 'COM_ORDENPRODUCCION') === 0) {
                                            $delConfirmMsgLegacy = '¿Eliminar este archivo adjunto?';
                                        }
                                        $proofFilesLegacy = method_exists($proofModel, 'getPaymentProofFiles') ? $proofModel->getPaymentProofFiles($proof) : [];
                                ?>
                                <tr id="proof-<?php echo (int)($proof->id ?? 0); ?>">
                                    <td>PA-<?php echo str_pad((string)(int)($proof->id ?? 0), 5, '0', STR_PAD_LEFT); ?></td>
                                    <td><?php echo htmlspecialchars($proof->document_number ?? ''); ?></td>
                                    <td class="text-nowrap">—</td>
                                    <td><?php echo $this->translatePaymentType($proof->payment_type ?? ''); ?></td>
                                    <td>—</td>
                                    <td>Q <?php echo number_format((float)($proof->payment_amount ?? 0), 2); ?></td>
                                    <td class="text-nowrap"><?php
                                        $proofStatus = isset($proof->verification_status) ? trim((string)$proof->verification_status) : '';
                                        $isIngresado = ($proofStatus === '' || strtolower($proofStatus) === 'ingresado');
                                        echo $isIngresado ? htmlspecialchars($this->labelIngresado ?? 'Ingresado') : htmlspecialchars($this->labelVerificado ?? 'Verificado');
                                    ?></td>
                                    <td><?php
                                        $fileShownLegacy = false;
                                        foreach ($proofFilesLegacy as $fObjLeg) {
                                            $pf2 = $this->getPaymentProofFileInfo($fObjLeg);
                                            if ($pf2 === null) {
                                                continue;
                                            }
                                            $fileShownLegacy = true;
                                            $url2  = htmlspecialchars($pf2['url'], ENT_QUOTES, 'UTF-8');
                                            $type2 = $pf2['type'];
                                            $fidL  = (int) ($fObjLeg->id ?? 0);
                                            echo '<span class="payment-proof-attach-cell-item me-1 mb-1 d-inline-block position-relative align-top">';
                                            if ($type2 === 'image') {
                                                echo '<span class="view-payment-attachment payment-proof-thumb-wrap" role="button" tabindex="0" data-url="' . $url2 . '" data-type="' . $type2 . '" title="Ver comprobante"><img src="' . $url2 . '" alt="" class="payment-proof-thumb"></span>';
                                            } else {
                                                echo '<span class="view-payment-attachment payment-proof-thumb-wrap payment-proof-thumb-pdf" role="button" tabindex="0" data-url="' . $url2 . '" data-type="' . $type2 . '" title="Ver comprobante"><i class="fas fa-file-pdf"></i><span class="small d-block">PDF</span></span>';
                                            }
                                            if (!empty($this->canEditNoteOrAssociateOrder)) {
                                                echo '<form method="post" action="' . Route::_('index.php?option=com_ordenproduccion&task=paymentproof.deleteAttachment') . '" class="payment-proof-delete-file-form d-inline" onsubmit="return confirm(' . json_encode($delConfirmMsgLegacy) . ');">';
                                                echo HTMLHelper::_('form.token');
                                                echo '<input type="hidden" name="proof_id" value="' . (int)($proof->id ?? 0) . '">';
                                                echo '<input type="hidden" name="order_id" value="' . (int)$orderId . '">';
                                                echo '<input type="hidden" name="file_id" value="' . $fidL . '">';
                                                echo '<button type="submit" class="btn btn-sm btn-danger payment-proof-attach-delete p-0" title="' . htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_PROOF_DELETE_FILE')) . '" aria-label="' . htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_PROOF_DELETE_FILE')) . '"><i class="fas fa-times"></i></button>';
                                                echo '</form>';
                                            }
                                            echo '</span>';
                                        }
                                        if (!$fileShownLegacy) {
                                            echo '<span class="text-muted">—</span>';
                                        }
                                    ?></td>
                                    <td class="text-center align-middle"><?php
                                        $proofStatusLeg = isset($proof->verification_status) ? trim((string)$proof->verification_status) : '';
                                        $isIngresadoLeg = ($proofStatusLeg === '' || strtolower($proofStatusLeg) === 'ingresado');
                                        if ($isIngresadoLeg) {
                                            echo '<button type="button" class="btn btn-sm btn-outline-secondary payment-proof-action-btn toggle-add-file-form" data-proof-id="' . (int)($proof->id ?? 0) . '" data-line-id="0" data-line-doc="' . htmlspecialchars((string) ($proof->document_number ?? ''), ENT_QUOTES, 'UTF-8') . '" title="' . htmlspecialchars(AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_LINE_ADD_FILE', 'Add file for this line', 'Adjuntar archivo a esta línea')) . '"><i class="fas fa-paperclip"></i></button>';
                                        } else {
                                            echo '<span class="text-muted">—</span>';
                                        }
                                    ?></td>
                                    <td class="align-top"><?php
                                        $pn = trim((string)($proof->mismatch_note ?? ''));
                                        if ($pn !== '') {
                                            echo '<span class="small text-muted d-block" title="' . htmlspecialchars($pn) . '">' . htmlspecialchars(mb_strlen($pn) > 40 ? mb_substr($pn, 0, 37) . '…' : $pn) . '</span>';
                                        }
                                        $proofStatus = isset($proof->verification_status) ? trim((string)$proof->verification_status) : '';
                                        $isIngresado = ($proofStatus === '' || strtolower($proofStatus) === 'ingresado');
                                        echo '<div class="payment-proof-actions-row mt-1">';
                                        if ($isIngresado && !empty($this->canEditNoteOrAssociateOrder)) {
                                            echo '<form action="' . Route::_('index.php?option=com_ordenproduccion&task=paymentproof.markAsVerificado') . '" method="post" class="d-inline">';
                                            echo HTMLHelper::_('form.token');
                                            echo '<input type="hidden" name="proof_id" value="' . (int)($proof->id ?? 0) . '"><input type="hidden" name="order_id" value="' . (int)$orderId . '">';
                                            echo '<button type="submit" class="btn btn-sm btn-success payment-proof-action-btn" title="' . htmlspecialchars($this->labelMarkVerificado ?? 'Marcar como Verificado') . '"><i class="fas fa-check"></i></button>';
                                            echo '</form>';
                                        }
                                        if (!empty($this->canEditNoteOrAssociateOrder)) {
                                            echo '<button type="button" class="btn btn-sm btn-outline-secondary payment-proof-action-btn toggle-edit-note-form" data-proof-id="' . (int)($proof->id ?? 0) . '" title="' . htmlspecialchars($this->labelEditMismatchNote ?? 'Editar nota') . '"><i class="fas fa-edit"></i></button>';
                                            echo '<button type="button" class="btn btn-sm btn-outline-secondary payment-proof-action-btn toggle-add-order-form" data-proof-id="' . (int)($proof->id ?? 0) . '" title="' . htmlspecialchars($this->labelAssociateAnotherOrder ?? 'Asociar otra orden') . '"><i class="fas fa-link"></i></button>';
                                        }
                                        echo '</div>';
                                    ?></td>
                                </tr>
                                <?php /* Removed duplicate simple "Orden #" list; keep detailed "Información de la Orden" table below. */ ?>
                                <?php endif; endforeach; ?>
                                <?php if (!empty($this->canEditNoteOrAssociateOrder)) : ?>
                                <!-- Edit mismatch note rows (hidden, one per proof) -->
                                <?php foreach ($existingPayments as $epf) :
                                    $currentNote = trim((string)($epf->mismatch_note ?? ''));
                                ?>
                                <tr class="edit-note-form-row" id="edit-note-row-<?php echo (int)($epf->id ?? 0); ?>" style="display:none;">
                                    <td colspan="10" class="bg-white py-2 px-3">
                                        <form action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=paymentproof.updateMismatchNote'); ?>" method="post" class="d-flex align-items-start gap-2 flex-wrap">
                                            <?php echo HTMLHelper::_('form.token'); ?>
                                            <input type="hidden" name="proof_id" value="<?php echo (int)($epf->id ?? 0); ?>">
                                            <input type="hidden" name="order_id" value="<?php echo $orderId; ?>">
                                            <label class="small fw-bold me-1"><?php echo htmlspecialchars($this->labelEditMismatchNote ?? 'Editar nota'); ?> (PA-<?php echo str_pad((string)(int)($epf->id ?? 0), 5, '0', STR_PAD_LEFT); ?>):</label>
                                            <textarea name="payment_mismatch_note" class="form-control form-control-sm" rows="2" style="min-width: 260px;" placeholder="<?php echo htmlspecialchars($this->labelMismatchNotePlaceholder ?? 'Indique el motivo o nota para la diferencia.'); ?>"><?php echo htmlspecialchars($currentNote); ?></textarea>
                                            <button type="submit" class="btn btn-sm btn-primary">Guardar</button>
                                            <button type="button" class="btn btn-sm btn-outline-secondary toggle-edit-note-form" data-proof-id="<?php echo (int)($epf->id ?? 0); ?>">Cancelar</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <!-- Associate another order rows (hidden, one per proof) -->
                                <?php foreach ($existingPayments as $epf) :
                                    $availableOrders = method_exists($proofModel, 'getOrdersNotLinkedToProof') ? $proofModel->getOrdersNotLinkedToProof($epf->id ?? 0, 150) : [];
                                ?>
                                <tr class="add-order-form-row" id="add-order-row-<?php echo (int)($epf->id ?? 0); ?>" style="display:none;">
                                    <td colspan="10" class="bg-white py-2 px-3">
                                        <form action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=paymentproof.addOrderToProof'); ?>" method="post" class="d-flex align-items-center gap-2 flex-wrap">
                                            <?php echo HTMLHelper::_('form.token'); ?>
                                            <input type="hidden" name="proof_id" value="<?php echo (int)($epf->id ?? 0); ?>">
                                            <input type="hidden" name="order_id" value="<?php echo $orderId; ?>">
                                            <span class="small fw-bold me-1"><?php echo htmlspecialchars($this->labelAssociateAnotherOrder ?? 'Asociar otra orden'); ?> a PA-<?php echo str_pad((string)(int)($epf->id ?? 0), 5, '0', STR_PAD_LEFT); ?>:</span>
                                            <select name="add_order_id" class="form-select form-select-sm add-order-select" style="max-width: 220px;" required>
                                                <option value="">— <?php echo htmlspecialchars($this->labelOrderNumber ?? 'Orden'); ?> —</option>
                                                <?php foreach ($availableOrders as $ao) :
                                                    $aoId = (int)($ao->id ?? 0);
                                                    if ($aoId === (int) $orderId) { continue; }
                                                    $invVal = isset($ao->invoice_value) ? (float) $ao->invoice_value : 0;
                                                ?>
                                                <option value="<?php echo $aoId; ?>" data-invoice-value="<?php echo $invVal > 0 ? number_format($invVal, 2, '.', '') : ''; ?>"><?php echo htmlspecialchars(($ao->order_number ?? '#' . ($ao->id ?? '')) . ' — ' . ($ao->client_name ?? '')); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <label class="small mb-0"><?php echo htmlspecialchars($this->labelAmountToApply ?? 'Valor a aplicar'); ?></label>
                                            <input type="number" name="add_amount_applied" step="0.01" min="0.01" class="form-control form-control-sm add-amount-input" style="width: 100px;" required placeholder="0.00">
                                            <button type="submit" class="btn btn-sm btn-primary">Agregar</button>
                                            <button type="button" class="btn btn-sm btn-outline-secondary toggle-add-order-form" data-proof-id="<?php echo (int)($epf->id ?? 0); ?>">Cancelar</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                            <tfoot>
                                <tr class="table-info fw-bold">
                                    <td></td>
                                    <td colspan="2" class="text-end"><?php echo htmlspecialchars($this->labelTotal ?? 'Total'); ?></td>
                                    <td></td>
                                    <td></td>
                                    <td>Q <?php echo number_format($totalMonto, 2); ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                        <?php if (!empty($existingPayments)) : ?>
                        <div class="modal fade" id="paymentProofAddFileModal" tabindex="-1" aria-labelledby="paymentProofAddFileModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="paymentProofAddFileModalLabel"><?php echo htmlspecialchars(AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_LINE_ADD_FILE_MODAL_TITLE', 'Add attachment', 'Agregar archivo adjunto')); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo htmlspecialchars(Text::_('JCLOSE')); ?>"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form id="paymentProofAddFileForm" action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=paymentproof.addFile'); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo HTMLHelper::_('form.token'); ?>
                                            <input type="hidden" name="proof_id" id="ppaf-proof-id" value="">
                                            <input type="hidden" name="order_id" value="<?php echo (int) $orderId; ?>">
                                            <input type="hidden" name="payment_proof_line_id" id="ppaf-line-id" value="0">
                                            <div class="mb-3">
                                                <label class="form-label" for="ppaf-file-input"><?php echo htmlspecialchars(AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_LINE_ADD_FILE_CHOOSE', 'Choose file(s)', 'Elegir archivo(s)')); ?></label>
                                                <input type="file" name="payment_proof_files[]" id="ppaf-file-input" class="form-control form-control-sm" multiple accept=".jpg,.jpeg,.png,.pdf" onchange="validateFiles(this)">
                                                <div class="form-text"><?php echo htmlspecialchars(AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_LINE_ADD_FILE_HINT', 'JPG, PNG or PDF. Max 5 MB per file.', 'JPG, PNG o PDF. Máximo 5 MB por archivo.')); ?></div>
                                            </div>
                                            <div class="d-flex gap-2 justify-content-end pt-2 border-top">
                                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal"><?php echo htmlspecialchars($this->labelCancel ?? 'Cancelar'); ?></button>
                                                <button type="submit" class="btn btn-primary"><i class="fas fa-upload me-1" aria-hidden="true"></i><?php echo htmlspecialchars(AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_LINE_ADD_FILE_SAVE', 'Upload', 'Guardar')); ?></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <!-- Información de la Orden: subtable of orders associated to payment(s), above the viewer -->
                        <?php
                        $orderInfoRows = [];
                        $seenOrderIds  = [];
                        foreach ($existingPayments as $proof) {
                            $proofOrders = method_exists($proofModel, 'getOrdersByPaymentProofId') ? $proofModel->getOrdersByPaymentProofId($proof->id ?? 0) : [];
                            foreach ($proofOrders as $po) {
                                $oid = (int) ($po->order_id ?? 0);
                                if ($oid > 0 && in_array($oid, $seenOrderIds, true)) {
                                    continue; // skip duplicate order
                                }
                                $seenOrderIds[]  = $oid;
                                $orderInfoRows[] = $po;
                            }
                        }
                        // When no rows from payment_orders (e.g. legacy proof), show current order so the table is never missing
                        if (empty($orderInfoRows) && !empty($order)) {
                            $orderInfoRows[] = (object) [
                                'order_id' => $orderId,
                                'order_number' => $order->order_number ?? $order->orden_de_trabajo ?? 'N/A',
                                'client_name' => $order->client_name ?? $order->nombre_del_cliente ?? '—',
                                'invoice_value' => $order->invoice_value ?? $order->valor_a_facturar ?? 0,
                                'request_date' => $order->request_date ?? $order->fecha_de_solicitud ?? null,
                                'amount_applied' => !empty($existingPayments) ? (float)($existingPayments[0]->amount_applied ?? 0) : 0,
                            ];
                        }
                        ?>
                        <?php if (!empty($orderInfoRows)) : ?>
                        <div class="mt-3">
                            <h6 class="small mb-2"><i class="fas fa-info-circle"></i> <?php echo htmlspecialchars($this->labelOrderInformation ?? 'Información de la Orden'); ?></h6>
                            <table class="table table-sm table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th class="small"><?php echo htmlspecialchars($this->labelOrderNumber ?? 'Orden #'); ?></th>
                                        <th class="small"><?php echo htmlspecialchars($this->labelClientName ?? 'Nombre del Cliente'); ?></th>
                                        <th class="small"><?php echo htmlspecialchars($this->labelOrderValue ?? 'Valor de Orden'); ?></th>
                                        <th class="small"><?php echo htmlspecialchars($this->labelRequestDate ?? 'Fecha de Solicitud'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $totalOrdersValue = 0.0;
                                    foreach ($orderInfoRows as $po) :
                                        $totalOrdersValue += (float) ($po->invoice_value ?? 0);
                                    ?>
                                    <tr>
                                        <td class="small"><?php echo htmlspecialchars($po->order_number ?? '#' . ($po->order_id ?? '')); ?></td>
                                        <td class="small"><?php echo htmlspecialchars($po->client_name ?? '—'); ?></td>
                                        <td class="small"><?php echo $this->formatCurrency($po->invoice_value ?? 0); ?></td>
                                        <td class="small"><?php echo $this->formatDate($po->request_date ?? ''); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                    <tr class="table-secondary fw-bold">
                                        <td colspan="2" class="small text-end">Total órdenes:</td>
                                        <td class="small"><?php echo $this->formatCurrency($totalOrdersValue); ?></td>
                                        <td></td>
                                    </tr>
                                    <tr class="table-info fw-bold">
                                        <td colspan="2" class="small text-end">Total pagado:</td>
                                        <td class="small">Q <?php echo number_format($totalMonto, 2); ?></td>
                                        <td></td>
                                    </tr>
                                    <?php
                                    $diff = $totalMonto - $totalOrdersValue;
                                    $diffClass = $diff < 0 ? 'text-danger' : ($diff > 0 ? 'text-warning' : 'text-success');
                                    $mismatchNoteDisplay = '';
                                    if (abs($diff) >= 0.01 && !empty($existingPayments)) {
                                        foreach ($existingPayments as $p) {
                                            $note = isset($p->mismatch_note) ? trim((string) $p->mismatch_note) : '';
                                            if ($note !== '') {
                                                $mismatchNoteDisplay = $note;
                                                break;
                                            }
                                        }
                                    }
                                    ?>
                                    <tr>
                                        <td colspan="2" class="small text-end <?php echo $diffClass; ?>"><?php if ($mismatchNoteDisplay !== '') : ?><span class="<?php echo $diffClass; ?>" style="word-break: break-word; text-align: justify; display: inline-block; max-width: 100%;" title="<?php echo htmlspecialchars($mismatchNoteDisplay); ?>"><?php echo htmlspecialchars($mismatchNoteDisplay); ?></span> — <?php endif; ?>Diferencia:</td>
                                        <td class="small <?php echo $diffClass; ?>"><?php echo ($diff >= 0 ? '+' : '') . 'Q ' . number_format($diff, 2); ?></td>
                                        <td></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        <?php endif; ?>
                        <!-- Viewer: image or PDF below table -->
                        <div id="payment-proof-viewer" class="mt-3 border rounded p-3 bg-light">
                            <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
                                <strong class="small">Comprobante adjunto</strong>
                                <div class="d-flex align-items-center gap-1">
                                    <span id="payment-proof-viewer-zoom-controls" class="me-2" style="display: none;">
                                        <button type="button" class="btn btn-sm btn-outline-secondary payment-proof-zoom-btn" data-zoom="out" title="Alejar" aria-label="Alejar">&minus;</button>
                                        <span id="payment-proof-viewer-zoom-label" class="small mx-1" style="min-width: 3.5em; display: inline-block; text-align: center;">100%</span>
                                        <button type="button" class="btn btn-sm btn-outline-secondary payment-proof-zoom-btn" data-zoom="in" title="Acercar" aria-label="Acercar">+</button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary payment-proof-zoom-btn" data-zoom="reset" title="Restablecer zoom" aria-label="Restablecer">1:1</button>
                                    </span>
                                    <button type="button" class="btn btn-sm btn-outline-secondary close-payment-viewer" aria-label="Cerrar">&times;</button>
                                </div>
                            </div>
                            <div id="payment-proof-viewer-image-wrap" style="display: none; overflow: auto; max-height: 70vh;">
                                <div id="payment-proof-viewer-image-zoom-wrap" style="display: inline-block;">
                                    <img id="payment-proof-viewer-img" src="" alt="" style="display: block; width: 100%; height: 100%; object-fit: contain; vertical-align: top;">
                                </div>
                            </div>
                            <div id="payment-proof-viewer-pdf-wrap" style="display: none; overflow: auto; max-height: 70vh;">
                                <div id="payment-proof-viewer-pdf-zoom-wrap" style="transform-origin: 0 0; display: inline-block;">
                                    <iframe id="payment-proof-viewer-iframe" src="" title="PDF" style="width: 800px; height: 70vh; border: 0;"></iframe>
                                </div>
                            </div>
                            <div id="payment-proof-viewer-empty" class="text-muted small">No hay comprobante para mostrar. Haga clic en una miniatura de la tabla para ver el documento.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
        (function() {
            var viewer    = document.getElementById('payment-proof-viewer');
            var imgWrap   = document.getElementById('payment-proof-viewer-image-wrap');
            var imgEl     = document.getElementById('payment-proof-viewer-img');
            var imgZoomWrap = document.getElementById('payment-proof-viewer-image-zoom-wrap');
            var pdfWrap   = document.getElementById('payment-proof-viewer-pdf-wrap');
            var pdfZoomWrap = document.getElementById('payment-proof-viewer-pdf-zoom-wrap');
            var iframe    = document.getElementById('payment-proof-viewer-iframe');
            var emptyMsg  = document.getElementById('payment-proof-viewer-empty');
            var closeBtn  = document.querySelector('.close-payment-viewer');
            var zoomControls = document.getElementById('payment-proof-viewer-zoom-controls');
            var zoomLabel   = document.getElementById('payment-proof-viewer-zoom-label');
            var zoomLevel = 1;
            var zoomMin = 0.25;
            var zoomMax = 3;
            var zoomStep = 0.25;
            var currentType = '';
            var imageNaturalW = 0;
            var imageNaturalH = 0;

            function applyZoom() {
                if (zoomLabel) zoomLabel.textContent = Math.round(zoomLevel * 100) + '%';
                if (currentType === 'image' && imgZoomWrap && imageNaturalW && imageNaturalH) {
                    imgZoomWrap.style.width  = (imageNaturalW * zoomLevel) + 'px';
                    imgZoomWrap.style.height = (imageNaturalH * zoomLevel) + 'px';
                }
                if (currentType === 'pdf' && pdfZoomWrap) {
                    pdfZoomWrap.style.transform = 'scale(' + zoomLevel + ')';
                }
            }

            function showZoomControls(show) {
                if (zoomControls) zoomControls.style.display = show ? 'inline-flex' : 'none';
            }

            function showInViewer(url, type) {
                if (!url) return;
                iframe.src = 'about:blank';
                imgEl.src  = '';
                emptyMsg.style.display = 'none';
                imgWrap.style.display  = 'none';
                pdfWrap.style.display  = 'none';
                imageNaturalW = 0;
                imageNaturalH = 0;
                zoomLevel = 1;
                currentType = type;
                if (type === 'image') {
                    imgWrap.style.display = 'block';
                    showZoomControls(true);
                    imgEl.onload = function() {
                        imageNaturalW = imgEl.naturalWidth || imgEl.offsetWidth;
                        imageNaturalH = imgEl.naturalHeight || imgEl.offsetHeight;
                        applyZoom();
                    };
                    imgEl.src = url;
                    if (imgEl.complete) imgEl.onload();
                } else if (type === 'pdf') {
                    iframe.src = url;
                    pdfWrap.style.display = 'block';
                    showZoomControls(true);
                    applyZoom();
                } else {
                    showZoomControls(false);
                }
                viewer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }

            function clearViewer() {
                iframe.src = 'about:blank';
                imgEl.src  = '';
                imgWrap.style.display  = 'none';
                pdfWrap.style.display  = 'none';
                showZoomControls(false);
                emptyMsg.style.display = 'block';
            }

            document.addEventListener('click', function(e) {
                var btn = e.target.closest('.view-payment-attachment');
                if (btn) {
                    e.preventDefault();
                    showInViewer(btn.getAttribute('data-url'), btn.getAttribute('data-type'));
                }
                var zoomBtn = e.target.closest('.payment-proof-zoom-btn');
                if (zoomBtn) {
                    e.preventDefault();
                    var action = zoomBtn.getAttribute('data-zoom');
                    if (action === 'in')  zoomLevel = Math.min(zoomMax, zoomLevel + zoomStep);
                    if (action === 'out') zoomLevel = Math.max(zoomMin, zoomLevel - zoomStep);
                    if (action === 'reset') zoomLevel = 1;
                    applyZoom();
                }
            });

            if (closeBtn) closeBtn.addEventListener('click', clearViewer);

            var first = document.querySelector('.view-payment-attachment');
            if (first) {
                showInViewer(first.getAttribute('data-url'), first.getAttribute('data-type'));
            } else {
                emptyMsg.style.display = 'block';
            }
        })();
        </script>
        <?php if (!empty($this->mismatchTicketHeaderProofId)) :
            $mismatchTicketJsonUrl   = Route::_('index.php?option=com_ordenproduccion&task=payments.getMismatchTicket&format=json', false);
            $mismatchCommentPostUrl  = Route::_('index.php?option=com_ordenproduccion&task=payments.addMismatchTicketComment', false);
            $mismatchStatusPostUrl   = Route::_('index.php?option=com_ordenproduccion&task=payments.setMismatchTicketStatus', false);
            $mismatchTicketFormToken = Session::getFormToken();
            ?>
        <div class="modal fade" id="mismatchTicketModal" tabindex="-1" aria-labelledby="mismatchTicketModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-scrollable">
                <div class="modal-content mismatch-ticket-modal-content">
                    <div class="modal-header py-2">
                        <h5 class="modal-title small" id="mismatchTicketModalLabel"><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_TITLE')); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo htmlspecialchars(Text::_('JCLOSE')); ?>"></button>
                    </div>
                    <div class="modal-body py-2 mismatch-ticket-modal-body">
                        <div id="mismatchTicketLoading" class="text-center py-3 small text-muted"><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_LOADING')); ?></div>
                        <div id="mismatchTicketBody" class="d-none">
                            <p class="small mb-1"><strong><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_STATUS')); ?></strong></p>
                            <select id="mismatchTicketStatusSelect" class="form-select form-select-sm mb-2" disabled></select>
                            <p id="mismatchTicketStatusHint" class="small text-warning mb-2 d-none"><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_STATUS_DISABLED')); ?></p>
                            <p id="mismatchTicketStatusHintAdmin" class="small text-muted mb-2 d-none"><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_STATUS_ADMIN_ONLY')); ?></p>
                            <div class="small border rounded p-2 mb-2 bg-light">
                                <div class="mb-1"><strong><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_INITIAL')); ?></strong> <span id="mismatchTicketCreator" class="text-muted"></span></div>
                                <div id="mismatchTicketInitialNote" class="mb-0 text-break"></div>
                                <div id="mismatchTicketDiffRow" class="mt-1 text-muted"></div>
                            </div>
                            <p class="small mb-1"><strong><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_THREAD')); ?></strong></p>
                            <p id="mismatchTicketCommentsDisabled" class="small text-warning d-none mb-2"><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_COMMENTS_DISABLED')); ?></p>
                            <div id="mismatchTicketComments" class="mb-2 mismatch-ticket-comments mismatch-ticket-comments--chat"></div>
                            <label for="mismatchTicketNewComment" class="form-label small mb-0"><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_NEW_COMMENT')); ?></label>
                            <textarea id="mismatchTicketNewComment" class="form-control form-control-sm mb-1" rows="2" maxlength="8000" disabled></textarea>
                            <button type="button" class="btn btn-primary btn-sm" id="mismatchTicketBtnSendComment" disabled><?php echo htmlspecialchars(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_SEND')); ?></button>
                        </div>
                        <div id="mismatchTicketError" class="alert alert-danger small py-2 mb-0 d-none"></div>
                    </div>
                </div>
            </div>
        </div>
        <style>
        .mismatch-ticket-modal-content { font-size: 0.8rem; }
        .mismatch-ticket-modal-body .form-select,
        .mismatch-ticket-modal-body .form-control { font-size: 0.8rem; }
        .mismatch-ticket-comments.mismatch-ticket-comments--chat {
            display: flex;
            flex-direction: column;
            gap: 0.55rem;
            max-height: 300px;
            overflow-y: auto;
            overflow-x: hidden;
            font-size: 0.78rem;
            padding: 0.65rem 0.55rem;
            background: linear-gradient(180deg, #e8edf0 0%, #eceff1 100%);
            border-radius: 12px;
            border: 1px solid rgba(0,0,0,0.06);
        }
        .mismatch-ticket-comment-item {
            max-width: 92%;
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }
        .mismatch-ticket-comment-item.mismatch-ticket-comment--source-telegram { align-self: flex-start; }
        .mismatch-ticket-comment-item.mismatch-ticket-comment--source-site { align-self: flex-end; }
        .mismatch-ticket-comment-item.mismatch-ticket-comment--source-telegram .mismatch-ticket-comment-meta { text-align: left; padding-left: 0.2rem; }
        .mismatch-ticket-comment-item.mismatch-ticket-comment--source-site .mismatch-ticket-comment-meta { text-align: right; padding-right: 0.2rem; }
        .mismatch-ticket-comment-meta { color: #6c757d; font-size: 0.68rem; line-height: 1.25; }
        .mismatch-ticket-comment-bubble {
            position: relative;
            z-index: 0;
            padding: 0.6rem 0.85rem;
            line-height: 1.45;
            word-break: break-word;
            font-size: 0.82rem;
        }
        /* Telegram app (inbound webhook): left, white + blue accent */
        .mismatch-ticket-comment--source-telegram .mismatch-ticket-comment-bubble {
            background: #fff;
            color: #212529;
            border: 1px solid rgba(34, 158, 217, 0.22);
            border-left: 3px solid #229ed9;
            border-radius: 18px 18px 18px 6px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.06), 0 3px 10px rgba(34, 158, 217, 0.08);
        }
        .mismatch-ticket-comment--source-telegram .mismatch-ticket-comment-bubble::before {
            content: '';
            position: absolute;
            top: 14px;
            left: -7px;
            width: 0;
            height: 0;
            border-style: solid;
            border-width: 5px 8px 5px 0;
            border-color: transparent #fff transparent transparent;
            filter: drop-shadow(-1px 1px 0 rgba(34, 158, 217, 0.12));
        }
        /* Web (browser): right, blue bubble */
        .mismatch-ticket-comment--source-site .mismatch-ticket-comment-bubble {
            background: linear-gradient(165deg, #2aabee 0%, #229ed9 100%);
            color: #fff;
            border: none;
            border-radius: 18px 18px 6px 18px;
            box-shadow: 0 2px 4px rgba(34, 158, 217, 0.25), 0 4px 14px rgba(34, 158, 217, 0.2);
        }
        .mismatch-ticket-comment--source-site .mismatch-ticket-comment-bubble::before {
            content: '';
            position: absolute;
            top: 14px;
            right: -7px;
            width: 0;
            height: 0;
            border-style: solid;
            border-width: 5px 0 5px 8px;
            border-color: transparent transparent transparent #229ed9;
        }
        </style>
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            var mismatchModalEl = document.getElementById('mismatchTicketModal');
            var mismatchTicketJsonUrl = <?php echo json_encode($mismatchTicketJsonUrl); ?>;
            var mismatchCommentPostUrl = <?php echo json_encode($mismatchCommentPostUrl); ?>;
            var mismatchStatusPostUrl = <?php echo json_encode($mismatchStatusPostUrl); ?>;
            var mismatchFormToken = <?php echo json_encode($mismatchTicketFormToken); ?>;
            var currentMismatchProofId = 0;
            var skipMismatchStatusChange = false;
            var mismatchPollTimer = null;
            var MISMATCH_POLL_MS = 4000;

            function stopMismatchPoll() {
                if (mismatchPollTimer !== null) {
                    clearInterval(mismatchPollTimer);
                    mismatchPollTimer = null;
                }
            }

            function startMismatchPoll() {
                stopMismatchPoll();
                if (!mismatchModalEl || !currentMismatchProofId) {
                    return;
                }
                mismatchPollTimer = setInterval(function() {
                    if (!mismatchModalEl || !currentMismatchProofId) {
                        return;
                    }
                    if (!mismatchModalEl.classList.contains('show')) {
                        return;
                    }
                    if (document.hidden) {
                        return;
                    }
                    refreshMismatchTicketQuiet();
                }, MISMATCH_POLL_MS);
            }

            function escapeMismatchHtml(s) {
                if (!s) { return ''; }
                var d = document.createElement('div');
                d.textContent = s;
                return d.innerHTML;
            }

            function updateMismatchStatusCells(proofId, label) {
                document.querySelectorAll('.mismatch-ticket-status-cell[data-proof-id="' + proofId + '"]').forEach(function(td) {
                    td.textContent = label;
                });
            }

            var mismatchSrcLabelTelegram = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_SOURCE_TELEGRAM')); ?>;
            var mismatchSrcLabelSite = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_SOURCE_SITE')); ?>;

            function renderMismatchComments(comments) {
                var box = document.getElementById('mismatchTicketComments');
                box.innerHTML = '';
                if (!comments || comments.length === 0) {
                    var p = document.createElement('p');
                    p.className = 'text-muted mb-0 px-1';
                    p.textContent = <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_NO_COMMENTS')); ?>;
                    box.appendChild(p);
                    return;
                }
                comments.forEach(function(c) {
                    var src = ((c.source || 'site') + '').toLowerCase() === 'telegram' ? 'telegram' : 'site';
                    var div = document.createElement('div');
                    div.className = 'mismatch-ticket-comment-item mismatch-ticket-comment--source-' + src;
                    var meta = document.createElement('div');
                    meta.className = 'mismatch-ticket-comment-meta';
                    var when = (c.created_display || '').trim() || '';
                    var srcLbl = src === 'telegram' ? mismatchSrcLabelTelegram : mismatchSrcLabelSite;
                    meta.textContent = [c.user_name || '', when, srcLbl].filter(Boolean).join(' · ');
                    var bubble = document.createElement('div');
                    bubble.className = 'mismatch-ticket-comment-bubble text-break';
                    bubble.innerHTML = escapeMismatchHtml(c.body || '').replace(/\n/g, '<br>');
                    div.appendChild(meta);
                    div.appendChild(bubble);
                    box.appendChild(div);
                });
            }

            function applyMismatchTicketPayload(d, opts) {
                opts = opts || {};
                var clearDraft = opts.clearCommentDraft !== false;
                if (d.error) {
                    return false;
                }
                document.getElementById('mismatchTicketBody').classList.remove('d-none');
                document.getElementById('mismatchTicketError').classList.add('d-none');
                document.getElementById('mismatchTicketModalLabel').textContent =
                    <?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PAYMENT_MISMATCH_TICKET_TITLE')); ?> + ' — ' + (d.payment_label || '');

                var sel = document.getElementById('mismatchTicketStatusSelect');
                sel.innerHTML = '';
                (d.status_options || []).forEach(function(opt) {
                    var o = document.createElement('option');
                    o.value = opt.value;
                    o.textContent = opt.label;
                    sel.appendChild(o);
                });
                skipMismatchStatusChange = true;
                sel.value = d.status || 'nuevo';
                setTimeout(function() { skipMismatchStatusChange = false; }, 0);
                var canSt = !!d.can_change_status;
                sel.disabled = !d.status_enabled || !canSt;
                document.getElementById('mismatchTicketStatusHint').classList.toggle('d-none', d.status_enabled);
                document.getElementById('mismatchTicketStatusHintAdmin').classList.toggle('d-none', !d.status_enabled || canSt);

                document.getElementById('mismatchTicketCreator').textContent = d.created_by_name ? '(' + d.created_by_name + ')' : '';
                var initN = document.getElementById('mismatchTicketInitialNote');
                initN.innerHTML = d.initial_note
                    ? escapeMismatchHtml(d.initial_note).replace(/\n/g, '<br>')
                    : '—';
                var diffRow = document.getElementById('mismatchTicketDiffRow');
                var diffPart = (d.difference !== '' && d.difference != null)
                    ? (<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PAYMENTS_MISMATCH_COL_DIFFERENCE')); ?> + ': ' + escapeMismatchHtml(String(d.difference)))
                    : '';
                var amt = (typeof d.payment_amount === 'number')
                    ? d.payment_amount.toLocaleString('es-GT', { minimumFractionDigits: 2 })
                    : '';
                diffRow.innerHTML = [diffPart, amt ? (<?php echo json_encode(Text::_('COM_ORDENPRODUCCION_PAYMENTS_MISMATCH_COL_AMOUNT')); ?> + ': ' + amt) : ''].filter(Boolean).join(' · ');

                document.getElementById('mismatchTicketCommentsDisabled').classList.toggle('d-none', d.comments_enabled);
                var ta = document.getElementById('mismatchTicketNewComment');
                var btnS = document.getElementById('mismatchTicketBtnSendComment');
                ta.disabled = !d.comments_enabled;
                btnS.disabled = !d.comments_enabled;
                if (clearDraft) {
                    ta.value = '';
                }

                renderMismatchComments(d.comments);
                if (typeof opts.afterComments === 'function') {
                    opts.afterComments();
                }
                return true;
            }

            function refreshMismatchTicketQuiet() {
                if (!currentMismatchProofId) {
                    return;
                }
                var commentsBox = document.getElementById('mismatchTicketComments');
                var pinTail = true;
                if (commentsBox) {
                    pinTail = commentsBox.scrollHeight - commentsBox.scrollTop - commentsBox.clientHeight < 120;
                }
                var url = mismatchTicketJsonUrl + (mismatchTicketJsonUrl.indexOf('?') >= 0 ? '&' : '?') +
                    'proof_id=' + encodeURIComponent(currentMismatchProofId) + '&' + encodeURIComponent(mismatchFormToken) + '=1';
                fetch(url, { headers: { 'Accept': 'application/json' } }).then(function(r) { return r.json(); }).then(function(d) {
                    if (d.error) {
                        return;
                    }
                    applyMismatchTicketPayload(d, {
                        clearCommentDraft: false,
                        afterComments: function() {
                            if (commentsBox && pinTail) {
                                commentsBox.scrollTop = commentsBox.scrollHeight;
                            }
                        }
                    });
                }).catch(function() { /* ignore transient errors */ });
            }

            function loadMismatchTicket(proofId) {
                if (!mismatchModalEl) { return; }
                stopMismatchPoll();
                currentMismatchProofId = proofId;
                document.getElementById('mismatchTicketLoading').classList.remove('d-none');
                document.getElementById('mismatchTicketBody').classList.add('d-none');
                document.getElementById('mismatchTicketError').classList.add('d-none');
                var url = mismatchTicketJsonUrl + (mismatchTicketJsonUrl.indexOf('?') >= 0 ? '&' : '?') +
                    'proof_id=' + encodeURIComponent(proofId) + '&' + encodeURIComponent(mismatchFormToken) + '=1';
                fetch(url, { headers: { 'Accept': 'application/json' } }).then(function(r) { return r.json(); }).then(function(d) {
                    document.getElementById('mismatchTicketLoading').classList.add('d-none');
                    if (d.error) {
                        var er = document.getElementById('mismatchTicketError');
                        er.textContent = d.message || 'Error';
                        er.classList.remove('d-none');
                        return;
                    }
                    applyMismatchTicketPayload(d, {
                        clearCommentDraft: true,
                        afterComments: function() {
                            var box = document.getElementById('mismatchTicketComments');
                            if (box) {
                                box.scrollTop = box.scrollHeight;
                            }
                        }
                    });
                    startMismatchPoll();
                }).catch(function() {
                    document.getElementById('mismatchTicketLoading').classList.add('d-none');
                    var er = document.getElementById('mismatchTicketError');
                    er.textContent = 'Error de red';
                    er.classList.remove('d-none');
                });
            }

            if (mismatchModalEl) {
                mismatchModalEl.addEventListener('hidden.bs.modal', function() {
                    stopMismatchPoll();
                    currentMismatchProofId = 0;
                });
            }

            document.querySelectorAll('.btn-mismatch-ticket').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var pid = this.getAttribute('data-proof-id');
                    if (!pid || !mismatchModalEl) { return; }
                    var mm = bootstrap.Modal.getInstance(mismatchModalEl);
                    if (!mm) { mm = new bootstrap.Modal(mismatchModalEl); }
                    mm.show();
                    loadMismatchTicket(pid);
                });
            });

            var statusSel = document.getElementById('mismatchTicketStatusSelect');
            if (statusSel) {
                statusSel.addEventListener('change', function() {
                    if (skipMismatchStatusChange) { return; }
                    if (!currentMismatchProofId) { return; }
                    var fd = new FormData();
                    fd.append(mismatchFormToken, '1');
                    fd.append('proof_id', String(currentMismatchProofId));
                    fd.append('status', this.value);
                    fetch(mismatchStatusPostUrl, { method: 'POST', body: fd, headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                        .then(function(r) { return r.json(); }).then(function(d) {
                            if (d.error) {
                                alert(d.message || 'Error');
                                return;
                            }
                            updateMismatchStatusCells(currentMismatchProofId, d.status_label || '');
                        }).catch(function() { alert('Error de red'); });
                });
            }

            var btnSendMismatch = document.getElementById('mismatchTicketBtnSendComment');
            if (btnSendMismatch) {
                btnSendMismatch.addEventListener('click', function() {
                    if (!currentMismatchProofId) { return; }
                    var ta = document.getElementById('mismatchTicketNewComment');
                    var body = (ta && ta.value) ? ta.value.trim() : '';
                    if (!body) { return; }
                    var fd = new FormData();
                    fd.append(mismatchFormToken, '1');
                    fd.append('proof_id', String(currentMismatchProofId));
                    fd.append('body', body);
                    btnSendMismatch.disabled = true;
                    fetch(mismatchCommentPostUrl, { method: 'POST', body: fd, headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                        .then(function(r) { return r.json(); }).then(function(d) {
                            btnSendMismatch.disabled = false;
                            if (d.error) {
                                alert(d.message || 'Error');
                                return;
                            }
                            ta.value = '';
                            loadMismatchTicket(String(currentMismatchProofId));
                        }).catch(function() {
                            btnSendMismatch.disabled = false;
                            alert('Error de red');
                        });
                });
            }
        });
        </script>
        <?php endif; ?>
        <?php endif; ?>

        <!-- Payment Proof Form -->
        <div class="row">
            <div class="col-12">
                <?php if (strtolower((string) ($order->status ?? '')) === 'anulada') : ?>
                <div class="alert alert-danger" role="alert">
                    <i class="fas fa-ban me-2"></i>
                    <strong>Orden Anulada.</strong> No se pueden registrar comprobantes de pago para una orden anulada.
                </div>
                <?php else : ?>
                <?php if (!empty($existingPayments)) : ?>
                <div class="alert alert-info mb-3" role="alert">
                    <i class="fas fa-info-circle"></i>
                    <?php echo htmlspecialchars($this->labelPaymentAddAnotherHelp ?? 'Puede registrar otro comprobante (ej. abono o anticipo).'); ?>
                </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-credit-card"></i>
                            <?php echo htmlspecialchars($this->labelPaymentProofRegistration ?? 'Registro de Comprobante de Pago'); ?>
                        </h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=paymentproof.register'); ?>" 
                              method="post" 
                              enctype="multipart/form-data" 
                              class="form-validate" 
                              id="payment-proof-form">
                            
                            <input type="hidden" name="order_id" value="<?php echo $orderId; ?>">
                            <?php echo HTMLHelper::_('form.token'); ?>

                            <!-- Payment method lines (cheque + NCF + etc.) -->
                            <div class="row mb-3">
                                <div class="col-12">
                                    <label><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_METHOD_LINES', 'Payment method lines', 'Métodos de pago'); ?></label>
                                    <small class="form-text text-muted d-block mb-2"><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_METHOD_LINES_HELP', 'Add one or more lines (e.g. Check + Tax Credit Note). Use + to add.', 'Agregue una o más líneas (ej. Cheque + Nota Crédito Fiscal). Use el botón + para agregar.'); ?></small>
                                    <div class="table-responsive">
                                        <table class="table table-bordered" id="payment-lines-table">
                                            <thead>
                                                <tr>
                                                    <th><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_TYPE', 'Payment Type', 'Tipo de pago'); ?></th>
                                                    <th><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_LINE_BANK_ORIGIN', 'Origin bank', 'Banco Origen'); ?></th>
                                                    <th><?php echo htmlspecialchars($bankAccountColumnLabel); ?></th>
                                                    <th style="width: 140px;">Doc. No</th>
                                                    <th style="width: 130px;"><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_DOCUMENT_DATE', 'Document Date', 'Fecha del Documento'); ?></th>
                                                    <th style="width: 110px;"><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_AMOUNT', 'Amount', 'Monto'); ?></th>
                                                    <th class="text-center" style="width: 52px;" title="<?php echo htmlspecialchars(AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_LINE_ATTACHMENTS', 'Attachments for this line', 'Archivos por línea')); ?>"><i class="fas fa-paperclip" aria-hidden="true"></i></th>
                                                    <th style="width: 40px;"></th>
                                                </tr>
                                            </thead>
                                            <tbody id="payment-lines-body">
                                                <tr class="payment-line-row">
                                                    <td>
                                                        <select name="payment_lines[0][payment_type]" class="form-control form-control-sm payment-line-type" required>
                                                            <option value="">Seleccionar</option>
                                                            <?php foreach ($paymentTypeOptions as $val => $txt): ?>
                                                            <option value="<?php echo htmlspecialchars($val); ?>"><?php echo htmlspecialchars($txt); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </td>
                                                    <td class="bank-cell">
                                                        <select name="payment_lines[0][bank]" class="form-control form-control-sm payment-line-bank">
                                                            <option value=""><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_SELECT_BANK', 'Select bank', 'Seleccionar banco'); ?></option>
                                                            <?php foreach ($bankOptions as $code => $name): ?>
                                                            <option value="<?php echo htmlspecialchars($code); ?>"<?php echo ($defaultBankCode && $code === $defaultBankCode) ? ' selected' : ''; ?>><?php echo htmlspecialchars($name); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </td>
                                                    <td class="bank-account-cell">
                                                        <select name="payment_lines[0][bank_account_id]" class="form-control form-control-sm payment-line-bank-account" required>
                                                            <option value=""><?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_SELECT_BANK_ACCOUNT', 'Select bank account', 'Seleccionar cuenta'); ?></option>
                                                            <?php foreach ($bankAccountOptionsForPayment as $accId => $accName) : ?>
                                                            <option value="<?php echo (int) $accId; ?>"<?php echo ((int) $defaultBankAccountIdForPayment === (int) $accId) ? ' selected' : ''; ?>><?php echo htmlspecialchars($accName); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <input type="text" name="payment_lines[0][document_number]" class="form-control form-control-sm" placeholder="<?php echo htmlspecialchars($this->labelDocumentNumberPlaceholder ?? 'ej. Número de cheque, referencia'); ?>" maxlength="255" required>
                                                    </td>
                                                    <td>
                                                        <input type="date" name="payment_lines[0][document_date]" class="form-control form-control-sm payment-line-document-date" placeholder="">
                                                    </td>
                                                    <td>
                                                        <input type="number" name="payment_lines[0][amount]" class="form-control form-control-sm payment-line-amount" min="0.01" step="0.01" max="999999.99" placeholder="0.00" required>
                                                    </td>
                                                    <td class="text-center align-middle">
                                                        <label class="btn btn-sm btn-outline-secondary mb-0 payment-line-clip-label" title="<?php echo htmlspecialchars(AsistenciaHelper::safeText('COM_ORDENPRODUCCION_PAYMENT_LINE_ATTACH_HINT', 'One or more files for this line', 'Uno o más archivos para esta línea')); ?>">
                                                            <i class="fas fa-paperclip" aria-hidden="true"></i>
                                                            <input type="file" name="payment_line_files[0][]" class="d-none payment-line-file-input" accept=".jpg,.jpeg,.png,.pdf" multiple onchange="validateFiles(this)">
                                                        </label>
                                                    </td>
                                                    <td class="text-center"></td>
                                                </tr>
                                            </tbody>
                                            <tfoot>
                                                <tr class="table-info">
                                                    <td colspan="5" class="text-end"><strong><?php echo htmlspecialchars($this->labelTotal ?? 'Total'); ?>:</strong></td>
                                                    <td><strong id="payment-lines-total">Q. 0.00</strong></td>
                                                    <td></td>
                                                    <td class="text-end">
                                                        <button type="button" class="btn btn-sm btn-success add-payment-line-btn" style="min-width: 38px;" title="<?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_ADD_LINE', 'Add line', 'Agregar línea'); ?>">
                                                            <i class="fas fa-plus"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <input type="hidden" name="payment_amount" id="payment_amount" value="">
                            <input type="hidden" name="payment_mismatch_note" id="payment_mismatch_note" value="">
                            <input type="hidden" name="payment_mismatch_difference" id="payment_mismatch_difference" value="">

                            <!-- Dynamic Orders Table -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>
                                            <?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_ORDERS_TO_APPLY_PAYMENT', 'Orders to apply payment', 'Órdenes a aplicar este pago'); ?>
                                        </label>
                                        <div class="table-responsive">
                                            <table class="table table-bordered" id="payment-orders-table">
                                                <thead>
                                                    <tr>
                                                        <th style="width: 50%"><?php echo htmlspecialchars($this->labelOrderNumber ?? 'Orden #'); ?></th>
                                                        <th style="width: 35%"><?php echo htmlspecialchars($this->labelValueToApply ?? 'Valor a Aplicar'); ?></th>
                                                        <th style="width: 40px;"></th>
                                                    </tr>
                                                </thead>
                                                <tbody id="payment-orders-body">
                                                    <!-- First row: current order (read-only) -->
                                                    <tr class="payment-order-row" data-row-index="0">
                                                        <td>
                                                            <input type="hidden" 
                                                                   name="payment_orders[0][order_id]" 
                                                                   value="<?php echo $orderId; ?>">
                                                            <input type="text" 
                                                                   class="form-control" 
                                                                   value="<?php echo htmlspecialchars($order->order_number ?? $order->orden_de_trabajo ?? 'ORD-' . $orderId); ?>" 
                                                                   readonly>
                                                        </td>
                                                        <td>
                                                            <div class="input-group">
                                                                <span class="input-group-text">Q.</span>
                                                                <input type="number" 
                                                                       name="payment_orders[0][value]" 
                                                                       class="form-control payment-value-input" 
                                                                       min="0.01" 
                                                                       step="0.01" 
                                                                       placeholder="0.00"
                                                                       value="<?php echo $defaultAmount; ?>"
                                                                       required>
                                                            </div>
                                                        </td>
                                                        <td class="text-center"></td>
                                                    </tr>
                                                </tbody>
                                                <tfoot>
                                                    <tr class="table-info">
                                                        <td class="text-end"><strong><?php echo htmlspecialchars($this->labelTotal ?? 'Total'); ?>:</strong></td>
                                                        <td>
                                                            <div class="input-group">
                                                                <span class="input-group-text">Q.</span>
                                                                <input type="text" 
                                                                       id="payment-total" 
                                                                       class="form-control font-weight-bold" 
                                                                       value="0.00" 
                                                                       readonly>
                                                            </div>
                                                        </td>
                                                        <td class="text-end">
                                                            <button type="button" 
                                                                    class="btn btn-sm btn-success add-row-btn" 
                                                                    title="<?php echo htmlspecialchars($this->labelAddOrder ?? 'Agregar orden'); ?>">
                                                                <i class="fas fa-plus"></i>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                        <small class="form-text text-muted">
                                            <?php echo AsistenciaHelper::safeText('COM_ORDENPRODUCCION_ORDERS_TO_APPLY_HELP', 'Add work orders and amount for each', 'Agregue las órdenes de trabajo y el monto para cada una'); ?>
                                        </small>
                                    </div>
                                </div>
                            </div>

                            <!-- Hidden field with orders-with-remaining-balance data for JavaScript -->
                            <script type="application/json" id="unpaid-orders-data">
                                <?php echo $this->getUnpaidOrdersJson(); ?>
                            </script>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i>
                                    <?php echo htmlspecialchars($this->labelRegisterPaymentProof ?? 'Registrar Comprobante de Pago'); ?>
                                </button>
                                <a href="<?php echo Route::_('index.php?option=com_ordenproduccion&view=ordenes'); ?>" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left"></i>
                                    <?php echo htmlspecialchars($this->labelCancel ?? 'Cancelar'); ?>
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endif; // end not-anulada check ?>
            </div>
        </div>
    </div>
</div>

<script>
window.validateFile = function(input) {
    const file = input.files[0];
    if (file) {
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
        const maxSize = 5 * 1024 * 1024;
        if (!allowedTypes.includes(file.type)) {
            alert('<?php echo addslashes(htmlspecialchars($this->labelErrorInvalidFileType ?? 'Tipo de archivo inválido. Solo se permiten JPG, PNG y PDF.')); ?>');
            input.value = '';
            return false;
        }
        if (file.size > maxSize) {
            alert('<?php echo addslashes(htmlspecialchars($this->labelErrorFileTooLarge ?? 'Archivo demasiado grande. Máximo 5MB.')); ?>');
            input.value = '';
            return false;
        }
    }
    return true;
};
window.validateFiles = function(input) {
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
    const maxSize = 5 * 1024 * 1024;
    for (const file of input.files) {
        if (!allowedTypes.includes(file.type)) {
            alert('Tipo de archivo inválido: ' + file.name + '. Solo JPG, PNG o PDF.');
            input.value = '';
            return false;
        }
        if (file.size > maxSize) {
            alert('Archivo demasiado grande: ' + file.name + '. Máximo 5MB por archivo.');
            input.value = '';
            return false;
        }
    }
    return true;
};
document.addEventListener('DOMContentLoaded', function () {
    var ppafModal = document.getElementById('paymentProofAddFileModal');
    if (ppafModal) {
        ppafModal.addEventListener('hidden.bs.modal', function () {
            var fi = document.getElementById('ppaf-file-input');
            if (fi) {
                fi.value = '';
            }
        });
    }
    document.querySelectorAll('.toggle-add-file-form').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            var proofId = this.getAttribute('data-proof-id') || '';
            var lineId = this.getAttribute('data-line-id');
            if (lineId === null || lineId === '') {
                lineId = '0';
            }
            var lineDoc = this.getAttribute('data-line-doc') || '';
            var form = document.getElementById('paymentProofAddFileForm');
            var modalEl = document.getElementById('paymentProofAddFileModal');
            if (!form || !modalEl) {
                return;
            }
            var proofInput = document.getElementById('ppaf-proof-id');
            if (proofInput) {
                proofInput.value = proofId;
            }
            var lineInput = document.getElementById('ppaf-line-id');
            if (lineInput) {
                lineInput.value = lineId;
            }
            var titleEl = document.getElementById('paymentProofAddFileModalLabel');
            if (titleEl) {
                var fid = parseInt(proofId, 10) || 0;
                var paNum = String(fid).padStart(5, '0');
                if (lineDoc) {
                    titleEl.textContent = 'PA-' + paNum + ' — doc. ' + lineDoc;
                } else {
                    titleEl.textContent = 'PA-' + paNum;
                }
            }
            var fi = document.getElementById('ppaf-file-input');
            if (fi) {
                fi.value = '';
            }
            if (window.bootstrap && window.bootstrap.Modal) {
                window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
            }
        });
    });
    document.querySelectorAll('.toggle-edit-note-form').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var proofId = this.getAttribute('data-proof-id');
            var row = document.getElementById('edit-note-row-' + proofId);
            if (row) {
                row.style.display = (row.style.display === 'none' || row.style.display === '') ? 'table-row' : 'none';
            }
        });
    });
    document.querySelectorAll('.toggle-add-order-form').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var proofId = this.getAttribute('data-proof-id');
            var row = document.getElementById('add-order-row-' + proofId);
            if (row) {
                row.style.display = (row.style.display === 'none' || row.style.display === '') ? 'table-row' : 'none';
            }
        });
    });
    document.querySelectorAll('.add-order-select').forEach(function (sel) {
        sel.addEventListener('change', function () {
            var opt = this.options[this.selectedIndex];
            var amountInput = this.closest('form') && this.closest('form').querySelector('.add-amount-input');
            if (amountInput && opt && opt.hasAttribute('data-invoice-value')) {
                var val = opt.getAttribute('data-invoice-value');
                amountInput.value = (val !== '' && parseFloat(val) >= 0) ? val : '';
            }
        });
    });
    <?php if (!empty($this->highlightProofId)) : ?>
    (function () {
        var el = document.getElementById('proof-<?php echo (int) $this->highlightProofId; ?>');
        if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            el.classList.add('table-warning');
            setTimeout(function () { el.classList.remove('table-warning'); }, 2500);
        }
    })();
    <?php endif; ?>
});

(function() {
    const bankOpts = <?php echo json_encode($bankOptions); ?>;
    const defaultBank = <?php echo json_encode($defaultBankCode ?? ''); ?>;
    const defaultBankAccountId = <?php echo (int) $defaultBankAccountIdForPayment; ?>;
    const typeOpts = <?php echo json_encode(array_keys($paymentTypeOptions)); ?>;
    const typeLabels = <?php echo json_encode($paymentTypeOptions); ?>;
    let lineIndex = 1;

    function toggleBankCell(row) {
        const typeSel = row.querySelector('.payment-line-type');
        const bankCell = row.querySelector('.bank-cell');
        const accCell = row.querySelector('.bank-account-cell');
        const bankSel = row.querySelector('.payment-line-bank');
        const accSel = row.querySelector('.payment-line-bank-account');
        if (!typeSel) return;
        const isCash = (typeSel.value === 'efectivo');
        if (bankCell) bankCell.style.visibility = isCash ? 'hidden' : 'visible';
        if (accCell) accCell.style.visibility = isCash ? 'hidden' : 'visible';
        if (bankSel) {
            bankSel.disabled = isCash;
            if (isCash) {
                bankSel.value = '';
            } else if (!bankSel.value && defaultBank) {
                bankSel.value = defaultBank;
            }
        }
        if (accSel) {
            accSel.disabled = isCash;
            accSel.required = !isCash;
            if (isCash) {
                accSel.value = '';
            } else if (!accSel.value && defaultBankAccountId) {
                accSel.value = String(defaultBankAccountId);
            }
        }
    }

    function updateLinesTotal() {
        let sum = 0;
        document.querySelectorAll('.payment-line-amount').forEach(function(inp) {
            sum += parseFloat(inp.value) || 0;
        });
        document.getElementById('payment-lines-total').textContent = 'Q. ' + sum.toFixed(2);
        const amt = document.getElementById('payment_amount');
        if (amt) amt.value = sum.toFixed(2);
        return sum;
    }

    function addLine() {
        const tbody = document.getElementById('payment-lines-body');
        const firstRow = tbody.querySelector('.payment-line-row');
        if (!firstRow) return;
        const newRow = firstRow.cloneNode(true);
        newRow.classList.remove('payment-line-row');
        var lastTd = newRow.querySelector('td:last-child');
        if (lastTd) lastTd.innerHTML = '<button type="button" class="btn btn-sm btn-danger remove-payment-line-btn" title="<?php echo htmlspecialchars($this->labelDelete ?? 'Eliminar'); ?>"><i class="fas fa-minus"></i></button>';
        newRow.querySelectorAll('select, input').forEach(function(el) {
            const m = el.name && el.name.match(/payment_lines\[\d+\]\[(\w+)\]/);
            if (m) {
                el.name = 'payment_lines[' + lineIndex + '][' + m[1] + ']';
                if (m[1] === 'amount') el.value = '';
                else if (m[1] === 'document_number') el.value = '';
                else if (m[1] === 'document_date') el.value = '';
                else if (m[1] === 'payment_type') el.value = '';
                else if (m[1] === 'bank') el.value = defaultBank || '';
                else if (m[1] === 'bank_account_id') el.value = defaultBankAccountId ? String(defaultBankAccountId) : '';
            }
            if (el.classList && el.classList.contains('payment-line-file-input')) {
                el.name = 'payment_line_files[' + lineIndex + '][]';
                el.value = '';
            }
        });
        tbody.appendChild(newRow);
        lineIndex++;
        toggleBankCell(newRow);
        newRow.querySelector('.payment-line-type').addEventListener('change', function() { toggleBankCell(newRow); });
        newRow.querySelector('.payment-line-amount').addEventListener('input', updateLinesTotal);
        var rmBtn = newRow.querySelector('.remove-payment-line-btn');
        if (rmBtn) rmBtn.addEventListener('click', function() { newRow.remove(); updateLinesTotal(); });
        updateLinesTotal();
    }

    document.querySelectorAll('.add-payment-line-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) { e.preventDefault(); addLine(); });
    });
    document.querySelectorAll('.payment-line-type').forEach(function(el) {
        el.addEventListener('change', function() { toggleBankCell(el.closest('tr')); });
    });
    document.querySelectorAll('.payment-line-amount').forEach(function(el) {
        el.addEventListener('input', updateLinesTotal);
    });
    document.querySelectorAll('.remove-payment-line-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            btn.closest('tr').remove();
            updateLinesTotal();
        });
    });
    document.querySelectorAll('#payment-lines-body tr').forEach(function(r) { toggleBankCell(r); });
    updateLinesTotal();
})();
</script>

<!-- Modal: totals mismatch warning -->
<div class="modal fade" id="payment-mismatch-modal" tabindex="-1" aria-labelledby="payment-mismatch-modal-label" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header alert-warning">
                <h5 class="modal-title" id="payment-mismatch-modal-label">
                    <?php echo htmlspecialchars($this->labelMismatchTitle ?? 'Los totales no coinciden'); ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo htmlspecialchars($this->labelMismatchCancel ?? 'Cancelar'); ?>"></button>
            </div>
            <div class="modal-body">
                <p class="mb-3"><?php echo htmlspecialchars($this->labelMismatchMessage ?? 'El total de Líneas de Pago no coincide con el total de Órdenes a aplicar. ¿Desea guardar de todos modos?'); ?></p>
                <p class="mb-2"><strong><?php echo htmlspecialchars($this->labelMismatchDifference ?? 'Diferencia'); ?>:</strong> <span id="payment-mismatch-difference-text">Q. 0.00</span></p>
                <label for="payment-mismatch-note-ta" class="form-label"><?php echo htmlspecialchars($this->labelMismatchNotePlaceholder ?? 'Nota (opcional)'); ?></label>
                <textarea class="form-control" id="payment-mismatch-note-ta" rows="4" placeholder="<?php echo htmlspecialchars($this->labelMismatchNotePlaceholder ?? 'Indique el motivo o nota...'); ?>"></textarea>
                <p class="small text-muted mt-2 mb-0"><?php echo htmlspecialchars($this->labelMismatchNoteHelp ?? 'Esta nota se enviará por correo al grupo Administración.'); ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo htmlspecialchars($this->labelMismatchCancel ?? 'Cancelar'); ?></button>
                <button type="button" class="btn btn-primary" id="payment-mismatch-proceed-btn"><?php echo htmlspecialchars($this->labelProceedSave ?? 'Sí, guardar'); ?></button>
            </div>
        </div>
    </div>
</div>
