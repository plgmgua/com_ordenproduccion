<?php
/**
 * Ajustes > Ajustes de Cotización: Encabezado, Términos y Condiciones, Pie de página (WYSIWYG) for PDF cotización.
 *
 * @package     Joomla.Site
 * @subpackage  com_ordenproduccion
 */

defined('_JEXEC') or die;

use Joomla\CMS\Editor\Editor;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

use Grimpsa\Component\Ordenproduccion\Site\Helper\CotizacionPdfHelper;

$app = Factory::getApplication();
HTMLHelper::_('behavior.core');
HTMLHelper::_('form.csrf');

// Ensure component language is loaded so labels translate (e.g. when included from Productos view)
$app->getLanguage()->load('com_ordenproduccion', JPATH_SITE . '/components/com_ordenproduccion');
$app->getLanguage()->load('com_ordenproduccion', JPATH_ADMINISTRATOR . '/components/com_ordenproduccion');

$settings = isset($this->cotizacionPdfSettings) && is_array($this->cotizacionPdfSettings)
    ? $this->cotizacionPdfSettings
    : ['format_version' => 1, 'logo_path' => '', 'logo_x' => 15, 'logo_y' => 15, 'logo_width' => 50, 'encabezado' => '', 'terminos_condiciones' => '', 'pie_pagina' => '', 'encabezado_x' => 15, 'encabezado_y' => 15, 'table_x' => 0, 'table_y' => 0, 'terminos_x' => 0, 'terminos_y' => 0, 'pie_x' => 0, 'pie_y' => 0];
$format_version = isset($settings['format_version']) ? max(1, min(2, (int) $settings['format_version'])) : 1;
$logo_path  = isset($settings['logo_path'])  ? $settings['logo_path']  : '';
$logo_x     = isset($settings['logo_x'])     ? (float) $settings['logo_x']     : 15;
$logo_y     = isset($settings['logo_y'])     ? (float) $settings['logo_y']     : 15;
$logo_width = isset($settings['logo_width']) ? (float) $settings['logo_width'] : 50;
$encabezado = isset($settings['encabezado']) ? $settings['encabezado'] : '';
$terminos = isset($settings['terminos_condiciones']) ? $settings['terminos_condiciones'] : '';
$pie = isset($settings['pie_pagina']) ? $settings['pie_pagina'] : '';
$encabezado_x = isset($settings['encabezado_x']) ? (float) $settings['encabezado_x'] : 15;
$encabezado_y = isset($settings['encabezado_y']) ? (float) $settings['encabezado_y'] : 15;
$table_x = isset($settings['table_x']) ? (float) $settings['table_x'] : 0;
$table_y = isset($settings['table_y']) ? (float) $settings['table_y'] : 0;
$terminos_x = isset($settings['terminos_x']) ? (float) $settings['terminos_x'] : 0;
$terminos_y = isset($settings['terminos_y']) ? (float) $settings['terminos_y'] : 0;
$pie_x = isset($settings['pie_x']) ? (float) $settings['pie_x'] : 0;
$pie_y = isset($settings['pie_y']) ? (float) $settings['pie_y'] : 0;

// Build preview URL for the current logo path
$logo_preview_url = '';
if (!empty($logo_path)) {
    if (preg_match('/^https?:\/\//i', $logo_path) || strpos($logo_path, '//') === 0) {
        $logo_preview_url = $logo_path; // already a full URL
    } else {
        $logo_preview_url = \Joomla\CMS\Uri\Uri::root() . ltrim($logo_path, '/');
    }
}

try {
    $editorName = $app->get('editor', 'tinymce');
    $editor = Editor::getInstance($editorName);
} catch (\Exception $e) {
    $editor = null;
}
$editorWidth = '100%';
$editorHeight = '280';
$editorCols = 75;
$editorRows = 20;
$editorButtons = true;
?>
<div class="card">
    <div class="card-header">
        <h2 class="card-title mb-0">
            <i class="fas fa-file-pdf"></i>
            <?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_TITLE'); ?>
        </h2>
    </div>
    <div class="card-body">
        <p class="text-muted mb-4">
            <?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_DESC'); ?>
        </p>

        <div class="alert alert-info mb-4">
            <h3 class="alert-heading h6 mb-2">
                <i class="fas fa-code"></i>
                <?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_VARS_HEADING'); ?>
            </h3>
            <p class="mb-2 small"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_VARS_DESC'); ?></p>
            <ul class="list-unstyled mb-0 small">
                <?php foreach (CotizacionPdfHelper::getPlaceholdersForUi() as $placeholder => $labelKey): ?>
                    <li><code><?php echo htmlspecialchars($placeholder, ENT_QUOTES, 'UTF-8'); ?></code> — <?php echo Text::_($labelKey); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <form action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=administracion.saveAjustesCotizacionPdf'); ?>" method="post" name="adminForm" id="ajustes-cotizacion-pdf-form" class="form-validate">
            <?php echo HTMLHelper::_('form.token'); ?>
            <?php if (!empty($this->returnUrlAjustesCotizacion)): ?>
                <input type="hidden" name="return_url" value="<?php echo htmlspecialchars($this->returnUrlAjustesCotizacion, ENT_QUOTES, 'UTF-8'); ?>" />
            <?php endif; ?>

            <!-- PDF format version -->
            <div class="mb-4">
                <label for="jform_format_version" class="form-label fw-bold">
                    <?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_FORMAT_VERSION'); ?>
                </label>
                <select name="jform[format_version]" id="jform_format_version" class="form-select" style="max-width: 22rem;">
                    <option value="1"<?php echo $format_version === 1 ? ' selected="selected"' : ''; ?>><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_FORMAT_1'); ?></option>
                    <option value="2"<?php echo $format_version === 2 ? ' selected="selected"' : ''; ?>><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_FORMAT_2'); ?></option>
                </select>
                <div class="form-text"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_FORMAT_VERSION_DESC'); ?></div>
            </div>

            <!-- ── Logo ──────────────────────────────────────────────────────── -->
            <div class="mb-4 p-3 border rounded bg-light">
                <label class="form-label fw-bold">
                    <i class="fas fa-image me-1"></i>
                    <?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_LOGO'); ?>
                </label>
                <p class="text-muted small mb-2">
                    <?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_LOGO_DESC'); ?>
                </p>

                <div class="mb-2">
                    <label for="jform_logo_path" class="form-label small mb-1">
                        <?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_LOGO_PATH'); ?>
                    </label>
                    <input type="text"
                           name="jform[logo_path]"
                           id="jform_logo_path"
                           class="form-control"
                           value="<?php echo htmlspecialchars($logo_path, ENT_QUOTES, 'UTF-8'); ?>"
                           placeholder="images/mi-logo.png" />
                    <div class="form-text"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_LOGO_PATH_HINT'); ?></div>
                </div>

                <div class="row g-2 mb-2">
                    <div class="col-auto">
                        <label for="jform_logo_x" class="form-label small mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_X'); ?></label>
                        <input type="number" step="0.1" min="0" name="jform[logo_x]" id="jform_logo_x"
                               class="form-control form-control-sm" style="width:5rem;"
                               value="<?php echo htmlspecialchars($logo_x, ENT_QUOTES, 'UTF-8'); ?>"
                               title="<?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_MM'); ?>" />
                    </div>
                    <div class="col-auto">
                        <label for="jform_logo_y" class="form-label small mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_Y'); ?></label>
                        <input type="number" step="0.1" min="0" name="jform[logo_y]" id="jform_logo_y"
                               class="form-control form-control-sm" style="width:5rem;"
                               value="<?php echo htmlspecialchars($logo_y, ENT_QUOTES, 'UTF-8'); ?>"
                               title="<?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_MM'); ?>" />
                    </div>
                    <div class="col-auto">
                        <label for="jform_logo_width" class="form-label small mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_LOGO_WIDTH'); ?></label>
                        <input type="number" step="0.1" min="1" name="jform[logo_width]" id="jform_logo_width"
                               class="form-control form-control-sm" style="width:5rem;"
                               value="<?php echo htmlspecialchars($logo_width, ENT_QUOTES, 'UTF-8'); ?>"
                               title="<?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_MM'); ?>" />
                    </div>
                </div>

                <?php if (!empty($logo_preview_url)): ?>
                <div class="mt-2">
                    <p class="small mb-1 text-muted"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_LOGO_PREVIEW'); ?></p>
                    <img src="<?php echo htmlspecialchars($logo_preview_url, ENT_QUOTES, 'UTF-8'); ?>"
                         alt="Logo preview" style="max-height:80px; max-width:200px; border:1px solid #dee2e6; padding:4px; background:#fff;" />
                </div>
                <?php endif; ?>
            </div>

            <!-- ── Encabezado ─────────────────────────────────────────────────── -->
            <div class="mb-4">
                <label for="jform_encabezado" class="form-label fw-bold">
                    <?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_ENCABEZADO'); ?>
                </label>
                <div class="row g-2 mb-2">
                    <div class="col-auto">
                        <label for="jform_encabezado_x" class="form-label small mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_X'); ?></label>
                        <input type="number" step="0.1" min="0" name="jform[encabezado_x]" id="jform_encabezado_x" class="form-control form-control-sm" style="width:5rem;" value="<?php echo htmlspecialchars($encabezado_x, ENT_QUOTES, 'UTF-8'); ?>" title="<?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_MM'); ?>" />
                    </div>
                    <div class="col-auto">
                        <label for="jform_encabezado_y" class="form-label small mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_Y'); ?></label>
                        <input type="number" step="0.1" min="0" name="jform[encabezado_y]" id="jform_encabezado_y" class="form-control form-control-sm" style="width:5rem;" value="<?php echo htmlspecialchars($encabezado_y, ENT_QUOTES, 'UTF-8'); ?>" title="<?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_MM'); ?>" />
                    </div>
                </div>
                <?php if ($editor): ?>
                    <?php echo $editor->display('jform[encabezado]', $encabezado, $editorWidth, $editorHeight, $editorCols, $editorRows, $editorButtons, 'jform_encabezado', null, null, []); ?>
                <?php else: ?>
                    <textarea name="jform[encabezado]" id="jform_encabezado" class="form-control" rows="<?php echo (int) $editorRows; ?>" cols="<?php echo (int) $editorCols; ?>"><?php echo htmlspecialchars($encabezado, ENT_QUOTES, 'UTF-8'); ?></textarea>
                <?php endif; ?>
            </div>

            <div class="mb-4">
                <label class="form-label fw-bold"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_TABLE_POS'); ?></label>
                <div class="row g-2">
                    <div class="col-auto">
                        <label for="jform_table_x" class="form-label small mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_X'); ?></label>
                        <input type="number" step="0.1" min="0" name="jform[table_x]" id="jform_table_x" class="form-control form-control-sm" style="width:5rem;" value="<?php echo htmlspecialchars($table_x, ENT_QUOTES, 'UTF-8'); ?>" title="<?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_0_FLOW'); ?>" />
                    </div>
                    <div class="col-auto">
                        <label for="jform_table_y" class="form-label small mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_Y'); ?></label>
                        <input type="number" step="0.1" min="0" name="jform[table_y]" id="jform_table_y" class="form-control form-control-sm" style="width:5rem;" value="<?php echo htmlspecialchars($table_y, ENT_QUOTES, 'UTF-8'); ?>" title="<?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_0_FLOW'); ?>" />
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <label for="jform_terminos_condiciones" class="form-label fw-bold">
                    <?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_TERMINOS'); ?>
                </label>
                <div class="row g-2 mb-2">
                    <div class="col-auto">
                        <label for="jform_terminos_x" class="form-label small mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_X'); ?></label>
                        <input type="number" step="0.1" min="0" name="jform[terminos_x]" id="jform_terminos_x" class="form-control form-control-sm" style="width:5rem;" value="<?php echo htmlspecialchars($terminos_x, ENT_QUOTES, 'UTF-8'); ?>" title="<?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_0_FLOW'); ?>" />
                    </div>
                    <div class="col-auto">
                        <label for="jform_terminos_y" class="form-label small mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_Y'); ?></label>
                        <input type="number" step="0.1" min="0" name="jform[terminos_y]" id="jform_terminos_y" class="form-control form-control-sm" style="width:5rem;" value="<?php echo htmlspecialchars($terminos_y, ENT_QUOTES, 'UTF-8'); ?>" title="<?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_0_FLOW'); ?>" />
                    </div>
                </div>
                <?php if ($editor): ?>
                    <?php echo $editor->display('jform[terminos_condiciones]', $terminos, $editorWidth, $editorHeight, $editorCols, $editorRows, $editorButtons, 'jform_terminos_condiciones', null, null, []); ?>
                <?php else: ?>
                    <textarea name="jform[terminos_condiciones]" id="jform_terminos_condiciones" class="form-control" rows="<?php echo (int) $editorRows; ?>" cols="<?php echo (int) $editorCols; ?>"><?php echo htmlspecialchars($terminos, ENT_QUOTES, 'UTF-8'); ?></textarea>
                <?php endif; ?>
            </div>

            <div class="mb-4">
                <label for="jform_pie_pagina" class="form-label fw-bold">
                    <?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_PIE'); ?>
                </label>
                <div class="row g-2 mb-2">
                    <div class="col-auto">
                        <label for="jform_pie_x" class="form-label small mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_X'); ?></label>
                        <input type="number" step="0.1" min="0" name="jform[pie_x]" id="jform_pie_x" class="form-control form-control-sm" style="width:5rem;" value="<?php echo htmlspecialchars($pie_x, ENT_QUOTES, 'UTF-8'); ?>" title="<?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_0_FLOW'); ?>" />
                    </div>
                    <div class="col-auto">
                        <label for="jform_pie_y" class="form-label small mb-0"><?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_Y'); ?></label>
                        <input type="number" step="0.1" min="0" name="jform[pie_y]" id="jform_pie_y" class="form-control form-control-sm" style="width:5rem;" value="<?php echo htmlspecialchars($pie_y, ENT_QUOTES, 'UTF-8'); ?>" title="<?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_POS_0_FLOW'); ?>" />
                    </div>
                </div>
                <?php if ($editor): ?>
                    <?php echo $editor->display('jform[pie_pagina]', $pie, $editorWidth, $editorHeight, $editorCols, $editorRows, $editorButtons, 'jform_pie_pagina', null, null, []); ?>
                <?php else: ?>
                    <textarea name="jform[pie_pagina]" id="jform_pie_pagina" class="form-control" rows="<?php echo (int) $editorRows; ?>" cols="<?php echo (int) $editorCols; ?>"><?php echo htmlspecialchars($pie, ENT_QUOTES, 'UTF-8'); ?></textarea>
                <?php endif; ?>
            </div>

            <div class="mt-3">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i>
                    <?php echo Text::_('COM_ORDENPRODUCCION_AJUSTES_COTIZACION_PDF_SAVE'); ?>
                </button>
            </div>
        </form>
    </div>
</div>
