<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_ordenproduccion
 *
 * @copyright   (C) 2025 Grimpsa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

$clients = $this->clients ?? [];
$canMerge = !empty($this->canMergeClients);
$canInitialize = !empty($this->canInitializeOpeningBalances);
$clientesOrdering = $this->clientesOrdering ?? 'name';
$clientesDirection = $this->clientesDirection ?? 'asc';
$clientesHideZero = !empty($this->clientesHideZero);
$clientesSalesAgent = $this->clientesSalesAgent ?? '';
$clientesClientName = $this->clientesClientName ?? '';
$clientesNit = $this->clientesNit ?? '';
$clientesSalesAgents = $this->clientesSalesAgents ?? [];
$clientesPagination = $this->clientesPagination ?? null;
$clientesTotal = (int) ($this->clientesTotal ?? 0);
$clientesLimit = max(5, min(100, (int) ($this->clientesLimit ?? 20)));
$clientesLimitStart = max(0, (int) ($this->clientesLimitStart ?? 0));
$clientesTotalSaldo = (float) ($this->clientesTotalSaldo ?? 0);
$clientesTotalCompras = (float) ($this->clientesTotalCompras ?? 0);
$clientesTotalOrders = (int) ($this->clientesTotalOrders ?? 0);
$showClientesSalesAgentFilter = !empty($this->clientesShowSalesAgentFilter);
$clientesSubtab = $this->clientesSubtab ?? 'estado_cuenta';
$emptyBucketSummary = ['count' => 0, 'total_value' => 0.0];
$clientesDiasCreditoBuckets = $this->clientesDiasCreditoBuckets ?? ['0_15' => $emptyBucketSummary, '16_30' => $emptyBucketSummary, '31_45' => $emptyBucketSummary, '45_plus' => $emptyBucketSummary];
$clientesDiasCreditoByClient = $this->clientesDiasCreditoByClient ?? [];
$clientesDiasCreditoByAgent = $this->clientesDiasCreditoByAgent ?? [];
$clientesDiasCreditoGroupedByAgent = $this->clientesDiasCreditoGroupedByAgent ?? [];
$clientesDiasCreditoOrdering = $this->clientesDiasCreditoOrdering ?? 'client';
$clientesDiasCreditoDirection = $this->clientesDiasCreditoDirection ?? 'asc';

function clientesBaseParams($clientesOrdering, $clientesDirection, $clientesHideZero, $clientesSalesAgent, $clientesClientName, $clientesNit, $clientesLimit, $subtab = 'estado_cuenta') {
    $params = ['option' => 'com_ordenproduccion', 'view' => 'administracion', 'tab' => 'clientes', 'subtab' => $subtab, 'filter_clientes_ordering' => $clientesOrdering, 'filter_clientes_direction' => $clientesDirection, 'clientes_limit' => $clientesLimit];
    if ($clientesHideZero) {
        $params['filter_clientes_hide_zero'] = 1;
    }
    if ($clientesSalesAgent !== '') {
        $params['filter_clientes_sales_agent'] = $clientesSalesAgent;
    }
    if ($clientesClientName !== '') {
        $params['filter_clientes_client'] = $clientesClientName;
    }
    if ($clientesNit !== '') {
        $params['filter_clientes_nit'] = $clientesNit;
    }
    return $params;
}
function clientesSortUrl($col, $currentOrdering, $currentDirection, $currentHideZero, $clientesSalesAgent = '', $clientesClientName = '', $clientesNit = '', $clientesLimit = 20, $subtab = 'estado_cuenta') {
    $dir = ($col === $currentOrdering && $currentDirection === 'asc') ? 'desc' : 'asc';
    $params = clientesBaseParams($col, $dir, $currentHideZero, $clientesSalesAgent, $clientesClientName, $clientesNit, $clientesLimit, $subtab);
    return \Joomla\CMS\Router\Route::_('index.php?' . http_build_query($params));
}

/**
 * Query params for Rango de días — preserves sort and agent filter.
 */
function diasCreditoBaseParams($ordering, $direction, $clientesSalesAgent)
{
    $params = [
        'option' => 'com_ordenproduccion',
        'view' => 'administracion',
        'tab' => 'clientes',
        'subtab' => 'dias_credito',
        'filter_dias_credito_ordering' => $ordering,
        'filter_dias_credito_direction' => $direction,
    ];
    if ($clientesSalesAgent !== '') {
        $params['filter_clientes_sales_agent'] = $clientesSalesAgent;
    }
    return $params;
}

function diasCreditoSortUrl($col, $currentOrdering, $currentDirection, $clientesSalesAgent = '')
{
    $dir = ($col === $currentOrdering && $currentDirection === 'asc') ? 'desc' : 'asc';
    $params = diasCreditoBaseParams($col, $dir, $clientesSalesAgent);

    return \Joomla\CMS\Router\Route::_('index.php?' . http_build_query($params));
}

function safeEscape($value, $default = '')
{
    if (is_string($value) && $value !== '') {
        return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    }
    return $default;
}
?>

<style>
#com-op-clientes.clientes-section {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.clientes-header {
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 2px solid #e9ecef;
}

.clientes-title {
    color: #495057;
    font-size: 24px;
    font-weight: 600;
    margin: 0;
}

.clientes-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
}

.clientes-table th,
.clientes-table td {
    padding: 12px 16px;
    text-align: left;
    border-bottom: 1px solid #e9ecef;
}

.clientes-table th {
    background: #f8f9fa;
    font-weight: 600;
    color: #495057;
}

.clientes-table th a.clientes-sort-link {
    color: #0d6efd;
    cursor: pointer;
}
.clientes-table th a.clientes-sort-link:hover {
    color: #0a58ca;
    text-decoration: underline !important;
}

.clientes-table tbody tr:hover {
    background: #f8f9fa;
}

.clientes-table .col-client-name {
    min-width: 200px;
}

.clientes-table .col-nit {
    min-width: 120px;
}

.clientes-table .col-order-count {
    width: 100px;
    text-align: center;
}

.clientes-table .col-total-value,
.clientes-table .col-compras,
.clientes-table .col-registrado,
.clientes-table .col-verificado,
.clientes-table .col-saldo {
    min-width: 120px;
    text-align: right;
}

.clientes-table .col-saldo {
    font-weight: 600;
}

.clientes-empty {
    padding: 40px;
    text-align: center;
    color: #6c757d;
    font-size: 16px;
}

.clientes-merge-actions {
    margin-bottom: 20px;
}

.clientes-table .col-select {
    width: 40px;
    text-align: center;
}

.clientes-filter-item {
    display: flex;
    flex-direction: column;
    gap: 4px;
    font-weight: 500;
    color: #495057;
}

.clientes-filter-item .form-control,
.clientes-filter-item .form-select {
    font-size: 14px;
}

.clientes-pagination {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
}

#mergeModal .merge-target-option {
    cursor: pointer;
    padding: 12px 16px;
    border: 2px solid #dee2e6;
    border-radius: 8px;
    margin-bottom: 10px;
    transition: border-color 0.2s, background 0.2s;
    display: flex;
    align-items: center;
    gap: 12px;
}

#mergeModal .merge-target-option::before {
    content: '';
    flex-shrink: 0;
    width: 20px;
    height: 20px;
    border: 2px solid #adb5bd;
    border-radius: 50%;
    background: #fff;
    transition: border-color 0.2s, background 0.2s;
}

#mergeModal .merge-target-option:hover {
    border-color: #667eea;
    background: rgba(102, 126, 234, 0.06);
}

#mergeModal .merge-target-option:hover::before {
    border-color: #667eea;
}

#mergeModal .merge-target-option.selected {
    border-color: #667eea;
    background: rgba(102, 126, 234, 0.12);
}

#mergeModal .merge-target-option.selected::before {
    border-color: #667eea;
    background: #667eea;
    box-shadow: inset 0 0 0 3px #fff;
}

.clientes-subtabs {
    display: flex;
    gap: 0;
    border-bottom: 2px solid #dee2e6;
    margin-bottom: 20px;
}
.clientes-subtab {
    padding: 8px 16px;
    color: #666;
    text-decoration: none;
    font-weight: 600;
    font-size: 14px;
    border-bottom: 3px solid transparent;
    margin-bottom: -2px;
    transition: all 0.2s;
}
.clientes-subtab:hover {
    color: #667eea;
    text-decoration: none;
}
.clientes-subtab.active {
    color: #667eea;
    border-bottom-color: #667eea;
}
.dias-credito-summary-table {
    width: 100%;
    max-width: 700px;
    border-collapse: collapse;
    font-size: 14px;
}
.dias-credito-summary-table th,
.dias-credito-summary-table td {
    padding: 12px 16px;
    text-align: center;
    border: 1px solid #e9ecef;
}
.dias-credito-summary-table th a.dias-credito-sort-link {
    color: #0d6efd;
    cursor: pointer;
}
.dias-credito-summary-table th a.dias-credito-sort-link:hover {
    color: #0a58ca;
    text-decoration: underline !important;
}

.dias-credito-summary-table th {
    background: #f8f9fa;
    font-weight: 600;
    color: #495057;
}
.dias-credito-summary-table td {
    font-weight: 600;
}
.dias-credito-summary-table .bucket-count {
    font-size: 12px;
    font-weight: normal;
    color: #6c757d;
    margin-top: 4px;
}
.dias-credito-summary-table .dias-credito-total-col {
    background: #f0f4f8;
    font-weight: 700;
}
.dias-credito-summary-table .dias-credito-col-toggle {
    min-width: 220px;
    text-align: left;
    vertical-align: middle;
    white-space: nowrap;
}
.dias-credito-summary-table .col-client-name {
    min-width: 220px;
    text-align: left;
}
.dias-credito-summary-table tfoot .dias-credito-grand-total-label {
    font-weight: 700;
    background: #e9ecef;
    padding: 12px 16px;
}
.dias-credito-summary-table tfoot td {
    font-weight: 700;
    background: #e9ecef;
    border-top: 2px solid #dee2e6;
}
.dias-credito-expand-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    padding: 0;
    background: #f8f9fa;
    border: 1px solid #dee2e6;
    border-radius: 6px;
    cursor: pointer;
    color: #495057;
}
.dias-credito-expand-btn:hover {
    background: #e9ecef;
    color: #667eea;
}
.dias-credito-agent-row td {
    font-weight: 500;
    background: #f8f9fa;
}
.dias-credito-detail-row td {
    background: #fafbfc;
}
.dias-credito-detail-indent {
    padding-left: 2rem;
}
.dias-credito-by-client-wrap {
    margin-top: 16px;
}
.dias-credito-by-client-toggle {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 6px 12px;
    background: #f8f9fa;
    border: 1px solid #dee2e6;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    color: #495057;
}
.dias-credito-by-client-toggle:hover {
    background: #e9ecef;
}
.dias-credito-by-client-toggle i.fa-plus,
.dias-credito-by-client-toggle i.fa-minus {
    width: 16px;
    text-align: center;
}
.dias-credito-by-client-table-wrap {
    display: none;
    margin-top: 12px;
    padding: 12px;
    background: #f8f9fa;
    border-radius: 8px;
    border: 1px solid #e9ecef;
}
.dias-credito-by-client-table-wrap.expanded {
    display: block;
}
.dias-credito-by-client-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}
.dias-credito-by-client-table th,
.dias-credito-by-client-table td {
    padding: 8px 12px;
    border-bottom: 1px solid #dee2e6;
}
.dias-credito-by-client-table th {
    background: #e9ecef;
    font-weight: 600;
    color: #495057;
    text-align: center;
}
.dias-credito-by-client-table th.col-client-name,
.dias-credito-by-client-table td.col-client-name {
    text-align: left;
    min-width: 160px;
}
.dias-credito-by-client-table td:not(.col-client-name) {
    text-align: center;
}
.dias-credito-by-client-table .bucket-count {
    font-size: 12px;
    font-weight: normal;
    color: #6c757d;
    margin-top: 2px;
}
.dias-credito-by-client-table .dias-credito-total-col {
    background: #f0f4f8;
    font-weight: 600;
}
</style>

<div id="com-op-clientes" class="clientes-section">
    <div class="clientes-header">
        <h2 class="clientes-title">
            <i class="fas fa-users"></i>
            <?php echo Text::_('COM_ORDENPRODUCCION_TAB_ESTADO_DE_CUENTA'); ?>
        </h2>
        <?php
        $subtabBase = ['option' => 'com_ordenproduccion', 'view' => 'administracion', 'tab' => 'clientes'];
        if ($clientesSalesAgent !== '') {
            $subtabBase['filter_clientes_sales_agent'] = $clientesSalesAgent;
        }
        $subtabEstadoUrl = Route::_('index.php?' . http_build_query($subtabBase + ['subtab' => 'estado_cuenta']));
        $subtabDiasUrl = Route::_('index.php?' . http_build_query($subtabBase + ['subtab' => 'dias_credito']));
        ?>
        <div class="clientes-subtabs">
            <a href="<?php echo $subtabEstadoUrl; ?>"
               class="clientes-subtab <?php echo $clientesSubtab === 'estado_cuenta' ? 'active' : ''; ?>">
                <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_SUBTAB_ESTADO_CUENTA'); ?>
            </a>
            <a href="<?php echo $subtabDiasUrl; ?>"
               class="clientes-subtab <?php echo $clientesSubtab === 'dias_credito' ? 'active' : ''; ?>">
                <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_SUBTAB_DIAS_CREDITO'); ?>
            </a>
        </div>
        <?php if ($clientesSubtab === 'estado_cuenta') : ?>
        <form method="get" action="<?php echo Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=clientes&subtab=estado_cuenta'); ?>" class="clientes-filters-form mb-3">
            <input type="hidden" name="option" value="com_ordenproduccion" />
            <input type="hidden" name="view" value="administracion" />
            <input type="hidden" name="tab" value="clientes" />
            <input type="hidden" name="subtab" value="estado_cuenta" />
            <input type="hidden" name="filter_clientes_ordering" value="<?php echo safeEscape($clientesOrdering); ?>" />
            <input type="hidden" name="filter_clientes_direction" value="<?php echo safeEscape($clientesDirection); ?>" />
            <input type="hidden" name="clientes_limit" value="<?php echo (int) $clientesLimit; ?>" />
            <?php if ($clientesHideZero) : ?><input type="hidden" name="filter_clientes_hide_zero" value="1" /><?php endif; ?>
            <div class="clientes-filter-bar d-flex flex-wrap align-items-end gap-3">
                <?php if ($showClientesSalesAgentFilter) : ?>
                <label class="clientes-filter-item">
                    <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_FILTER_SALES_AGENT'); ?>
                    <select name="filter_clientes_sales_agent" class="form-select form-select-sm" style="min-width: 180px;">
                        <option value=""><?php echo Text::_('COM_ORDENPRODUCCION_REPORTES_ALL_SALES_AGENTS'); ?></option>
                        <?php foreach ($clientesSalesAgents as $agent) : ?>
                            <option value="<?php echo safeEscape($agent); ?>" <?php echo $clientesSalesAgent === $agent ? 'selected="selected"' : ''; ?>><?php echo safeEscape($agent); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <?php endif; ?>
                <label class="clientes-filter-item">
                    <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_FILTER_CLIENT'); ?>
                    <input type="text" name="filter_clientes_client" class="form-control form-control-sm" value="<?php echo safeEscape($clientesClientName); ?>" placeholder="<?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_FILTER_CLIENT_PLACEHOLDER'); ?>" style="min-width: 200px;" />
                </label>
                <label class="clientes-filter-item">
                    <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_FILTER_NIT'); ?>
                    <input type="text" name="filter_clientes_nit" class="form-control form-control-sm" value="<?php echo safeEscape($clientesNit); ?>" placeholder="<?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_FILTER_NIT_PLACEHOLDER'); ?>" style="min-width: 140px;" />
                </label>
                <button type="submit" class="btn btn-sm btn-primary">
                    <i class="fas fa-search"></i>
                    <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_FILTER_BTN'); ?>
                </button>
                <?php
                $baseParams = clientesBaseParams($clientesOrdering, $clientesDirection, false, $clientesSalesAgent, $clientesClientName, $clientesNit, $clientesLimit, 'estado_cuenta');
                $hideZeroUrl = Route::_('index.php?' . http_build_query($baseParams + ['filter_clientes_hide_zero' => 1]));
                $showAllParams = clientesBaseParams($clientesOrdering, $clientesDirection, false, $clientesSalesAgent, $clientesClientName, $clientesNit, $clientesLimit, 'estado_cuenta');
                $showAllUrl = Route::_('index.php?' . http_build_query($showAllParams));
                ?>
                <a href="<?php echo $clientesHideZero ? $showAllUrl : $hideZeroUrl; ?>"
                   class="btn btn-sm <?php echo $clientesHideZero ? 'btn-primary' : 'btn-outline-secondary'; ?>"
                   title="<?php echo $clientesHideZero ? Text::_('COM_ORDENPRODUCCION_CLIENTES_SHOW_ALL_TIP') : Text::_('COM_ORDENPRODUCCION_CLIENTES_HIDE_ZERO_TIP'); ?>">
                    <i class="fas fa-filter"></i>
                    <?php echo $clientesHideZero ? Text::_('COM_ORDENPRODUCCION_CLIENTES_SHOW_ALL') : Text::_('COM_ORDENPRODUCCION_CLIENTES_HIDE_ZERO'); ?>
                </a>
            </div>
        </form>
        <?php if (($canMerge || $canInitialize) && !empty($clients)) : ?>
        <div class="clientes-merge-actions mt-3 d-flex flex-wrap gap-2">
            <?php if ($canMerge) : ?>
            <button type="button" class="btn btn-primary" id="btn-merge-clients" disabled title="<?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_MERGE_SELECT_TIP'); ?>">
                <i class="fas fa-compress-arrows-alt"></i>
                <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_MERGE_BTN'); ?>
            </button>
            <?php endif; ?>
            <?php if ($canInitialize) : ?>
            <form method="post" action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=administracion.initializeOpeningBalances'); ?>" class="d-inline">
                <?php echo HTMLHelper::_('form.token'); ?>
                <button type="submit" class="btn btn-outline-primary" title="<?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_INITIALIZE_TIP'); ?>">
                    <i class="fas fa-calculator"></i>
                    <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_INITIALIZE_BTN'); ?>
                </button>
            </form>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <?php if (!empty($clients)) : ?>
        <form method="post" action="<?php echo Route::_('index.php?option=com_ordenproduccion&task=administracion.mergeClients'); ?>" id="clientes-merge-form" style="display:none;">
            <?php echo HTMLHelper::_('form.token'); ?>
            <div id="merge-form-fields"></div>
        </form>
        <div class="table-responsive">
                <table class="clientes-table">
                    <thead>
                        <tr>
                            <?php if ($canMerge) : ?>
                            <th class="col-select"><input type="checkbox" id="select-all-clients" title="<?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_SELECT_ALL'); ?>"></th>
                            <?php endif; ?>
                            <th class="col-client-name"><a href="<?php echo clientesSortUrl('name', $clientesOrdering, $clientesDirection, $clientesHideZero, $clientesSalesAgent, $clientesClientName, $clientesNit, $clientesLimit, 'estado_cuenta'); ?>" class="clientes-sort-link text-decoration-none<?php echo $clientesOrdering === 'name' ? ' fw-bold' : ''; ?>" title="<?php echo safeEscape(Text::_('COM_ORDENPRODUCCION_CLIENTES_SORT_BY_NAME')); ?>"><?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_COL_CLIENT_NAME'); ?><?php if ($clientesOrdering === 'name') : ?><i class="fas fa-sort-<?php echo $clientesDirection === 'asc' ? 'down' : 'up'; ?> ms-1" aria-hidden="true"></i><?php else : ?><i class="fas fa-sort ms-1 text-muted opacity-50" style="font-size:0.85em;" aria-hidden="true"></i><?php endif; ?></a></th>
                            <th class="col-compras"><a href="<?php echo clientesSortUrl('compras', $clientesOrdering, $clientesDirection, $clientesHideZero, $clientesSalesAgent, $clientesClientName, $clientesNit, $clientesLimit, 'estado_cuenta'); ?>" class="clientes-sort-link text-decoration-none<?php echo $clientesOrdering === 'compras' ? ' fw-bold' : ''; ?>" title="<?php echo safeEscape(Text::_('COM_ORDENPRODUCCION_CLIENTES_SORT_BY_COMPRAS')); ?>"><?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_COL_COMPRAS'); ?><?php if ($clientesOrdering === 'compras') : ?><i class="fas fa-sort-<?php echo $clientesDirection === 'asc' ? 'down' : 'up'; ?> ms-1" aria-hidden="true"></i><?php else : ?><i class="fas fa-sort ms-1 text-muted opacity-50" style="font-size:0.85em;" aria-hidden="true"></i><?php endif; ?></a></th>
                            <th class="col-registrado"><?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_COL_REGISTRADO'); ?></th>
                            <th class="col-verificado"><?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_COL_VERIFICADO'); ?></th>
                            <th class="col-saldo"><a href="<?php echo clientesSortUrl('saldo', $clientesOrdering, $clientesDirection, $clientesHideZero, $clientesSalesAgent, $clientesClientName, $clientesNit, $clientesLimit, 'estado_cuenta'); ?>" class="clientes-sort-link text-decoration-none<?php echo $clientesOrdering === 'saldo' ? ' fw-bold' : ''; ?>" title="<?php echo safeEscape(Text::_('COM_ORDENPRODUCCION_CLIENTES_SORT_BY_SALDO')); ?>"><?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_COL_SALDO'); ?><?php if ($clientesOrdering === 'saldo') : ?><i class="fas fa-sort-<?php echo $clientesDirection === 'asc' ? 'down' : 'up'; ?> ms-1" aria-hidden="true"></i><?php else : ?><i class="fas fa-sort ms-1 text-muted opacity-50" style="font-size:0.85em;" aria-hidden="true"></i><?php endif; ?></a></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($clients as $idx => $client) :
                            $saldo = (float) ($client->saldo ?? 0);
                            $saldoDisplay = -1 * $saldo;
                            $compras = (float) ($client->compras ?? 0);
                            $registrado = (float) ($client->registrado_from_jan2026 ?? 0);
                            $verificado = (float) ($client->verificado_from_jan2026 ?? 0);
                            $cn = $client->client_name ?? '';
                            $nit = $client->nit ?? '';
                        ?>
                            <tr>
                                <?php if ($canMerge) : ?>
                                <td class="col-select">
                                    <input type="checkbox" class="client-merge-cb" value=""
                                        data-client-name="<?php echo safeEscape($cn); ?>"
                                        data-nit="<?php echo safeEscape($nit); ?>">
                                </td>
                                <?php endif; ?>
                                <td class="col-client-name"><?php echo safeEscape($cn); ?></td>
                                <td class="col-compras">Q.<?php echo number_format($compras, 2); ?></td>
                                <td class="col-registrado">Q.<?php echo number_format($registrado, 2); ?></td>
                                <td class="col-verificado">Q.<?php echo number_format($verificado, 2); ?></td>
                                <td class="col-saldo">Q.<?php echo number_format($saldoDisplay, 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php if ($clientesPagination && $clientesTotal > $clientesLimit) : ?>
        <div class="clientes-pagination mt-2"><?php echo $clientesPagination->getListFooter(); ?></div>
        <?php endif; ?>
    <?php else : ?>
        <div class="clientes-empty">
            <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_NO_CLIENTS'); ?>
        </div>
    <?php endif; ?>
        <?php endif; ?>

    <?php if ($clientesSubtab === 'dias_credito') : ?>
        <form method="get" action="<?php echo Route::_('index.php?option=com_ordenproduccion&view=administracion&tab=clientes&subtab=dias_credito'); ?>" class="clientes-filters-form mb-4">
            <input type="hidden" name="option" value="com_ordenproduccion" />
            <input type="hidden" name="view" value="administracion" />
            <input type="hidden" name="tab" value="clientes" />
            <input type="hidden" name="subtab" value="dias_credito" />
            <input type="hidden" name="filter_dias_credito_ordering" value="<?php echo safeEscape($clientesDiasCreditoOrdering); ?>" />
            <input type="hidden" name="filter_dias_credito_direction" value="<?php echo safeEscape($clientesDiasCreditoDirection); ?>" />
            <?php if ($showClientesSalesAgentFilter) : ?>
            <label class="clientes-filter-item d-inline-block me-3">
                <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_FILTER_SALES_AGENT'); ?>
                <select name="filter_clientes_sales_agent" class="form-select form-select-sm" style="min-width: 180px;">
                    <option value=""><?php echo Text::_('COM_ORDENPRODUCCION_REPORTES_ALL_SALES_AGENTS'); ?></option>
                    <?php foreach ($clientesSalesAgents as $agent) : ?>
                        <option value="<?php echo safeEscape($agent); ?>" <?php echo $clientesSalesAgent === $agent ? 'selected="selected"' : ''; ?>><?php echo safeEscape($agent); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <?php endif; ?>
            <button type="submit" class="btn btn-sm btn-primary">
                <i class="fas fa-search"></i>
                <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_FILTER_BTN'); ?>
            </button>
        </form>
        <p class="text-muted mb-3"><?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_INTRO'); ?></p>
        <?php
        $bucketLabels = [
            '0_15'   => Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_0_15'),
            '16_30'  => Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_16_30'),
            '31_45'  => Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_31_45'),
            '45_plus' => Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_45_PLUS'),
        ];
        $b0 = $clientesDiasCreditoBuckets['0_15'] ?? ['count' => 0, 'total_value' => 0.0];
        $b1 = $clientesDiasCreditoBuckets['16_30'] ?? ['count' => 0, 'total_value' => 0.0];
        $b2 = $clientesDiasCreditoBuckets['31_45'] ?? ['count' => 0, 'total_value' => 0.0];
        $b3 = $clientesDiasCreditoBuckets['45_plus'] ?? ['count' => 0, 'total_value' => 0.0];
        $totalValue = (float)$b0['total_value'] + (float)$b1['total_value'] + (float)$b2['total_value'] + (float)$b3['total_value'];
        $totalCount = (int)$b0['count'] + (int)$b1['count'] + (int)$b2['count'] + (int)$b3['count'];
        $hasAny = $totalCount > 0;
        // Group client rows by sales agent (pre-sorted per agent in the view)
        $clientsByAgent = !empty($clientesDiasCreditoGroupedByAgent)
            ? $clientesDiasCreditoGroupedByAgent
            : [];
        if (empty($clientsByAgent)) {
            foreach ($clientesDiasCreditoByClient as $row) {
                $key = isset($row->sales_agent) ? (string) $row->sales_agent : (string) $clientesSalesAgent;
                if (!isset($clientsByAgent[$key])) {
                    $clientsByAgent[$key] = [];
                }
                $clientsByAgent[$key][] = $row;
            }
        }
        $showAgentLevel = !empty($clientesDiasCreditoByAgent);
        ?>
        <div class="table-responsive">
            <table class="dias-credito-summary-table" id="dias-credito-unified-table">
                <thead>
                    <tr>
                        <th class="dias-credito-col-toggle">
                            <a href="<?php echo diasCreditoSortUrl('client', $clientesDiasCreditoOrdering, $clientesDiasCreditoDirection, $clientesSalesAgent); ?>" class="dias-credito-sort-link text-decoration-none<?php echo $clientesDiasCreditoOrdering === 'client' ? ' fw-bold' : ''; ?>" title="<?php echo safeEscape(Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_SORT_CLIENT')); ?>">
                                <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_COL_CLIENT'); ?>
                                <?php if ($clientesDiasCreditoOrdering === 'client') : ?><i class="fas fa-sort-<?php echo $clientesDiasCreditoDirection === 'asc' ? 'down' : 'up'; ?> ms-1" aria-hidden="true"></i><?php else : ?><i class="fas fa-sort ms-1 text-muted opacity-50" style="font-size:0.85em;" aria-hidden="true"></i><?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="<?php echo diasCreditoSortUrl('0_15', $clientesDiasCreditoOrdering, $clientesDiasCreditoDirection, $clientesSalesAgent); ?>" class="dias-credito-sort-link text-decoration-none<?php echo $clientesDiasCreditoOrdering === '0_15' ? ' fw-bold' : ''; ?>" title="<?php echo safeEscape(Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_SORT_BUCKET')); ?>">
                                <?php echo $bucketLabels['0_15']; ?>
                                <?php if ($clientesDiasCreditoOrdering === '0_15') : ?><i class="fas fa-sort-<?php echo $clientesDiasCreditoDirection === 'asc' ? 'down' : 'up'; ?> ms-1" aria-hidden="true"></i><?php else : ?><i class="fas fa-sort ms-1 text-muted opacity-50" style="font-size:0.85em;" aria-hidden="true"></i><?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="<?php echo diasCreditoSortUrl('16_30', $clientesDiasCreditoOrdering, $clientesDiasCreditoDirection, $clientesSalesAgent); ?>" class="dias-credito-sort-link text-decoration-none<?php echo $clientesDiasCreditoOrdering === '16_30' ? ' fw-bold' : ''; ?>" title="<?php echo safeEscape(Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_SORT_BUCKET')); ?>">
                                <?php echo $bucketLabels['16_30']; ?>
                                <?php if ($clientesDiasCreditoOrdering === '16_30') : ?><i class="fas fa-sort-<?php echo $clientesDiasCreditoDirection === 'asc' ? 'down' : 'up'; ?> ms-1" aria-hidden="true"></i><?php else : ?><i class="fas fa-sort ms-1 text-muted opacity-50" style="font-size:0.85em;" aria-hidden="true"></i><?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="<?php echo diasCreditoSortUrl('31_45', $clientesDiasCreditoOrdering, $clientesDiasCreditoDirection, $clientesSalesAgent); ?>" class="dias-credito-sort-link text-decoration-none<?php echo $clientesDiasCreditoOrdering === '31_45' ? ' fw-bold' : ''; ?>" title="<?php echo safeEscape(Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_SORT_BUCKET')); ?>">
                                <?php echo $bucketLabels['31_45']; ?>
                                <?php if ($clientesDiasCreditoOrdering === '31_45') : ?><i class="fas fa-sort-<?php echo $clientesDiasCreditoDirection === 'asc' ? 'down' : 'up'; ?> ms-1" aria-hidden="true"></i><?php else : ?><i class="fas fa-sort ms-1 text-muted opacity-50" style="font-size:0.85em;" aria-hidden="true"></i><?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="<?php echo diasCreditoSortUrl('45_plus', $clientesDiasCreditoOrdering, $clientesDiasCreditoDirection, $clientesSalesAgent); ?>" class="dias-credito-sort-link text-decoration-none<?php echo $clientesDiasCreditoOrdering === '45_plus' ? ' fw-bold' : ''; ?>" title="<?php echo safeEscape(Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_SORT_BUCKET')); ?>">
                                <?php echo $bucketLabels['45_plus']; ?>
                                <?php if ($clientesDiasCreditoOrdering === '45_plus') : ?><i class="fas fa-sort-<?php echo $clientesDiasCreditoDirection === 'asc' ? 'down' : 'up'; ?> ms-1" aria-hidden="true"></i><?php else : ?><i class="fas fa-sort ms-1 text-muted opacity-50" style="font-size:0.85em;" aria-hidden="true"></i><?php endif; ?>
                            </a>
                        </th>
                        <th class="dias-credito-total-col">
                            <a href="<?php echo diasCreditoSortUrl('total', $clientesDiasCreditoOrdering, $clientesDiasCreditoDirection, $clientesSalesAgent); ?>" class="dias-credito-sort-link text-decoration-none<?php echo $clientesDiasCreditoOrdering === 'total' ? ' fw-bold' : ''; ?>" title="<?php echo safeEscape(Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_SORT_TOTAL')); ?>">
                                <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_TOTAL'); ?>
                                <?php if ($clientesDiasCreditoOrdering === 'total') : ?><i class="fas fa-sort-<?php echo $clientesDiasCreditoDirection === 'asc' ? 'down' : 'up'; ?> ms-1" aria-hidden="true"></i><?php else : ?><i class="fas fa-sort ms-1 text-muted opacity-50" style="font-size:0.85em;" aria-hidden="true"></i><?php endif; ?>
                            </a>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($showAgentLevel) : ?>
                        <?php foreach ($clientesDiasCreditoByAgent as $agentIdx => $agentRow) : ?>
                            <?php
                            $agentName = $agentRow->sales_agent ?? '';
                            $agentClients = $clientsByAgent[$agentName] ?? [];
                            $a0 = (int)($agentRow->count_0_15 ?? 0);
                            $a1 = (int)($agentRow->count_16_30 ?? 0);
                            $a2 = (int)($agentRow->count_31_45 ?? 0);
                            $a3 = (int)($agentRow->count_45_plus ?? 0);
                            $agentTotalVal = (float)($agentRow->total_value_0_15 ?? 0) + (float)($agentRow->total_value_16_30 ?? 0) + (float)($agentRow->total_value_31_45 ?? 0) + (float)($agentRow->total_value_45_plus ?? 0);
                            $agentTotalCnt = (int)($agentRow->order_count ?? 0);
                            ?>
                            <tr class="dias-credito-agent-row" data-agent-idx="<?php echo (int) $agentIdx; ?>">
                                <td class="dias-credito-col-toggle">
                                    <button type="button" class="dias-credito-expand-btn dias-credito-agent-toggle" data-agent-idx="<?php echo (int) $agentIdx; ?>" aria-expanded="false" title="<?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_BY_CLIENT_TOGGLE'); ?>">
                                        <i class="fas fa-plus" aria-hidden="true"></i>
                                    </button>
                                    <?php echo safeEscape($agentName); ?>
                                </td>
                                <td>
                                    Q.<?php echo number_format((float)($agentRow->total_value_0_15 ?? 0), 2); ?>
                                    <div class="bucket-count"><?php echo $a0; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                                </td>
                                <td>
                                    Q.<?php echo number_format((float)($agentRow->total_value_16_30 ?? 0), 2); ?>
                                    <div class="bucket-count"><?php echo $a1; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                                </td>
                                <td>
                                    Q.<?php echo number_format((float)($agentRow->total_value_31_45 ?? 0), 2); ?>
                                    <div class="bucket-count"><?php echo $a2; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                                </td>
                                <td>
                                    Q.<?php echo number_format((float)($agentRow->total_value_45_plus ?? 0), 2); ?>
                                    <div class="bucket-count"><?php echo $a3; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                                </td>
                                <td class="dias-credito-total-col">
                                    Q.<?php echo number_format($agentTotalVal, 2); ?>
                                    <div class="bucket-count"><?php echo $agentTotalCnt; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                                </td>
                            </tr>
                            <?php foreach ($agentClients as $row) : ?>
                            <tr class="dias-credito-detail-row" data-agent-idx="<?php echo (int) $agentIdx; ?>" style="display: none;">
                                <td class="col-client-name dias-credito-detail-indent"><?php echo safeEscape($row->client_name ?? ''); ?></td>
                                <td>
                                    Q.<?php echo number_format((float)($row->total_value_0_15 ?? 0), 2); ?>
                                    <div class="bucket-count"><?php echo (int)($row->count_0_15 ?? 0); ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                                </td>
                                <td>
                                    Q.<?php echo number_format((float)($row->total_value_16_30 ?? 0), 2); ?>
                                    <div class="bucket-count"><?php echo (int)($row->count_16_30 ?? 0); ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                                </td>
                                <td>
                                    Q.<?php echo number_format((float)($row->total_value_31_45 ?? 0), 2); ?>
                                    <div class="bucket-count"><?php echo (int)($row->count_31_45 ?? 0); ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                                </td>
                                <td>
                                    Q.<?php echo number_format((float)($row->total_value_45_plus ?? 0), 2); ?>
                                    <div class="bucket-count"><?php echo (int)($row->count_45_plus ?? 0); ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                                </td>
                                <td class="dias-credito-total-col">
                                    Q.<?php echo number_format((float)($row->total_value ?? 0), 2); ?>
                                    <div class="bucket-count"><?php echo (int)($row->order_count ?? 0); ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    <?php else : ?>
                    <tr class="dias-credito-summary-row">
                        <td class="dias-credito-col-toggle">
                            <button type="button" class="dias-credito-expand-btn" id="dias-credito-toggle-by-client" aria-expanded="false" title="<?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_BY_CLIENT_TOGGLE'); ?>">
                                <i class="fas fa-plus" id="dias-credito-toggle-icon" aria-hidden="true"></i>
                            </button>
                        </td>
                        <td>
                            Q.<?php echo number_format((float)$b0['total_value'], 2); ?>
                            <div class="bucket-count"><?php echo (int)$b0['count']; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                        </td>
                        <td>
                            Q.<?php echo number_format((float)$b1['total_value'], 2); ?>
                            <div class="bucket-count"><?php echo (int)$b1['count']; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                        </td>
                        <td>
                            Q.<?php echo number_format((float)$b2['total_value'], 2); ?>
                            <div class="bucket-count"><?php echo (int)$b2['count']; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                        </td>
                        <td>
                            Q.<?php echo number_format((float)$b3['total_value'], 2); ?>
                            <div class="bucket-count"><?php echo (int)$b3['count']; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                        </td>
                        <td class="dias-credito-total-col">
                            Q.<?php echo number_format($totalValue, 2); ?>
                            <div class="bucket-count"><?php echo $totalCount; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                        </td>
                    </tr>
                    <?php if (!empty($clientesDiasCreditoByClient)) : ?>
                        <?php foreach ($clientesDiasCreditoByClient as $row) : ?>
                        <tr class="dias-credito-detail-row" style="display: none;">
                            <td class="col-client-name"><?php echo safeEscape($row->client_name ?? ''); ?></td>
                            <td>
                                Q.<?php echo number_format((float)($row->total_value_0_15 ?? 0), 2); ?>
                                <div class="bucket-count"><?php echo (int)($row->count_0_15 ?? 0); ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                            </td>
                            <td>
                                Q.<?php echo number_format((float)($row->total_value_16_30 ?? 0), 2); ?>
                                <div class="bucket-count"><?php echo (int)($row->count_16_30 ?? 0); ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                            </td>
                            <td>
                                Q.<?php echo number_format((float)($row->total_value_31_45 ?? 0), 2); ?>
                                <div class="bucket-count"><?php echo (int)($row->count_31_45 ?? 0); ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                            </td>
                            <td>
                                Q.<?php echo number_format((float)($row->total_value_45_plus ?? 0), 2); ?>
                                <div class="bucket-count"><?php echo (int)($row->count_45_plus ?? 0); ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                            </td>
                            <td class="dias-credito-total-col">
                                Q.<?php echo number_format((float)($row->total_value ?? 0), 2); ?>
                                <div class="bucket-count"><?php echo (int)($row->order_count ?? 0); ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr class="dias-credito-detail-row" style="display: none;"><td colspan="6" class="text-muted"><?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_EMPTY'); ?></td></tr>
                    <?php endif; ?>
                    <?php endif; ?>
                </tbody>
                <?php if ($hasAny) : ?>
                <tfoot>
                    <tr class="dias-credito-grand-total-row">
                        <td class="dias-credito-grand-total-label"><?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_GRAND_TOTAL'); ?></td>
                        <td>
                            Q.<?php echo number_format((float)$b0['total_value'], 2); ?>
                            <div class="bucket-count"><?php echo (int)$b0['count']; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                        </td>
                        <td>
                            Q.<?php echo number_format((float)$b1['total_value'], 2); ?>
                            <div class="bucket-count"><?php echo (int)$b1['count']; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                        </td>
                        <td>
                            Q.<?php echo number_format((float)$b2['total_value'], 2); ?>
                            <div class="bucket-count"><?php echo (int)$b2['count']; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                        </td>
                        <td>
                            Q.<?php echo number_format((float)$b3['total_value'], 2); ?>
                            <div class="bucket-count"><?php echo (int)$b3['count']; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                        </td>
                        <td class="dias-credito-total-col">
                            Q.<?php echo number_format($totalValue, 2); ?>
                            <div class="bucket-count"><?php echo $totalCount; ?> <?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_ORDERS'); ?></div>
                        </td>
                    </tr>
                </tfoot>
                <?php endif; ?>
            </table>
        </div>
        <?php if (!$hasAny) : ?>
            <p class="text-muted mt-2"><?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_DIAS_CREDITO_EMPTY'); ?></p>
        <?php endif; ?>
        <script>
        (function() {
            if (document.querySelectorAll('.dias-credito-agent-toggle').length) {
                document.querySelectorAll('.dias-credito-agent-toggle').forEach(function(btn) {
                    var idx = btn.getAttribute('data-agent-idx');
                    var icon = btn.querySelector('i');
                    if (!idx || !icon) return;
                    btn.addEventListener('click', function() {
                        var isExpanded = btn.getAttribute('aria-expanded') === 'true';
                        isExpanded = !isExpanded;
                        btn.setAttribute('aria-expanded', isExpanded ? 'true' : 'false');
                        icon.className = isExpanded ? 'fas fa-minus' : 'fas fa-plus';
                        document.querySelectorAll('.dias-credito-detail-row[data-agent-idx="' + idx + '"]').forEach(function(tr) {
                            tr.style.display = isExpanded ? '' : 'none';
                        });
                    });
                });
            } else {
                var legacyBtn = document.getElementById('dias-credito-toggle-by-client');
                var legacyIcon = document.getElementById('dias-credito-toggle-icon');
                var detailRows = document.querySelectorAll('.dias-credito-detail-row');
                if (legacyBtn && legacyIcon) {
                    legacyBtn.addEventListener('click', function() {
                        var isExpanded = legacyBtn.getAttribute('aria-expanded') === 'true';
                        isExpanded = !isExpanded;
                        legacyBtn.setAttribute('aria-expanded', isExpanded ? 'true' : 'false');
                        legacyIcon.className = isExpanded ? 'fas fa-minus' : 'fas fa-plus';
                        detailRows.forEach(function(tr) { tr.style.display = isExpanded ? '' : 'none'; });
                    });
                }
            }
        })();
        </script>
    <?php endif; ?>
</div>

<?php if ($canMerge && !empty($clients)) : ?>
<!-- Merge modal -->
<div class="modal fade" id="mergeModal" tabindex="-1" role="dialog" aria-labelledby="mergeModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="mergeModalLabel"><?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_MERGE_MODAL_TITLE'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="text-muted"><?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_MERGE_CHOOSE_TARGET'); ?></p>
                <div id="merge-target-list"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo Text::_('JCANCEL'); ?></button>
                <button type="button" class="btn btn-primary" id="merge-confirm-btn" disabled><?php echo Text::_('COM_ORDENPRODUCCION_CLIENTES_MERGE_CONFIRM'); ?></button>
            </div>
        </div>
    </div>
</div>

<script>
(function() {
    var selectAll = document.getElementById('select-all-clients');
    var checkboxes = document.querySelectorAll('.client-merge-cb');
    var mergeBtn = document.getElementById('btn-merge-clients');
    var form = document.getElementById('clientes-merge-form');
    var formFields = document.getElementById('merge-form-fields');
    var mergeModal = document.getElementById('mergeModal');
    var mergeTargetList = document.getElementById('merge-target-list');
    var mergeConfirmBtn = document.getElementById('merge-confirm-btn');
    var selectedTarget = null;

    function updateMergeBtn() {
        var checked = document.querySelectorAll('.client-merge-cb:checked');
        mergeBtn.disabled = checked.length < 2;
    }

    if (selectAll) {
        selectAll.addEventListener('change', function() {
            checkboxes.forEach(function(cb) { cb.checked = selectAll.checked; });
            updateMergeBtn();
        });
    }

    checkboxes.forEach(function(cb) {
        cb.addEventListener('change', function() {
            updateMergeBtn();
        });
    });

    if (mergeBtn) {
        mergeBtn.addEventListener('click', function() {
            var checked = document.querySelectorAll('.client-merge-cb:checked');
            if (checked.length < 2) return;
            mergeTargetList.innerHTML = '';
            selectedTarget = null;
            var selected = [];
            checked.forEach(function(cb) {
                selected.push({
                    name: cb.getAttribute('data-client-name') || '',
                    nit: cb.getAttribute('data-nit') || ''
                });
            });
            selected.forEach(function(s, i) {
                var div = document.createElement('div');
                div.className = 'merge-target-option';
                div.dataset.name = s.name;
                div.dataset.nit = s.nit;
                div.innerHTML = '<strong>' + (s.name || '—') + '</strong>' + (s.nit ? ' <span class="text-muted">(' + s.nit + ')</span>' : '');
                div.addEventListener('click', function() {
                    document.querySelectorAll('#merge-target-list .merge-target-option').forEach(function(o) { o.classList.remove('selected'); });
                    div.classList.add('selected');
                    selectedTarget = { name: div.dataset.name, nit: div.dataset.nit || '' };
                    mergeConfirmBtn.disabled = false;
                });
                mergeTargetList.appendChild(div);
            });
            mergeConfirmBtn.disabled = true;
            var bsModal = typeof bootstrap !== 'undefined' ? new bootstrap.Modal(mergeModal) : null;
            if (bsModal) bsModal.show(); else if (typeof jQuery !== 'undefined') jQuery(mergeModal).modal('show');
        });
    }

    if (mergeConfirmBtn && form && formFields) {
        mergeConfirmBtn.addEventListener('click', function() {
            if (!selectedTarget || !selectedTarget.name) return;
            mergeConfirmBtn.disabled = true;
            mergeConfirmBtn.textContent = '<?php echo addslashes(Text::_('JPROCESSING')); ?>';
            var checked = document.querySelectorAll('.client-merge-cb:checked');
            formFields.innerHTML = '';
            var idx = 0;
            checked.forEach(function(cb) {
                var name = cb.getAttribute('data-client-name') || '';
                var nit = cb.getAttribute('data-nit') || '';
                var in1 = document.createElement('input');
                in1.type = 'hidden';
                in1.name = 'merge_sources[' + idx + '][client_name]';
                in1.value = name;
                formFields.appendChild(in1);
                var in2 = document.createElement('input');
                in2.type = 'hidden';
                in2.name = 'merge_sources[' + idx + '][nit]';
                in2.value = nit;
                formFields.appendChild(in2);
                idx++;
            });
            var t1 = document.createElement('input');
            t1.type = 'hidden';
            t1.name = 'merge_target_name';
            t1.value = selectedTarget.name;
            formFields.appendChild(t1);
            var t2 = document.createElement('input');
            t2.type = 'hidden';
            t2.name = 'merge_target_nit';
            t2.value = selectedTarget.nit;
            formFields.appendChild(t2);
            form.submit();
        });
    }
})();
</script>
<?php endif; ?>
